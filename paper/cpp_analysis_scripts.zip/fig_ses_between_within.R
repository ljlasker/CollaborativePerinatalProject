#!/usr/bin/env Rscript
# fig_ses_between_within.R — Between-family vs within-family SES-IQ gradients
# Shows the massive gap: large between-family gradients, near-zero within-family

library(data.table)
library(fixest)

d <- readRDS("prepared_data.rds")

sib <- d[!is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
sib[, n_sibs := .N, by = mother_id]
sib_fam <- sib[n_sibs >= 2]

# ---- Compute between-family and FE coefficients, scaled by WF-SD ----
ses_vars   <- c("income", "sei_decimal", "housing_density")
ses_labels <- c("Family\nIncome", "Occupational\nStatus (SEI)", "Housing\nDensity")

results <- list()
for (i in seq_along(ses_vars)) {
  v <- ses_vars[i]
  sub <- sib_fam[!is.na(get(v)) & !is.na(wisc_fsiq)]

  # Within-family SD
  sub[, fam_mean := mean(get(v)), by = mother_id]
  sub[, ses_dev := get(v) - fam_mean]
  wf_sd <- sd(sub$ses_dev)

  # Between: Mundlak family-mean coefficient
  m_mund <- feols(wisc_fsiq ~ ses_dev + fam_mean + factor(sex) + birth_order,
                  data = sub, vcov = "hetero")
  b_between <- coef(m_mund)["fam_mean"]
  se_between <- se(m_mund)["fam_mean"]

  # Within: Mother FE
  f_fe <- as.formula(paste("wisc_fsiq ~", v, "+ factor(sex) + birth_order | mother_id"))
  m_fe <- feols(f_fe, data = sub, vcov = ~mother_id)
  b_within <- coef(m_fe)[v]
  se_within <- se(m_fe)[v]

  # Scale by WF-SD: IQ points per 1 within-family SD of SES change
  results[[i]] <- data.frame(
    indicator = ses_labels[i],
    bw_scaled = b_between * wf_sd,
    bw_se_scaled = se_between * wf_sd,
    wf_scaled = b_within * wf_sd,
    wf_se_scaled = se_within * wf_sd,
    wf_sd = wf_sd
  )
}

res <- do.call(rbind, results)
# Flip housing density sign so all are "higher SES → higher IQ"
res$bw_scaled[3] <- -res$bw_scaled[3]
res$wf_scaled[3] <- -res$wf_scaled[3]
res$indicator[3] <- "Housing\nDensity\n(reversed)"

# ---- Plot ----
pdf("fig_ses_between_within.pdf", width = 7, height = 5)
par(mar = c(5, 6.5, 2, 3), family = "serif")

n <- nrow(res)
x <- 1:n
w <- 0.3  # bar half-width

col_bw <- "#2C3E50"
col_wf <- "#8B1A1A"

ylim_max <- max(res$bw_scaled + res$bw_se_scaled * 1.96) * 1.25
ylim <- c(-0.5, ylim_max)

plot(NULL, xlim = c(0.3, n + 0.7), ylim = ylim,
     xaxt = "n", yaxt = "n", xlab = "", ylab = "",
     bty = "n")

# Horizontal gridlines
grid_y <- seq(0, ceiling(ylim_max), by = 0.5)
for (gy in grid_y) {
  segments(0.3, gy, n + 0.7, gy, col = "grey85", lwd = 0.5)
}

# Zero line
abline(h = 0, col = "grey40", lwd = 1)

# Between-family bars
rect(x - w, 0, x - 0.02, res$bw_scaled, col = col_bw, border = NA)

# Within-family bars
rect(x + 0.02, 0, x + w, res$wf_scaled, col = col_wf, border = NA)

# Error bars for within-family (FE)
for (i in 1:n) {
  xpos <- x[i] + w/2 + 0.02
  lo <- res$wf_scaled[i] - 1.96 * res$wf_se_scaled[i]
  hi <- res$wf_scaled[i] + 1.96 * res$wf_se_scaled[i]
  segments(xpos, lo, xpos, hi, col = col_wf, lwd = 1.5)
  segments(xpos - 0.05, lo, xpos + 0.05, lo, col = col_wf, lwd = 1.5)
  segments(xpos - 0.05, hi, xpos + 0.05, hi, col = col_wf, lwd = 1.5)
}

# Value labels above between-family bars
for (i in 1:n) {
  text(x[i] - w/2 - 0.02, res$bw_scaled[i] + 0.25, sprintf("%.1f", res$bw_scaled[i]),
       cex = 0.85, font = 2, col = col_bw)
}

# Value labels for within-family — place below the lower CI bound
for (i in 1:n) {
  ci_lo <- res$wf_scaled[i] - 1.96 * res$wf_se_scaled[i]
  ypos <- min(ci_lo, 0) - 0.2
  text(x[i] + w/2 + 0.02, ypos, sprintf("%.1f", res$wf_scaled[i]),
       cex = 0.85, font = 2, col = col_wf, adj = 0.5)
}

# X axis
axis(1, at = x, labels = res$indicator, tick = FALSE, las = 1, cex.axis = 0.9, line = -0.5)

# Y axis
axis(2, at = grid_y, labels = sprintf("%.1f", grid_y), las = 1, cex.axis = 0.85)
mtext("IQ points per 1 within-family SD of SES", side = 2, line = 3.5, cex = 0.95)

# Legend
legend("topright", legend = c("Between families", "Within family (Mother FE)"),
       fill = c(col_bw, col_wf), border = NA, bty = "o", bg = "white",
       box.col = "gray80", cex = 0.9)

dev.off()
cat("Wrote fig_ses_between_within.pdf\n")
