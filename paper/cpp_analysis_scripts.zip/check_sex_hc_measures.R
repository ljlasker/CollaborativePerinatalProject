library(data.table)
library(fixest)

d <- as.data.table(readRDS("prepared_data.rds"))
growth <- as.data.table(readRDS("prepared_growth.rds"))

# Merge anthropometrics at age 7
for (meas in c("head_circ_cm", "height_cm", "weight_g")) {
  g7 <- growth[measure == meas & age_months == 84,
               .(case_id = as.character(case_id), value)]
  short <- gsub("_cm$|_g$", "", meas)
  setnames(g7, "value", paste0(short, "_7yr"))
  d <- merge(d, g7, by = "case_id", all.x = TRUE)
}
d[, weight_7yr := weight_7yr / 1000]

hc <- d[race %in% c(1, 2) & !is.na(head_circ_7yr)]

# IQ measures
measures <- c("wisc_fsiq", "wisc_viq", "wisc_piq", "sb_iq", "g_factor")
labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (age 4)", "PCA g")

cat("=== Sex Gap in HC Controlling for Different IQ Measures ===\n\n")
cat(sprintf("%-15s  %8s  %8s  %8s  %8s\n", "IQ Measure", "Raw_gap", "IQ_ctrl", "Full_ctrl", "N"))
cat(paste(rep("-", 60), collapse=""), "\n")

for (i in seq_along(measures)) {
  m <- measures[i]
  lab <- labels[i]
  sub <- hc[!is.na(get(m))]

  # Raw
  m1 <- feols(head_circ_7yr ~ factor(sex), data = sub, vcov = "hetero")
  raw <- coef(m1)["factor(sex)2"]

  # IQ controlled
  f2 <- as.formula(paste("head_circ_7yr ~ factor(sex) +", m))
  m2 <- feols(f2, data = sub, vcov = "hetero")
  iq_ctrl <- coef(m2)["factor(sex)2"]

  # Full: IQ + race + height + weight
  sub_full <- sub[!is.na(height_7yr) & !is.na(weight_7yr)]
  f3 <- as.formula(paste("head_circ_7yr ~ factor(sex) +", m, "+ factor(race) + height_7yr + weight_7yr"))
  m3 <- feols(f3, data = sub_full, vcov = "hetero")
  full_ctrl <- coef(m3)["factor(sex)2"]
  p3 <- 2 * pnorm(-abs(coef(m3)["factor(sex)2"] / se(m3)["factor(sex)2"]))

  cat(sprintf("%-15s  %8.3f  %8.3f  %8.3f  %8d  p=%s\n",
              lab, raw, iq_ctrl, full_ctrl, nrow(sub_full),
              ifelse(p3 < 1e-16, "<1e-16", sprintf("%.1e", p3))))
}

# Within-family for each measure
cat("\n=== Within-Family (Mother FE, mixed-sex sibships) ===\n\n")
hc[, n_sibs := .N, by = mother_id]
hc_sib <- hc[n_sibs >= 2]
hc_sib[, n_male := sum(sex == 1), by = mother_id]
hc_sib[, n_female := sum(sex == 2), by = mother_id]
hc_mixed <- hc_sib[n_male >= 1 & n_female >= 1]

cat(sprintf("%-15s  %8s  %8s  %8s  %8s\n", "IQ Measure", "FE|IQ", "SE", "p", "N_fam"))
cat(paste(rep("-", 55), collapse=""), "\n")

for (i in seq_along(measures)) {
  m <- measures[i]
  lab <- labels[i]
  sub <- hc_mixed[!is.na(get(m))]

  f <- as.formula(paste("head_circ_7yr ~ factor(sex) +", m, "| mother_id"))
  fit <- tryCatch(feols(f, data = sub, vcov = ~mother_id), error = function(e) NULL)

  if (!is.null(fit)) {
    b <- coef(fit)["factor(sex)2"]
    s <- se(fit)["factor(sex)2"]
    p <- 2 * pnorm(-abs(b/s))
    cat(sprintf("%-15s  %8.3f  %8.3f  %8s  %8d\n",
                lab, b, s,
                ifelse(p < 1e-16, "<1e-16", sprintf("%.1e", p)),
                uniqueN(sub$mother_id)))
  }
}
