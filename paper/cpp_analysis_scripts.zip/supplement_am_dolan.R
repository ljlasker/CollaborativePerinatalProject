#!/usr/bin/env Rscript
# supplement_am_dolan.R — AM sensitivity for Dolan between-group decomposition
# Tests spousal correlation levels (mu = 0, 0.20, 0.35, 0.55).
#
# For each mu:
#   1. Fit free-means ACE IP model with AM-corrected R values
#   2. Validate parameters (convergence, Heywood cases, PD check)
#   3. Post-hoc OLS Shapley decomposition (common + total 4-way)
#   4. Fit structural Dolan: M2 (kA+kC), M3 (kA only), M4 (kC only)
#   5. LRTs for significance of each channel
#   6. Tucker congruence of a_c, c_c with phenotypic g-loadings

library(data.table)
library(OpenMx)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

# ---- DATA PREPARATION (from 02e_between_group_expanded.R) ----
d <- readRDS("prepared_data.rds")
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}
links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "Digit",
                "PicArr", "Block", "Coding",
                "WRAT Read", "Bender",
                "WRAT Spell", "WRAT Arith", "Goodenough")
nv <- length(sub_vars)

# Standardize to z-scores (pooled across races)
d_z <- copy(d)
z_means <- z_sds <- setNames(numeric(nv), sub_vars)
for (v in sub_vars) {
  vals <- d_z[[v]]
  m <- mean(vals, na.rm = TRUE)
  s <- sd(vals, na.rm = TRUE)
  z_means[v] <- m; z_sds[v] <- s
  d_z[, (v) := (get(v) - m) / s]
}

# Build pair-level data
d_sub <- d_z[, c("case_id", "race", sub_vars), with = FALSE]
pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
setnames(pair, "race", "race_1")
new_names1 <- paste0(sub_vars, "_1")
setnames(pair, sub_vars, new_names1)
pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
setnames(pair, "race", "race_2")
new_names2 <- paste0(sub_vars, "_2")
setnames(pair, sub_vars, new_names2)

pair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair <- pair[!is.na(pair_class)]
pair <- pair[race_1 == race_2 & race_1 %in% c(1, 2)]
pair[, race := ifelse(race_1 == 1, "White", "Black")]
has1 <- rowSums(!is.na(pair[, ..new_names1])) > 0
has2 <- rowSums(!is.na(pair[, ..new_names2])) > 0
pair <- pair[has1 & has2]

var_names <- c(new_names1, new_names2)

ct <- pair[, .N, by = .(race, pair_class)]
ct <- dcast(ct, race ~ pair_class, value.var = "N", fill = 0)
cat("Pair counts:\n"); print(ct)

# Observed gaps (from pair data, z-score units)
obs_gaps <- numeric(nv)
names(obs_gaps) <- sub_labels
for (i in seq_along(sub_vars)) {
  v1 <- pair[[new_names1[i]]]; v2 <- pair[[new_names2[i]]]
  vals_w <- c(v1[pair$race == "White"], v2[pair$race == "White"])
  vals_b <- c(v1[pair$race == "Black"], v2[pair$race == "Black"])
  obs_gaps[i] <- mean(vals_w, na.rm = TRUE) - mean(vals_b, na.rm = TRUE)
}

# Split into 8 groups
mkdata <- function(rv, pc) {
  as.data.frame(pair[race == rv & pair_class == pc, ..var_names])
}
w_mz <- mkdata("White", "MZ"); w_dz <- mkdata("White", "DZ")
w_fs <- mkdata("White", "FS"); w_hs <- mkdata("White", "HS")
b_mz <- mkdata("Black", "MZ"); b_dz <- mkdata("Black", "DZ")
b_fs <- mkdata("Black", "FS"); b_hs <- mkdata("Black", "HS")

total_n <- nrow(w_mz) + nrow(w_dz) + nrow(w_fs) + nrow(w_hs) +
           nrow(b_mz) + nrow(b_dz) + nrow(b_fs) + nrow(b_hs)

cat(sprintf("\nTotal pairs: %d\n", total_n))
cat(sprintf("White: MZ=%d DZ=%d FS=%d HS=%d\n",
            nrow(w_mz), nrow(w_dz), nrow(w_fs), nrow(w_hs)))
cat(sprintf("Black: MZ=%d DZ=%d FS=%d HS=%d\n",
            nrow(b_mz), nrow(b_dz), nrow(b_fs), nrow(b_hs)))

# PCA g-loadings for collinearity check
g_model <- readRDS("g_factor_model.rds")
g_load <- as.numeric(g_model$loadings)

# ---- HELPER FUNCTIONS ----

make_sub <- function(p, sub_name, data, R_coeff, use_white) {
  mu_ref <- if (use_white) paste0(p, ".MuW") else paste0(p, ".MuB")
  b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C")
  mxModel(sub_name, mxData(data, "raw"),
    mxAlgebraFromString(b_str, name = "B"),
    mxAlgebraFromString(
      paste0("rbind(cbind(", p, ".V, B), cbind(B, ", p, ".V))"),
      name = "expCov"),
    mxAlgebraFromString(
      paste0("cbind(", mu_ref, ", ", mu_ref, ")"),
      name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = var_names),
    mxFitFunctionML())
}

eight_subs <- function(p, R_dz, R_fs, R_hs) {
  list(
    make_sub(p, "W_MZ", w_mz, 1,    TRUE),
    make_sub(p, "W_DZ", w_dz, R_dz, TRUE),
    make_sub(p, "W_FS", w_fs, R_fs, TRUE),
    make_sub(p, "W_HS", w_hs, R_hs, TRUE),
    make_sub(p, "B_MZ", b_mz, 1,    FALSE),
    make_sub(p, "B_DZ", b_dz, R_dz, FALSE),
    make_sub(p, "B_FS", b_fs, R_fs, FALSE),
    make_sub(p, "B_HS", b_hs, R_hs, FALSE),
    mxFitFunctionMultigroup(c("W_MZ","W_DZ","W_FS","W_HS",
                              "B_MZ","B_DZ","B_FS","B_HS"))
  )
}

ip_core <- function() {
  list(
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.5, nv),
             lbound = -5, name = "ac"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
             lbound = 0.001, name = "as"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.3, nv),
             lbound = -5, name = "cc"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.3, nv),
             lbound = 0.001, name = "cs"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.4, nv),
             lbound = -5, name = "ec"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
             lbound = 0.001, name = "es"),
    mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
    mxAlgebra(A + C + E, name = "V"),
    mxMatrix("Full", 1, nv, free = TRUE, values = rep(-0.2, nv),
             name = "MuB")
  )
}

# Free-means IP
fit_ip_free <- function(label, R_dz, R_fs, R_hs) {
  parts <- c(
    ip_core(),
    list(mxMatrix("Full", 1, nv, free = TRUE, values = rep(0.2, nv),
                  name = "MuW")),
    eight_subs(label, R_dz, R_fs, R_hs)
  )
  mod <- do.call(mxModel, c(list(label), parts))
  mxTryHard(mod, extraTries = 30, silent = TRUE)
}

# Structural Dolan: MuW = MuB + ac'*kA + cc'*kC
fit_dolan <- function(label, R_dz, R_fs, R_hs,
                      kA_free = TRUE, kC_free = TRUE,
                      kA_val = 0.5, kC_val = 0.5) {
  parts <- c(
    ip_core(),
    list(
      mxMatrix("Full", 1, 1, free = kA_free, values = kA_val, name = "kA"),
      mxMatrix("Full", 1, 1, free = kC_free, values = kC_val, name = "kC"),
      mxAlgebra(MuB + t(ac) * kA + t(cc) * kC, name = "MuW")
    ),
    eight_subs(label, R_dz, R_fs, R_hs)
  )
  mod <- do.call(mxModel, c(list(label), parts))
  mxTryHard(mod, extraTries = 30, silent = TRUE)
}

# Parameter validation
validate_params <- function(fit, label) {
  cat(sprintf("\n  --- Validation: %s ---\n", label))
  issues <- 0

  status <- fit$output$status$code
  cat(sprintf("    Convergence: status = %d %s\n", status,
              ifelse(status == 0, "(GREEN)", ifelse(status <= 1, "(YELLOW)", "(RED)"))))
  if (status > 1) issues <- issues + 1

  ac <- fit$ac$values[,1]
  cc <- fit$cc$values[,1]
  ec <- fit$ec$values[,1]
  as_d <- diag(fit$as$values)
  cs_d <- diag(fit$cs$values)
  es_d <- diag(fit$es$values)

  # Check variance decomposition per indicator
  heywood <- 0
  for (i in 1:nv) {
    a_var <- ac[i]^2 + as_d[i]^2
    c_var <- cc[i]^2 + cs_d[i]^2
    e_var <- ec[i]^2 + es_d[i]^2
    total <- a_var + c_var + e_var
    h2 <- a_var / total
    c2 <- c_var / total
    e2 <- e_var / total
    if (h2 > 0.99 || c2 > 0.99 || e2 < 0.005) {
      cat(sprintf("    HEYWOOD: %s h2=%.3f c2=%.3f e2=%.3f\n",
                  sub_labels[i], h2, c2, e2))
      heywood <- heywood + 1
    }
  }
  if (heywood == 0) cat("    Variance decomposition: all indicators OK (no Heywood cases)\n")
  issues <- issues + heywood

  # Check specific variances at boundary
  at_bound <- sum(as_d < 0.002) + sum(cs_d < 0.002) + sum(es_d < 0.002)
  if (at_bound > 0) {
    cat(sprintf("    Boundary: %d specific variance(s) at lower bound (0.001)\n", at_bound))
    # Show which ones
    for (i in 1:nv) {
      if (as_d[i] < 0.002) cat(sprintf("      as[%s] = %.4f\n", sub_labels[i], as_d[i]))
      if (cs_d[i] < 0.002) cat(sprintf("      cs[%s] = %.4f\n", sub_labels[i], cs_d[i]))
      if (es_d[i] < 0.002) cat(sprintf("      es[%s] = %.4f\n", sub_labels[i], es_d[i]))
    }
  } else {
    cat("    Specific variances: all above boundary\n")
  }

  # Check implied covariance matrix is positive definite
  V <- mxEval(V, fit)
  eig <- eigen(V, symmetric = TRUE, only.values = TRUE)$values
  if (any(eig <= 0)) {
    cat(sprintf("    WARNING: Implied cov matrix has %d non-positive eigenvalue(s)!\n",
                sum(eig <= 0)))
    issues <- issues + 1
  } else {
    cat(sprintf("    Implied cov matrix: PD (min eigenvalue = %.4f)\n", min(eig)))
  }

  # Loading magnitude check
  max_load <- max(abs(c(ac, cc, ec)))
  if (max_load > 20) {
    cat(sprintf("    WARNING: Extreme loading magnitude: max |loading| = %.2f\n", max_load))
    issues <- issues + 1
  }

  cat(sprintf("    VERDICT: %s (%d issue%s)\n",
              ifelse(issues == 0, "VALID", "CHECK CAREFULLY"),
              issues, ifelse(issues == 1, "", "s")))
  invisible(issues)
}

# Tucker congruence
tucker <- function(a, b) sum(a * b) / sqrt(sum(a^2) * sum(b^2))

# Post-hoc OLS Shapley (common-variance, 2 predictors)
shapley_2way <- function(ac, cc, delta) {
  X <- cbind(ac, cc)
  kappa <- tryCatch(solve(t(X) %*% X, t(X) %*% delta), error = function(e) NULL)
  if (is.null(kappa)) return(list(kA = NA, kC = NA, R2 = NA,
                                   shapley_A = NA, shapley_C = NA))
  fitted <- X %*% kappa
  ss_total <- sum(delta^2)
  R2 <- 1 - sum((delta - fitted)^2) / ss_total

  kA_only <- (sum(ac * delta) / sum(ac^2))
  R2_A <- 1 - sum((delta - kA_only * ac)^2) / ss_total
  kC_only <- (sum(cc * delta) / sum(cc^2))
  R2_C <- 1 - sum((delta - kC_only * cc)^2) / ss_total

  uA <- R2 - R2_C; uC <- R2 - R2_A; sh <- R2 - uA - uC
  shA <- (uA + sh/2) / R2; shC <- (uC + sh/2) / R2

  list(kA = kappa[1], kC = kappa[2], R2 = R2,
       shapley_A = shA, shapley_C = shC,
       R2_A_only = R2_A, R2_C_only = R2_C)
}

# 4-way Shapley (ac, cc, as_diag, cs_diag)
shapley_4way <- function(ac, cc, as_vec, cs_vec, delta) {
  X4 <- cbind(ac = ac, cc = cc, as_d = as_vec, cs_d = cs_vec)
  ss_total <- sum(delta^2)

  # All 2^4 - 1 = 15 subsets
  subsets <- list()
  all_R2 <- numeric(15)
  idx <- 1
  for (k in 1:4) {
    combos <- combn(4, k, simplify = FALSE)
    for (s in combos) {
      Xs <- X4[, s, drop = FALSE]
      kap <- tryCatch(solve(t(Xs) %*% Xs, t(Xs) %*% delta), error = function(e) NULL)
      if (!is.null(kap)) {
        all_R2[idx] <- 1 - sum((delta - Xs %*% kap)^2) / ss_total
      }
      subsets[[idx]] <- s
      idx <- idx + 1
    }
  }

  # Compute Shapley values
  shapley_vals <- numeric(4)
  for (j in 1:4) {
    sv <- 0
    for (idx in seq_along(subsets)) {
      s <- subsets[[idx]]
      if (j %in% s) {
        sw <- setdiff(s, j)
        if (length(sw) == 0) {
          marginal <- all_R2[idx]
        } else {
          for (idx2 in seq_along(subsets)) {
            if (setequal(subsets[[idx2]], sw)) {
              marginal <- all_R2[idx] - all_R2[idx2]
              break
            }
          }
        }
        wt <- factorial(length(sw)) * factorial(4 - length(sw) - 1) / factorial(4)
        sv <- sv + wt * marginal
      }
    }
    shapley_vals[j] <- sv
  }
  names(shapley_vals) <- c("ac", "cc", "as", "cs")
  R2_full <- all_R2[15]
  pct <- shapley_vals / R2_full

  list(R2 = R2_full, shapley = shapley_vals, pct = pct,
       total_genetic = unname(pct["ac"] + pct["as"]),
       total_environmental = unname(pct["cc"] + pct["cs"]))
}


# ---- MAIN ANALYSIS LOOP ----

h2 <- 0.71  # within-group heritability for AM correction
mu_vals <- c(0, 0.20, 0.35, 0.55)

results_all <- list()

for (mu in mu_vals) {
  cat(sprintf("  ASSORTATIVE MATING SENSITIVITY: mu = %.2f (h2 = %.2f)\n", mu, h2))

  # AM-corrected genetic relatedness (first-generation approximation)
  R_dz <- 0.5 + mu * h2 / 2
  R_fs <- R_dz
  R_hs <- 0.25 + mu * h2 / 4

  cat(sprintf("  R_DZ = R_FS = %.4f, R_HS = %.4f\n", R_dz, R_hs))

  # ────────────────────────────────────────────────────────────────────
  # 1. Free-means ACE IP model
  # ────────────────────────────────────────────────────────────────────
  lab <- paste0("FM", gsub("\\.", "", sprintf("%.2f", mu)))
  cat(sprintf("\n  [1] Fitting free-means IP (%s)...\n", lab))
  fit_fm <- fit_ip_free(lab, R_dz, R_fs, R_hs)
  s_fm <- summary(fit_fm)
  cat(sprintf("      -2LL = %.1f, k = %d, status = %d\n",
              s_fm$Minus2LogLikelihood, s_fm$estimatedParameters,
              fit_fm$output$status$code))

  # Validate
  validate_params(fit_fm, lab)

  # Extract loadings
  ac <- fit_fm$ac$values[,1]
  cc <- fit_fm$cc$values[,1]
  ec <- fit_fm$ec$values[,1]
  as_d <- diag(fit_fm$as$values)
  cs_d <- diag(fit_fm$cs$values)
  es_d <- diag(fit_fm$es$values)

  # Loading table
  cat(sprintf("\n  %-12s  %8s  %8s  %8s  %6s  %6s  %6s\n",
              "Subtest", "a_c", "c_c", "e_c", "h2", "c2", "e2"))
  cat("  ", strrep("-", 62), "\n")
  for (i in 1:nv) {
    a_var <- ac[i]^2 + as_d[i]^2
    c_var <- cc[i]^2 + cs_d[i]^2
    e_var <- ec[i]^2 + es_d[i]^2
    total <- a_var + c_var + e_var
    cat(sprintf("  %-12s  %8.3f  %8.3f  %8.3f  %6.3f  %6.3f  %6.3f\n",
                sub_labels[i], ac[i], cc[i], ec[i],
                a_var/total, c_var/total, e_var/total))
  }

  # Collinearity with g
  phi_ac <- tucker(g_load, ac)
  phi_cc <- tucker(g_load, cc)
  r_ac <- cor(g_load, ac)
  r_cc <- cor(g_load, cc)
  cos_ac_cc <- sum(ac * cc) / (sqrt(sum(ac^2)) * sqrt(sum(cc^2)))
  angle_deg <- acos(min(abs(cos_ac_cc), 1)) * 180 / pi
  cond_num <- {
    sv <- svd(cbind(ac, cc))$d
    max(sv) / min(sv)
  }

  cat(sprintf("\n  Collinearity diagnostics:\n"))
  cat(sprintf("    Tucker phi(g, a_c) = %.3f, phi(g, c_c) = %.3f\n", phi_ac, phi_cc))
  cat(sprintf("    Pearson r(g, a_c)  = %.3f, r(g, c_c)  = %.3f\n", r_ac, r_cc))
  cat(sprintf("    Angle(a_c, c_c) = %.1f degrees\n", angle_deg))
  cat(sprintf("    Condition number = %.2f\n", cond_num))

  # ────────────────────────────────────────────────────────────────────
  # 2. Post-hoc OLS Shapley decomposition
  # ────────────────────────────────────────────────────────────────────
  muW_est <- mxEval(MuW, fit_fm)[1,]
  muB_est <- mxEval(MuB, fit_fm)[1,]
  delta <- muW_est - muB_est

  # 2-way (common only)
  sh2 <- shapley_2way(ac, cc, delta)
  cat(sprintf("\n  Post-hoc Shapley (common variance, 2-way):\n"))
  cat(sprintf("    kA = %.4f, kC = %.4f\n", sh2$kA, sh2$kC))
  cat(sprintf("    R2 = %.3f\n", sh2$R2))
  cat(sprintf("    Shapley: A = %.1f%%, C = %.1f%%\n",
              100 * sh2$shapley_A, 100 * sh2$shapley_C))

  # 4-way (common + specific)
  sh4 <- shapley_4way(ac, cc, as_d, cs_d, delta)
  cat(sprintf("\n  Post-hoc Shapley (total, 4-way):\n"))
  cat(sprintf("    R2 = %.3f\n", sh4$R2))
  cat(sprintf("    ac = %.1f%%, cc = %.1f%%, as = %.1f%%, cs = %.1f%%\n",
              100*sh4$pct["ac"], 100*sh4$pct["cc"],
              100*sh4$pct["as"], 100*sh4$pct["cs"]))
  cat(sprintf("    Total genetic = %.1f%%, Total environmental = %.1f%%\n",
              100*sh4$total_genetic, 100*sh4$total_environmental))

  # ────────────────────────────────────────────────────────────────────
  # 3. Structural Dolan decomposition: M2, M3, M4
  # ────────────────────────────────────────────────────────────────────
  lab_m2 <- paste0("D2_", gsub("\\.", "", sprintf("%.2f", mu)))
  lab_m3 <- paste0("D3_", gsub("\\.", "", sprintf("%.2f", mu)))
  lab_m4 <- paste0("D4_", gsub("\\.", "", sprintf("%.2f", mu)))

  cat(sprintf("\n  [3a] Fitting structural Dolan M2 (kA + kC)...\n"))
  m2 <- fit_dolan(lab_m2, R_dz, R_fs, R_hs, kA_free=TRUE, kC_free=TRUE)
  s_m2 <- summary(m2)
  cat(sprintf("      M2: -2LL = %.1f, k = %d, status = %d\n",
              s_m2$Minus2LogLikelihood, s_m2$estimatedParameters,
              m2$output$status$code))

  cat(sprintf("\n  [3b] Fitting M3 (genetic only, kC = 0)...\n"))
  m3 <- fit_dolan(lab_m3, R_dz, R_fs, R_hs,
                  kA_free=TRUE, kC_free=FALSE, kC_val=0)
  s_m3 <- summary(m3)
  cat(sprintf("      M3: -2LL = %.1f, k = %d, status = %d\n",
              s_m3$Minus2LogLikelihood, s_m3$estimatedParameters,
              m3$output$status$code))

  cat(sprintf("\n  [3c] Fitting M4 (environmental only, kA = 0)...\n"))
  m4 <- fit_dolan(lab_m4, R_dz, R_fs, R_hs,
                  kA_free=FALSE, kC_free=TRUE, kA_val=0)
  s_m4 <- summary(m4)
  cat(sprintf("      M4: -2LL = %.1f, k = %d, status = %d\n",
              s_m4$Minus2LogLikelihood, s_m4$estimatedParameters,
              m4$output$status$code))

  # LRTs
  chi2_dropC <- s_m3$Minus2LogLikelihood - s_m2$Minus2LogLikelihood
  df_dropC   <- s_m2$estimatedParameters - s_m3$estimatedParameters
  p_dropC    <- if (df_dropC > 0) pchisq(chi2_dropC, df_dropC, lower.tail=FALSE) else NA

  chi2_dropA <- s_m4$Minus2LogLikelihood - s_m2$Minus2LogLikelihood
  df_dropA   <- s_m2$estimatedParameters - s_m4$estimatedParameters
  p_dropA    <- if (df_dropA > 0) pchisq(chi2_dropA, df_dropA, lower.tail=FALSE) else NA

  # M2 vs M1 (free means): does decomposition fit as well?
  chi2_m2m1 <- s_m2$Minus2LogLikelihood - s_fm$Minus2LogLikelihood
  df_m2m1   <- s_fm$estimatedParameters - s_m2$estimatedParameters
  p_m2m1    <- if (df_m2m1 > 0) pchisq(chi2_m2m1, df_m2m1, lower.tail=FALSE) else NA

  cat(sprintf("\n  Structural Dolan results:\n"))
  if (m2$output$status$code <= 1) {
    kA_s <- m2$kA$values[1,1]
    kC_s <- m2$kC$values[1,1]
    cat(sprintf("    M2 structural: kA = %.4f, kC = %.4f\n", kA_s, kC_s))
  } else {
    kA_s <- NA; kC_s <- NA
    cat("    M2 did not converge cleanly.\n")
  }

  cat(sprintf("\n  Likelihood ratio tests:\n"))
  cat(sprintf("    M2 vs M1 (decomp fits?): chi2=%.2f, df=%d, p=%s\n",
              chi2_m2m1, df_m2m1,
              ifelse(is.na(p_m2m1), "NA", sprintf("%.4f", p_m2m1))))
  cat(sprintf("    M3 vs M2 (drop kC):      chi2=%.2f, df=%d, p=%s → C %s\n",
              chi2_dropC, df_dropC,
              ifelse(is.na(p_dropC), "NA", sprintf("%.6f", p_dropC)),
              ifelse(!is.na(p_dropC) && p_dropC < 0.05, "SIGNIFICANT", "n.s.")))
  cat(sprintf("    M4 vs M2 (drop kA):      chi2=%.2f, df=%d, p=%s → A %s\n",
              chi2_dropA, df_dropA,
              ifelse(is.na(p_dropA), "NA", sprintf("%.6f", p_dropA)),
              ifelse(!is.na(p_dropA) && p_dropA < 0.05, "SIGNIFICANT", "n.s.")))

  # Store all results
  results_all[[as.character(mu)]] <- list(
    mu = mu, h2 = h2, R_dz = R_dz, R_hs = R_hs,
    # Free-means model
    fit_status = fit_fm$output$status$code,
    ll_free = s_fm$Minus2LogLikelihood,
    ac = ac, cc = cc, ec = ec,
    as_d = as_d, cs_d = cs_d, es_d = es_d,
    # Collinearity
    tucker_ac = phi_ac, tucker_cc = phi_cc,
    r_ac = r_ac, r_cc = r_cc,
    angle_deg = angle_deg, cond_num = cond_num,
    # Post-hoc Shapley
    shapley_2way = sh2,
    shapley_4way = sh4,
    # Structural Dolan
    ll_m2 = s_m2$Minus2LogLikelihood,
    ll_m3 = s_m3$Minus2LogLikelihood,
    ll_m4 = s_m4$Minus2LogLikelihood,
    kA_structural = kA_s, kC_structural = kC_s,
    m2_status = m2$output$status$code,
    m3_status = m3$output$status$code,
    m4_status = m4$output$status$code,
    chi2_dropC = chi2_dropC, p_dropC = p_dropC,
    chi2_dropA = chi2_dropA, p_dropA = p_dropA,
    chi2_m2m1 = chi2_m2m1, p_m2m1 = p_m2m1,
    # Mean differences
    delta = delta
  )
}


# ---- SUMMARY TABLES ----
cat("--- SUMMARY TABLE 1: AM Sensitivity — Loadings & Collinearity ---\n")

cat(sprintf("\n%-6s  %6s  %6s  %8s  %8s  %7s  %6s\n",
            "mu", "R_DZ", "R_HS", "phi_ac", "phi_cc", "angle", "kappa"))
cat(strrep("-", 55), "\n")
for (mu in mu_vals) {
  r <- results_all[[as.character(mu)]]
  cat(sprintf("%-6.2f  %6.3f  %6.3f  %8.3f  %8.3f  %6.1f°  %6.2f\n",
              r$mu, r$R_dz, r$R_hs,
              r$tucker_ac, r$tucker_cc,
              r$angle_deg, r$cond_num))
}

cat("--- SUMMARY TABLE 2: AM Sensitivity — Shapley Decomposition ---\n")

cat(sprintf("\n%-6s  %5s  %8s  %8s  |  %5s  %8s  %8s\n",
            "mu", "R2_2", "Sh2_A%", "Sh2_C%", "R2_4", "Tot_A%", "Tot_C%"))
cat(strrep("-", 65), "\n")
for (mu in mu_vals) {
  r <- results_all[[as.character(mu)]]
  cat(sprintf("%-6.2f  %5.3f  %7.1f%%  %7.1f%%  |  %5.3f  %7.1f%%  %7.1f%%\n",
              r$mu,
              r$shapley_2way$R2,
              100 * r$shapley_2way$shapley_A,
              100 * r$shapley_2way$shapley_C,
              r$shapley_4way$R2,
              100 * r$shapley_4way$total_genetic,
              100 * r$shapley_4way$total_environmental))
}

cat("--- SUMMARY TABLE 3: AM Sensitivity — Structural Dolan LRTs ---\n")

cat(sprintf("\n%-6s  %8s  %8s  %10s  %10s  %6s  %6s\n",
            "mu", "kA_str", "kC_str",
            "chi2_dC", "chi2_dA", "p_dC", "p_dA"))
cat(strrep("-", 65), "\n")
for (mu in mu_vals) {
  r <- results_all[[as.character(mu)]]
  cat(sprintf("%-6.2f  %8.4f  %8.4f  %10.2f  %10.2f  %6.4f  %6.4f\n",
              r$mu,
              ifelse(is.na(r$kA_structural), NA, r$kA_structural),
              ifelse(is.na(r$kC_structural), NA, r$kC_structural),
              r$chi2_dropC, r$chi2_dropA,
              r$p_dropC, r$p_dropA))
}

cat("--- SUMMARY TABLE 4: Loading Profiles Across AM Levels ---\n")

cat(sprintf("\n%-12s", "Subtest"))
for (mu in mu_vals) cat(sprintf("  | a_c(%.2f) c_c(%.2f)", mu, mu))
cat("\n")
cat(strrep("-", 12 + length(mu_vals) * 22), "\n")
for (i in 1:nv) {
  cat(sprintf("%-12s", sub_labels[i]))
  for (mu in mu_vals) {
    r <- results_all[[as.character(mu)]]
    cat(sprintf("  | %7.3f  %7.3f", r$ac[i], r$cc[i]))
  }
  cat("\n")
}

# Save results
saveRDS(results_all, "results_am_sensitivity.rds")
cat("\n\nResults saved to results_am_sensitivity.rds\n")
cat("Done.\n")
