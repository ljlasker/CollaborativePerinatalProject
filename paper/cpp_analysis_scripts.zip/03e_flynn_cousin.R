#!/usr/bin/env Rscript
# Cousin-pair cohort/Flynn sensitivity with extended-family clustering.

library(data.table)
library(fixest)

cat("--- NCPP cousin-pair cohort/Flynn sensitivity ---\n")

d <- as.data.table(readRDS("prepared_data.rds"))
birth_text <- sprintf("%06d", as.integer(d$birth_date))
d[, `:=`(
  birth_month = suppressWarnings(as.integer(substr(birth_text, 1L, 2L))),
  birth_day = suppressWarnings(as.integer(substr(birth_text, 3L, 4L))),
  birth_short_year = suppressWarnings(as.integer(substr(birth_text, 5L, 6L)))
)]
d[, valid_birth_date := birth_month %between% c(1L, 12L) &
    birth_day %between% c(1L, 31L) & birth_short_year %between% c(50L, 79L)]
d[, cohort := fifelse(
  valid_birth_date,
  1900 + birth_short_year + (birth_month - 0.5) / 12 + (birth_day - 15.5) / 365.25,
  NA_real_
)]
d[!wisc_fsiq %between% c(40, 160), wisc_fsiq := NA_real_]
d[!sb_iq %between% c(40, 160), sb_iq := NA_real_]
d[, `:=`(
  wisc_cohort_z = as.numeric(scale(wisc_fsiq)),
  sb_cohort_z = as.numeric(scale(sb_iq)),
  male = fifelse(sex == 1L, 1, fifelse(sex == 2L, 0, NA_real_))
)]

links <- fread(
  "../clean/cpp_extended_kinship_links.csv",
  colClasses = list(character = c("id_1", "id_2", "pair_type"))
)[pair_type == "first_cousin"]
links[, `:=`(left = pmin(id_1, id_2), right = pmax(id_1, id_2))]
links <- unique(links[, .(id_1 = left, id_2 = right)])
if (any(links$id_1 == links$id_2)) stop("Self-pair in cousin links")

# Connected components define extended-family blocks for clustered inference.
vertices <- sort(unique(c(links$id_1, links$id_2)))
parent <- seq_along(vertices)
find_root <- function(i) {
  while (parent[[i]] != i) {
    parent[[i]] <<- parent[[parent[[i]]]]
    i <- parent[[i]]
  }
  i
}
for (i in seq_len(nrow(links))) {
  left <- find_root(match(links$id_1[[i]], vertices))
  right <- find_root(match(links$id_2[[i]], vertices))
  if (left != right) parent[[right]] <- left
}
links[, extended_family := vapply(
  match(id_1, vertices), find_root, integer(1L)
)]

values <- d[, .(
  case_id, cohort, male, maternal_age, birth_order, educ_yrs, sei_decimal,
  wisc_cohort_z, sb_cohort_z
)]
pair <- merge(links, values, by.x = "id_1", by.y = "case_id")
setnames(pair, setdiff(names(values), "case_id"),
         paste0(setdiff(names(values), "case_id"), "_1"))
pair <- merge(pair, values, by.x = "id_2", by.y = "case_id")
setnames(pair, setdiff(names(values), "case_id"),
         paste0(setdiff(names(values), "case_id"), "_2"))
pair[, `:=`(
  delta_cohort = cohort_2 - cohort_1,
  delta_male = male_2 - male_1,
  delta_maternal_age = maternal_age_2 - maternal_age_1,
  delta_rank = birth_order_2 - birth_order_1,
  delta_educ = educ_yrs_2 - educ_yrs_1,
  delta_sei = sei_decimal_2 - sei_decimal_1,
  delta_wisc = wisc_cohort_z_2 - wisc_cohort_z_1,
  delta_sb = sb_cohort_z_2 - sb_cohort_z_1
)]

tidy <- function(model, outcome, specification, pairs, families) {
  data.table(
    outcome = outcome,
    specification = specification,
    estimate_sd_decade = 10 * coef(model)[["delta_cohort"]],
    se_sd_decade = 10 * se(model)[["delta_cohort"]],
    p_value = pvalue(model)[["delta_cohort"]],
    pairs = pairs,
    extended_families = families
  )
}

fit_outcome <- function(delta_outcome, label) {
  fit_specification <- function(rhs, specification, family_equal = TRUE) {
    rhs_terms <- strsplit(rhs, " \\+ ")[[1L]]
    analytic <- pair[complete.cases(pair[, .SD, .SDcols = c(
      delta_outcome, rhs_terms, "extended_family"
    )])]
    formula <- as.formula(paste0(delta_outcome, " ~ 0 + ", rhs))
    if (family_equal) {
      analytic[, family_equal_weight := 1 / .N, by = extended_family]
      model <- feols(
        formula, analytic, weights = ~family_equal_weight,
        vcov = ~extended_family
      )
    } else {
      model <- feols(formula, analytic, vcov = ~extended_family)
    }
    tidy(
      model, label, specification, nrow(analytic),
      uniqueN(analytic$extended_family)
    )
  }

  rbindlist(list(
    fit_specification(
      "delta_cohort + delta_male + delta_rank",
      "All cousin pairs; clustered by extended family",
      family_equal = FALSE
    ),
    fit_specification(
      "delta_cohort + delta_male + delta_rank",
      "Equal total weight per extended family; clustered"
    ),
    fit_specification(
      paste(
        "delta_cohort + delta_male + delta_rank +",
        "delta_maternal_age"
      ),
      "Equal family weight + maternal age; clustered"
    ),
    fit_specification(
      paste(
        "delta_cohort + delta_male + delta_rank +",
        "delta_maternal_age + delta_educ + delta_sei"
      ),
      "Equal family weight + maternal age + education + SEI; clustered"
    )
  ))
}

results <- rbind(
  fit_outcome("delta_wisc", "WISC FSIQ"),
  fit_outcome("delta_sb", "Stanford-Binet IQ")
)
results[, `:=`(
  ci_low = estimate_sd_decade - 1.96 * se_sd_decade,
  ci_high = estimate_sd_decade + 1.96 * se_sd_decade
)]
fwrite(results, "results_flynn_cousin.csv")
saveRDS(list(results = results, pairs = pair), "results_flynn_cousin.rds")
print(results)
cat("Wrote results_flynn_cousin.csv and results_flynn_cousin.rds.\n")
