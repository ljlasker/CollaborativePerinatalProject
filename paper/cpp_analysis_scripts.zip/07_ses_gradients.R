#!/usr/bin/env Rscript
# 07_ses_gradients.R — SES-IQ gradients by race

library(data.table)
library(fixest)

cat("--- SES-IQ Gradients by Race ---\n")

d <- readRDS("prepared_data.rds")

# ---- 1. Descriptive ----
ses <- d[!is.na(wisc_fsiq) & race %in% c(1, 2)]
cat(sprintf("Children with WISC FSIQ (White/Black): %d\n", nrow(ses)))

# SES by race
for (rv in c(1, 2)) {
  rl <- ifelse(rv == 1, "White", "Black")
  sub <- ses[race == rv]
  cat(sprintf("  %s: n=%d, mean educ=%.1f, mean SEI=%.1f, mean FSIQ=%.1f\n",
              rl, nrow(sub),
              mean(sub$educ_yrs, na.rm=TRUE),
              mean(sub$sei_decimal, na.rm=TRUE),
              mean(sub$wisc_fsiq)))
}

# ---- 2. Education-IQ slopes by race ----
cat("\n--- Education-IQ Slopes ---\n\n")

outcomes <- c("wisc_fsiq", "wisc_viq", "wisc_piq", "sb_iq", "g_factor")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

cat(sprintf("%-12s  %10s  %10s  %10s\n",
            "Outcome", "White_b", "Black_b", "Interact_p"))
cat(paste(rep("-", 50), collapse=""), "\n")

ses_results <- list()
for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  sub <- ses[!is.na(get(y)) & !is.na(educ_yrs)]

  # Interaction model
  fit <- feols(as.formula(paste(y, "~ educ_yrs * factor(race) + factor(sex) + maternal_age + birth_order")),
               data = sub, vcov = "hetero")

  # Separate by race
  w_fit <- feols(as.formula(paste(y, "~ educ_yrs + factor(sex) + maternal_age + birth_order")),
                 data = sub[race == 1], vcov = "hetero")
  b_fit <- feols(as.formula(paste(y, "~ educ_yrs + factor(sex) + maternal_age + birth_order")),
                 data = sub[race == 2], vcov = "hetero")

  # Interaction p-value
  int_coef <- grep("educ_yrs:factor", names(coef(fit)), value = TRUE)
  int_p <- if (length(int_coef) > 0) {
    2 * pnorm(-abs(coef(fit)[int_coef[1]] / se(fit)[int_coef[1]]))
  } else NA

  ses_results[[y]] <- list(fit = fit, w_fit = w_fit, b_fit = b_fit)

  cat(sprintf("%-12s  %7.3f(%s)  %7.3f(%s)  %10.4f\n",
              outcome_labels[i],
              coef(w_fit)["educ_yrs"], sprintf("%.3f", se(w_fit)["educ_yrs"]),
              coef(b_fit)["educ_yrs"], sprintf("%.3f", se(b_fit)["educ_yrs"]),
              ifelse(is.na(int_p), NA, int_p)))
}

# ---- 3. SEI-IQ slopes by race ----
cat("\n--- SEI-IQ Slopes ---\n\n")

cat(sprintf("%-12s  %10s  %10s  %10s\n",
            "Outcome", "White_b", "Black_b", "Interact_p"))
cat(paste(rep("-", 50), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  sub <- ses[!is.na(get(y)) & !is.na(sei_decimal)]

  w_fit <- feols(as.formula(paste(y, "~ sei_decimal + factor(sex) + maternal_age + educ_yrs + birth_order")),
                 data = sub[race == 1], vcov = "hetero")
  b_fit <- feols(as.formula(paste(y, "~ sei_decimal + factor(sex) + maternal_age + educ_yrs + birth_order")),
                 data = sub[race == 2], vcov = "hetero")

  fit <- feols(as.formula(paste(y, "~ sei_decimal * factor(race) + factor(sex) + maternal_age + educ_yrs + birth_order")),
               data = sub, vcov = "hetero")
  int_coef <- grep("sei_decimal:factor", names(coef(fit)), value = TRUE)
  int_p <- if (length(int_coef) > 0) {
    2 * pnorm(-abs(coef(fit)[int_coef[1]] / se(fit)[int_coef[1]]))
  } else NA

  cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)  %10.4f\n",
              outcome_labels[i],
              coef(w_fit)["sei_decimal"], sprintf("%.4f", se(w_fit)["sei_decimal"]),
              coef(b_fit)["sei_decimal"], sprintf("%.4f", se(b_fit)["sei_decimal"]),
              ifelse(is.na(int_p), NA, int_p)))
}

# ---- 4. Education bins by race ----
cat("\n--- Mean FSIQ by Education and Race ---\n\n")

ses[, educ_bin := cut(educ_yrs, breaks = c(0, 8, 11, 12, 15, 25),
                      labels = c("<9", "9-11", "12", "13-15", "16+"))]
tab <- ses[!is.na(educ_bin), .(mean_iq = mean(wisc_fsiq),
                                n = .N), by = .(race, educ_bin)]
cat(sprintf("%-8s  %8s  %8s  %8s  %8s\n", "Educ", "White_IQ", "White_n", "Black_IQ", "Black_n"))
cat(paste(rep("-", 48), collapse=""), "\n")

for (eb in levels(ses$educ_bin)) {
  w <- tab[race == 1 & educ_bin == eb]
  b <- tab[race == 2 & educ_bin == eb]
  cat(sprintf("%-8s  %8.1f  %8d  %8.1f  %8d\n",
              eb,
              ifelse(nrow(w) > 0, w$mean_iq, NA), ifelse(nrow(w) > 0, w$n, 0),
              ifelse(nrow(b) > 0, b$mean_iq, NA), ifelse(nrow(b) > 0, b$n, 0)))
}

# ---- 5. Race gap at each education level ----
cat("\n--- Black-White IQ Gap by Education Level ---\n\n")
for (eb in levels(ses$educ_bin)) {
  w <- ses[race == 1 & educ_bin == eb]
  b <- ses[race == 2 & educ_bin == eb]
  if (nrow(w) > 10 && nrow(b) > 10) {
    gap <- mean(w$wisc_fsiq) - mean(b$wisc_fsiq)
    pooled_sd <- sqrt((var(w$wisc_fsiq) * (nrow(w)-1) + var(b$wisc_fsiq) * (nrow(b)-1)) /
                      (nrow(w) + nrow(b) - 2))
    d_val <- gap / pooled_sd
    cat(sprintf("  %-8s: gap=%.1f points (d=%.2f)\n", eb, gap, d_val))
  }
}

# ---- 6. Save ----
saveRDS(list(ses_results = ses_results), "results_ses_gradients.rds")
cat("Done.\n")
