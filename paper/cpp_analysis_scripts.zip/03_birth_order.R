#!/usr/bin/env Rscript
# 03_birth_order.R — Within-family birth order effects on IQ
#   + MI testing (configural -> metric -> scalar -> strict)
#   + Latent variance and mean homogeneity

library(data.table)
library(fixest)
library(lavaan)

cat("--- Birth Order Effects on IQ ---\n")

d <- readRDS("prepared_data.rds")

# ---- 1. Prepare birth order variable ----
d[, parity := birth_order]  # 0-based from prior_livebirths

# Restrict to children with WISC and known parity
bo <- d[!is.na(wisc_fsiq) & !is.na(parity)]
cat(sprintf("Children with WISC FSIQ and parity: %d\n", nrow(bo)))
cat(sprintf("Families: %d\n", uniqueN(bo$mother_id)))

# Only families with 2+ tested children (for FE)
bo[, n_tested := .N, by = mother_id]
bo_fe <- bo[n_tested >= 2]
cat(sprintf("Children in families with 2+ tested: %d (in %d families)\n",
            nrow(bo_fe), uniqueN(bo_fe$mother_id)))

# Cap parity at 8+ for display
bo[, parity_cat := ifelse(parity >= 8, "8+", as.character(parity))]
bo[, parity_cat := factor(parity_cat, levels = c(as.character(0:7), "8+"))]
bo_fe[, parity_cat := ifelse(parity >= 8, "8+", as.character(parity))]
bo_fe[, parity_cat := factor(parity_cat, levels = c(as.character(0:7), "8+"))]

# ---- 2. Descriptive: IQ by birth order ----
cat("\n--- IQ by Birth Order (Descriptive) ---\n\n")
desc <- bo[, .(mean_iq = mean(wisc_fsiq), sd_iq = sd(wisc_fsiq),
               mean_viq = mean(wisc_viq, na.rm=TRUE),
               mean_piq = mean(wisc_piq, na.rm=TRUE),
               n = .N), by = parity_cat][order(parity_cat)]
cat(sprintf("%-8s  %8s  %6s  %8s  %8s  %6s\n", "Parity", "FSIQ", "SD", "VIQ", "PIQ", "N"))
cat(paste(rep("-", 52), collapse=""), "\n")
for (i in 1:nrow(desc)) {
  cat(sprintf("%-8s  %8.1f  %6.1f  %8.1f  %8.1f  %6d\n",
              desc$parity_cat[i], desc$mean_iq[i], desc$sd_iq[i],
              desc$mean_viq[i], desc$mean_piq[i], desc$n[i]))
}

# ---- 3. OLS vs Within-Family FE ----
cat("\n--- OLS vs Mother Fixed Effects ---\n\n")

outcomes <- c("wisc_fsiq_z", "wisc_viq_z", "wisc_piq_z", "sb_iq_z", "g_factor_z")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

cat(sprintf("%-12s  %8s %8s  %8s %8s  %8s\n",
            "Outcome", "OLS_b", "OLS_se", "FE_b", "FE_se", "N_FE"))
cat(paste(rep("-", 65), collapse=""), "\n")

fe_results <- list()
for (i in seq_along(outcomes)) {
  y <- outcomes[i]

  # OLS: linear parity
  ols <- feols(as.formula(paste(y, "~ parity")), data = bo, vcov = "hetero")

  # Mother FE: linear parity
  fe <- feols(as.formula(paste(y, "~ parity | mother_id")),
              data = bo_fe, vcov = ~mother_id)

  fe_results[[outcomes[i]]] <- list(ols = ols, fe = fe)

  cat(sprintf("%-12s  %8.4f %8.4f  %8.4f %8.4f  %8d\n",
              outcome_labels[i],
              coef(ols)["parity"], se(ols)["parity"],
              coef(fe)["parity"], se(fe)["parity"],
              nobs(fe)))
}

# ---- 4. Categorical birth order within family ----
cat("\n--- Categorical Birth Order (Mother FE) ---\n")
cat("Reference: parity = 0 (firstborn)\n\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  fe_cat <- feols(as.formula(paste(y, "~ parity_cat | mother_id")),
                  data = bo_fe, vcov = ~mother_id)

  cat(sprintf("  %s:\n", outcome_labels[i]))
  cf <- coef(fe_cat)
  se_cf <- se(fe_cat)
  for (j in seq_along(cf)) {
    p_val <- 2 * pnorm(-abs(cf[j] / se_cf[j]))
    sig <- ifelse(p_val < 0.001, "***", ifelse(p_val < 0.01, "**",
           ifelse(p_val < 0.05, "*", "")))
    cat(sprintf("    %-15s  b=%7.4f  se=%7.4f  %s\n",
                names(cf)[j], cf[j], se_cf[j], sig))
  }
}

# ---- 5. Robustness: control for maternal age ----
cat("\n--- Robustness: Controlling for Maternal Age ---\n\n")

cat(sprintf("%-12s  %8s %8s  %8s %8s\n",
            "Outcome", "FE_b", "FE_se", "FE+age_b", "FE+age_se"))
cat(paste(rep("-", 55), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  fe <- fe_results[[outcomes[i]]]$fe

  fe_age <- feols(as.formula(paste(y, "~ parity + maternal_age | mother_id")),
                  data = bo_fe[!is.na(maternal_age)], vcov = ~mother_id)

  cat(sprintf("%-12s  %8.4f %8.4f  %8.4f %8.4f\n",
              outcome_labels[i],
              coef(fe)["parity"], se(fe)["parity"],
              coef(fe_age)["parity"], se(fe_age)["parity"]))
}

# ---- 6. Race-stratified birth order ----
cat("\n--- Birth Order by Race (Mother FE) ---\n\n")

for (race_val in c(1, 2)) {
  race_lab <- ifelse(race_val == 1, "White", "Black")
  sub <- bo_fe[race == race_val]
  sub[, n_tested_r := .N, by = mother_id]
  sub <- sub[n_tested_r >= 2]

  if (nrow(sub) > 100) {
    fe <- feols(wisc_fsiq_z ~ parity | mother_id, data = sub, vcov = ~mother_id)
    cat(sprintf("  %s: b=%.4f (se=%.4f), n=%d children, %d families\n",
                race_lab, coef(fe)["parity"], se(fe)["parity"],
                nrow(sub), uniqueN(sub$mother_id)))
  }
}

# ---- 7. Measurement Invariance Testing ----
cat("\n\n--- MI of WISC Across Birth Order Groups ---\n")
cat("Testing: Configural → Metric → Scalar → Strict\n\n")

# WISC subtests for MI testing
wisc_subtests <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit")

# Create birth order groups: 0 (firstborn), 1 (secondborn), 2+ (laterborn)
mi_data <- d[!is.na(wisc_fsiq) & !is.na(parity)]
mi_data[, bo_group := fcase(
  parity == 0, "firstborn",
  parity == 1, "secondborn",
  parity >= 2, "laterborn"
)]
mi_data[, bo_group := factor(bo_group, levels = c("firstborn", "secondborn", "laterborn"))]

# Check complete cases
mi_complete <- mi_data[complete.cases(mi_data[, ..wisc_subtests])]
cat(sprintf("Complete cases for MI testing: %d\n", nrow(mi_complete)))
cat("Group sizes:\n")
print(mi_complete[, .N, by = bo_group][order(bo_group)])

# Define the CFA model (single factor)
cfa_model <- '
  g =~ wisc_info + wisc_comp + wisc_vocab + wisc_digit
'

# ---- 7a. Configural invariance ----
cat("\n--- Step 1: Configural Invariance ---\n")
fit_config <- cfa(cfa_model, data = mi_complete, group = "bo_group",
                  std.lv = TRUE)
cat(sprintf("  Chi-sq = %.1f, df = %d, p = %.4f\n",
            fitMeasures(fit_config, "chisq"),
            fitMeasures(fit_config, "df"),
            fitMeasures(fit_config, "pvalue")))
cat(sprintf("  CFI = %.4f, RMSEA = %.4f, SRMR = %.4f\n",
            fitMeasures(fit_config, "cfi"),
            fitMeasures(fit_config, "rmsea"),
            fitMeasures(fit_config, "srmr")))

# ---- 7b. Metric invariance (equal loadings) ----
cat("\n--- Step 2: Metric Invariance (equal loadings) ---\n")
fit_metric <- cfa(cfa_model, data = mi_complete, group = "bo_group",
                  std.lv = TRUE, group.equal = "loadings")
cat(sprintf("  Chi-sq = %.1f, df = %d, p = %.4f\n",
            fitMeasures(fit_metric, "chisq"),
            fitMeasures(fit_metric, "df"),
            fitMeasures(fit_metric, "pvalue")))
cat(sprintf("  CFI = %.4f, RMSEA = %.4f, SRMR = %.4f\n",
            fitMeasures(fit_metric, "cfi"),
            fitMeasures(fit_metric, "rmsea"),
            fitMeasures(fit_metric, "srmr")))

# LRT: configural vs metric
lrt_cm <- anova(fit_config, fit_metric)
cat(sprintf("  LRT vs configural: delta_chi2 = %.2f, delta_df = %d, p = %.4f\n",
            lrt_cm[["Chisq diff"]][2], lrt_cm[["Df diff"]][2], lrt_cm[["Pr(>Chisq)"]][2]))
delta_cfi_cm <- fitMeasures(fit_config, "cfi") - fitMeasures(fit_metric, "cfi")
cat(sprintf("  Delta CFI = %.4f (criterion: |delta| < 0.01)\n", delta_cfi_cm))

# ---- 7c. Scalar invariance (equal loadings + intercepts) ----
cat("\n--- Step 3: Scalar Invariance (equal loadings + intercepts) ---\n")
fit_scalar <- cfa(cfa_model, data = mi_complete, group = "bo_group",
                  std.lv = TRUE, group.equal = c("loadings", "intercepts"))
cat(sprintf("  Chi-sq = %.1f, df = %d, p = %.4f\n",
            fitMeasures(fit_scalar, "chisq"),
            fitMeasures(fit_scalar, "df"),
            fitMeasures(fit_scalar, "pvalue")))
cat(sprintf("  CFI = %.4f, RMSEA = %.4f, SRMR = %.4f\n",
            fitMeasures(fit_scalar, "cfi"),
            fitMeasures(fit_scalar, "rmsea"),
            fitMeasures(fit_scalar, "srmr")))

lrt_ms <- anova(fit_metric, fit_scalar)
cat(sprintf("  LRT vs metric: delta_chi2 = %.2f, delta_df = %d, p = %.4f\n",
            lrt_ms[["Chisq diff"]][2], lrt_ms[["Df diff"]][2], lrt_ms[["Pr(>Chisq)"]][2]))
delta_cfi_ms <- fitMeasures(fit_metric, "cfi") - fitMeasures(fit_scalar, "cfi")
cat(sprintf("  Delta CFI = %.4f (criterion: |delta| < 0.01)\n", delta_cfi_ms))

# ---- 7d. Strict invariance (equal loadings + intercepts + residuals) ----
cat("\n--- Step 4: Strict Invariance (equal loadings + intercepts + residuals) ---\n")
fit_strict <- cfa(cfa_model, data = mi_complete, group = "bo_group",
                  std.lv = TRUE,
                  group.equal = c("loadings", "intercepts", "residuals"))
cat(sprintf("  Chi-sq = %.1f, df = %d, p = %.4f\n",
            fitMeasures(fit_strict, "chisq"),
            fitMeasures(fit_strict, "df"),
            fitMeasures(fit_strict, "pvalue")))
cat(sprintf("  CFI = %.4f, RMSEA = %.4f, SRMR = %.4f\n",
            fitMeasures(fit_strict, "cfi"),
            fitMeasures(fit_strict, "rmsea"),
            fitMeasures(fit_strict, "srmr")))

lrt_ss <- anova(fit_scalar, fit_strict)
cat(sprintf("  LRT vs scalar: delta_chi2 = %.2f, delta_df = %d, p = %.4f\n",
            lrt_ss[["Chisq diff"]][2], lrt_ss[["Df diff"]][2], lrt_ss[["Pr(>Chisq)"]][2]))
delta_cfi_ss <- fitMeasures(fit_scalar, "cfi") - fitMeasures(fit_strict, "cfi")
cat(sprintf("  Delta CFI = %.4f (criterion: |delta| < 0.01)\n", delta_cfi_ss))

# ---- 7e. MI summary table ----
cat("\n--- MI Summary ---\n\n")
mi_summary <- data.table(
  Model = c("Configural", "Metric", "Scalar", "Strict"),
  chi2 = sapply(list(fit_config, fit_metric, fit_scalar, fit_strict),
                function(f) fitMeasures(f, "chisq")),
  df = sapply(list(fit_config, fit_metric, fit_scalar, fit_strict),
              function(f) fitMeasures(f, "df")),
  CFI = sapply(list(fit_config, fit_metric, fit_scalar, fit_strict),
               function(f) fitMeasures(f, "cfi")),
  RMSEA = sapply(list(fit_config, fit_metric, fit_scalar, fit_strict),
                 function(f) fitMeasures(f, "rmsea")),
  delta_CFI = c(NA, delta_cfi_cm, delta_cfi_ms, delta_cfi_ss)
)

cat(sprintf("%-12s  %8s  %4s  %8s  %8s  %10s\n",
            "Model", "Chi-sq", "df", "CFI", "RMSEA", "delta_CFI"))
cat(paste(rep("-", 60), collapse=""), "\n")
for (i in 1:nrow(mi_summary)) {
  cat(sprintf("%-12s  %8.1f  %4.0f  %8.4f  %8.4f  %10s\n",
              mi_summary$Model[i], mi_summary$chi2[i], mi_summary$df[i],
              mi_summary$CFI[i], mi_summary$RMSEA[i],
              ifelse(is.na(mi_summary$delta_CFI[i]), "--",
                     sprintf("%.4f", mi_summary$delta_CFI[i]))))
}

# ---- 8. Latent Variance and Mean Homogeneity ----
# (Only meaningful if strict MI holds)
cat("\n\n--- Latent Variance and Mean Homogeneity ---\n")
cat("Testing whether birth order groups differ in latent g variance and means\n\n")

# Check if strict MI held (delta CFI < 0.01)
strict_holds <- abs(delta_cfi_ss) < 0.01
cat(sprintf("Strict MI holds (|delta CFI| < 0.01): %s\n\n",
            ifelse(strict_holds, "YES — proceeding", "NO — interpret cautiously")))

# ---- 8a. Latent variance homogeneity ----
cat("--- Latent Variance Homogeneity ---\n")
cat("Constraining latent variances equal across groups\n")
fit_var <- cfa(cfa_model, data = mi_complete, group = "bo_group",
               std.lv = FALSE,
               group.equal = c("loadings", "intercepts", "residuals",
                                "lv.variances"))
lrt_var <- anova(fit_strict, fit_var)
cat(sprintf("  LRT vs strict: delta_chi2 = %.2f, delta_df = %d, p = %.4f\n",
            lrt_var[["Chisq diff"]][2], lrt_var[["Df diff"]][2],
            lrt_var[["Pr(>Chisq)"]][2]))
cat(sprintf("  CFI = %.4f, RMSEA = %.4f\n",
            fitMeasures(fit_var, "cfi"), fitMeasures(fit_var, "rmsea")))

# Extract group-specific latent variances from strict model
cat("\n  Latent variances by group (strict model):\n")
pe_strict <- parameterEstimates(fit_strict)
lv_vars <- pe_strict[pe_strict$op == "~~" & pe_strict$lhs == "g" & pe_strict$rhs == "g", ]
groups <- c("firstborn", "secondborn", "laterborn")
for (j in 1:nrow(lv_vars)) {
  cat(sprintf("    %-12s: var = %.4f (se = %.4f)\n",
              groups[j], lv_vars$est[j], lv_vars$se[j]))
}

# ---- 8b. Latent mean homogeneity ----
cat("\n--- Latent Mean Homogeneity ---\n")
cat("Constraining latent means equal across groups\n")
fit_mean <- cfa(cfa_model, data = mi_complete, group = "bo_group",
                std.lv = FALSE,
                group.equal = c("loadings", "intercepts", "residuals",
                                 "lv.variances", "means"))
lrt_mean <- anova(fit_var, fit_mean)
cat(sprintf("  LRT vs variance-equal: delta_chi2 = %.2f, delta_df = %d, p = %.4f\n",
            lrt_mean[["Chisq diff"]][2], lrt_mean[["Df diff"]][2],
            lrt_mean[["Pr(>Chisq)"]][2]))
cat(sprintf("  CFI = %.4f, RMSEA = %.4f\n",
            fitMeasures(fit_mean, "cfi"), fitMeasures(fit_mean, "rmsea")))

# Extract group-specific latent means from strict model (firstborn is reference)
cat("\n  Latent means by group (strict model, firstborn = reference):\n")
pe_strict_means <- parameterEstimates(fit_strict)
lv_means <- pe_strict_means[pe_strict_means$op == "~1" & pe_strict_means$lhs == "g", ]
for (j in 1:nrow(lv_means)) {
  cat(sprintf("    %-12s: mean = %.4f (se = %.4f, p = %.4f)\n",
              groups[j], lv_means$est[j], lv_means$se[j], lv_means$pvalue[j]))
}

# ---- 9. Full MI summary including variance/mean tests ----
cat("\n\n--- Full MI Hierarchy ---\n\n")
cat(sprintf("%-25s  %8s  %4s  %8s  %10s  %8s\n",
            "Model", "Chi-sq", "df", "CFI", "delta_CFI", "LRT_p"))
cat(paste(rep("-", 70), collapse=""), "\n")
models <- list(
  list("1. Configural", fit_config, NA, NA),
  list("2. Metric", fit_metric, delta_cfi_cm, lrt_cm[["Pr(>Chisq)"]][2]),
  list("3. Scalar", fit_scalar, delta_cfi_ms, lrt_ms[["Pr(>Chisq)"]][2]),
  list("4. Strict", fit_strict, delta_cfi_ss, lrt_ss[["Pr(>Chisq)"]][2]),
  list("5. Equal variances", fit_var,
       fitMeasures(fit_strict, "cfi") - fitMeasures(fit_var, "cfi"),
       lrt_var[["Pr(>Chisq)"]][2]),
  list("6. Equal means", fit_mean,
       fitMeasures(fit_var, "cfi") - fitMeasures(fit_mean, "cfi"),
       lrt_mean[["Pr(>Chisq)"]][2])
)
for (m in models) {
  cat(sprintf("%-25s  %8.1f  %4.0f  %8.4f  %10s  %8s\n",
              m[[1]],
              fitMeasures(m[[2]], "chisq"), fitMeasures(m[[2]], "df"),
              fitMeasures(m[[2]], "cfi"),
              ifelse(is.na(m[[3]]), "--", sprintf("%.4f", m[[3]])),
              ifelse(is.na(m[[4]]), "--", sprintf("%.4f", m[[4]]))))
}

# ---- 10. Save results ----
saveRDS(list(
  fe_results = fe_results,
  mi_summary = mi_summary,
  fit_config = fit_config,
  fit_metric = fit_metric,
  fit_scalar = fit_scalar,
  fit_strict = fit_strict,
  fit_var = fit_var,
  fit_mean = fit_mean,
  desc_table = desc
), "results_birth_order.rds")

cat("Done.\n")
