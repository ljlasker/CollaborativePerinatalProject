#!/usr/bin/env Rscript
# 04b_breastfeeding_health.R — Breastfeeding-IQ with health controls & twins

library(data.table)
library(fixest)

cat("--- Breastfeeding: Health Controls & Twins ---\n")

d <- as.data.table(readRDS("prepared_data.rds"))
d[, case_id := as.character(case_id)]
d[, mother_id := as.character(mother_id)]

# ---- 1. Create health variables ----
# Use variables with good coverage (>90% non-NA)
d[, low_apgar := as.integer(!is.na(apgar_total) & apgar_total < 7)]
d[, preterm := as.integer(!is.na(gest_age) & gest_age < 37)]
d[, lbw := as.integer(!is.na(birth_wt_g) & birth_wt_g < 2500)]
d[, vlbw := as.integer(!is.na(birth_wt_g) & birth_wt_g < 1500)]
d[, jaundice_any := as.integer(!is.na(jaundice) & jaundice > 0)]
d[, is_twin := as.integer(plurality > 0)]

# Congenital malformations from standalone file (good coverage)
cong <- fread("../clean/standalone/congmalf_structured.csv",
              colClasses = c(case_id = "character"))
cong_flag <- cong[, .(case_id, any_malf = as.integer(n_malf_1yr > 0))]
d <- merge(d, cong_flag, by = "case_id", all.x = TRUE)
d[is.na(any_malf), any_malf := 0L]

# Composite: neonatal health problem that might interfere with feeding
d[, health_problem := as.integer(
  low_apgar == 1 | preterm == 1 | vlbw == 1 | any_malf == 1
)]

cat("--- Health Variable Prevalence ---\n")
cat(sprintf("Low Apgar (<7):      %5d (%4.1f%%)\n",
            sum(d$low_apgar), 100*mean(d$low_apgar)))
cat(sprintf("Preterm (<37wk):     %5d (%4.1f%%)\n",
            sum(d$preterm), 100*mean(d$preterm)))
cat(sprintf("LBW (<2500g):        %5d (%4.1f%%)\n",
            sum(d$lbw), 100*mean(d$lbw)))
cat(sprintf("VLBW (<1500g):       %5d (%4.1f%%)\n",
            sum(d$vlbw), 100*mean(d$vlbw)))
cat(sprintf("Any malformation:    %5d (%4.1f%%)\n",
            sum(d$any_malf), 100*mean(d$any_malf)))
cat(sprintf("Jaundice:            %5d (%4.1f%%)\n",
            sum(d$jaundice_any), 100*mean(d$jaundice_any)))
cat(sprintf("Twin:                %5d (%4.1f%%)\n",
            sum(d$is_twin), 100*mean(d$is_twin)))
cat(sprintf("Composite problem:   %5d (%4.1f%%)\n",
            sum(d$health_problem), 100*mean(d$health_problem)))

# ---- 2. Analysis sample ----
bf <- d[!is.na(wisc_fsiq) & !is.na(bf_any)]
cat(sprintf("\nAnalysis sample (WISC + BF): N=%d\n", nrow(bf)))

cat("\nBF rates by health status:\n")
cat(sprintf("  All:                %.1f%% (N=%d)\n",
            100*mean(bf$bf_any), nrow(bf)))
cat(sprintf("  Healthy singleton:  %.1f%% (N=%d)\n",
            100*mean(bf[health_problem==0 & is_twin==0]$bf_any),
            nrow(bf[health_problem==0 & is_twin==0])))
cat(sprintf("  Health problem:     %.1f%% (N=%d)\n",
            100*mean(bf[health_problem==1]$bf_any),
            nrow(bf[health_problem==1])))
cat(sprintf("  Twin:               %.1f%% (N=%d)\n",
            100*mean(bf[is_twin==1]$bf_any),
            nrow(bf[is_twin==1])))
cat(sprintf("  Low Apgar:          %.1f%% (N=%d)\n",
            100*mean(bf[low_apgar==1]$bf_any),
            nrow(bf[low_apgar==1])))
cat(sprintf("  Preterm:            %.1f%% (N=%d)\n",
            100*mean(bf[preterm==1]$bf_any),
            nrow(bf[preterm==1])))
cat(sprintf("  LBW:                %.1f%% (N=%d)\n",
            100*mean(bf[lbw==1]$bf_any),
            nrow(bf[lbw==1])))

outcomes <- c("wisc_fsiq_z", "wisc_viq_z", "wisc_piq_z", "sb_iq_z", "g_factor_z")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

cat("\n--- A. OLS: Adding Health Controls ---\n")

# Three specifications: original full, full + health, full + health + Apgar continuous
cov_full <- "bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order"
cov_health <- "bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order + low_apgar + any_malf + jaundice_any + is_twin"
cov_apgar <- "bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order + apgar_total + any_malf + jaundice_any + is_twin"

cat(sprintf("%-12s  %14s  %14s  %14s\n", "Outcome", "Full", "+Health", "+Apgar(cont)"))
cat(paste(rep("-", 60), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  m1 <- feols(as.formula(paste(y, "~", cov_full)), data = bf, vcov = "hetero")
  m2 <- feols(as.formula(paste(y, "~", cov_health)), data = bf, vcov = "hetero")
  m3 <- feols(as.formula(paste(y, "~", cov_apgar)), data = bf, vcov = "hetero")
  cat(sprintf("%-12s  %7.3f (%.3f)  %7.3f (%.3f)  %7.3f (%.3f)\n",
              outcome_labels[i],
              coef(m1)["bf_any"], se(m1)["bf_any"],
              coef(m2)["bf_any"], se(m2)["bf_any"],
              coef(m3)["bf_any"], se(m3)["bf_any"]))
}

cat("\nN for full model: ", nobs(feols(wisc_fsiq_z ~ bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order, bf, vcov="hetero")), "\n")
cat("N for health model: ", nobs(feols(wisc_fsiq_z ~ bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order + low_apgar + any_malf + jaundice_any + is_twin, bf, vcov="hetero")), "\n")

cat("\n--- B. Mother FE: With and Without Health Controls ---\n")

bf[, n_tested := .N, by = mother_id]
bf_fe <- bf[n_tested >= 2]
bf_fe[, bf_var := sd(bf_any, na.rm=TRUE), by = mother_id]
bf_disc <- bf_fe[bf_var > 0]

cat(sprintf("All 2+ sibling families: %d children\n", nrow(bf_fe)))
cat(sprintf("BF-discordant families: %d children in %d families\n\n",
            nrow(bf_disc), uniqueN(bf_disc$mother_id)))

cov_fe <- "bf_any + factor(sex) + birth_order"
cov_fe_h <- "bf_any + factor(sex) + birth_order + low_apgar + lbw + any_malf + jaundice_any"

cat(sprintf("%-12s  %14s  %14s  %5s  %5s\n",
            "Outcome", "FE(base)", "FE(+health)", "N_b", "N_h"))
cat(paste(rep("-", 58), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  fe1 <- tryCatch(
    feols(as.formula(paste(y, "~", cov_fe, "| mother_id")),
          data = bf_disc, vcov = ~mother_id),
    error = function(e) NULL)
  fe2 <- tryCatch(
    feols(as.formula(paste(y, "~", cov_fe_h, "| mother_id")),
          data = bf_disc, vcov = ~mother_id),
    error = function(e) NULL)

  b1 <- if (!is.null(fe1)) sprintf("%7.3f (%.3f)", coef(fe1)["bf_any"], se(fe1)["bf_any"]) else "       --     "
  b2 <- if (!is.null(fe2)) sprintf("%7.3f (%.3f)", coef(fe2)["bf_any"], se(fe2)["bf_any"]) else "       --     "
  n1 <- if (!is.null(fe1)) nobs(fe1) else NA
  n2 <- if (!is.null(fe2)) nobs(fe2) else NA
  cat(sprintf("%-12s  %s  %s  %5s  %5s\n",
              outcome_labels[i], b1, b2,
              ifelse(is.na(n1), "--", as.character(n1)),
              ifelse(is.na(n2), "--", as.character(n2))))
}

cat("\n\n--- C. Exclusion: Healthy Singletons Only ---\n")

bf_healthy <- bf[health_problem == 0 & is_twin == 0]
cat(sprintf("Healthy singletons: N=%d (%.1f%% of analysis sample)\n",
            nrow(bf_healthy), 100*nrow(bf_healthy)/nrow(bf)))
cat(sprintf("BF rate: %.1f%%\n\n", 100*mean(bf_healthy$bf_any)))

cat("--- OLS ---\n\n")
cat(sprintf("%-12s  %14s  %14s\n", "Outcome", "All", "Healthy only"))
cat(paste(rep("-", 44), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  m_all <- feols(as.formula(paste(y, "~", cov_full)), data = bf, vcov = "hetero")
  m_h <- feols(as.formula(paste(y, "~", cov_full)), data = bf_healthy, vcov = "hetero")
  cat(sprintf("%-12s  %7.3f (%.3f)  %7.3f (%.3f)\n",
              outcome_labels[i],
              coef(m_all)["bf_any"], se(m_all)["bf_any"],
              coef(m_h)["bf_any"], se(m_h)["bf_any"]))
}

# Mother FE on healthy singletons
cat("\n--- Mother FE ---\n\n")
bf_healthy[, n_tested_h := .N, by = mother_id]
bf_healthy_fe <- bf_healthy[n_tested_h >= 2]
bf_healthy_fe[, bf_var_h := sd(bf_any, na.rm=TRUE), by = mother_id]
bf_healthy_disc <- bf_healthy_fe[bf_var_h > 0]

cat(sprintf("Healthy discordant families: %d children in %d families\n\n",
            nrow(bf_healthy_disc), uniqueN(bf_healthy_disc$mother_id)))

cat(sprintf("%-12s  %14s  %14s\n", "Outcome", "FE disc (all)", "FE disc (hlthy)"))
cat(paste(rep("-", 44), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  fe_all <- tryCatch(
    feols(as.formula(paste(y, "~ bf_any + factor(sex) + birth_order | mother_id")),
          data = bf_disc, vcov = ~mother_id),
    error = function(e) NULL)
  fe_h <- tryCatch(
    feols(as.formula(paste(y, "~ bf_any + factor(sex) + birth_order | mother_id")),
          data = bf_healthy_disc, vcov = ~mother_id),
    error = function(e) NULL)

  b1 <- if (!is.null(fe_all)) sprintf("%7.3f (%.3f)", coef(fe_all)["bf_any"], se(fe_all)["bf_any"]) else "       --     "
  b2 <- if (!is.null(fe_h)) sprintf("%7.3f (%.3f)", coef(fe_h)["bf_any"], se(fe_h)["bf_any"]) else "       --     "
  cat(sprintf("%-12s  %s  %s\n", outcome_labels[i], b1, b2))
}

cat("\n\n--- D. Twin Analysis ---\n")

# Twin descriptives
twins <- bf[is_twin == 1]
cat(sprintf("Twins with WISC + BF: %d\n", nrow(twins)))
cat(sprintf("BF rate in twins: %.1f%%\n", 100*mean(twins$bf_any)))
cat(sprintf("Not breastfed twins: %d\n\n", sum(twins$bf_any == 0)))

# Load twin pair info
links <- as.data.table(readRDS("prepared_links.rds"))
links[, id_1 := as.character(id_1)]
links[, id_2 := as.character(id_2)]
twin_links <- links[grepl("twin", pair_type, ignore.case=TRUE)]
cat("Twin pair types:\n")
print(twin_links[, .N, by=pair_type][order(-N)])

# Match twins to pairs
twin_ids <- unique(c(twin_links$id_1, twin_links$id_2))
twin_pair_map <- rbind(
  twin_links[, .(case_id = id_1, twin_pair_id = paste0("tp_", .I))],
  twin_links[, .(case_id = id_2, twin_pair_id = paste0("tp_", .I))]
)
twin_pair_map <- twin_pair_map[!duplicated(case_id)]

twins_paired <- merge(twins, twin_pair_map, by = "case_id")
twins_paired[, n_pair := .N, by = twin_pair_id]
complete_pairs <- twins_paired[n_pair == 2]
cat(sprintf("\nComplete twin pairs with WISC + BF: %d pairs\n", nrow(complete_pairs)/2))

# BF discordance within twin pairs
complete_pairs[, bf_var_tp := sd(bf_any), by = twin_pair_id]
disc_pairs <- complete_pairs[bf_var_tp > 0]
cat(sprintf("BF-discordant twin pairs: %d pairs\n", nrow(disc_pairs)/2))

if (nrow(disc_pairs) >= 10) {
  cat("\n--- Within-Twin-Pair Fixed Effects ---\n")
  for (i in seq_along(outcomes)) {
    y <- outcomes[i]
    m <- tryCatch(
      feols(as.formula(paste(y, "~ bf_any | twin_pair_id")),
            data = disc_pairs, vcov = ~twin_pair_id),
      error = function(e) NULL)
    if (!is.null(m) && "bf_any" %in% names(coef(m))) {
      cat(sprintf("  %s: b=%.3f (SE=%.3f)\n",
                  outcome_labels[i], coef(m)["bf_any"], se(m)["bf_any"]))
    }
  }
} else {
  cat(sprintf("\nOnly %d BF-discordant twin pairs — insufficient for within-pair FE.\n",
              nrow(disc_pairs)/2))
  cat("This is because twin BF rate is nearly universal (98%).\n")
  cat("In the 1960s CPP, twins were virtually always breastfed in the nursery.\n")
}

# OLS comparison: singletons vs twins
cat("\n--- OLS: Singleton vs Twin BF Coefficients ---\n\n")
cat(sprintf("%-12s  %14s  %14s\n", "Outcome", "Singletons", "Twins"))
cat(paste(rep("-", 44), collapse=""), "\n")

cov_s <- "bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + birth_order"
cov_t <- "bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs"

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  ms <- feols(as.formula(paste(y, "~", cov_s)), data = bf[is_twin==0], vcov="hetero")
  mt <- tryCatch(
    feols(as.formula(paste(y, "~", cov_t)), data = bf[is_twin==1], vcov="hetero"),
    error = function(e) NULL)
  b_s <- sprintf("%7.3f (%.3f)", coef(ms)["bf_any"], se(ms)["bf_any"])
  b_t <- if (!is.null(mt) && "bf_any" %in% names(coef(mt)))
    sprintf("%7.3f (%.3f)", coef(mt)["bf_any"], se(mt)["bf_any"]) else "       --     "
  cat(sprintf("%-12s  %s  %s\n", outcome_labels[i], b_s, b_t))
}
cat(sprintf("\nN singletons: %d; N twins: %d\n",
            nrow(bf[is_twin==0]), nrow(bf[is_twin==1])))

cat("\n\n--- E. Summary: Key Estimates ---\n")

cat("WISC FSIQ key estimates (all in SD units):\n\n")

# Run all specifications for FSIQ
m_bivar <- feols(wisc_fsiq_z ~ bf_any, data = bf, vcov = "hetero")
m_demo <- feols(wisc_fsiq_z ~ bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal, data = bf, vcov = "hetero")
m_full <- feols(wisc_fsiq_z ~ bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order, data = bf, vcov = "hetero")
m_health <- feols(wisc_fsiq_z ~ bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order + low_apgar + any_malf + jaundice_any + is_twin, data = bf, vcov = "hetero")
m_fe <- feols(wisc_fsiq_z ~ bf_any + factor(sex) + birth_order | mother_id, data = bf_disc, vcov = ~mother_id)
m_fe_h <- tryCatch(feols(wisc_fsiq_z ~ bf_any + factor(sex) + birth_order + low_apgar + lbw + any_malf + jaundice_any | mother_id, data = bf_disc, vcov = ~mother_id), error = function(e) NULL)

cat(sprintf("  Bivariate:           b = %+.3f (SE = %.3f, N = %d)\n",
            coef(m_bivar)["bf_any"], se(m_bivar)["bf_any"], nobs(m_bivar)))
cat(sprintf("  + Demographics:      b = %+.3f (SE = %.3f, N = %d)\n",
            coef(m_demo)["bf_any"], se(m_demo)["bf_any"], nobs(m_demo)))
cat(sprintf("  + Full controls:     b = %+.3f (SE = %.3f, N = %d)\n",
            coef(m_full)["bf_any"], se(m_full)["bf_any"], nobs(m_full)))
cat(sprintf("  + Health controls:   b = %+.3f (SE = %.3f, N = %d)\n",
            coef(m_health)["bf_any"], se(m_health)["bf_any"], nobs(m_health)))
cat(sprintf("  Mother FE (disc):    b = %+.3f (SE = %.3f, N = %d)\n",
            coef(m_fe)["bf_any"], se(m_fe)["bf_any"], nobs(m_fe)))
if (!is.null(m_fe_h)) {
  cat(sprintf("  Mother FE + health:  b = %+.3f (SE = %.3f, N = %d)\n",
              coef(m_fe_h)["bf_any"], se(m_fe_h)["bf_any"], nobs(m_fe_h)))
}

# Exclusion
m_h_ols <- feols(wisc_fsiq_z ~ bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order, data = bf_healthy, vcov = "hetero")
cat(sprintf("  Healthy only (OLS):  b = %+.3f (SE = %.3f, N = %d)\n",
            coef(m_h_ols)["bf_any"], se(m_h_ols)["bf_any"], nobs(m_h_ols)))

if (nrow(bf_healthy_disc) >= 20) {
  m_h_fe <- tryCatch(
    feols(wisc_fsiq_z ~ bf_any + factor(sex) + birth_order | mother_id,
          data = bf_healthy_disc, vcov = ~mother_id),
    error = function(e) NULL)
  if (!is.null(m_h_fe)) {
    cat(sprintf("  Healthy only (FE):   b = %+.3f (SE = %.3f, N = %d, %d fams)\n",
                coef(m_h_fe)["bf_any"], se(m_h_fe)["bf_any"], nobs(m_h_fe),
                uniqueN(bf_healthy_disc$mother_id)))
  }
}

cat(sprintf("\n  Twin BF rate: %.1f%% (N=%d)\n", 100*mean(twins$bf_any), nrow(twins)))
cat(sprintf("  BF-discordant twin pairs: %d (of %d total)\n",
            nrow(disc_pairs)/2, nrow(complete_pairs)/2))

# ---- F. Save results ----

extract_coef <- function(m, var = "bf_any") {
  if (is.null(m)) return(list(b = NA, se = NA, n = NA))
  list(b = coef(m)[var], se = se(m)[var], n = nobs(m))
}

results <- list(
  bivar     = extract_coef(m_bivar),
  demo      = extract_coef(m_demo),
  full      = extract_coef(m_full),
  health    = extract_coef(m_health),
  fe        = extract_coef(m_fe),
  fe_health = extract_coef(m_fe_h),
  healthy_ols = extract_coef(m_h_ols),
  healthy_fe  = if (exists("m_h_fe")) extract_coef(m_h_fe) else NULL,
  twin_bf_rate = mean(twins$bf_any),
  n_twins = nrow(twins),
  n_disc_twin_pairs = nrow(disc_pairs) / 2,
  n_total_twin_pairs = nrow(complete_pairs) / 2
)
saveRDS(results, "results_breastfeeding_health.rds")
cat("\nSaved to results_breastfeeding_health.rds\n")

cat("Done.\n")
