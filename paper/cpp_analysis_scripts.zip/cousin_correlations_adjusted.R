###############################################################################
# cousin_correlations_adjusted.R
# Compute within-race and residualized IQ correlations for extended kinship
# pairs in the CPP data, to address population stratification (race/institution
# confounding) that inflates raw cousin-pair correlations.
###############################################################################

library(dplyr)
library(tidyr)

# ── 1. Read data ─────────────────────────────────────────────────────────────

BASE <- ".."
iq_data <- readRDS(file.path(BASE, "clean", "cpp_clean_expanded.rds"))
kinship_ext <- read.csv(file.path(BASE, "clean", "cpp_extended_kinship_links.csv"),
                        colClasses = c("character", "character", "character", "numeric", "character"))
kinship_main <- read.csv(file.path(BASE, "clean", "cpp_kinship_links.csv"),
                         colClasses = c("character", "character", "character", "character", "numeric", "character", "character"))

# Preserve the fixed-width ID components; never numeric-left-pad CPP IDs.
source("case_id_helpers.R")
kinship_ext$id_1 <- canonicalize_cpp_case_id(kinship_ext$id_1)
kinship_ext$id_2 <- canonicalize_cpp_case_id(kinship_ext$id_2)
kinship_main$id_1 <- canonicalize_cpp_case_id(kinship_main$id_1)
kinship_main$id_2 <- canonicalize_cpp_case_id(kinship_main$id_2)

cat("Extended kinship links loaded:", nrow(kinship_ext), "pairs\n")
cat("Main kinship links loaded:", nrow(kinship_main), "pairs\n")
cat("IQ data loaded:", nrow(iq_data), "individuals\n\n")

# ── 2. Prepare individual-level data ─────────────────────────────────────────

# Race labels: 1=White, 2=Black, 3=Oriental, 4=Puerto Rican
iq_data$race_cat <- factor(iq_data$race, levels = c(1, 2, 3, 4),
                           labels = c("White", "Black", "Oriental", "Puerto Rican"))
iq_data$institution <- factor(iq_data$institution)

# Residualize WISC FSIQ on race + institution dummies
# This removes between-group mean differences
has_iq <- !is.na(iq_data$wisc_fsiq) & !is.na(iq_data$race) & !is.na(iq_data$institution)
cat("Individuals with WISC FSIQ + race + institution:", sum(has_iq), "\n")

mod <- lm(wisc_fsiq ~ race_cat + institution, data = iq_data[has_iq, ])
cat("\nResidualizing model R²:", round(summary(mod)$r.squared, 4), "\n")
cat("Race + institution explain", round(summary(mod)$r.squared * 100, 1), "% of WISC FSIQ variance\n\n")

# Store residuals back
iq_data$wisc_fsiq_resid <- NA_real_
iq_data$wisc_fsiq_resid[has_iq] <- residuals(mod)

# Also residualize on race only (for comparison)
mod_race <- lm(wisc_fsiq ~ race_cat, data = iq_data[has_iq, ])
iq_data$wisc_fsiq_resid_race <- NA_real_
iq_data$wisc_fsiq_resid_race[has_iq] <- residuals(mod_race)

# Also residualize on institution only
mod_inst <- lm(wisc_fsiq ~ institution, data = iq_data[has_iq, ])
iq_data$wisc_fsiq_resid_inst <- NA_real_
iq_data$wisc_fsiq_resid_inst[has_iq] <- residuals(mod_inst)

# Subset for merging
iq_sub <- iq_data[, c("case_id", "race", "race_cat", "institution",
                       "wisc_fsiq", "wisc_fsiq_resid", "wisc_fsiq_resid_race",
                       "wisc_fsiq_resid_inst")]

# ── 3. Combine kinship links ────────────────────────────────────────────────

# From main kinship: MZ, DZ, full sib, half sib
# Keep only clean pair types
main_pairs <- kinship_main %>%
  filter(pair_type %in% c("MZ_twin", "DZ_twin", "DZ_twin_probable",
                           "full_sibling", "half_sibling")) %>%
  mutate(
    pair_type = case_when(
      pair_type %in% c("DZ_twin", "DZ_twin_probable") ~ "DZ_twin",
      TRUE ~ pair_type
    ),
    R = case_when(
      pair_type == "MZ_twin" ~ 1.0,
      pair_type == "DZ_twin" ~ 0.5,
      pair_type == "full_sibling" ~ 0.5,
      pair_type == "half_sibling" ~ 0.25,
      TRUE ~ R
    )
  ) %>%
  select(id_1, id_2, pair_type, R)

# Extended kinship pairs
ext_pairs <- kinship_ext %>%
  select(id_1, id_2, pair_type, R)

# Combine all
all_pairs <- bind_rows(main_pairs, ext_pairs)
cat("Total pairs (all types):", nrow(all_pairs), "\n")
cat("Pair type counts:\n")
print(table(all_pairs$pair_type))
cat("\n")

# ── 4. Merge IQ + demographics onto pairs ────────────────────────────────────

pairs <- all_pairs %>%
  left_join(iq_sub, by = c("id_1" = "case_id")) %>%
  rename(race_1 = race, race_cat_1 = race_cat, inst_1 = institution,
         iq_1 = wisc_fsiq, iq_resid_1 = wisc_fsiq_resid,
         iq_resid_race_1 = wisc_fsiq_resid_race,
         iq_resid_inst_1 = wisc_fsiq_resid_inst) %>%
  left_join(iq_sub, by = c("id_2" = "case_id")) %>%
  rename(race_2 = race, race_cat_2 = race_cat, inst_2 = institution,
         iq_2 = wisc_fsiq, iq_resid_2 = wisc_fsiq_resid,
         iq_resid_race_2 = wisc_fsiq_resid_race,
         iq_resid_inst_2 = wisc_fsiq_resid_inst)

# Flag same-race pairs
pairs$same_race <- pairs$race_1 == pairs$race_2
pairs$same_inst <- pairs$inst_1 == pairs$inst_2

cat("Pairs with both IQ scores:", sum(!is.na(pairs$iq_1) & !is.na(pairs$iq_2)), "\n")
cat("Same-race pairs (of those with IQ):",
    sum(!is.na(pairs$iq_1) & !is.na(pairs$iq_2) & pairs$same_race, na.rm = TRUE), "\n\n")

# ── 5. Correlation function with CI ─────────────────────────────────────────

compute_cor <- function(x, y, method = "pearson") {
  complete <- complete.cases(x, y)
  n <- sum(complete)
  if (n < 10) {
    return(data.frame(n_pairs = n, r = NA_real_, ci_lo = NA_real_, ci_hi = NA_real_,
                      se = NA_real_))
  }
  ct <- cor.test(x[complete], y[complete], method = method)
  se <- (ct$conf.int[2] - ct$conf.int[1]) / (2 * 1.96)
  data.frame(
    n_pairs = n,
    r       = ct$estimate,
    ci_lo   = ct$conf.int[1],
    ci_hi   = ct$conf.int[2],
    se      = se
  )
}

# ── 6. Define relationship types and labels ──────────────────────────────────

# Full gradient from MZ twins down to second cousins
rel_types <- c("MZ_twin", "DZ_twin", "full_sibling", "half_sibling",
               "niece_nephew", "first_cousin", "half_niece_nephew",
               "first_cousin_once_removed", "half_first_cousin", "second_cousin")

R_map <- c(MZ_twin = 1.0, DZ_twin = 0.5, full_sibling = 0.5,
           half_sibling = 0.25, niece_nephew = 0.25,
           first_cousin = 0.125, half_niece_nephew = 0.125,
           first_cousin_once_removed = 0.0625, half_first_cousin = 0.0625,
           second_cousin = 0.03125)

nice_labels <- c(MZ_twin = "MZ twin", DZ_twin = "DZ twin",
                 full_sibling = "Full sibling", half_sibling = "Half-sibling",
                 niece_nephew = "Niece/nephew",
                 first_cousin = "First cousin", half_niece_nephew = "Half niece/nephew",
                 first_cousin_once_removed = "1st cousin 1x removed",
                 half_first_cousin = "Half first cousin",
                 second_cousin = "Second cousin")

# Combined groups for cleaner gradient
combined_groups <- list(
  "R=0.5 (DZ+FS)" = c("DZ_twin", "full_sibling"),
  "R=0.25 (HS+NN)" = c("half_sibling", "niece_nephew"),
  "R=0.125 (FC+HNN)" = c("first_cousin", "half_niece_nephew"),
  "R=0.0625 (FC1R+HFC)" = c("first_cousin_once_removed", "half_first_cousin")
)
combined_R <- c("R=0.5 (DZ+FS)" = 0.5, "R=0.25 (HS+NN)" = 0.25,
                "R=0.125 (FC+HNN)" = 0.125, "R=0.0625 (FC1R+HFC)" = 0.0625)

# ── 7. Compute correlations: raw, within-race, residualized ─────────────────

results_list <- list()

for (pt in rel_types) {
  sub <- pairs %>% filter(pair_type == pt)

  # --- Raw ---
  raw <- compute_cor(sub$iq_1, sub$iq_2)
  raw$pair_type <- pt
  raw$R <- R_map[pt]
  raw$method <- "raw"
  raw$race <- "all"
  results_list[[paste(pt, "raw")]] <- raw

  # --- Residualized (race + institution) ---
  resid <- compute_cor(sub$iq_resid_1, sub$iq_resid_2)
  resid$pair_type <- pt
  resid$R <- R_map[pt]
  resid$method <- "resid_race_inst"
  resid$race <- "all"
  results_list[[paste(pt, "resid")]] <- resid

  # --- Residualized (race only) ---
  resid_r <- compute_cor(sub$iq_resid_race_1, sub$iq_resid_race_2)
  resid_r$pair_type <- pt
  resid_r$R <- R_map[pt]
  resid_r$method <- "resid_race"
  resid_r$race <- "all"
  results_list[[paste(pt, "resid_race")]] <- resid_r

  # --- Residualized (institution only) ---
  resid_i <- compute_cor(sub$iq_resid_inst_1, sub$iq_resid_inst_2)
  resid_i$pair_type <- pt
  resid_i$R <- R_map[pt]
  resid_i$method <- "resid_inst"
  resid_i$race <- "all"
  results_list[[paste(pt, "resid_inst")]] <- resid_i

  # --- Within-race: White ---
  sub_w <- sub %>% filter(race_1 == 1 & race_2 == 1)
  wr <- compute_cor(sub_w$iq_1, sub_w$iq_2)
  wr$pair_type <- pt
  wr$R <- R_map[pt]
  wr$method <- "within_race"
  wr$race <- "White"
  results_list[[paste(pt, "White")]] <- wr

  # --- Within-race: Black ---
  sub_b <- sub %>% filter(race_1 == 2 & race_2 == 2)
  br <- compute_cor(sub_b$iq_1, sub_b$iq_2)
  br$pair_type <- pt
  br$R <- R_map[pt]
  br$method <- "within_race"
  br$race <- "Black"
  results_list[[paste(pt, "Black")]] <- br

  # --- Within-race: White, residualized on institution ---
  resid_w <- compute_cor(sub_w$iq_resid_inst_1, sub_w$iq_resid_inst_2)
  resid_w$pair_type <- pt
  resid_w$R <- R_map[pt]
  resid_w$method <- "within_race_resid_inst"
  resid_w$race <- "White"
  results_list[[paste(pt, "White_resid_inst")]] <- resid_w

  # --- Within-race: Black, residualized on institution ---
  resid_b <- compute_cor(sub_b$iq_resid_inst_1, sub_b$iq_resid_inst_2)
  resid_b$pair_type <- pt
  resid_b$R <- R_map[pt]
  resid_b$method <- "within_race_resid_inst"
  resid_b$race <- "Black"
  results_list[[paste(pt, "Black_resid_inst")]] <- resid_b
}

results_all <- bind_rows(results_list)
rownames(results_all) <- NULL

# ── 8. Also compute for combined groups ──────────────────────────────────────

combined_list <- list()

for (grp in names(combined_groups)) {
  grp_types <- combined_groups[[grp]]
  R_val <- combined_R[grp]
  sub <- pairs %>% filter(pair_type %in% grp_types)

  for (meth in c("raw", "resid_race_inst", "resid_race", "resid_inst")) {
    v1 <- switch(meth,
                 raw = "iq_1",
                 resid_race_inst = "iq_resid_1",
                 resid_race = "iq_resid_race_1",
                 resid_inst = "iq_resid_inst_1")
    v2 <- switch(meth,
                 raw = "iq_2",
                 resid_race_inst = "iq_resid_2",
                 resid_race = "iq_resid_race_2",
                 resid_inst = "iq_resid_inst_2")
    res <- compute_cor(sub[[v1]], sub[[v2]])
    res$pair_type <- grp
    res$R <- R_val
    res$method <- meth
    res$race <- "all"
    combined_list[[paste(grp, meth)]] <- res
  }

  # Within-race
  for (rc in c("White", "Black")) {
    rc_num <- ifelse(rc == "White", 1, 2)
    sub_rc <- sub %>% filter(race_1 == rc_num & race_2 == rc_num)

    # Raw within-race
    res <- compute_cor(sub_rc$iq_1, sub_rc$iq_2)
    res$pair_type <- grp
    res$R <- R_val
    res$method <- "within_race"
    res$race <- rc
    combined_list[[paste(grp, rc)]] <- res

    # Within-race + institution residualized
    res2 <- compute_cor(sub_rc$iq_resid_inst_1, sub_rc$iq_resid_inst_2)
    res2$pair_type <- grp
    res2$R <- R_val
    res2$method <- "within_race_resid_inst"
    res2$race <- rc
    combined_list[[paste(grp, rc, "resid_inst")]] <- res2
  }
}

results_combined <- bind_rows(combined_list)
rownames(results_combined) <- NULL

# Merge all results
results_full <- bind_rows(results_all, results_combined)

# ── 9. Print comparison tables ───────────────────────────────────────────────

cat("\n")
cat(paste(rep("=", 110), collapse = ""), "\n")
cat("RAW vs WITHIN-RACE vs RESIDUALIZED CORRELATIONS — WISC FSIQ\n")
cat(paste(rep("=", 110), collapse = ""), "\n\n")

# For each relationship type, show raw, within-White, within-Black, residualized
cat(sprintf("%-28s  %6s  %6s  %8s  %8s  %8s  %8s  %8s  %8s\n",
            "Relationship", "R", "n_raw", "r_raw", "r_White", "r_Black",
            "r_resid", "r_rRace", "r_rInst"))
cat(paste(rep("-", 110), collapse = ""), "\n")

for (pt in rel_types) {
  raw_r <- results_all %>% filter(pair_type == pt, method == "raw")
  white_r <- results_all %>% filter(pair_type == pt, method == "within_race", race == "White")
  black_r <- results_all %>% filter(pair_type == pt, method == "within_race", race == "Black")
  resid_r <- results_all %>% filter(pair_type == pt, method == "resid_race_inst")
  resid_race_r <- results_all %>% filter(pair_type == pt, method == "resid_race")
  resid_inst_r <- results_all %>% filter(pair_type == pt, method == "resid_inst")

  fmt_r <- function(df) {
    if (nrow(df) == 0 || is.na(df$r[1])) return(sprintf("%8s", "—"))
    sprintf("%8.4f", df$r[1])
  }
  fmt_n <- function(df) {
    if (nrow(df) == 0) return(sprintf("%6s", "—"))
    sprintf("%6d", df$n_pairs[1])
  }

  cat(sprintf("%-28s  %.4f  %s  %s  %s  %s  %s  %s  %s\n",
              nice_labels[pt], R_map[pt],
              fmt_n(raw_r), fmt_r(raw_r), fmt_r(white_r), fmt_r(black_r),
              fmt_r(resid_r), fmt_r(resid_race_r), fmt_r(resid_inst_r)))
}

cat("\n")
cat("Combined groups:\n")
cat(paste(rep("-", 110), collapse = ""), "\n")

for (grp in names(combined_groups)) {
  raw_r <- results_combined %>% filter(pair_type == grp, method == "raw")
  white_r <- results_combined %>% filter(pair_type == grp, method == "within_race", race == "White")
  black_r <- results_combined %>% filter(pair_type == grp, method == "within_race", race == "Black")
  resid_r <- results_combined %>% filter(pair_type == grp, method == "resid_race_inst")
  resid_race_r <- results_combined %>% filter(pair_type == grp, method == "resid_race")
  resid_inst_r <- results_combined %>% filter(pair_type == grp, method == "resid_inst")

  fmt_r <- function(df) {
    if (nrow(df) == 0 || is.na(df$r[1])) return(sprintf("%8s", "—"))
    sprintf("%8.4f", df$r[1])
  }
  fmt_n <- function(df) {
    if (nrow(df) == 0) return(sprintf("%6s", "—"))
    sprintf("%6d", df$n_pairs[1])
  }

  cat(sprintf("%-28s  %.4f  %s  %s  %s  %s  %s  %s  %s\n",
              grp, combined_R[grp],
              fmt_n(raw_r), fmt_r(raw_r), fmt_r(white_r), fmt_r(black_r),
              fmt_r(resid_r), fmt_r(resid_race_r), fmt_r(resid_inst_r)))
}

# ── 10. Race composition of pairs ───────────────────────────────────────────

cat("\n\n")
cat(paste(rep("=", 80), collapse = ""), "\n")
cat("RACE COMPOSITION OF PAIRS (with both IQ scores)\n")
cat(paste(rep("=", 80), collapse = ""), "\n\n")

for (pt in rel_types) {
  sub <- pairs %>%
    filter(pair_type == pt, !is.na(iq_1), !is.na(iq_2))
  n_total <- nrow(sub)
  if (n_total == 0) next

  n_ww <- sum(sub$race_1 == 1 & sub$race_2 == 1, na.rm = TRUE)
  n_bb <- sum(sub$race_1 == 2 & sub$race_2 == 2, na.rm = TRUE)
  n_other_same <- sum(sub$same_race & !(sub$race_1 %in% c(1, 2)), na.rm = TRUE)
  n_cross <- sum(!sub$same_race, na.rm = TRUE)

  cat(sprintf("  %-28s  N=%5d  WW=%5d (%.0f%%)  BB=%5d (%.0f%%)  Other=%4d  Cross=%4d\n",
              nice_labels[pt], n_total,
              n_ww, 100 * n_ww / n_total,
              n_bb, 100 * n_bb / n_total,
              n_other_same, n_cross))
}

# ── 11. Full gradient using residualized IQ ──────────────────────────────────

cat("\n\n")
cat(paste(rep("=", 90), collapse = ""), "\n")
cat("FULL GENETIC RELATEDNESS GRADIENT — RESIDUALIZED WISC FSIQ\n")
cat("(Residualized on race + institution dummies)\n")
cat(paste(rep("=", 90), collapse = ""), "\n\n")

# Build the clean gradient table
# For R=0.5, use combined DZ+FS; keep MZ separate; etc.
gradient_types <- c("MZ_twin", "R=0.5 (DZ+FS)", "R=0.25 (HS+NN)",
                     "R=0.125 (FC+HNN)", "R=0.0625 (FC1R+HFC)", "second_cousin")
gradient_R <- c(1.0, 0.5, 0.25, 0.125, 0.0625, 0.03125)
gradient_labels <- c("MZ twin (R=1.0)", "DZ/FS (R=0.5)", "HS/NN (R=0.25)",
                      "FC/HNN (R=0.125)", "FC1R/HFC (R=0.0625)",
                      "2nd cousin (R=0.03125)")

gradient_table <- data.frame(
  group = gradient_labels,
  R = gradient_R,
  stringsAsFactors = FALSE
)

# Pull correlations for each
for (i in seq_along(gradient_types)) {
  gt <- gradient_types[i]

  if (gt %in% rel_types) {
    # Individual type (MZ, second_cousin)
    raw <- results_all %>% filter(pair_type == gt, method == "raw")
    resid <- results_all %>% filter(pair_type == gt, method == "resid_race_inst")
    white <- results_all %>% filter(pair_type == gt, method == "within_race", race == "White")
    black <- results_all %>% filter(pair_type == gt, method == "within_race", race == "Black")
  } else {
    # Combined group
    raw <- results_combined %>% filter(pair_type == gt, method == "raw")
    resid <- results_combined %>% filter(pair_type == gt, method == "resid_race_inst")
    white <- results_combined %>% filter(pair_type == gt, method == "within_race", race == "White")
    black <- results_combined %>% filter(pair_type == gt, method == "within_race", race == "Black")
  }

  gradient_table$n_raw[i] <- ifelse(nrow(raw) > 0, raw$n_pairs[1], NA)
  gradient_table$r_raw[i] <- ifelse(nrow(raw) > 0, raw$r[1], NA)
  gradient_table$se_raw[i] <- ifelse(nrow(raw) > 0, raw$se[1], NA)
  gradient_table$r_resid[i] <- ifelse(nrow(resid) > 0, resid$r[1], NA)
  gradient_table$se_resid[i] <- ifelse(nrow(resid) > 0, resid$se[1], NA)
  gradient_table$n_white[i] <- ifelse(nrow(white) > 0, white$n_pairs[1], NA)
  gradient_table$r_white[i] <- ifelse(nrow(white) > 0, white$r[1], NA)
  gradient_table$se_white[i] <- ifelse(nrow(white) > 0, white$se[1], NA)
  gradient_table$n_black[i] <- ifelse(nrow(black) > 0, black$n_pairs[1], NA)
  gradient_table$r_black[i] <- ifelse(nrow(black) > 0, black$r[1], NA)
  gradient_table$se_black[i] <- ifelse(nrow(black) > 0, black$se[1], NA)
}

cat(sprintf("%-26s  %8s  %6s  %8s  %8s  %6s  %8s  %6s  %8s\n",
            "Group", "R", "n", "r_raw", "r_resid", "n_W", "r_White", "n_B", "r_Black"))
cat(paste(rep("-", 105), collapse = ""), "\n")
for (i in seq_len(nrow(gradient_table))) {
  row <- gradient_table[i, ]
  cat(sprintf("%-26s  %8.4f  %6d  %8.4f  %8.4f  %6s  %8s  %6s  %8s\n",
              row$group, row$R,
              ifelse(is.na(row$n_raw), 0, row$n_raw),
              ifelse(is.na(row$r_raw), NA, row$r_raw),
              ifelse(is.na(row$r_resid), NA, row$r_resid),
              ifelse(is.na(row$n_white), "—", as.character(row$n_white)),
              ifelse(is.na(row$r_white), "—", sprintf("%.4f", row$r_white)),
              ifelse(is.na(row$n_black), "—", as.character(row$n_black)),
              ifelse(is.na(row$r_black), "—", sprintf("%.4f", row$r_black))))
}

# ── 12. Check monotonicity ──────────────────────────────────────────────────

cat("\n\n")
cat(paste(rep("=", 80), collapse = ""), "\n")
cat("MONOTONICITY CHECK\n")
cat(paste(rep("=", 80), collapse = ""), "\n\n")

check_monotonic <- function(r_vals, label) {
  valid <- !is.na(r_vals)
  if (sum(valid) < 2) {
    cat(sprintf("  %s: insufficient data\n", label))
    return(FALSE)
  }
  r_clean <- r_vals[valid]
  diffs <- diff(r_clean)
  is_mono <- all(diffs <= 0)
  cat(sprintf("  %s: %s\n", label,
              ifelse(is_mono, "YES — monotonically declining",
                     "NO — violations detected")))
  if (!is_mono) {
    violations <- which(diffs > 0)
    for (v in violations) {
      cat(sprintf("    Violation at step %d -> %d: %.4f -> %.4f (diff = +%.4f)\n",
                  v, v + 1, r_clean[v], r_clean[v + 1], diffs[v]))
    }
  }
  return(is_mono)
}

cat("Does correlation decline monotonically with decreasing R?\n\n")
check_monotonic(gradient_table$r_raw, "Raw correlations")
check_monotonic(gradient_table$r_resid, "Residualized (race+inst)")
check_monotonic(gradient_table$r_white, "Within-White")
check_monotonic(gradient_table$r_black, "Within-Black")

# ── 13. Inflation factor ────────────────────────────────────────────────────

cat("\n\n")
cat(paste(rep("=", 80), collapse = ""), "\n")
cat("INFLATION DUE TO POPULATION STRATIFICATION\n")
cat(paste(rep("=", 80), collapse = ""), "\n\n")

cat(sprintf("%-26s  %8s  %8s  %8s  %10s\n",
            "Group", "r_raw", "r_resid", "diff", "inflation%"))
cat(paste(rep("-", 75), collapse = ""), "\n")
for (i in seq_len(nrow(gradient_table))) {
  row <- gradient_table[i, ]
  if (!is.na(row$r_raw) & !is.na(row$r_resid)) {
    diff_val <- row$r_raw - row$r_resid
    pct <- ifelse(row$r_resid != 0, 100 * diff_val / row$r_resid, NA)
    cat(sprintf("%-26s  %8.4f  %8.4f  %8.4f  %9.1f%%\n",
                row$group, row$r_raw, row$r_resid, diff_val,
                ifelse(is.na(pct), 0, pct)))
  }
}

# ── 14. Detailed within-race table for individual pair types ─────────────────

cat("\n\n")
cat(paste(rep("=", 110), collapse = ""), "\n")
cat("DETAILED WITHIN-RACE CORRELATIONS BY PAIR TYPE\n")
cat(paste(rep("=", 110), collapse = ""), "\n\n")

for (pt in rel_types) {
  raw_r <- results_all %>% filter(pair_type == pt, method == "raw")
  white_r <- results_all %>% filter(pair_type == pt, method == "within_race", race == "White")
  black_r <- results_all %>% filter(pair_type == pt, method == "within_race", race == "Black")
  resid_r <- results_all %>% filter(pair_type == pt, method == "resid_race_inst")
  w_resid <- results_all %>% filter(pair_type == pt, method == "within_race_resid_inst", race == "White")
  b_resid <- results_all %>% filter(pair_type == pt, method == "within_race_resid_inst", race == "Black")

  cat(sprintf("  %s (R = %.4f)\n", nice_labels[pt], R_map[pt]))

  fmt_line <- function(label, df) {
    if (nrow(df) == 0 || is.na(df$r[1])) {
      cat(sprintf("    %-30s  n = %5s   r = %s\n", label, "—", "—"))
    } else {
      cat(sprintf("    %-30s  n = %5d   r = %.4f [%.4f, %.4f]\n",
                  label, df$n_pairs[1], df$r[1], df$ci_lo[1], df$ci_hi[1]))
    }
  }

  fmt_line("Raw (all races)", raw_r)
  fmt_line("Resid (race+inst)", resid_r)
  fmt_line("White only", white_r)
  fmt_line("Black only", black_r)
  fmt_line("White + resid(inst)", w_resid)
  fmt_line("Black + resid(inst)", b_resid)
  cat("\n")
}

# ── 15. Unrelated pair benchmark ──────────────────────────────────────────────
# Draw random pairs of children from DIFFERENT mothers and compute IQ
# correlations under progressively stricter matching (race, institution,
# race+institution). This tests whether population stratification alone
# produces the inflated raw cross-family correlations observed above.

cat("\n\n")
cat(paste(rep("=", 90), collapse = ""), "\n")
cat("UNRELATED PAIR BENCHMARK — STRATIFICATION TEST\n")
cat(paste(rep("=", 90), collapse = ""), "\n\n")

set.seed(42)

# Build individual-level data with mother ID
iq_unrel <- iq_data[has_iq, c("case_id", "race", "race_cat", "institution",
                               "wisc_fsiq", "wisc_fsiq_resid")]

# Mother ID: first 7 digits of case_id (CPP convention)
iq_unrel$mother_id <- substr(iq_unrel$case_id, 1, 7)
cat("Individuals with WISC FSIQ + covariates:", nrow(iq_unrel), "\n")
cat("Unique mothers:", length(unique(iq_unrel$mother_id)), "\n\n")

# Sample 100,000 random pairs from different mothers
n_pairs_target <- 100000
idx1 <- sample(nrow(iq_unrel), n_pairs_target, replace = TRUE)
idx2 <- sample(nrow(iq_unrel), n_pairs_target, replace = TRUE)

# Keep only pairs from different mothers
diff_mother <- iq_unrel$mother_id[idx1] != iq_unrel$mother_id[idx2]
idx1 <- idx1[diff_mother]
idx2 <- idx2[diff_mother]
cat("Random pairs from different mothers:", length(idx1), "\n")

# Build pair data
unrel_pairs <- data.frame(
  iq_1 = iq_unrel$wisc_fsiq[idx1],
  iq_2 = iq_unrel$wisc_fsiq[idx2],
  iq_resid_1 = iq_unrel$wisc_fsiq_resid[idx1],
  iq_resid_2 = iq_unrel$wisc_fsiq_resid[idx2],
  race_1 = iq_unrel$race[idx1],
  race_2 = iq_unrel$race[idx2],
  inst_1 = iq_unrel$institution[idx1],
  inst_2 = iq_unrel$institution[idx2]
)

# 1. Fully random (all pairs, different mothers)
r_random <- compute_cor(unrel_pairs$iq_1, unrel_pairs$iq_2)
cat(sprintf("  Fully random (diff mothers):        r = %.4f  (n = %d)\n",
            r_random$r, r_random$n_pairs))

# 2. Same race
same_race_idx <- unrel_pairs$race_1 == unrel_pairs$race_2
sub_sr <- unrel_pairs[same_race_idx, ]
r_same_race <- compute_cor(sub_sr$iq_1, sub_sr$iq_2)
cat(sprintf("  Same race:                          r = %.4f  (n = %d)\n",
            r_same_race$r, r_same_race$n_pairs))

# 3. Same institution
same_inst_idx <- as.character(unrel_pairs$inst_1) == as.character(unrel_pairs$inst_2)
sub_si <- unrel_pairs[same_inst_idx, ]
r_same_inst <- compute_cor(sub_si$iq_1, sub_si$iq_2)
cat(sprintf("  Same institution:                   r = %.4f  (n = %d)\n",
            r_same_inst$r, r_same_inst$n_pairs))

# 4. Same race + institution (raw IQ)
same_both_idx <- same_race_idx & same_inst_idx
sub_both <- unrel_pairs[same_both_idx, ]
r_same_both_raw <- compute_cor(sub_both$iq_1, sub_both$iq_2)
cat(sprintf("  Same race + institution (raw):      r = %.4f  (n = %d)\n",
            r_same_both_raw$r, r_same_both_raw$n_pairs))

# 5. Same race + institution (residualized IQ)
r_same_both_resid <- compute_cor(sub_both$iq_resid_1, sub_both$iq_resid_2)
cat(sprintf("  Same race + institution (resid):    r = %.4f  (n = %d)\n",
            r_same_both_resid$r, r_same_both_resid$n_pairs))

# Comparison with cousins
cousin_raw <- results_all %>% filter(pair_type == "first_cousin", method == "raw")
cousin_resid <- results_all %>% filter(pair_type == "first_cousin", method == "resid_race_inst")
cat(sprintf("\n  For comparison — first cousins:\n"))
cat(sprintf("    Raw:          r = %.4f  (n = %d)\n", cousin_raw$r[1], cousin_raw$n_pairs[1]))
cat(sprintf("    Residualized: r = %.4f  (n = %d)\n", cousin_resid$r[1], cousin_resid$n_pairs[1]))
cat(sprintf("    Unrelated/cousin ratio (raw): %.1f%%\n",
            100 * r_same_both_raw$r / cousin_raw$r[1]))

unrelated_benchmark <- data.frame(
  condition = c("Fully random", "Same race", "Same institution",
                "Same race + institution (raw)", "Same race + institution (resid)"),
  r = c(r_random$r, r_same_race$r, r_same_inst$r,
        r_same_both_raw$r, r_same_both_resid$r),
  n = c(r_random$n_pairs, r_same_race$n_pairs, r_same_inst$n_pairs,
        r_same_both_raw$n_pairs, r_same_both_resid$n_pairs)
)

# ── 16. Save results ────────────────────────────────────────────────────────

output <- list(
  # All individual correlations
  results_full       = results_full,
  # Clean gradient table
  gradient_table     = gradient_table,
  # Detailed by type + method
  by_type            = results_all,
  combined           = results_combined,
  # Model info
  resid_model_r2     = summary(mod)$r.squared,
  resid_model_coefs  = coef(mod),
  # Unrelated pair benchmark
  unrelated_benchmark = unrelated_benchmark,
  # Pair race composition
  pair_race_composition = pairs %>%
    filter(!is.na(iq_1), !is.na(iq_2)) %>%
    group_by(pair_type) %>%
    summarise(
      n_total = n(),
      n_white_white = sum(race_1 == 1 & race_2 == 1, na.rm = TRUE),
      n_black_black = sum(race_1 == 2 & race_2 == 2, na.rm = TRUE),
      n_cross_race = sum(!same_race, na.rm = TRUE),
      pct_white = round(100 * n_white_white / n_total, 1),
      pct_black = round(100 * n_black_black / n_total, 1),
      .groups = "drop"
    )
)

saveRDS(output, "cousin_correlations_adjusted.rds")
cat("\n\nResults saved to cousin_correlations_adjusted.rds\n")
