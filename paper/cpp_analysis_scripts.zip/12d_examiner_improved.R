#!/usr/bin/env Rscript
# 12d_examiner_improved.R — Improved four-factor model (7 WISC subtests, MLR)
# + extended MI sequence (WLSMV theta: configural through mean homogeneity)

library(data.table)
library(lavaan)

cat("=== Improved Examiner Models ===\n\n")

# ---- Load data ----
d <- as.data.table(readRDS("prepared_data.rds"))
d[, case_id := as.character(case_id)]

beh7 <- fread("../clean/master/parsed/card_41300_parsed.csv")
beh7[, case_id := as.character(case_id)]
beh7_fields <- fread("../clean/master/parsed/card_41300_fields.csv")
psy25_fields <- beh7_fields[grepl("PSY25", data_id)]
psy25_fields[, col_key := paste(data_col_from, data_col_to, sep = "-")]
psy25_unique <- psy25_fields[!duplicated(col_key)]
psy25_vars <- intersect(psy25_unique$varname, names(beh7))

for (col in psy25_vars) {
  beh7[, (col) := suppressWarnings(as.integer(get(col)))]
  fw <- psy25_unique[varname == col, field_width]
  if (length(fw) > 0 && fw == 2)
    beh7[!is.na(get(col)), (col) := as.integer(get(col) %/% 10)]
  beh7[get(col) %in% c(8, 9, 88, 99), (col) := NA_integer_]
}

psy25_good <- character(0)
for (col in psy25_vars) {
  v <- beh7[[col]][!is.na(beh7[[col]])]
  if (length(unique(v)) >= 2 && length(v) >= 5000)
    psy25_good <- c(psy25_good, col)
}

comp_items <- psy25_good[grepl("^comprehension", psy25_good)]
read_items <- psy25_good[grepl("^reading", psy25_good)]
pers_items <- psy25_good[grepl("^personality", psy25_good)]

beh7_merged <- merge(
  beh7[, c("case_id", psy25_good), with = FALSE],
  d[, .(case_id, race,
        wisc_info, wisc_comp, wisc_vocab, wisc_digit,
        wisc_picarr, wisc_block, wisc_coding,
        wrat_read_raw, wrat_spell_raw, wrat_arith_raw,
        bender_gestalt, goodenough_raw, wisc_fsiq, sb_iq)],
  by = "case_id"
)

beh7_bw <- beh7_merged[race %in% c(1, 2)]
beh7_bw[, group := factor(ifelse(race == 1, "White", "Black"),
                           levels = c("White", "Black"))]

# Examiner parcels (reverse-coded)
beh7_bw[, comp_parcel := rowMeans(.SD, na.rm = FALSE), .SDcols = comp_items]
beh7_bw[, read_parcel := rowMeans(.SD, na.rm = FALSE), .SDcols = read_items]
beh7_bw[, pers_parcel := rowMeans(.SD, na.rm = FALSE), .SDcols = pers_items]
for (p in c("comp_parcel", "read_parcel", "pers_parcel")) {
  mx <- max(beh7_bw[[p]], na.rm = TRUE)
  beh7_bw[, (p) := mx - get(p)]
}

cat(sprintf("Sample: N=%d (White=%d, Black=%d)\n\n",
            nrow(beh7_bw), sum(beh7_bw$group == "White"),
            sum(beh7_bw$group == "Black")))


# ====================================================================
# PART 1: FOUR-FACTOR MODEL WITH 7 WISC SUBTESTS (Section 8.2)
# ====================================================================
cat("================================================================\n")
cat("PART 1: FOUR-FACTOR MODEL (7 WISC subtests, MLR)\n")
cat("================================================================\n\n")

wisc7 <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
            "wisc_picarr", "wisc_block", "wisc_coding")
written5 <- c("wrat_read_raw", "wrat_spell_raw", "wrat_arith_raw",
              "bender_gestalt", "goodenough_raw")
parcels <- c("comp_parcel", "read_parcel", "pers_parcel")
all_ind <- c(wisc7, written5, parcels, "sb_iq")

cc <- beh7_bw[complete.cases(beh7_bw[, ..all_ind])]
cat(sprintf("Complete cases: %d (White=%d, Black=%d)\n",
            nrow(cc), sum(cc$group == "White"), sum(cc$group == "Black")))

for (v in all_ind) cc[, (paste0(v, "_z")) := scale(get(v))]
wisc_z <- paste0(wisc7, "_z")
writ_z <- paste0(written5, "_z")
parc_z <- paste0(parcels, "_z")

sb_rel <- 0.90
sb_resid <- var(cc$sb_iq_z) * (1 - sb_rel)

# --- Correlated four factors ---
cat("\n--- Correlated four-factor model ---\n")
model_4f <- paste0('
  g_wisc =~ ', paste(wisc_z, collapse = " + "), '
  g_writ =~ ', paste(writ_z, collapse = " + "), '
  g_exam =~ ', paste(parc_z, collapse = " + "), '
  g_sb   =~ sb_iq_z
  sb_iq_z ~~ ', sb_resid, ' * sb_iq_z
  g_wisc ~~ g_writ + g_exam + g_sb
  g_writ ~~ g_exam + g_sb
  g_exam ~~ g_sb
')

fit_4f <- cfa(model_4f, data = cc, estimator = "MLR", std.lv = TRUE)
fm_4f <- fitMeasures(fit_4f, c("chisq.scaled", "df.scaled", "cfi.robust",
                                "tli.robust", "rmsea.robust", "srmr"))
cat(sprintf("  CFI = %.4f, TLI = %.4f, RMSEA = %.4f, SRMR = %.4f\n",
            fm_4f["cfi.robust"], fm_4f["tli.robust"],
            fm_4f["rmsea.robust"], fm_4f["srmr"]))

pe_4f <- parameterEstimates(fit_4f, standardized = TRUE)
pe_4f <- as.data.table(pe_4f)
factors <- c("g_wisc", "g_writ", "g_exam", "g_sb")

cat("\n  Latent correlation matrix:\n")
cat(sprintf("  %-12s", ""))
for (f in factors) cat(sprintf("  %10s", f))
cat("\n")
for (fi in factors) {
  cat(sprintf("  %-12s", fi))
  for (fj in factors) {
    if (fi == fj) {
      cat(sprintf("  %10s", "1.000"))
    } else {
      r <- pe_4f[op == "~~" & ((lhs == fi & rhs == fj) | (lhs == fj & rhs == fi))]
      if (nrow(r) > 0) cat(sprintf("  %10.3f", r$std.all[1]))
      else cat(sprintf("  %10s", "---"))
    }
  }
  cat("\n")
}

cat("\n  Factor loadings:\n")
ld <- pe_4f[op == "=~"]
for (f in factors) {
  fl <- ld[lhs == f]
  for (i in 1:nrow(fl))
    cat(sprintf("    %s -> %-25s  %.3f\n", f, fl$rhs[i], fl$std.all[i]))
}

# --- Higher-order G ---
cat("\n--- Higher-order G model ---\n")
model_ho <- paste0('
  g_wisc =~ ', paste(wisc_z, collapse = " + "), '
  g_writ =~ ', paste(writ_z, collapse = " + "), '
  g_exam =~ ', paste(parc_z, collapse = " + "), '
  g_sb   =~ sb_iq_z
  sb_iq_z ~~ ', sb_resid, ' * sb_iq_z
  G =~ g_wisc + g_writ + g_exam + g_sb
')

fit_ho <- cfa(model_ho, data = cc, estimator = "MLR", std.lv = TRUE)
cat(sprintf("  Converged: %s\n", lavInspect(fit_ho, "converged")))

if (lavInspect(fit_ho, "converged")) {
  fm_ho <- fitMeasures(fit_ho, c("chisq.scaled", "df.scaled", "cfi.robust",
                                  "tli.robust", "rmsea.robust", "srmr"))
  cat(sprintf("  CFI = %.4f, TLI = %.4f, RMSEA = %.4f, SRMR = %.4f\n",
              fm_ho["cfi.robust"], fm_ho["tli.robust"],
              fm_ho["rmsea.robust"], fm_ho["srmr"]))

  pe_ho <- parameterEstimates(fit_ho, standardized = TRUE)
  pe_ho <- as.data.table(pe_ho)
  cat("\n  Higher-order loadings:\n")
  ho <- pe_ho[op == "=~" & lhs == "G"]
  for (i in 1:nrow(ho))
    cat(sprintf("    G -> %s: %.3f (SE %.3f)\n", ho$rhs[i], ho$std.all[i], ho$se[i]))
}


# ====================================================================
# PART 2: EXTENDED MI SEQUENCE (Section 8.3)
# WLSMV with theta parameterization on ordinal examiner items
# ====================================================================
cat("\n\n================================================================\n")
cat("PART 2: EXTENDED MI SEQUENCE (WLSMV, theta)\n")
cat("================================================================\n\n")

# Use only the clinical impression items (cognitive portion)
psy25_cog <- comp_items
cat(sprintf("Clinical impression items: %d — %s\n",
            length(psy25_cog), paste(psy25_cog, collapse = ", ")))

psy25_cfa <- character(0)
for (col in psy25_cog) {
  ok <- TRUE
  for (g in c("White", "Black")) {
    vals <- beh7_bw[group == g][[col]]
    vals <- vals[!is.na(vals)]
    tab <- table(vals)
    if (sum(tab >= 10) < 2) { ok <- FALSE; break }
  }
  if (ok) psy25_cfa <- c(psy25_cfa, col)
}
dropped <- setdiff(psy25_cog, psy25_cfa)
cat(sprintf("Items for MI: %d", length(psy25_cfa)))
if (length(dropped) > 0) cat(sprintf(" (dropped: %s)", paste(dropped, collapse = ", ")))
cat("\n")

mi_data <- copy(beh7_bw)
for (col in psy25_cfa) mi_data[, (col) := ordered(get(col))]
mi_cc <- mi_data[complete.cases(mi_data[, ..psy25_cfa])]
cat(sprintf("Sample: %d (White=%d, Black=%d)\n\n",
            nrow(mi_cc), sum(mi_cc$group == "White"), sum(mi_cc$group == "Black")))

examiner_model <- paste0("g_exam =~ ", paste(psy25_cfa, collapse = " + "))

# Fit all 6 models
# Under theta parameterization, latent means are fixed to 0 by default.
# From scalar onward, we explicitly free the group 2 mean so that
# mean homogeneity can be tested as a separate step.
cat("Fitting MI sequence...\n")

# Model with group 2 mean freed (used from scalar onward)
examiner_model_mean <- paste0(examiner_model, "\n  g_exam ~ c(0, NA) * 1")

fit1 <- cfa(examiner_model, data = mi_cc, group = "group",
            ordered = psy25_cfa, estimator = "WLSMV",
            parameterization = "theta")

fit2 <- cfa(examiner_model, data = mi_cc, group = "group",
            ordered = psy25_cfa, estimator = "WLSMV",
            parameterization = "theta",
            group.equal = "loadings")

fit3 <- cfa(examiner_model_mean, data = mi_cc, group = "group",
            ordered = psy25_cfa, estimator = "WLSMV",
            parameterization = "theta",
            group.equal = c("loadings", "thresholds"))

fit4 <- cfa(examiner_model_mean, data = mi_cc, group = "group",
            ordered = psy25_cfa, estimator = "WLSMV",
            parameterization = "theta",
            group.equal = c("loadings", "thresholds", "residuals"))

fit5 <- cfa(examiner_model_mean, data = mi_cc, group = "group",
            ordered = psy25_cfa, estimator = "WLSMV",
            parameterization = "theta",
            group.equal = c("loadings", "thresholds", "residuals",
                            "lv.variances"))

fit6 <- cfa(examiner_model, data = mi_cc, group = "group",
            ordered = psy25_cfa, estimator = "WLSMV",
            parameterization = "theta",
            group.equal = c("loadings", "thresholds", "residuals",
                            "lv.variances", "means"))

# Summary table
cat("\n--- MI Sequence Summary ---\n")
cat(sprintf("  %-25s  %10s  %5s  %8s  %8s  %10s  %8s\n",
            "Model", "Chi-sq", "df", "CFI", "RMSEA", "Delta_CFI", "Verdict"))

fits <- list(
  list("1. Configural", fit1, NULL),
  list("2. Metric", fit2, fit1),
  list("3. Scalar", fit3, fit2),
  list("4. Strict", fit4, fit3),
  list("5. Var homogeneity", fit5, fit4),
  list("6. Mean homogeneity", fit6, fit5)
)

for (m in fits) {
  fm <- fitMeasures(m[[2]], c("chisq.scaled", "df.scaled",
                               "cfi.scaled", "rmsea.scaled"))
  if (!is.null(m[[3]])) {
    dcfi <- fitMeasures(m[[3]], "cfi.scaled") - fm["cfi.scaled"]
    verdict <- ifelse(abs(dcfi) < 0.01, "PASS", "FAIL")
    dcfi_str <- sprintf("%.4f", dcfi)
  } else {
    dcfi_str <- "---"
    verdict <- "baseline"
  }
  cat(sprintf("  %-25s  %10.1f  %5.0f  %8.4f  %8.4f  %10s  %8s\n",
              m[[1]], fm["chisq.scaled"], fm["df.scaled"],
              fm["cfi.scaled"], fm["rmsea.scaled"], dcfi_str, verdict))
}

# Latent parameters from variance-homogeneity model (free mean)
cat("\nLatent parameters from variance-homogeneity model:\n")
pe5 <- parameterEstimates(fit5)
pe5 <- as.data.table(pe5)
for (g in 1:2) {
  glab <- c("White", "Black")[g]
  lv <- pe5[op == "~~" & lhs == "g_exam" & rhs == "g_exam" & group == g]
  lm <- pe5[op == "~1" & lhs == "g_exam" & group == g]
  cat(sprintf("  %s: variance = %.3f (SE %.3f)", glab, lv$est, lv$se))
  if (nrow(lm) > 0) cat(sprintf(", mean = %.3f (SE %.3f)", lm$est, lm$se))
  cat("\n")
}

# Latent mean gap in SD units
pe5_mean <- pe5[op == "~1" & lhs == "g_exam"]
pe5_var  <- pe5[op == "~~" & lhs == "g_exam" & rhs == "g_exam"]
if (nrow(pe5_mean) == 2 && nrow(pe5_var) >= 1) {
  gap <- pe5_mean$est[2] - pe5_mean$est[1]
  pooled_sd <- sqrt(pe5_var$est[1])  # constrained equal
  cat(sprintf("\n  Latent mean gap (Black - White): %.3f (%.2f SD)\n",
              gap, gap / pooled_sd))
}

cat("\nDone.\n")
