#!/usr/bin/env Rscript
# 17_replication_mcgrath.R
# Replication: McGrath et al. (2014)
# "Advanced paternal age is associated with impaired neurocognitive outcomes"
#
# Original finding: In ~33,000 CPP children, advanced paternal age was
# associated with poorer scores on SB (4yr) and WISC (7yr), after adjusting
# for maternal age and other confounders.
#
# Extension: Within-family (mother FE) paternal age effects.

library(data.table)
library(fixest)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")
ses <- fread(file.path("..", "clean", "cpp_ses_detailed.csv"),
             colClasses = c(case_id = "character", mother_id = "character"))

cat("\n")
cat("--- REPLICATION: McGrath et al. (2014) Advanced Paternal Age and Neurocognitive Outcomes ---
")

# ── Merge father's age ────────────────────────────────────────────────
father_fields <- c("father_age", "father_education")
missing_father_fields <- setdiff(father_fields, names(d))
if (length(missing_father_fields)) {
  d <- merge(
    d,
    ses[, c("case_id", missing_father_fields), with = FALSE],
    by = "case_id",
    all.x = TRUE
  )
}

# Clean father_age
d[father_age %in% c(0, 99), father_age := NA_integer_]
d[father_age < 12 | father_age > 70, father_age := NA_integer_]

cat(sprintf("\nChildren with father's age: %d (%.1f%%)\n",
            d[!is.na(father_age), .N],
            100 * d[!is.na(father_age), .N] / nrow(d)))
cat(sprintf("  Mean paternal age: %.1f (SD = %.1f)\n",
            d[, mean(father_age, na.rm = TRUE)],
            d[, sd(father_age, na.rm = TRUE)]))
cat(sprintf("  Range: %d - %d\n",
            d[, min(father_age, na.rm = TRUE)],
            d[, max(father_age, na.rm = TRUE)]))

# Create paternal age categories (matching McGrath)
d[, pat_age_cat := fcase(
  father_age < 20, "<20",
  father_age < 25, "20-24",
  father_age < 30, "25-29",
  father_age < 35, "30-34",
  father_age < 40, "35-39",
  father_age < 45, "40-44",
  father_age >= 45, "45+",
  default = NA_character_
)]

# Create married indicator (1 = married)
d[, married := as.integer(marital == 1)]

# PART A: CLOSE REPLICATION — Singleton, Term Births
# McGrath et al. restricted to singleton, live-born, term (GA>=37) births.
# Covariates: maternal age, race, education, SEI, marital status,
#             parity, child sex.
cat("\n")
cat("--- PART A: CLOSE REPLICATION — McGrath et al. (2014) Sample: singleton, term births (GA >= 37 weeks) ---
")

# Apply McGrath's sample restrictions
d_close <- d[plurality == 0 & gest_age >= 37 & !is.na(father_age)]
cat(sprintf("\n  Full sample with father_age: %d\n", d[!is.na(father_age), .N]))
cat(sprintf("  After singleton restriction: %d\n",
            d[plurality == 0 & !is.na(father_age), .N]))
cat(sprintf("  After term (GA>=37) restriction: %d\n", nrow(d_close)))

# Close replication regression: WISC FSIQ
cat("\n  WISC FSIQ — Close Replication Models:\n")
cat(sprintf("  %-50s  %8s  %8s  %8s  %5s\n", "Model", "b(pat_age)", "SE", "p", "N"))
cat("  ", strrep("-", 75), "\n")

mc1 <- lm(wisc_fsiq ~ father_age, data = d_close)
cat(sprintf("  %-50s  %8.3f  %8.3f  %8.4f  %5d\n",
            "Unadjusted",
            coef(mc1)["father_age"], summary(mc1)$coef["father_age", 2],
            summary(mc1)$coef["father_age", 4], nobs(mc1)))

mc2 <- lm(wisc_fsiq ~ father_age + maternal_age, data = d_close)
cat(sprintf("  %-50s  %8.3f  %8.3f  %8.4f  %5d\n",
            "+ maternal age",
            coef(mc2)["father_age"], summary(mc2)$coef["father_age", 2],
            summary(mc2)$coef["father_age", 4], nobs(mc2)))

mc3 <- lm(wisc_fsiq ~ father_age + maternal_age + race + sex + educ_yrs +
             sei_decimal + married + parity, data = d_close)
cat(sprintf("  %-50s  %8.3f  %8.3f  %8.4f  %5d\n",
            "+ race, sex, educ, SEI, marital, parity",
            coef(mc3)["father_age"], summary(mc3)$coef["father_age", 2],
            summary(mc3)$coef["father_age", 4], nobs(mc3)))

# Close replication: SB IQ
cat("\n  Stanford-Binet IQ — Close Replication Models:\n")
cat(sprintf("  %-50s  %8s  %8s  %8s  %5s\n", "Model", "b(pat_age)", "SE", "p", "N"))
cat("  ", strrep("-", 75), "\n")

mc4 <- lm(sb_iq ~ father_age + maternal_age + race + sex + educ_yrs +
             sei_decimal + married + parity, data = d_close)
cat(sprintf("  %-50s  %8.3f  %8.3f  %8.4f  %5d\n",
            "Fully adjusted",
            coef(mc4)["father_age"], summary(mc4)$coef["father_age", 2],
            summary(mc4)$coef["father_age", 4], nobs(mc4)))

cat("\n  McGrath et al. original: ~0.5-point FSIQ decrease per 10-year increase\n")
cat(sprintf("  Our close replication (per 10-yr): %.2f points\n",
            coef(mc3)["father_age"] * 10))

# ---- PART B: EXTENSION — Full Sample + Mother Fixed Effects ----
cat("\n")
cat("--- PART B: EXTENSION — Full Sample + Mother Fixed Effects ---
")

cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE 1: Mean IQ by Paternal Age Category (Full Sample)\n")
cat(strrep("-", 70), "\n")

pat_tab <- d[!is.na(pat_age_cat), .(
  mean_sb = mean(sb_iq, na.rm = TRUE),
  n_sb = sum(!is.na(sb_iq)),
  mean_wisc = mean(wisc_fsiq, na.rm = TRUE),
  n_wisc = sum(!is.na(wisc_fsiq)),
  mean_mat_age = mean(maternal_age, na.rm = TRUE),
  mean_educ = mean(educ_yrs, na.rm = TRUE),
  mean_sei = mean(sei_decimal, na.rm = TRUE)
), by = pat_age_cat]

# Order categories
pat_tab[, pat_age_cat := factor(pat_age_cat,
  levels = c("<20", "20-24", "25-29", "30-34", "35-39", "40-44", "45+"))]
pat_tab <- pat_tab[order(pat_age_cat)]

cat(sprintf("\n  %-8s  %8s (%5s)  %8s (%5s)  %6s  %5s  %6s\n",
            "Pat Age", "SB IQ", "N", "WISC IQ", "N", "MatAge", "Educ", "SEI"))
cat("  ", strrep("-", 70), "\n")
for (i in 1:nrow(pat_tab)) {
  cat(sprintf("  %-8s  %8.1f (%5d)  %8.1f (%5d)  %6.1f  %5.1f  %6.1f\n",
              as.character(pat_tab[i, pat_age_cat]),
              pat_tab[i, mean_sb], pat_tab[i, n_sb],
              pat_tab[i, mean_wisc], pat_tab[i, n_wisc],
              pat_tab[i, mean_mat_age], pat_tab[i, mean_educ],
              pat_tab[i, mean_sei]))
}

cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE 2: OLS Regression — IQ on Paternal Age (Full Sample)\n")
cat(strrep("-", 70), "\n")

# Models for WISC FSIQ
cat("\nWISC FSIQ:\n")
cat(sprintf("  %-45s  %8s  %8s  %8s  %5s\n", "Model", "b(pat_age)", "SE", "p", "N"))
cat("  ", strrep("-", 75), "\n")

m1 <- lm(wisc_fsiq ~ father_age, data = d)
cat(sprintf("  %-45s  %8.3f  %8.3f  %8.4f  %5d\n",
            "Unadjusted",
            coef(m1)["father_age"], summary(m1)$coef["father_age", 2],
            summary(m1)$coef["father_age", 4], nobs(m1)))

m2 <- lm(wisc_fsiq ~ father_age + maternal_age, data = d)
cat(sprintf("  %-45s  %8.3f  %8.3f  %8.4f  %5d\n",
            "+ maternal age",
            coef(m2)["father_age"], summary(m2)$coef["father_age", 2],
            summary(m2)$coef["father_age", 4], nobs(m2)))

m3 <- lm(wisc_fsiq ~ father_age + maternal_age + race + sex + educ_yrs +
           sei_decimal, data = d)
cat(sprintf("  %-45s  %8.3f  %8.3f  %8.4f  %5d\n",
            "+ race, sex, education, SEI",
            coef(m3)["father_age"], summary(m3)$coef["father_age", 2],
            summary(m3)$coef["father_age", 4], nobs(m3)))

m4 <- lm(wisc_fsiq ~ father_age + maternal_age + race + sex + educ_yrs +
           sei_decimal + birth_wt_g + gest_age + parity, data = d)
cat(sprintf("  %-45s  %8.3f  %8.3f  %8.4f  %5d\n",
            "+ birth weight, gest. age, parity",
            coef(m4)["father_age"], summary(m4)$coef["father_age", 2],
            summary(m4)$coef["father_age", 4], nobs(m4)))

# Quadratic
m5 <- lm(wisc_fsiq ~ father_age + I(father_age^2) + maternal_age + race +
           sex + educ_yrs + sei_decimal, data = d)
cat(sprintf("  %-45s  %8.3f  %8.3f  %8.4f  %5d\n",
            "Quadratic (linear term)",
            coef(m5)["father_age"], summary(m5)$coef["father_age", 2],
            summary(m5)$coef["father_age", 4], nobs(m5)))
cat(sprintf("  %-45s  %8.4f  %8.4f  %8.4f\n",
            "  (quadratic term)",
            coef(m5)["I(father_age^2)"], summary(m5)$coef["I(father_age^2)", 2],
            summary(m5)$coef["I(father_age^2)", 4]))

# Models for SB IQ
cat("\nStanford-Binet IQ:\n")
cat(sprintf("  %-45s  %8s  %8s  %8s  %5s\n", "Model", "b(pat_age)", "SE", "p", "N"))
cat("  ", strrep("-", 75), "\n")

m1s <- lm(sb_iq ~ father_age, data = d)
cat(sprintf("  %-45s  %8.3f  %8.3f  %8.4f  %5d\n",
            "Unadjusted",
            coef(m1s)["father_age"], summary(m1s)$coef["father_age", 2],
            summary(m1s)$coef["father_age", 4], nobs(m1s)))

m3s <- lm(sb_iq ~ father_age + maternal_age + race + sex + educ_yrs +
            sei_decimal, data = d)
cat(sprintf("  %-45s  %8.3f  %8.3f  %8.4f  %5d\n",
            "+ maternal age, race, sex, education, SEI",
            coef(m3s)["father_age"], summary(m3s)$coef["father_age", 2],
            summary(m3s)$coef["father_age", 4], nobs(m3s)))

# TABLE 3: Within-Family (Mother FE) Paternal Age Effects
cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE 3: Within-Family (Mother FE) — Paternal Age on IQ\n")
cat(strrep("-", 70), "\n")
cat("  (Controls for all time-invariant maternal characteristics)\n\n")

# WISC FSIQ
fe1 <- feols(wisc_fsiq ~ father_age | mother_id, data = d, vcov = ~mother_id)
fe2 <- feols(wisc_fsiq ~ father_age + sex + birth_wt_g + gest_age | mother_id,
             data = d, vcov = ~mother_id)
fe2_rank <- feols(wisc_fsiq ~ father_age + birth_order | mother_id,
                  data = d, vcov = ~mother_id)

cat("WISC FSIQ:\n")
cat(sprintf("  %-40s  b = %7.3f (SE = %.3f, p = %.4f), N = %d\n",
            "Father age only (mother FE)",
            coef(fe1)["father_age"], se(fe1)["father_age"],
            pvalue(fe1)["father_age"], fe1$nobs))
cat(sprintf("  %-40s  b = %7.3f (SE = %.3f, p = %.4f), N = %d\n",
            "+ sex, birth weight, gest. age",
            coef(fe2)["father_age"], se(fe2)["father_age"],
            pvalue(fe2)["father_age"], fe2$nobs))
cat(sprintf("  %-40s  b = %7.3f (SE = %.3f, p = %.4f), N = %d\n",
            "+ corrected live-birth order",
            coef(fe2_rank)["father_age"], se(fe2_rank)["father_age"],
            pvalue(fe2_rank)["father_age"], fe2_rank$nobs))

# SB IQ
fe3 <- feols(sb_iq ~ father_age | mother_id, data = d, vcov = ~mother_id)
fe4 <- feols(sb_iq ~ father_age + sex + birth_wt_g + gest_age | mother_id,
             data = d, vcov = ~mother_id)
fe4_rank <- feols(sb_iq ~ father_age + birth_order | mother_id,
                  data = d, vcov = ~mother_id)

cat("\nStanford-Binet IQ:\n")
cat(sprintf("  %-40s  b = %7.3f (SE = %.3f, p = %.4f), N = %d\n",
            "Father age only (mother FE)",
            coef(fe3)["father_age"], se(fe3)["father_age"],
            pvalue(fe3)["father_age"], fe3$nobs))
cat(sprintf("  %-40s  b = %7.3f (SE = %.3f, p = %.4f), N = %d\n",
            "+ sex, birth weight, gest. age",
            coef(fe4)["father_age"], se(fe4)["father_age"],
            pvalue(fe4)["father_age"], fe4$nobs))
cat(sprintf("  %-40s  b = %7.3f (SE = %.3f, p = %.4f), N = %d\n",
            "+ corrected live-birth order",
            coef(fe4_rank)["father_age"], se(fe4_rank)["father_age"],
            pvalue(fe4_rank)["father_age"], fe4_rank$nobs))

# ── Comparison ────────────────────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Comparison with McGrath et al. (2014):\n")
cat(strrep("-", 70), "\n")
cat("  Original: N ~ 33,000, WISC at age 7\n")
cat("  Original: Negative linear association after adjustment\n")
cat("  Original: ~0.5-point FSIQ decrease per 10-year paternal age increase\n")
cat("  Extension: Mother fixed effects control for all shared family factors\n")

# ── Save ──────────────────────────────────────────────────────────────
results <- list(
  pat_age_table = pat_tab,
  ols_wisc = list(m1 = m1, m2 = m2, m3 = m3, m4 = m4, m5 = m5),
  ols_sb = list(m1 = m1s, m3 = m3s),
  fe_wisc = list(fe1 = fe1, fe2 = fe2, fe2_rank = fe2_rank),
  fe_sb = list(fe3 = fe3, fe4 = fe4, fe4_rank = fe4_rank)
)
saveRDS(results, "results_replication_mcgrath.rds")
cat("\nResults saved to results_replication_mcgrath.rds\n")
