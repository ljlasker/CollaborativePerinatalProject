#!/usr/bin/env Rscript
# fig_between_group.R — Between-group decomposition visualization
# Panel A: Observed gaps vs genetic/environmental predicted components
# Panel B: IP genetic vs environmental loading profiles

setwd("C:/Users/14787/Documents/Research/Miscellaneous/Substack/Claude Code/breastfeeding_iq/cpp_data/analysis_paper")

res <- readRDS("results_between_group_expanded.rds")

# ── Panel A: Observed gap vs genetic + environmental predicted ────────
sub_labels <- res$labels
obs  <- res$obs_gaps
kA   <- res$kA
kC   <- res$kC
ac   <- res$ac
cc   <- res$cc

# Genetic and environmental contributions
a_contrib <- kA * ac
c_contrib <- kC * cc

# Order by observed gap magnitude
ord <- order(obs, decreasing = TRUE)

pdf("fig_between_group.pdf", width = 10, height = 5.5)

# ── Panel A ──────────────────────────────────────────────────────────
par(mar = c(4.5, 5, 2.5, 1), family = "serif")

x <- barplot(obs[ord], names.arg = sub_labels[ord], las = 2,
             col = "gray85", border = "gray60",
             ylim = c(min(c_contrib) - 0.05, max(obs) * 1.15),
             ylab = "Black\u2013White gap (SD units)", cex.names = 0.85,
             cex.axis = 0.9, cex.lab = 1)

# Overlay predicted total
pred <- a_contrib + c_contrib
points(x, pred[ord], pch = 4, col = "black", cex = 1.3, lwd = 2)

# Genetic component markers
points(x, a_contrib[ord], pch = 16, col = "#8B1A1A", cex = 1.2)
# Environmental component markers
points(x, c_contrib[ord], pch = 17, col = "#2C3E50", cex = 1.2)

# Connect predicted to observed with thin lines
segments(x, obs[ord], x, pred[ord], lty = 3, col = "gray50")

abline(h = 0, col = "gray40")

legend("topright",
       legend = c("Observed gap", "Predicted total",
                   expression(hat(kappa)[A] %.% a[c]),
                   expression(hat(kappa)[C] %.% c[c])),
       col = c("gray60", "black", "#8B1A1A", "#2C3E50"),
       pch = c(22, 4, 16, 17),
       pt.bg = c("gray85", NA, NA, NA),
       pt.cex = c(1.5, 1.3, 1.2, 1.2), lwd = c(NA, 2, NA, NA),
       bty = "n", cex = 0.9)

mtext(bquote(R^2 == .(sprintf("%.3f", res$R2_decomp)) ~
             "; Shapley:" ~ .(sprintf("%.1f%%", 100 * res$shapley_A)) ~
             "genetic," ~ .(sprintf("%.1f%%", 100 * res$shapley_C)) ~
             "environmental"),
      side = 3, line = 0.3, cex = 0.85, col = "gray40")

dev.off()
cat("Saved fig_between_group.pdf\n")
