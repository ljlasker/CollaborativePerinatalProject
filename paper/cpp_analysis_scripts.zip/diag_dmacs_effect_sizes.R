#!/usr/bin/env Rscript
# diag_dmacs_effect_sizes.R — dMACS effect sizes for measurement non-invariance
#
# Two approaches:
#   1. Full scalar vs. partial scalar latent mean comparison
#   2. Per-item dMACS_True from the partial scalar model (freed items only)
#
# Methods: Nye & Drasgow (2019), Nye, Drasgow, Rounds, Hulin & Sun (2019)
#
# The configural-model dMACS conflates true latent differences with measurement
# bias (both groups have factor mean = 0). The partial scalar model separates
# these: constrained items have dMACS = 0 by construction; freed items capture
# the remaining non-invariance bias.

library(data.table)
library(lavaan)

cat("--- dMACS Effect Sizes for Measurement Non-Invariance ---\n\n")

# ── Data prep (identical to diag_spearman_bifactor.R) ──────────────────────

d <- readRDS("prepared_data.rds")
d <- as.data.table(d)

for (v in c("wisc_picarr", "wisc_block", "wisc_coding"))
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "Digit", "PicArr",
                "Block", "Coding", "WRAT Read", "Bender",
                "WRAT Spell", "WRAT Arith", "Goodenough")
nv <- length(sub_vars)

v_idx <- c(1, 2, 3, 4, 8, 10, 11)  # Verbal-factor indicators
p_idx <- c(5, 6, 7, 9, 12)          # g-only indicators

ord_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding")

d[, race_grp := factor(race, levels = c(1, 2), labels = c("White", "Black"))]
dat <- as.data.frame(d[!is.na(race_grp), c(..sub_vars, "mother_id", "race_grp")])
dat <- dat[complete.cases(dat[, sub_vars]), ]

cat(sprintf("N = %d (White = %d, Black = %d) [complete cases]\n",
            nrow(dat), sum(dat$race_grp == "White"), sum(dat$race_grp == "Black")))

# Collapse empty categories for ordered variables
for (v in ord_vars) {
  repeat {
    changed <- FALSE
    vals <- sort(unique(dat[[v]][!is.na(dat[[v]])]))
    for (val in vals) {
      nw <- sum(dat[[v]][dat$race_grp == "White"] == val, na.rm = TRUE)
      nb <- sum(dat[[v]][dat$race_grp == "Black"] == val, na.rm = TRUE)
      if (nw == 0 || nb == 0) {
        others <- vals[vals != val]
        if (length(others) == 0) break
        nearest <- others[which.min(abs(others - val))]
        dat[[v]][dat[[v]] == val & !is.na(dat[[v]])] <- nearest
        changed <- TRUE
        break
      }
    }
    if (!changed) break
  }
}

# Pooled SDs and observed gaps
pool_sds <- numeric(nv)
gaps_d   <- numeric(nv)
for (i in 1:nv) {
  xw <- dat[[sub_vars[i]]][dat$race_grp == "White"]
  xb <- dat[[sub_vars[i]]][dat$race_grp == "Black"]
  sdp <- sqrt((var(xw, na.rm = TRUE) * (sum(!is.na(xw)) - 1) +
               var(xb, na.rm = TRUE) * (sum(!is.na(xb)) - 1)) /
              (sum(!is.na(xw)) + sum(!is.na(xb)) - 2))
  pool_sds[i] <- sdp
  gaps_d[i] <- (mean(xw, na.rm = TRUE) - mean(xb, na.rm = TRUE)) / sdp
}

# Load MI results for freed parameter lists
mi_res <- readRDS("results_spearman_bifactor.rds")
cat(sprintf("\nFreed parameters from MI analysis:\n"))
cat(sprintf("  BF loading: %s\n", paste(mi_res$bf_freed_loadings, collapse = ", ")))
cat(sprintf("  BF scalar:  %s\n", paste(mi_res$bf_freed_scalar, collapse = ", ")))
cat(sprintf("  HO loading: %s\n", paste(mi_res$ho_freed_loadings, collapse = ", ")))
cat(sprintf("  HO scalar:  %s\n", paste(mi_res$ho_freed_scalar, collapse = ", ")))


# ---- SECTION 1: Full vs. Partial Scalar Latent Mean Comparison ----

cat("--- SECTION 1: Full Scalar vs. Partial Scalar Latent Means | (How much does freeing non-invariant items change the g gap?) ---\n")

# ── 1a. Higher-Order Model (MLR) ──

ho_base <- '
  Gc =~ NA*wisc_info + wisc_comp + wisc_vocab
  Gv =~ NA*wisc_picarr + wisc_block + goodenough_raw
  Grw =~ NA*wrat_read_raw + wrat_spell_raw + wrat_arith_raw
  Gs =~ NA*wisc_digit + bender_gestalt + wisc_coding
  g =~ NA*Gc + Gv + Grw + Gs
  g ~~ 1*g
  Gs ~~ 0*Gs
'
ho_means <- paste0(ho_base, '
  Gc ~ c(0, NA)*1; Gv ~ c(0, NA)*1; Grw ~ c(0, NA)*1; Gs ~ c(0, NA)*1
')

# Second-order loadings always freed (structural, not measurement)
ho_2nd_order_gp <- c("g =~ Gc", "g =~ Gv", "g =~ Grw", "g =~ Gs")

# HO loading params map
ho_loading_params <- list()
for (v in sub_vars[c(1,2,3)])   ho_loading_params[[v]] <- paste0("Gc =~ ", v)
for (v in sub_vars[c(5,6,12)])  ho_loading_params[[v]] <- paste0("Gv =~ ", v)
for (v in sub_vars[c(8,10,11)]) ho_loading_params[[v]] <- paste0("Grw =~ ", v)
for (v in sub_vars[c(4,9,7)])   ho_loading_params[[v]] <- paste0("Gs =~ ", v)

# Build group.partial for HO freed loading
ho_gp_loading <- ho_2nd_order_gp
for (v in mi_res$ho_freed_loadings) {
  if (v %in% names(ho_loading_params))
    ho_gp_loading <- c(ho_gp_loading, ho_loading_params[[v]])
}

# Full scalar: only metric-level frees
ho_gp_full_scalar <- ho_gp_loading

# Partial scalar: also free scalar-level items
ho_gp_partial_scalar <- ho_gp_loading
for (v in mi_res$ho_freed_scalar)
  ho_gp_partial_scalar <- c(ho_gp_partial_scalar, paste0(v, " ~ 1"))

cat("--- Higher-Order Model (MLR) ---\n\n")
cat("Fitting HO full scalar...\n")
ho_full <- suppressWarnings(
  cfa(ho_means, data = dat, group = "race_grp", estimator = "MLR",
      group.equal = c("loadings", "intercepts"), group.partial = ho_gp_full_scalar)
)
cat("Fitting HO partial scalar...\n")
ho_partial <- suppressWarnings(
  cfa(ho_means, data = dat, group = "race_grp", estimator = "MLR",
      group.equal = c("loadings", "intercepts"), group.partial = ho_gp_partial_scalar)
)

# Extract latent means (Black group)
pe_ho_full <- as.data.table(parameterEstimates(ho_full))
pe_ho_part <- as.data.table(parameterEstimates(ho_partial))

ho_means_full <- pe_ho_full[op == "~1" & group == 2 & lhs %in% c("Gc","Gv","Grw","Gs")]
ho_means_part <- pe_ho_part[op == "~1" & group == 2 & lhs %in% c("Gc","Gv","Grw","Gs")]

cat("\n  HO Latent Means (Black - White, SD units):\n")
cat(sprintf("  %-8s  %12s  %12s  %12s\n", "Factor", "Full Scalar", "Partial", "Difference"))
for (f in c("Gc", "Gv", "Grw", "Gs")) {
  m_full <- ho_means_full[lhs == f, est]
  m_part <- ho_means_part[lhs == f, est]
  if (length(m_full) > 0 && length(m_part) > 0)
    cat(sprintf("  %-8s  %+12.4f  %+12.4f  %+12.4f\n", f, m_full, m_part, m_full - m_part))
}

ho_cfi_full <- as.numeric(fitMeasures(ho_full, "cfi.robust"))
ho_cfi_part <- as.numeric(fitMeasures(ho_partial, "cfi.robust"))
cat(sprintf("\n  CFI: full=%.4f, partial=%.4f, Δ=%.4f\n",
            ho_cfi_full, ho_cfi_part, ho_cfi_full - ho_cfi_part))

# ── 1b. Bifactor Model (WLSMV) ──

bf_base <- '
  g =~ NA*wisc_info + wisc_comp + wisc_vocab + wisc_digit +
       wisc_picarr + wisc_block + wisc_coding +
       wrat_read_raw + bender_gestalt +
       wrat_spell_raw + wrat_arith_raw + goodenough_raw
  V =~ NA*wisc_info + wisc_comp + wisc_vocab + wisc_digit +
       wrat_read_raw + wrat_spell_raw + wrat_arith_raw
  g ~~ 1*g; V ~~ 1*V
  g ~~ 0*V
'
bf_means <- paste0(bf_base, '
  g ~ c(0, NA)*1; V ~ c(0, NA)*1
')

wlsmv_scalar_eq <- c("loadings", "thresholds", "intercepts")

# BF loading params map
bf_loading_params <- list()
for (v in sub_vars) {
  params <- paste0("g =~ ", v)
  if (v %in% sub_vars[v_idx]) params <- c(params, paste0("V =~ ", v))
  bf_loading_params[[v]] <- params
}

# Build group.partial for BF freed loading
bf_gp_loading <- character(0)
for (v in mi_res$bf_freed_loadings) {
  if (v %in% names(bf_loading_params))
    bf_gp_loading <- c(bf_gp_loading, bf_loading_params[[v]])
}

# Full scalar: only metric-level frees
bf_gp_full_scalar <- bf_gp_loading

# Partial scalar: also free scalar-level items
bf_gp_partial_scalar <- bf_gp_loading
for (v in mi_res$bf_freed_scalar) {
  if (v %in% ord_vars) {
    bf_gp_partial_scalar <- c(bf_gp_partial_scalar, paste0(v, "|t", 1:25))
  } else {
    bf_gp_partial_scalar <- c(bf_gp_partial_scalar, paste0(v, " ~ 1"))
  }
}

cat("\n--- Bifactor Model (WLSMV) ---\n\n")
cat("Fitting BF full scalar...\n")
bf_full <- suppressWarnings(
  cfa(bf_means, data = dat, group = "race_grp", estimator = "WLSMV",
      ordered = ord_vars,
      group.equal = wlsmv_scalar_eq, group.partial = bf_gp_full_scalar)
)
cat("Fitting BF partial scalar...\n")
bf_partial <- suppressWarnings(
  cfa(bf_means, data = dat, group = "race_grp", estimator = "WLSMV",
      ordered = ord_vars,
      group.equal = wlsmv_scalar_eq, group.partial = bf_gp_partial_scalar)
)

# Extract latent means (Black group)
pe_bf_full <- as.data.table(parameterEstimates(bf_full))
pe_bf_part <- as.data.table(parameterEstimates(bf_partial))

bf_g_full <- pe_bf_full[op == "~1" & lhs == "g" & group == 2]
bf_V_full <- pe_bf_full[op == "~1" & lhs == "V" & group == 2]
bf_g_part <- pe_bf_part[op == "~1" & lhs == "g" & group == 2]
bf_V_part <- pe_bf_part[op == "~1" & lhs == "V" & group == 2]

cat("\n  BF Latent Means (Black - White, SD units):\n")
cat(sprintf("  %-8s  %12s  %12s  %12s\n", "Factor", "Full Scalar", "Partial", "Difference"))
cat(sprintf("  %-8s  %+12.4f  %+12.4f  %+12.4f\n", "g",
            bf_g_full$est, bf_g_part$est, bf_g_full$est - bf_g_part$est))
cat(sprintf("  %-8s  %+12.4f  %+12.4f  %+12.4f\n", "V",
            bf_V_full$est, bf_V_part$est, bf_V_full$est - bf_V_part$est))

bf_cfi_full <- as.numeric(fitMeasures(bf_full, "cfi.scaled"))
bf_cfi_part <- as.numeric(fitMeasures(bf_partial, "cfi.scaled"))
cat(sprintf("\n  CFI: full=%.4f, partial=%.4f, Δ=%.4f\n",
            bf_cfi_full, bf_cfi_part, bf_cfi_full - bf_cfi_part))

# Summary
cat("\n--- Impact Summary ---\n\n")
cat(sprintf("  HO model: freeing %d intercept(s) changes latent means by < %.3f SD\n",
            length(mi_res$ho_freed_scalar),
            max(abs(ho_means_full$est - ho_means_part$est))))
bf_g_shift <- bf_g_full$est - bf_g_part$est
bf_V_shift <- bf_V_full$est - bf_V_part$est
cat(sprintf("  BF model: freeing 8 thresholds/intercepts shifts g gap by %+.3f SD\n",
            bf_g_shift))
cat(sprintf("            and V gap by %+.3f SD\n", bf_V_shift))
cat(sprintf("  BF g gap: full scalar = %.3f SD, partial scalar = %.3f SD\n",
            bf_g_full$est, bf_g_part$est))


# ---- SECTION 2: Per-Item dMACS from Partial Scalar Model ----

cat("--- SECTION 2: Per-Item dMACS from Partial Scalar Models | (dMACS = 0 for constrained items; > 0 only for freed items) ---\n")

# ── Helper: expected score for ordered item ──
expected_score_ordered <- function(eta_lin, thresholds, values) {
  K <- length(values)
  probs <- numeric(K)
  for (j in 1:K) {
    upper <- if (j < K) pnorm(thresholds[j] - eta_lin) else 1.0
    lower <- if (j > 1) pnorm(thresholds[j-1] - eta_lin) else 0.0
    probs[j] <- max(0, upper - lower)
  }
  sum(values * probs)
}

# ── 2a. HO Model Per-Item dMACS ──

cat("--- HO Model (MLR, partial scalar) ---\n\n")

# Determine freed items
ho_freed_items <- union(mi_res$ho_freed_loadings, mi_res$ho_freed_scalar)

# Factor assignment
factor_map <- list(
  Gc  = c("wisc_info", "wisc_comp", "wisc_vocab"),
  Gv  = c("wisc_picarr", "wisc_block", "goodenough_raw"),
  Grw = c("wrat_read_raw", "wrat_spell_raw", "wrat_arith_raw"),
  Gs  = c("wisc_digit", "bender_gestalt", "wisc_coding")
)
var_to_factor <- character(nv)
for (f in names(factor_map))
  for (v in factor_map[[f]])
    var_to_factor[match(v, sub_vars)] <- f

# First-order factor variances from partial scalar model (reference group)
cov_lv_ho <- lavInspect(ho_partial, "cov.lv")$White

ho_dmacs <- data.table(
  var = sub_vars, label = sub_labels, factor = var_to_factor,
  freed_loading = sub_vars %in% mi_res$ho_freed_loadings,
  freed_scalar = sub_vars %in% mi_res$ho_freed_scalar,
  sd_pool = pool_sds,
  dmacs = 0, dmacs_signed = 0, dmacs_true = 0
)

for (i in 1:nv) {
  v <- sub_vars[i]
  if (!v %in% ho_freed_items) next  # dMACS = 0 for constrained items

  f <- var_to_factor[i]
  sigma_k <- sqrt(cov_lv_ho[f, f])

  lw <- pe_ho_part[op == "=~" & lhs == f & rhs == v & group == 1, est]
  lb <- pe_ho_part[op == "=~" & lhs == f & rhs == v & group == 2, est]
  tw <- pe_ho_part[op == "~1" & lhs == v & group == 1, est]
  tb <- pe_ho_part[op == "~1" & lhs == v & group == 2, est]

  dtau <- tw - tb
  dlam <- lw - lb

  # Closed form: integrate over N(0, sigma_k^2) for reference group
  dm   <- sqrt(dtau^2 + dlam^2 * sigma_k^2) / pool_sds[i]
  dm_s <- dtau / pool_sds[i]
  dm_t <- ifelse(abs(dm_s) < 1e-10, 0, ifelse(dm_s >= 0, 1, -1) * dm)

  set(ho_dmacs, i, "dmacs", dm)
  set(ho_dmacs, i, "dmacs_signed", dm_s)
  set(ho_dmacs, i, "dmacs_true", dm_t)
}

cat(sprintf("  %-12s  %-4s  %5s  %5s  %8s  %8s  %8s  %s\n",
            "Subtest", "Fac", "λfree", "τfree", "dMACS", "Signed", "True", ""))
for (i in 1:nv) {
  flag <- ""
  if (ho_dmacs$dmacs[i] >= 0.20) flag <- " ***"
  else if (ho_dmacs$dmacs[i] > 0) flag <- " *"
  cat(sprintf("  %-12s  %-4s  %5s  %5s  %8.4f  %+8.4f  %+8.4f%s\n",
              ho_dmacs$label[i], ho_dmacs$factor[i],
              ifelse(ho_dmacs$freed_loading[i], "FREE", "="),
              ifelse(ho_dmacs$freed_scalar[i], "FREE", "="),
              ho_dmacs$dmacs[i], ho_dmacs$dmacs_signed[i], ho_dmacs$dmacs_true[i],
              flag))
}
cat(sprintf("\n  Freed items: %d of %d\n", length(ho_freed_items), nv))
cat(sprintf("  Items with dMACS >= 0.20: %d\n", sum(ho_dmacs$dmacs >= 0.20)))
cat(sprintf("  Composite dMACS_True (signed): %+.4f SD\n", sum(ho_dmacs$dmacs_true)))

# ── 2b. Bifactor Model Per-Item dMACS ──

cat("\n--- Bifactor Model (WLSMV, partial scalar) ---\n\n")

bf_freed_items <- union(mi_res$bf_freed_loadings, mi_res$bf_freed_scalar)
has_V <- sub_vars %in% sub_vars[v_idx]

bf_dmacs <- data.table(
  var = sub_vars, label = sub_labels,
  is_ordered = sub_vars %in% ord_vars,
  has_V = has_V,
  freed_loading = sub_vars %in% mi_res$bf_freed_loadings,
  freed_scalar = sub_vars %in% mi_res$bf_freed_scalar,
  sd_pool = pool_sds,
  dmacs = 0, dmacs_signed = 0, dmacs_true = 0
)

# Integration grid
n_pts <- 81
eta_grid <- seq(-4, 4, length.out = n_pts)
d_eta <- eta_grid[2] - eta_grid[1]
phi_grid <- dnorm(eta_grid)

for (i in 1:nv) {
  v <- sub_vars[i]
  if (!v %in% bf_freed_items) next  # dMACS = 0 for constrained items

  is_ord <- v %in% ord_vars
  has_v <- has_V[i]

  # Get loadings from partial scalar model
  lam_g_W <- pe_bf_part[op == "=~" & lhs == "g" & rhs == v & group == 1, est]
  lam_g_B <- pe_bf_part[op == "=~" & lhs == "g" & rhs == v & group == 2, est]
  lam_V_W <- 0; lam_V_B <- 0
  if (has_v) {
    tmp_W <- pe_bf_part[op == "=~" & lhs == "V" & rhs == v & group == 1, est]
    tmp_B <- pe_bf_part[op == "=~" & lhs == "V" & rhs == v & group == 2, est]
    if (length(tmp_W) > 0) lam_V_W <- tmp_W
    if (length(tmp_B) > 0) lam_V_B <- tmp_B
  }

  if (is_ord) {
    # Ordered item: expected-score dMACS
    thresh_rows_W <- pe_bf_part[op == "|" & lhs == v & group == 1]
    thresh_rows_B <- pe_bf_part[op == "|" & lhs == v & group == 2]
    thresh_rows_W <- thresh_rows_W[order(as.integer(gsub("t", "", rhs)))]
    thresh_rows_B <- thresh_rows_B[order(as.integer(gsub("t", "", rhs)))]
    thresh_W <- thresh_rows_W$est
    thresh_B <- thresh_rows_B$est

    vals <- sort(unique(dat[[v]]))

    # Check if thresholds actually differ
    if (max(abs(thresh_W - thresh_B)) < 1e-6 &&
        abs(lam_g_W - lam_g_B) < 1e-6 && abs(lam_V_W - lam_V_B) < 1e-6) {
      next  # No actual difference
    }

    if (has_v) {
      # 2D integration over (eta_g, eta_V) — reference group N(0,1) x N(0,1)
      dm_sq_sum <- 0; dm_s_sum <- 0
      for (ig in seq_along(eta_grid)) {
        for (iv in seq_along(eta_grid)) {
          lin_W <- lam_g_W * eta_grid[ig] + lam_V_W * eta_grid[iv]
          lin_B <- lam_g_B * eta_grid[ig] + lam_V_B * eta_grid[iv]
          es_W <- expected_score_ordered(lin_W, thresh_W, vals)
          es_B <- expected_score_ordered(lin_B, thresh_B, vals)
          b <- es_W - es_B
          w <- phi_grid[ig] * phi_grid[iv] * d_eta^2
          dm_sq_sum <- dm_sq_sum + b^2 * w
          dm_s_sum  <- dm_s_sum  + b * w
        }
      }
    } else {
      # 1D integration over eta_g
      dm_sq_sum <- 0; dm_s_sum <- 0
      for (ig in seq_along(eta_grid)) {
        lin_W <- lam_g_W * eta_grid[ig]
        lin_B <- lam_g_B * eta_grid[ig]
        es_W <- expected_score_ordered(lin_W, thresh_W, vals)
        es_B <- expected_score_ordered(lin_B, thresh_B, vals)
        b <- es_W - es_B
        w <- phi_grid[ig] * d_eta
        dm_sq_sum <- dm_sq_sum + b^2 * w
        dm_s_sum  <- dm_s_sum  + b * w
      }
    }

    dm   <- (1/pool_sds[i]) * sqrt(dm_sq_sum)
    dm_s <- (1/pool_sds[i]) * dm_s_sum
    dm_t <- ifelse(abs(dm_s) < 1e-10, 0, ifelse(dm_s >= 0, 1, -1) * dm)

  } else {
    # Continuous item: closed-form
    tau_W <- pe_bf_part[op == "~1" & lhs == v & group == 1, est]
    tau_B <- pe_bf_part[op == "~1" & lhs == v & group == 2, est]
    dtau <- tau_W - tau_B
    dlam_g <- lam_g_W - lam_g_B
    dlam_V <- lam_V_W - lam_V_B

    # Check if parameters actually differ
    if (abs(dtau) < 1e-6 && abs(dlam_g) < 1e-6 && abs(dlam_V) < 1e-6) next

    # g ~ N(0,1), V ~ N(0,1), independent:
    dm   <- sqrt(dtau^2 + dlam_g^2 + dlam_V^2) / pool_sds[i]
    dm_s <- dtau / pool_sds[i]
    dm_t <- ifelse(abs(dm_s) < 1e-10, 0, ifelse(dm_s >= 0, 1, -1) * dm)
  }

  set(bf_dmacs, i, "dmacs", dm)
  set(bf_dmacs, i, "dmacs_signed", dm_s)
  set(bf_dmacs, i, "dmacs_true", dm_t)
}

cat(sprintf("  %-12s  %3s  %3s  %5s  %5s  %8s  %8s  %8s  %s\n",
            "Subtest", "Ord", "V?", "λfree", "τfree", "dMACS", "Signed", "True", ""))
for (i in 1:nv) {
  flag <- ""
  if (bf_dmacs$dmacs[i] >= 0.20) flag <- " ***"
  else if (bf_dmacs$dmacs[i] > 0) flag <- " *"
  cat(sprintf("  %-12s  %3s  %3s  %5s  %5s  %8.4f  %+8.4f  %+8.4f%s\n",
              bf_dmacs$label[i],
              ifelse(bf_dmacs$is_ordered[i], "Y", "N"),
              ifelse(bf_dmacs$has_V[i], "Y", "N"),
              ifelse(bf_dmacs$freed_loading[i], "FREE", "="),
              ifelse(bf_dmacs$freed_scalar[i], "FREE", "="),
              bf_dmacs$dmacs[i], bf_dmacs$dmacs_signed[i], bf_dmacs$dmacs_true[i],
              flag))
}
cat(sprintf("\n  Freed items: %d of %d\n", length(bf_freed_items), nv))
cat(sprintf("  Items with dMACS >= 0.20: %d\n", sum(bf_dmacs$dmacs >= 0.20)))
cat(sprintf("  Composite dMACS_True (signed): %+.4f SD\n", sum(bf_dmacs$dmacs_true)))


# ---- SECTION 3: Summary and Interpretation ----

cat("--- SECTION 3: Summary and Interpretation ---\n")

cat("--- Impact on Latent Mean Estimates ---\n\n")
cat("  The question: does freeing non-invariant items meaningfully change\n")
cat("  the estimated latent g gap?\n\n")
cat(sprintf("  HO model:  freed %d of %d intercepts\n",
            length(mi_res$ho_freed_scalar), nv))
cat(sprintf("  BF model:  freed %d of %d thresholds/intercepts (+ 1 loading)\n",
            length(mi_res$bf_freed_scalar), nv))
cat(sprintf("\n  BF g gap:  full scalar = %+.3f SD\n", bf_g_full$est))
cat(sprintf("             partial scalar = %+.3f SD\n", bf_g_part$est))
cat(sprintf("             shift = %+.3f SD (%.1f%% of partial gap)\n",
            bf_g_shift, abs(bf_g_shift / bf_g_part$est) * 100))

cat("\n--- Per-Item dMACS Interpretation (Nye & Drasgow 2019) ---\n\n")
cat("  dMACS < 0.20:    trivial measurement non-invariance\n")
cat("  dMACS 0.20-0.40: small non-invariance\n")
cat("  dMACS > 0.40:    moderate to large non-invariance\n\n")
cat("  Positive dMACS_True = White scores inflated relative to Black\n")
cat("  at the same latent ability level.\n\n")

bf_above <- bf_dmacs[dmacs >= 0.20]
if (nrow(bf_above) > 0) {
  cat("  BF items above 0.20 threshold:\n")
  for (j in 1:nrow(bf_above))
    cat(sprintf("    %s: dMACS = %.3f (%s)\n", bf_above$label[j], bf_above$dmacs[j],
                ifelse(bf_above$dmacs[j] >= 0.40, "moderate+",
                       ifelse(bf_above$dmacs[j] >= 0.20, "small", "trivial"))))
} else {
  cat("  No BF items exceed the 0.20 threshold.\n")
}

ho_above <- ho_dmacs[dmacs >= 0.20]
if (nrow(ho_above) > 0) {
  cat("\n  HO items above 0.20 threshold:\n")
  for (j in 1:nrow(ho_above))
    cat(sprintf("    %s: dMACS = %.3f (%s)\n", ho_above$label[j], ho_above$dmacs[j],
                ifelse(ho_above$dmacs[j] >= 0.40, "moderate+",
                       ifelse(ho_above$dmacs[j] >= 0.20, "small", "trivial"))))
} else {
  cat("\n  No HO items exceed the 0.20 threshold.\n")
}


# ---- Save Results ----

results <- list(
  N = nrow(dat),
  # Full vs. partial scalar comparison
  ho_means_full = ho_means_full,
  ho_means_partial = ho_means_part,
  bf_g_full = bf_g_full$est, bf_g_partial = bf_g_part$est,
  bf_V_full = bf_V_full$est, bf_V_partial = bf_V_part$est,
  bf_g_shift = bf_g_shift, bf_V_shift = bf_V_shift,
  # CFI
  ho_cfi_full = ho_cfi_full, ho_cfi_partial = ho_cfi_part,
  bf_cfi_full = bf_cfi_full, bf_cfi_partial = bf_cfi_part,
  # Per-item dMACS
  ho_dmacs = ho_dmacs,
  bf_dmacs = bf_dmacs,
  ho_composite_signed = sum(ho_dmacs$dmacs_true),
  bf_composite_signed = sum(bf_dmacs$dmacs_true),
  # Freed parameter lists
  ho_freed_loadings = mi_res$ho_freed_loadings,
  ho_freed_scalar = mi_res$ho_freed_scalar,
  bf_freed_loadings = mi_res$bf_freed_loadings,
  bf_freed_scalar = mi_res$bf_freed_scalar
)

saveRDS(results, "results_dmacs_effect_sizes.rds")
cat("\n\nSaved to results_dmacs_effect_sizes.rds\n")
cat("\nDone.\n")
