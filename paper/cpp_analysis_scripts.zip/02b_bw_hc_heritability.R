#!/usr/bin/env Rscript
# 02b_bw_hc_heritability.R — Heritability of birth weight and head circumference

library(data.table)

cat("--- BW/HC Heritability ---\n")

d <- readRDS("prepared_data.rds")
growth <- as.data.table(readRDS("prepared_growth.rds"))
links <- fread("../clean/cpp_kinship_links.csv",
               colClasses = c(id_1 = "character", id_2 = "character"))

# ---- 1. Prepare phenotypes ----
# Birth weight z-score (sex-adjusted)
d[, bw_z_sex := as.numeric(scale(birth_wt_g)), by = sex]

# Head circumference at birth
hc_birth <- growth[measure == "head_circ_cm" & age_months == 0,
                    .(case_id = as.character(case_id), hc_birth = value)]
d <- merge(d, hc_birth, by = "case_id", all.x = TRUE)
d[, hc_z_sex := as.numeric(scale(hc_birth)), by = sex]

# Head circumference at 7 years
hc_7yr <- growth[measure == "head_circ_cm" & age_months == 84,
                  .(case_id = as.character(case_id), hc_7yr = value)]
d <- merge(d, hc_7yr, by = "case_id", all.x = TRUE)
d[, hc7_z_sex := as.numeric(scale(hc_7yr)), by = sex]

cat(sprintf("Children with BW: %d\n", sum(!is.na(d$birth_wt_g))))
cat(sprintf("Children with birth HC: %d\n", sum(!is.na(d$hc_birth))))
cat(sprintf("Children with 7yr HC: %d\n", sum(!is.na(d$hc_7yr))))

# ---- 2. Compute pairwise correlations ----
compute_cors <- function(links, d, pheno_col, pheno_label) {
  cat(sprintf("\n--- %s Correlations by Relatedness ---\n\n", pheno_label))

  # Merge phenotypes
  pairs <- merge(links, d[, .(id_1 = case_id, y1 = get(pheno_col))], by = "id_1")
  pairs <- merge(pairs, d[, .(id_2 = case_id, y2 = get(pheno_col))], by = "id_2")
  pairs <- pairs[!is.na(y1) & !is.na(y2)]

  # Classify groups
  pairs[, group := fcase(
    pair_type == "MZ_twin", "MZ",
    pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
    pair_type == "full_sibling", "Full sib",
    pair_type == "half_sibling", "Half sib",
    default = NA_character_
  )]
  pairs <- pairs[!is.na(group)]

  cat(sprintf("%-12s  %6s  %8s  %8s\n", "Group", "N", "r", "SE"))
  cat(paste(rep("-", 40), collapse=""), "\n")

  results <- list()
  for (g in c("MZ", "DZ", "Full sib", "Half sib")) {
    sub <- pairs[group == g]
    if (nrow(sub) < 10) next
    r <- cor(sub$y1, sub$y2)
    # Fisher z SE
    se_r <- sqrt(1 / (nrow(sub) - 3))
    cat(sprintf("%-12s  %6d  %8.3f  %8.3f\n", g, nrow(sub), r, se_r))
    results[[g]] <- list(n = nrow(sub), r = r, se = se_r)
  }

  return(results)
}

# BW correlations
bw_cors <- compute_cors(links, d, "bw_z_sex", "Birth Weight (sex-adjusted z)")

# HC at birth correlations
hc_cors <- compute_cors(links, d, "hc_z_sex", "Head Circumference at Birth (sex-adjusted z)")

# HC at 7yr correlations
hc7_cors <- compute_cors(links, d, "hc7_z_sex", "Head Circumference at 7yr (sex-adjusted z)")

# ---- 3. ACE decomposition ----
ace_decomp <- function(cors, label) {
  cat(sprintf("\n--- ACE Decomposition: %s ---\n\n", label))

  # Multi-level Falconer
  if (length(cors) >= 3) {
    R_vals <- c(MZ = 1.0, DZ = 0.5, `Full sib` = 0.5, `Half sib` = 0.25)
    r_obs <- sapply(cors, function(x) x$r)
    n_obs <- sapply(cors, function(x) x$n)
    R_matched <- R_vals[names(cors)]

    # WLS regression: r = a^2 * R + c^2
    w <- n_obs
    fit <- lm(r_obs ~ R_matched, weights = w)
    a2 <- coef(fit)["R_matched"]
    c2 <- coef(fit)["(Intercept)"]
    e2 <- 1 - a2 - c2

    cat(sprintf("  Multi-level Falconer: a2=%.3f, c2=%.3f, e2=%.3f\n", a2, c2, e2))

    # Bootstrap CIs
    set.seed(42)
    boot_a2 <- numeric(1000)
    for (b in 1:1000) {
      boot_r <- r_obs + rnorm(length(r_obs)) * sapply(cors, function(x) x$se)
      bfit <- lm(boot_r ~ R_matched, weights = w)
      boot_a2[b] <- coef(bfit)["R_matched"]
    }
    ci <- quantile(boot_a2, c(0.025, 0.975))
    cat(sprintf("  a2 95%% CI: [%.3f, %.3f]\n", ci[1], ci[2]))
  }

  # Twin-only Falconer
  if ("MZ" %in% names(cors) && "DZ" %in% names(cors)) {
    rMZ <- cors[["MZ"]]$r
    rDZ <- cors[["DZ"]]$r
    a2_twin <- 2 * (rMZ - rDZ)
    c2_twin <- 2 * rDZ - rMZ
    e2_twin <- 1 - rMZ

    cat(sprintf("  Twin-only Falconer:   a2=%.3f, c2=%.3f, e2=%.3f\n",
                a2_twin, c2_twin, e2_twin))
  }
}

ace_decomp(bw_cors, "Birth Weight")
ace_decomp(hc_cors, "Head Circumference at Birth")
ace_decomp(hc7_cors, "Head Circumference at 7yr")

# ---- 4. Save ----
saveRDS(list(bw_cors = bw_cors, hc_cors = hc_cors, hc7_cors = hc7_cors),
        "results_bw_hc_heritability.rds")
cat("Done.\n")
