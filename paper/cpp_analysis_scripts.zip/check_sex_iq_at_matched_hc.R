library(data.table)
library(fixest)

d <- as.data.table(readRDS("prepared_data.rds"))
growth <- as.data.table(readRDS("prepared_growth.rds"))

for (meas in c("head_circ_cm", "height_cm", "weight_g")) {
  g7 <- growth[measure == meas & age_months == 84,
               .(case_id = as.character(case_id), value)]
  short <- gsub("_cm$|_g$", "", meas)
  setnames(g7, "value", paste0(short, "_7yr"))
  d <- merge(d, g7, by = "case_id", all.x = TRUE)
}
d[, weight_7yr := weight_7yr / 1000]

hc <- d[race %in% c(1, 2) & !is.na(head_circ_7yr) & !is.na(wisc_fsiq)]

# ==== 1. IQ gap controlling for HC ====
cat("=== IQ GAP CONTROLLING FOR HEAD CIRCUMFERENCE ===\n\n")

# Raw IQ gap
m0 <- feols(wisc_fsiq ~ factor(sex), data = hc, vcov = "hetero")
cat(sprintf("Raw IQ sex gap (F-M):      b=%.3f (SE=%.3f)\n",
            coef(m0)["factor(sex)2"], se(m0)["factor(sex)2"]))

# Controlling for HC
m1 <- feols(wisc_fsiq ~ factor(sex) + head_circ_7yr, data = hc, vcov = "hetero")
cat(sprintf("IQ gap | HC:               b=%.3f (SE=%.3f), p=%.1e\n",
            coef(m1)["factor(sex)2"], se(m1)["factor(sex)2"],
            2*pnorm(-abs(coef(m1)["factor(sex)2"]/se(m1)["factor(sex)2"]))))

# + race
m2 <- feols(wisc_fsiq ~ factor(sex) + head_circ_7yr + factor(race), data = hc, vcov = "hetero")
cat(sprintf("IQ gap | HC + race:        b=%.3f (SE=%.3f), p=%.1e\n",
            coef(m2)["factor(sex)2"], se(m2)["factor(sex)2"],
            2*pnorm(-abs(coef(m2)["factor(sex)2"]/se(m2)["factor(sex)2"]))))

# + height + weight
hc_full <- hc[!is.na(height_7yr) & !is.na(weight_7yr)]
m3 <- feols(wisc_fsiq ~ factor(sex) + head_circ_7yr + factor(race) + height_7yr + weight_7yr,
            data = hc_full, vcov = "hetero")
cat(sprintf("IQ gap | HC+race+ht+wt:    b=%.3f (SE=%.3f), p=%.1e\n",
            coef(m3)["factor(sex)2"], se(m3)["factor(sex)2"],
            2*pnorm(-abs(coef(m3)["factor(sex)2"]/se(m3)["factor(sex)2"]))))

# Within family
hc[, n_sibs := .N, by = mother_id]
hc_sib <- hc[n_sibs >= 2]
hc_sib[, n_male := sum(sex == 1), by = mother_id]
hc_sib[, n_female := sum(sex == 2), by = mother_id]
hc_mixed <- hc_sib[n_male >= 1 & n_female >= 1]

m4 <- feols(wisc_fsiq ~ factor(sex) + head_circ_7yr | mother_id,
            data = hc_mixed, vcov = ~mother_id)
cat(sprintf("FE: IQ gap | HC:           b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m4)["factor(sex)2"], se(m4)["factor(sex)2"],
            2*pnorm(-abs(coef(m4)["factor(sex)2"]/se(m4)["factor(sex)2"]))))

hc_mixed_full <- hc_mixed[!is.na(height_7yr) & !is.na(weight_7yr)]
m5 <- feols(wisc_fsiq ~ factor(sex) + head_circ_7yr + height_7yr + weight_7yr | mother_id,
            data = hc_mixed_full, vcov = ~mother_id)
cat(sprintf("FE: IQ gap | HC+ht+wt:     b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m5)["factor(sex)2"], se(m5)["factor(sex)2"],
            2*pnorm(-abs(coef(m5)["factor(sex)2"]/se(m5)["factor(sex)2"]))))

# ==== 2. HC-matched IQ comparison ====
cat("\n=== IQ BY SEX AT MATCHED HC BINS ===\n\n")
hc[, hc_bin := cut(head_circ_7yr, breaks = seq(46, 56, 1))]
tab <- hc[!is.na(hc_bin), .(iq_m = mean(wisc_fsiq[sex == 1]),
                              iq_f = mean(wisc_fsiq[sex == 2]),
                              n_m = sum(sex == 1),
                              n_f = sum(sex == 2)),
           by = hc_bin][order(hc_bin)]
tab[, gap := iq_f - iq_m]
cat(sprintf("%-12s  %6s  %6s  %6s  %5s  %5s\n", "HC bin", "IQ_M", "IQ_F", "F-M", "n_M", "n_F"))
for (i in 1:nrow(tab)) {
  if (tab$n_m[i] >= 20 & tab$n_f[i] >= 20)
    cat(sprintf("%-12s  %6.1f  %6.1f  %+5.1f  %5d  %5d\n",
                as.character(tab$hc_bin[i]),
                tab$iq_m[i], tab$iq_f[i], tab$gap[i], tab$n_m[i], tab$n_f[i]))
}

# ==== 3. Check for selection: are HC-matched women "exceptional"? ====
cat("\n=== SELECTION CHECK: ARE HC-MATCHED WOMEN UNUSUAL? ===\n")
cat("At matched HC, are women drawn from a different part of their IQ distribution?\n\n")

# Within each HC bin, what percentile of their sex distribution are they?
hc[, hc_pctile_m := ecdf(head_circ_7yr[sex == 1])(head_circ_7yr), by = race]
hc[, hc_pctile_f := ecdf(head_circ_7yr[sex == 2])(head_circ_7yr), by = race]
hc[, hc_pctile := ifelse(sex == 1, hc_pctile_m, hc_pctile_f)]

# At the overlap region (HC 49-53 cm), what's the sex-specific percentile?
overlap <- hc[head_circ_7yr >= 49 & head_circ_7yr <= 53]
cat("At HC 49-53 cm (overlap region):\n")
for (s in c(1, 2)) {
  sl <- ifelse(s == 1, "Male", "Female")
  sub <- overlap[sex == s]
  cat(sprintf("  %s: mean HC percentile within sex = %.0f%%, mean IQ = %.1f, n = %d\n",
              sl, 100*mean(sub$hc_pctile), mean(sub$wisc_fsiq), nrow(sub)))
}

# More specifically: at HC = 51 cm (near overlap center)
cat("\nAt HC = 50.5-51.5 cm:\n")
hc51 <- hc[head_circ_7yr >= 50.5 & head_circ_7yr < 51.5]
for (s in c(1, 2)) {
  sl <- ifelse(s == 1, "Male", "Female")
  sub <- hc51[sex == s]
  cat(sprintf("  %s: n=%d, mean IQ=%.1f (SD=%.1f), HC pctile within sex=%.0f%%\n",
              sl, nrow(sub), mean(sub$wisc_fsiq), sd(sub$wisc_fsiq),
              100*mean(sub$hc_pctile)))
}

# SB IQ too
cat("\n=== Same with SB IQ ===\n")
m_sb <- feols(sb_iq ~ factor(sex) + head_circ_7yr + factor(race),
              data = hc[!is.na(sb_iq)], vcov = "hetero")
cat(sprintf("SB IQ gap | HC + race:     b=%.3f (SE=%.3f), p=%.1e\n",
            coef(m_sb)["factor(sex)2"], se(m_sb)["factor(sex)2"],
            2*pnorm(-abs(coef(m_sb)["factor(sex)2"]/se(m_sb)["factor(sex)2"]))))

# g factor
m_g <- feols(g_factor ~ factor(sex) + head_circ_7yr + factor(race),
             data = hc[!is.na(g_factor)], vcov = "hetero")
cat(sprintf("PCA g gap | HC + race:     b=%.3f (SE=%.3f), p=%.1e\n",
            coef(m_g)["factor(sex)2"], se(m_g)["factor(sex)2"],
            2*pnorm(-abs(coef(m_g)["factor(sex)2"]/se(m_g)["factor(sex)2"]))))

cat("\nDone.\n")
