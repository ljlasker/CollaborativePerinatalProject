#!/usr/bin/env Rscript
# Quantify dyad reuse and estimate dependence-robust WISC correlation
# intervals. The independent sampling unit is a connected extended-family
# component: maternal families joined by any documented extended-kin link are
# kept together in every bootstrap draw.

library(data.table)
set.seed(20260823)

build_component_map <- function(analysis_mothers, extended_path) {
  extended <- fread(
    extended_path,
    colClasses = c(id_1 = "character", id_2 = "character")
  )
  extended[, mother_1 := substr(id_1, 1L, 7L)]
  extended[, mother_2 := substr(id_2, 1L, 7L)]
  extended <- extended[
    !is.na(mother_1) & !is.na(mother_2) & mother_1 != mother_2
  ]

  nodes <- unique(c(analysis_mothers, extended$mother_1, extended$mother_2))
  node_index <- setNames(seq_along(nodes), nodes)
  parent <- seq_along(nodes)
  tree_rank <- integer(length(nodes))

  find_root <- function(x) {
    while (parent[x] != x) {
      parent[x] <<- parent[parent[x]]
      x <- parent[x]
    }
    x
  }
  union_nodes <- function(a, b) {
    root_a <- find_root(a)
    root_b <- find_root(b)
    if (root_a == root_b) return(invisible(NULL))
    if (tree_rank[root_a] < tree_rank[root_b]) {
      parent[root_a] <<- root_b
    } else if (tree_rank[root_a] > tree_rank[root_b]) {
      parent[root_b] <<- root_a
    } else {
      parent[root_b] <<- root_a
      tree_rank[root_a] <<- tree_rank[root_a] + 1L
    }
    invisible(NULL)
  }

  for (i in seq_len(nrow(extended))) {
    union_nodes(
      unname(node_index[[extended$mother_1[i]]]),
      unname(node_index[[extended$mother_2[i]]])
    )
  }

  roots <- vapply(seq_along(nodes), find_root, integer(1L))
  component_map <- data.table(mother_id = nodes, root = roots)
  # Stable, human-auditable label: smallest mother ID in the component.
  component_map[, component_id := min(mother_id), by = root]
  component_map[, root := NULL]
  attr(component_map, "extended_pair_rows") <- nrow(extended)
  component_map
}

pairs <- as.data.table(readRDS("prepared_iq_links.rds"))
pairs <- pairs[complete.cases(iq_1z, iq_2z) & !is.na(mother_id)]
pairs[, group := fcase(
  pair_type == "MZ_twin", "MZ twin",
  pair_type %chin% c("DZ_twin", "DZ_twin_probable"), "DZ twin",
  pair_type == "half_sibling", "Half sibling",
  pair_type == "full_sibling", "Full sibling",
  default = NA_character_
)]
pairs <- pairs[!is.na(group)]
setorder(pairs, group, mother_id, id_1, id_2)

component_map <- build_component_map(
  unique(pairs$mother_id),
  file.path("..", "clean", "cpp_extended_kinship_links.csv")
)
extended_pair_rows <- attr(component_map, "extended_pair_rows")
pairs <- merge(pairs, component_map, by = "mother_id", all.x = TRUE)
stopifnot(!anyNA(pairs$component_id))

mother_reuse <- pairs[, .(
  pairs = .N,
  unique_children = uniqueN(c(id_1, id_2)),
  groups = uniqueN(group)
), by = mother_id]

component_reuse <- pairs[, .(
  pairs = .N,
  mothers = uniqueN(mother_id),
  unique_children = uniqueN(c(id_1, id_2)),
  groups = uniqueN(group)
), by = component_id]

# Group-specific correlations may select one pair per group. The model-fit
# sensitivity below selects one pair total per component so no component can
# occur in more than one OpenMx group.
one_pair_mother <- pairs[, .SD[1L], by = .(group, mother_id)]
one_pair_component <- pairs[, .SD[1L], by = .(group, component_id)]

cor_rows <- function(x, label) {
  x[, .(
    specification = label,
    pairs = .N,
    mothers = uniqueN(mother_id),
    components = uniqueN(component_id),
    correlation = cor(iq_1z, iq_2z)
  ), by = group]
}

point <- rbindlist(list(
  cor_rows(pairs, "All available pairs"),
  cor_rows(one_pair_mother, "One pair per group per mother"),
  cor_rows(one_pair_component, "One pair per group per extended family")
))

weighted_group_cor <- function(source, weights, cluster_var, iteration) {
  z <- merge(
    source,
    weights,
    by.x = cluster_var,
    by.y = "cluster_id",
    all = FALSE,
    allow.cartesian = TRUE
  )
  z[, {
    mean_x <- weighted.mean(iq_1z, weight)
    mean_y <- weighted.mean(iq_2z, weight)
    covariance <- sum(weight * (iq_1z - mean_x) * (iq_2z - mean_y)) /
      sum(weight)
    variance_x <- sum(weight * (iq_1z - mean_x)^2) / sum(weight)
    variance_y <- sum(weight * (iq_2z - mean_y)^2) / sum(weight)
    .(correlation = covariance / sqrt(variance_x * variance_y))
  }, by = group][, iteration := iteration]
}

cluster_bootstrap <- function(source, cluster_var, label, replications = 1000L) {
  clusters <- unique(source[[cluster_var]])
  draws <- vector("list", replications)
  for (b in seq_len(replications)) {
    sampled <- sample(clusters, length(clusters), replace = TRUE)
    weights <- data.table(cluster_id = sampled)[, .(weight = .N), by = cluster_id]
    draws[[b]] <- weighted_group_cor(source, weights, cluster_var, b)
  }
  result <- rbindlist(draws)
  result[, specification := label]
  result
}

B <- 1000L
boot <- rbindlist(list(
  cluster_bootstrap(
    pairs, "mother_id", "All available pairs: mother blocks", B
  ),
  cluster_bootstrap(
    pairs, "component_id", "All available pairs: extended-family blocks", B
  ),
  cluster_bootstrap(
    one_pair_mother, "component_id",
    "One pair per group per mother: extended-family blocks", B
  ),
  cluster_bootstrap(
    one_pair_component, "component_id",
    "One pair per group per extended family: extended-family blocks", B
  )
))

ci <- boot[, .(
  cluster_boot_se = sd(correlation),
  ci_low = quantile(correlation, 0.025),
  ci_high = quantile(correlation, 0.975)
), by = .(group, specification)]

point_ci_map <- data.table(
  specification = c(
    "All available pairs",
    "All available pairs",
    "One pair per group per mother",
    "One pair per group per extended family"
  ),
  bootstrap_specification = c(
    "All available pairs: mother blocks",
    "All available pairs: extended-family blocks",
    "One pair per group per mother: extended-family blocks",
    "One pair per group per extended family: extended-family blocks"
  )
)
point_with_ci <- merge(point, point_ci_map, by = "specification", allow.cartesian = TRUE)
point_with_ci <- merge(
  point_with_ci,
  ci,
  by.x = c("group", "bootstrap_specification"),
  by.y = c("group", "specification"),
  all.x = TRUE
)

diagnostics <- data.table(
  metric = c(
    "pair_rows", "unique_mothers", "extended_family_components",
    "documented_extended_kin_pair_rows",
    "mothers_with_multiple_pairs", "pair_rows_from_multi_pair_mothers",
    "mothers_spanning_multiple_groups", "maximum_pairs_from_one_mother",
    "components_with_multiple_analysis_mothers",
    "analysis_mothers_in_multi_mother_components",
    "pair_rows_in_multi_mother_components",
    "maximum_analysis_mothers_in_one_component",
    "maximum_pair_rows_in_one_component"
  ),
  value = c(
    nrow(pairs), uniqueN(pairs$mother_id), uniqueN(pairs$component_id),
    extended_pair_rows,
    sum(mother_reuse$pairs > 1), sum(mother_reuse[pairs > 1]$pairs),
    sum(mother_reuse$groups > 1), max(mother_reuse$pairs),
    sum(component_reuse$mothers > 1),
    sum(component_reuse[mothers > 1]$mothers),
    sum(component_reuse[mothers > 1]$pairs),
    max(component_reuse$mothers), max(component_reuse$pairs)
  )
)

fwrite(point_with_ci, "results_pair_reuse_robustness.csv")
fwrite(diagnostics, "results_family_dependence_diagnostics.csv")
fwrite(
  component_reuse[order(-mothers, -pairs)],
  "results_extended_family_component_diagnostics.csv"
)
saveRDS(
  list(
    point = point_with_ci,
    bootstrap = boot,
    diagnostics = diagnostics,
    component_reuse = component_reuse,
    component_map = component_map
  ),
  "results_family_dependence_robustness.rds"
)

# Extended-family block-bootstrap SEs for every correlation displayed in the
# main behavior-genetics table. This replaces the conventional row-level SEs.
outcome_columns <- list(
  wisc_fsiq = c("iq_1z", "iq_2z"),
  wisc_viq = c("viq_1z", "viq_2z"),
  wisc_piq = c("piq_1z", "piq_2z"),
  sb_iq = c("sb_1z", "sb_2z"),
  g_factor = c("g_1z", "g_2z")
)
all_outcome_pairs <- as.data.table(readRDS("prepared_iq_links.rds"))
all_outcome_pairs[, group := fcase(
  pair_type == "MZ_twin", "MZ twin",
  pair_type %chin% c("DZ_twin", "DZ_twin_probable"), "DZ twin",
  pair_type == "half_sibling", "Half sibling",
  pair_type == "full_sibling", "Full sibling",
  default = NA_character_
)]
all_outcome_pairs <- all_outcome_pairs[!is.na(group) & !is.na(mother_id)]
missing_outcome_mothers <- setdiff(
  unique(all_outcome_pairs$mother_id), component_map$mother_id
)
if (length(missing_outcome_mothers)) {
  component_map <- rbind(
    component_map,
    data.table(
      mother_id = missing_outcome_mothers,
      component_id = missing_outcome_mothers
    )
  )
}
all_outcome_pairs <- merge(
  all_outcome_pairs, component_map, by = "mother_id", all.x = TRUE
)
stopifnot(!anyNA(all_outcome_pairs$component_id))

outcome_results <- vector("list", length(outcome_columns))
names(outcome_results) <- names(outcome_columns)
for (outcome_name in names(outcome_columns)) {
  cols <- outcome_columns[[outcome_name]]
  outcome_data <- all_outcome_pairs[
    !is.na(get(cols[1L])) & !is.na(get(cols[2L])),
    .(
      component_id, mother_id, group,
      iq_1z = get(cols[1L]), iq_2z = get(cols[2L])
    )
  ]
  set.seed(20260823L + match(outcome_name, names(outcome_columns)))
  outcome_boot <- cluster_bootstrap(
    outcome_data, "component_id", outcome_name, B
  )
  outcome_point <- outcome_data[, .(
    pairs = .N,
    components = uniqueN(component_id),
    correlation = cor(iq_1z, iq_2z)
  ), by = group]
  outcome_ci <- outcome_boot[, .(
    cluster_boot_se = sd(correlation),
    ci_low = quantile(correlation, 0.025),
    ci_high = quantile(correlation, 0.975)
  ), by = group]
  outcome_results[[outcome_name]] <- merge(
    outcome_point, outcome_ci, by = "group"
  )[, outcome := outcome_name]
}
outcome_results <- rbindlist(outcome_results, use.names = TRUE)
setcolorder(outcome_results, c(
  "outcome", "group", "pairs", "components", "correlation",
  "cluster_boot_se", "ci_low", "ci_high"
))
fwrite(
  outcome_results[order(outcome, group)],
  "results_kinship_correlations_extended_family_bootstrap.csv"
)

cat("--- Pair-reuse and extended-family sensitivity ---\n")
print(diagnostics)
print(point_with_ci[order(group, specification, bootstrap_specification)])
cat("--- Extended-family bootstrap for all displayed outcomes ---\n")
print(outcome_results[order(outcome, group)])
