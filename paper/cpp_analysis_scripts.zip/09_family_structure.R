#!/usr/bin/env Rscript
# 09_family_structure.R — Half-sibling rates by race, descriptive analysis

library(data.table)

cat("--- Family Structure ---\n")

d <- readRDS("prepared_data.rds")
links <- readRDS("prepared_links.rds")

# ---- 1. Half-sibling rates by race ----
cat("--- Half-Sibling Rates by Race ---\n\n")

# Merge race info
race_1 <- d[, .(id_1 = case_id, race_1 = race)]
race_2 <- d[, .(id_2 = case_id, race_2 = race)]
lr <- merge(links, race_1, by = "id_1")
lr <- merge(lr, race_2, by = "id_2")

# Classified pairs only
classified <- lr[pair_type %in% c("full_sibling", "half_sibling")]
classified[, race_label := fcase(
  race_1 == 1 & race_2 == 1, "White",
  race_1 == 2 & race_2 == 2, "Black",
  race_1 == 5 & race_2 == 5, "Puerto Rican",
  race_1 == 6 & race_2 == 6, "Oriental",
  default = "Mixed/Other"
)]

halfsib_rates <- classified[, .(
  n_total = .N,
  n_half = sum(pair_type == "half_sibling"),
  rate = 100 * mean(pair_type == "half_sibling")
), by = race_label][order(-n_total)]

cat(sprintf("%-15s  %6s  %6s  %8s\n", "Race", "Total", "Half", "Rate"))
cat(paste(rep("-", 42), collapse=""), "\n")
for (i in 1:nrow(halfsib_rates)) {
  cat(sprintf("%-15s  %6d  %6d  %7.1f%%\n",
              halfsib_rates$race_label[i], halfsib_rates$n_total[i],
              halfsib_rates$n_half[i], halfsib_rates$rate[i]))
}

# Chi-squared: White vs Black
wb <- classified[race_label %in% c("White", "Black")]
wb[, is_half := pair_type == "half_sibling"]
ct <- chisq.test(table(wb$race_label, wb$is_half))
cat(sprintf("\nWhite vs Black chi-squared: %.1f, p = %.2e\n", ct$statistic, ct$p.value))

# ---- 2. Family size by race ----
cat("\n--- Family Size by Race ---\n\n")

fam_size <- d[race %in% c(1, 2), .(n_kids = .N), by = .(mother_id, race)]
for (rv in c(1, 2)) {
  rl <- ifelse(rv == 1, "White", "Black")
  sub <- fam_size[race == rv]
  cat(sprintf("  %s: %d mothers, mean children=%.2f\n",
              rl, nrow(sub), mean(sub$n_kids)))
  cat(sprintf("    1 child: %.1f%%, 2: %.1f%%, 3+: %.1f%%\n",
              100*mean(sub$n_kids==1), 100*mean(sub$n_kids==2),
              100*mean(sub$n_kids>=3)))
}

# ---- 3. ABO typing error sidebar ----
cat("\n--- ABO Typing Error Sidebar ---\n")
cat("All Mendelian exclusions are typing errors (see data paper).\n")
cat("68 impossible mother-child combinations out of 50,201 (0.14%).\n")
cat("Zero evidence of cuckoldry from blood type data.\n")

# ---- 4. Save ----
saveRDS(list(halfsib_rates = halfsib_rates), "results_family_structure.rds")
cat("Done.\n")
