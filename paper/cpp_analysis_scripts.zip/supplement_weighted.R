#!/usr/bin/env Rscript
# supplement_weighted.R — Survey-weighted sensitivity analysis

library(data.table)
library(fixest)

cat("--- Survey-Weighted Sensitivity Analysis ---\n")

# ---- 0. Load data and merge weights ----

d <- readRDS("prepared_data.rds")
wt_file <- fread("../clean/cpp_weights.csv")
wt_file[, case_id := as.character(case_id)]

d <- merge(d, wt_file[, .(case_id, wt = combined_age7_urban)],
           by = "case_id", all.x = TRUE)

n_total <- nrow(d)
n_wt    <- sum(!is.na(d$wt))
cat(sprintf("Weight merge: %d / %d children have weights (%.1f%%)\n",
            n_wt, n_total, 100 * n_wt / n_total))
cat(sprintf("Weight range: [%.3f, %.3f], median = %.3f\n",
            min(d$wt, na.rm = TRUE), max(d$wt, na.rm = TRUE),
            median(d$wt, na.rm = TRUE)))

# Shared outcome definitions
outcomes <- c("wisc_fsiq_z", "wisc_viq_z", "wisc_piq_z", "sb_iq_z", "g_factor_z")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

# Helper: extract coefficient + SE from feols, return data.table row
ext <- function(model, var, label, spec, weighted) {
  if (is.null(model) || !(var %in% names(coef(model)))) {
    return(data.table(outcome = label, spec = spec, weighted = weighted,
                      b = NA_real_, se = NA_real_, n = NA_integer_))
  }
  data.table(outcome = label, spec = spec, weighted = weighted,
             b = as.numeric(coef(model)[var]),
             se = as.numeric(se(model)[var]),
             n = as.integer(nobs(model)))
}

rows <- list()  # collector

# ---- 1. Kinship Correlations ----
cat("\n--- 1. Kinship Correlations ---\n\n")

iq_links <- readRDS("prepared_iq_links.rds")
iq_links <- merge(iq_links, wt_file[, .(case_id, wt1 = combined_age7_urban)],
                  by.x = "id_1", by.y = "case_id", all.x = TRUE)
iq_links <- merge(iq_links, wt_file[, .(case_id, wt2 = combined_age7_urban)],
                  by.x = "id_2", by.y = "case_id", all.x = TRUE)
iq_links[, wt_pair := (wt1 + wt2) / 2]

# Classify groups (same as 02_behavior_genetics.R)
iq_links[, r_group := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
iq_clean <- iq_links[!is.na(r_group)]

# Weighted correlation using cov.wt
wcor <- function(x, y, w) {
  ok <- complete.cases(x, y, w)
  if (sum(ok) < 10) return(NA_real_)
  cov.wt(cbind(x[ok], y[ok]), wt = w[ok], cor = TRUE)$cor[1, 2]
}

cor_rows <- list()
for (rg in c("MZ", "DZ", "FS", "HS")) {
  sub <- iq_clean[r_group == rg & !is.na(iq_1) & !is.na(iq_2)]
  n <- nrow(sub)
  if (n < 10) next

  # Unweighted
  r_uw <- cor(sub$iq_1, sub$iq_2, use = "complete.obs")

  # Weighted (complete weight cases)
  sub_w <- sub[!is.na(wt_pair)]
  r_wt <- if (nrow(sub_w) >= 10) wcor(sub_w$iq_1, sub_w$iq_2, sub_w$wt_pair) else NA

  cat(sprintf("  %s: r_unwt = %.3f (n=%d), r_wt = %.3f (n=%d)\n",
              rg, r_uw, n, ifelse(is.na(r_wt), NA, r_wt), nrow(sub_w)))

  cor_rows[[length(cor_rows) + 1]] <- data.table(
    outcome = "WISC FSIQ", spec = paste0("r_", rg),
    weighted = FALSE, b = r_uw, se = sqrt((1 - r_uw^2)^2 / (n - 2)),
    n = n)
  if (!is.na(r_wt)) {
    cor_rows[[length(cor_rows) + 1]] <- data.table(
      outcome = "WISC FSIQ", spec = paste0("r_", rg),
      weighted = TRUE, b = r_wt,
      se = sqrt((1 - r_wt^2)^2 / (nrow(sub_w) - 2)),
      n = nrow(sub_w))
  }
}
rows <- c(rows, cor_rows)

# ---- 2. Birth Order (FE) ----
cat("\n--- 2. Birth Order ---\n\n")

bo <- d[!is.na(wisc_fsiq) & !is.na(birth_order) & !is.na(wt)]
bo[, n_tested := .N, by = mother_id]
bo_fe <- bo[n_tested >= 2]

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  sub_fe <- bo_fe[!is.na(get(y))]
  if (nrow(sub_fe) < 50) next

  fe_uw <- tryCatch(
    feols(as.formula(paste(y, "~ birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id),
    error = function(e) NULL)
  fe_wt <- tryCatch(
    feols(as.formula(paste(y, "~ birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id, weights = ~wt),
    error = function(e) NULL)

  rows[[length(rows) + 1]] <- ext(fe_uw, "birth_order", outcome_labels[i], "bo_FE", FALSE)
  rows[[length(rows) + 1]] <- ext(fe_wt, "birth_order", outcome_labels[i], "bo_FE", TRUE)
}
cat("  Birth order FE: done\n")

# ---- 3. Breastfeeding (FE) ----
cat("\n--- 3. Breastfeeding ---\n\n")

bf <- d[!is.na(wisc_fsiq) & !is.na(bf_any) & !is.na(wt)]
bf[, n_tested := .N, by = mother_id]
bf_fe <- bf[n_tested >= 2]

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  sub_fe <- bf_fe[!is.na(get(y))]
  if (nrow(sub_fe) < 50) next

  fe_uw <- tryCatch(
    feols(as.formula(paste(y, "~ bf_any + factor(sex) + birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id),
    error = function(e) NULL)
  fe_wt <- tryCatch(
    feols(as.formula(paste(y, "~ bf_any + factor(sex) + birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id, weights = ~wt),
    error = function(e) NULL)

  rows[[length(rows) + 1]] <- ext(fe_uw, "bf_any", outcome_labels[i], "bf_FE", FALSE)
  rows[[length(rows) + 1]] <- ext(fe_wt, "bf_any", outcome_labels[i], "bf_FE", TRUE)
}
cat("  Breastfeeding FE: done\n")

# ---- 4. Birth Weight (FE) ----
cat("\n--- 4. Birth Weight ---\n\n")

bw <- d[!is.na(wisc_fsiq) & !is.na(birth_wt_g) & birth_wt_g > 400 & !is.na(wt)]
bw[, bw_100g := birth_wt_g / 100]
bw[, n_tested := .N, by = mother_id]
bw_fe <- bw[n_tested >= 2]

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  sub_fe <- bw_fe[!is.na(get(y))]
  if (nrow(sub_fe) < 50) next

  fe_uw <- tryCatch(
    feols(as.formula(paste(y, "~ bw_100g + factor(sex) + gest_age + birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id),
    error = function(e) NULL)
  fe_wt <- tryCatch(
    feols(as.formula(paste(y, "~ bw_100g + factor(sex) + gest_age + birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id, weights = ~wt),
    error = function(e) NULL)

  rows[[length(rows) + 1]] <- ext(fe_uw, "bw_100g", outcome_labels[i], "bw_FE", FALSE)
  rows[[length(rows) + 1]] <- ext(fe_wt, "bw_100g", outcome_labels[i], "bw_FE", TRUE)
}
cat("  Birth weight FE: done\n")

# ---- 5. Maternal Age (FE) ----
cat("\n--- 5. Maternal Age ---\n\n")

ma <- d[!is.na(wisc_fsiq) & !is.na(maternal_age) & !is.na(wt)]
ma[, n_tested := .N, by = mother_id]
ma_fe <- ma[n_tested >= 2]

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  sub_fe <- ma_fe[!is.na(get(y))]
  if (nrow(sub_fe) < 50) next

  fe_uw <- tryCatch(
    feols(as.formula(paste(y, "~ maternal_age + birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id),
    error = function(e) NULL)
  fe_wt <- tryCatch(
    feols(as.formula(paste(y, "~ maternal_age + birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id, weights = ~wt),
    error = function(e) NULL)

  rows[[length(rows) + 1]] <- ext(fe_uw, "maternal_age", outcome_labels[i], "ma_FE", FALSE)
  rows[[length(rows) + 1]] <- ext(fe_wt, "maternal_age", outcome_labels[i], "ma_FE", TRUE)
}
cat("  Maternal age FE: done\n")

# ---- 6. SES Gradients ----
cat("\n--- 6. SES Gradients ---\n\n")

ses <- d[!is.na(wisc_fsiq) & race %in% c(1, 2) & !is.na(educ_yrs) & !is.na(wt)]

for (race_val in c(1, 2)) {
  race_lab <- ifelse(race_val == 1, "White", "Black")
  sub <- ses[race == race_val]

  for (i in 1:length(outcomes)) {
    y <- outcomes[i]
    # SES script uses raw outcomes for some; use z-scored for comparability
    sub2 <- sub[!is.na(get(y))]
    if (nrow(sub2) < 50) next

    ols_uw <- tryCatch(
      feols(as.formula(paste(y, "~ educ_yrs + factor(sex) + maternal_age + birth_order")),
            data = sub2, vcov = "hetero"),
      error = function(e) NULL)
    ols_wt <- tryCatch(
      feols(as.formula(paste(y, "~ educ_yrs + factor(sex) + maternal_age + birth_order")),
            data = sub2, vcov = "hetero", weights = ~wt),
      error = function(e) NULL)

    spec <- paste0("ses_educ_", race_lab)
    rows[[length(rows) + 1]] <- ext(ols_uw, "educ_yrs", outcome_labels[i], spec, FALSE)
    rows[[length(rows) + 1]] <- ext(ols_wt, "educ_yrs", outcome_labels[i], spec, TRUE)
  }
}
cat("  SES gradients: done\n")

# ---- 7. Smoking (FE) ----
cat("\n--- 7. Smoking ---\n\n")

sm <- d[!is.na(wisc_fsiq) & !is.na(smoker) & !is.na(wt)]
sm[, n_tested := .N, by = mother_id]
sm_fe <- sm[n_tested >= 2]

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  sub_fe <- sm_fe[!is.na(get(y))]
  if (nrow(sub_fe) < 50) next

  fe_uw <- tryCatch(
    feols(as.formula(paste(y, "~ smoker + factor(sex) + birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id),
    error = function(e) NULL)
  fe_wt <- tryCatch(
    feols(as.formula(paste(y, "~ smoker + factor(sex) + birth_order | mother_id")),
          data = sub_fe, vcov = ~mother_id, weights = ~wt),
    error = function(e) NULL)

  rows[[length(rows) + 1]] <- ext(fe_uw, "smoker", outcome_labels[i], "smoke_FE", FALSE)
  rows[[length(rows) + 1]] <- ext(fe_wt, "smoker", outcome_labels[i], "smoke_FE", TRUE)
}
cat("  Smoking FE: done\n")

# NOTE: Growth & IQ (10_growth_iq.R) omitted — growth variables are in a
# separate long-format file (prepared_growth.rds) requiring extensive reshaping.
# The birth-weight FE estimates above already capture the key growth-IQ channel.

# ---- 8. Compile results ----
cat("\n\n--- Comparison: Unweighted vs. Weighted ---\n")

comp <- rbindlist(rows)

# Pivot to wide: unweighted vs weighted side by side
uw <- comp[weighted == FALSE, .(outcome, spec, b_uw = b, se_uw = se, n_uw = n)]
wt_tbl <- comp[weighted == TRUE, .(outcome, spec, b_wt = b, se_wt = se, n_wt = n)]
wide <- merge(uw, wt_tbl, by = c("outcome", "spec"), all = TRUE)
wide[, diff := b_wt - b_uw]
wide[, pct_change := ifelse(abs(b_uw) > 1e-6, 100 * (b_wt - b_uw) / abs(b_uw), NA_real_)]

# Print comparison table
cat(sprintf("%-12s %-18s %8s %8s %8s %8s %8s\n",
            "Outcome", "Specification", "b_unwt", "b_wt", "diff", "pct_chg", "n_wt"))
cat(paste(rep("-", 80), collapse = ""), "\n")

for (i in 1:nrow(wide)) {
  cat(sprintf("%-12s %-18s %8.4f %8.4f %8.4f %7.1f%% %8d\n",
              wide$outcome[i], wide$spec[i],
              wide$b_uw[i], wide$b_wt[i],
              ifelse(is.na(wide$diff[i]), NA, wide$diff[i]),
              ifelse(is.na(wide$pct_change[i]), NA, wide$pct_change[i]),
              ifelse(is.na(wide$n_wt[i]), NA, wide$n_wt[i])))
}

# Summary statistics
cat(sprintf("\nMedian absolute pct change: %.1f%%\n",
            median(abs(wide$pct_change), na.rm = TRUE)))
cat(sprintf("Max absolute pct change: %.1f%% (%s, %s)\n",
            max(abs(wide$pct_change), na.rm = TRUE),
            wide$outcome[which.max(abs(wide$pct_change))],
            wide$spec[which.max(abs(wide$pct_change))]))

# Count how many estimates change sign
sign_changes <- wide[!is.na(b_uw) & !is.na(b_wt) & sign(b_uw) != sign(b_wt) &
                     abs(b_uw) > 0.001 & abs(b_wt) > 0.001]
cat(sprintf("Sign changes: %d / %d estimates\n", nrow(sign_changes), nrow(wide)))

# ---- 9. Save ----
results <- list(
  comparison_table = wide,
  full_results = comp,
  notes = paste0(
    "Weight: combined_age7_urban (IPW × population raking). ",
    "OpenMx pathway/between-group models cannot be weighted (individual-level). ",
    "Replication analyses kept unweighted for fidelity to original methods. ",
    "Attrition analysis omitted (weights ARE the attrition correction)."
  )
)
saveRDS(results, "results_weighted_supplement.rds")

cat("\nResults saved to results_weighted_supplement.rds\n")
cat("Done.\n")
