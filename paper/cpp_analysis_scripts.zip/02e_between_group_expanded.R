#!/usr/bin/env Rscript
# 02e_between_group_expanded.R
# Between-Group IP Model: Free Means (Baseline MI) with 9 Cognitive Measures
#
# Fits the free-means ACE IP model across 8 groups (White/Black x MZ/DZ/FS/HS)
# and reports variance decomposition, loading profiles, mean estimates,
# and Dolan-style decomposition of the Black-White gap.

library(data.table)
library(OpenMx)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")

# Clean sentinel values
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}

links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

cat("\n")
cat("--- BETWEEN-GROUP ANALYSIS (12 Cognitive Measures) Baseline MI (Free-Means ACE IP Model) + Dolan Decomposition ---
")

# ── Define variables ──────────────────────────────────────────────────
sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "Digit",
                "PicArr", "Block", "Coding",
                "WRAT Read", "Bender",
                "WRAT Spell", "WRAT Arith", "Goodenough")
nv <- length(sub_vars)

{

  # ── Standardize variables ─────────────────────────────────────────
  d_z <- copy(d)
  z_means <- z_sds <- setNames(numeric(nv), sub_vars)
  for (v in sub_vars) {
    vals <- d_z[[v]]
    m <- mean(vals, na.rm = TRUE)
    s <- sd(vals, na.rm = TRUE)
    z_means[v] <- m; z_sds[v] <- s
    d_z[, (v) := (get(v) - m) / s]
  }
  cat("  Variables standardized to z-scores.\n")

  # ── Build pair-level data ─────────────────────────────────────────
  d_sub <- d_z[, c("case_id", "race", sub_vars), with = FALSE]

  pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
  setnames(pair, "race", "race_1")
  new_names1 <- paste0(sub_vars, "_1")
  setnames(pair, sub_vars, new_names1)

  pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
  setnames(pair, "race", "race_2")
  new_names2 <- paste0(sub_vars, "_2")
  setnames(pair, sub_vars, new_names2)

  pair[, pair_class := fcase(
    pair_type == "MZ_twin", "MZ",
    pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
    pair_type == "full_sibling", "FS",
    pair_type == "half_sibling", "HS",
    default = NA_character_
  )]
  pair <- pair[!is.na(pair_class)]
  pair <- pair[race_1 == race_2 & race_1 %in% c(1, 2)]
  pair[, race := ifelse(race_1 == 1, "White", "Black")]

  has1 <- rowSums(!is.na(pair[, ..new_names1])) > 0
  has2 <- rowSums(!is.na(pair[, ..new_names2])) > 0
  pair <- pair[has1 & has2]

  # Pair counts
  ct <- pair[, .N, by = .(race, pair_class)]
  ct <- dcast(ct, race ~ pair_class, value.var = "N", fill = 0)
  cat("\nPair counts (Race x Kinship):\n"); print(ct)

  # Observed mean differences (in z-score units = Cohen's d)
  cat(sprintf("\nObserved mean differences (d = White - Black):\n"))
  cat(sprintf("  %-10s  %8s  %8s  %8s\n", "Measure", "White", "Black", "d"))
  cat("  ", strrep("-", 40), "\n")
  obs_gaps <- numeric(nv)
  names(obs_gaps) <- sub_labels
  for (i in seq_along(sub_vars)) {
    v1 <- pair[[new_names1[i]]]; v2 <- pair[[new_names2[i]]]
    vals_w <- c(v1[pair$race == "White"], v2[pair$race == "White"])
    vals_b <- c(v1[pair$race == "Black"], v2[pair$race == "Black"])
    mw <- mean(vals_w, na.rm = TRUE); mb <- mean(vals_b, na.rm = TRUE)
    obs_gaps[i] <- mw - mb
    cat(sprintf("  %-10s  %8.3f  %8.3f  %8.3f\n",
                sub_labels[i], mw, mb, mw - mb))
  }

  # ── Split into 8 groups ───────────────────────────────────────────
  var_names <- c(new_names1, new_names2)
  mkdata <- function(rv, pc) {
    as.data.frame(pair[race == rv & pair_class == pc, ..var_names])
  }

  w_mz <- mkdata("White", "MZ"); w_dz <- mkdata("White", "DZ")
  w_fs <- mkdata("White", "FS"); w_hs <- mkdata("White", "HS")
  b_mz <- mkdata("Black", "MZ"); b_dz <- mkdata("Black", "DZ")
  b_fs <- mkdata("Black", "FS"); b_hs <- mkdata("Black", "HS")

  total_n <- nrow(w_mz) + nrow(w_dz) + nrow(w_fs) + nrow(w_hs) +
             nrow(b_mz) + nrow(b_dz) + nrow(b_fs) + nrow(b_hs)

  cat(sprintf("\n  White: MZ=%d DZ=%d FS=%d HS=%d (total=%d)\n",
              nrow(w_mz), nrow(w_dz), nrow(w_fs), nrow(w_hs),
              nrow(w_mz) + nrow(w_dz) + nrow(w_fs) + nrow(w_hs)))
  cat(sprintf("  Black: MZ=%d DZ=%d FS=%d HS=%d (total=%d)\n",
              nrow(b_mz), nrow(b_dz), nrow(b_fs), nrow(b_hs),
              nrow(b_mz) + nrow(b_dz) + nrow(b_fs) + nrow(b_hs)))

  # ── Submodel builder (ACE, no T) ─────────────────────────────────
  make_sub <- function(p, sub_name, data, R_coeff, use_white) {
    mu_ref <- if (use_white) paste0(p, ".MuW") else paste0(p, ".MuB")
    b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C")
    mxModel(sub_name, mxData(data, "raw"),
      mxAlgebraFromString(b_str, name = "B"),
      mxAlgebraFromString(
        paste0("rbind(cbind(", p, ".V, B), cbind(B, ", p, ".V))"),
        name = "expCov"),
      mxAlgebraFromString(
        paste0("cbind(", mu_ref, ", ", mu_ref, ")"),
        name = "expMean"),
      mxExpectationNormal("expCov", "expMean", dimnames = var_names),
      mxFitFunctionML())
  }

  eight_subs <- function(p) {
    list(
      make_sub(p, "W_MZ", w_mz, 1,    TRUE),
      make_sub(p, "W_DZ", w_dz, 0.5,  TRUE),
      make_sub(p, "W_FS", w_fs, 0.5,  TRUE),
      make_sub(p, "W_HS", w_hs, 0.25, TRUE),
      make_sub(p, "B_MZ", b_mz, 1,    FALSE),
      make_sub(p, "B_DZ", b_dz, 0.5,  FALSE),
      make_sub(p, "B_FS", b_fs, 0.5,  FALSE),
      make_sub(p, "B_HS", b_hs, 0.25, FALSE),
      mxFitFunctionMultigroup(c("W_MZ","W_DZ","W_FS","W_HS",
                                "B_MZ","B_DZ","B_FS","B_HS"))
    )
  }

  ip_core <- function(has_A = TRUE, has_C = TRUE) {
    parts <- list()
    # Common factor loadings
    if (has_A) {
      parts <- c(parts, list(
        mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.5, nv),
                 lbound = -5, name = "ac"),
        mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
                 lbound = 0.001, name = "as")))
    } else {
      parts <- c(parts, list(
        mxMatrix("Full", nv, 1, free = FALSE, values = 0, name = "ac"),
        mxMatrix("Diag", nv, nv, free = FALSE, values = 0, name = "as")))
    }
    if (has_C) {
      parts <- c(parts, list(
        mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.3, nv),
                 lbound = -5, name = "cc"),
        mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.3, nv),
                 lbound = 0.001, name = "cs")))
    } else {
      parts <- c(parts, list(
        mxMatrix("Full", nv, 1, free = FALSE, values = 0, name = "cc"),
        mxMatrix("Diag", nv, nv, free = FALSE, values = 0, name = "cs")))
    }
    parts <- c(parts, list(
      mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.4, nv),
               lbound = -5, name = "ec"),
      mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
               lbound = 0.001, name = "es"),
      mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
      mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
      mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
      mxAlgebra(A + C + E, name = "V"),
      mxMatrix("Full", 1, nv, free = TRUE, values = rep(-0.2, nv),
               name = "MuB")
    ))
    parts
  }

  # ── Fit ACE IP model (free means) ─────────────────────────────────
  fit_ip <- function(label, has_A = TRUE, has_C = TRUE) {
    cat(sprintf("\n  Fitting %s...\n", label))
    parts <- c(
      ip_core(has_A = has_A, has_C = has_C),
      list(mxMatrix("Full", 1, nv, free = TRUE, values = rep(0.2, nv),
                    name = "MuW")),
      eight_subs(label)
    )
    mod <- do.call(mxModel, c(list(label), parts))
    fit <- mxTryHard(mod, extraTries = 100, silent = TRUE)
    s <- summary(fit)
    cat(sprintf("  %s: -2LL = %.2f, k = %d, status = %d\n",
        label, s$Minus2LogLikelihood, s$estimatedParameters,
        fit$output$status$code))
    list(fit = fit, sum = s)
  }

  # Full ACE
  ace <- fit_ip("ACE")
  # Drop C → AE
  ae <- fit_ip("AE", has_A = TRUE, has_C = FALSE)
  # Drop A → CE
  ce <- fit_ip("CE", has_A = FALSE, has_C = TRUE)

  # Model comparison
  cat(sprintf("\n  MODEL COMPARISON:\n"))
  cat(sprintf("  %-20s  %5s  %12s  %6s\n", "Model", "k", "-2LL", "Stat"))
  cat("  ", strrep("-", 50), "\n")
  for (nm in c("ACE", "AE", "CE")) {
    r <- get(tolower(nm))
    cat(sprintf("  %-20s  %5d  %12.2f  %6d\n",
                nm, r$sum$estimatedParameters,
                r$sum$Minus2LogLikelihood,
                r$fit$output$status$code))
  }

  # LRT: ACE vs AE (is C significant?)
  chi2_c <- ae$sum$Minus2LogLikelihood - ace$sum$Minus2LogLikelihood
  df_c <- ace$sum$estimatedParameters - ae$sum$estimatedParameters
  p_c <- pchisq(chi2_c, df_c, lower.tail = FALSE)
  cat(sprintf("\n  Drop C (ACE→AE): chi2=%.2f, df=%d, p=%.4f → C %s\n",
      chi2_c, df_c, p_c, ifelse(p_c < 0.05, "SIGNIFICANT", "n.s.")))

  # LRT: ACE vs CE (is A significant?)
  chi2_a <- ce$sum$Minus2LogLikelihood - ace$sum$Minus2LogLikelihood
  df_a <- ace$sum$estimatedParameters - ce$sum$estimatedParameters
  p_a <- pchisq(chi2_a, df_a, lower.tail = FALSE)
  cat(sprintf("  Drop A (ACE→CE): chi2=%.2f, df=%d, p=%.4f → A %s\n",
      chi2_a, df_a, p_a, ifelse(p_a < 0.05, "SIGNIFICANT", "n.s.")))

  # Use ACE as the primary model
  m1_fit <- ace$fit
  m1_sum <- ace$sum

  # Extract loading profiles
  ac_est <- m1_fit$ac$values[,1]
  cc_est <- m1_fit$cc$values[,1]
  ec_est <- m1_fit$ec$values[,1]

  # ── Loading angle diagnostic ──────────────────────────────────────
  cos_ac_cc <- sum(ac_est * cc_est) /
    (sqrt(sum(ac_est^2)) * sqrt(sum(cc_est^2)))
  angle_deg <- acos(min(abs(cos_ac_cc), 1)) * 180 / pi
  X <- cbind(ac_est, cc_est)
  svd_x <- svd(X)
  cond_num <- max(svd_x$d) / min(svd_x$d)
  pearson_r <- cor(ac_est, cc_est)

  cat(sprintf("\n  LOADING PROFILE DIAGNOSTIC:\n"))
  cat(sprintf("  %-10s  %8s  %8s  %8s\n", "Measure", "ac", "cc", "ec"))
  cat("  ", strrep("-", 38), "\n")
  for (i in seq_along(sub_vars)) {
    cat(sprintf("  %-10s  %8.3f  %8.3f  %8.3f\n",
                sub_labels[i], ac_est[i], cc_est[i], ec_est[i]))
  }

  cat(sprintf("\n    Cosine(ac, cc) = %.4f\n", cos_ac_cc))
  cat(sprintf("    Angle = %.1f degrees\n", angle_deg))
  cat(sprintf("    Pearson r(ac, cc) = %.4f\n", pearson_r))
  cat(sprintf("    Condition number = %.2f\n", cond_num))

  # ── Variance decomposition ─────────────────────────────────────
  cat(sprintf("\n  VARIANCE DECOMPOSITION (ACE IP):\n"))
  as_est <- diag(m1_fit$as$values)
  cs_est <- diag(m1_fit$cs$values)
  es_est <- diag(m1_fit$es$values)

  cat(sprintf("  %-10s  %6s  %6s  %6s  %7s\n",
              "Measure", "h2", "c2", "e2", "% A_com"))
  cat("  ", strrep("-", 42), "\n")
  for (i in seq_along(sub_vars)) {
    a_com <- ac_est[i]^2; a_spec <- as_est[i]^2
    c_com <- cc_est[i]^2; c_spec <- cs_est[i]^2
    e_com <- ec_est[i]^2; e_spec <- es_est[i]^2
    total <- a_com + a_spec + c_com + c_spec + e_com + e_spec
    pct_a_com <- if ((a_com + a_spec) > 0) 100 * a_com / (a_com + a_spec) else 0
    cat(sprintf("  %-10s  %6.3f  %6.3f  %6.3f  %6.1f%%\n",
                sub_labels[i],
                (a_com + a_spec) / total,
                (c_com + c_spec) / total,
                (e_com + e_spec) / total,
                pct_a_com))
  }

  # Mean estimates
  cat(sprintf("\n  MEAN ESTIMATES (z-score units):\n"))
  muB <- mxEval(MuB, m1_fit)[1,]
  muW <- mxEval(MuW, m1_fit)[1,]
  cat(sprintf("  %-10s  %8s  %8s  %8s\n", "Measure", "White", "Black", "Diff"))
  cat("  ", strrep("-", 38), "\n")
  for (i in seq_along(sub_vars)) {
    cat(sprintf("  %-10s  %8.3f  %8.3f  %8.3f\n",
                sub_labels[i], muW[i], muB[i], muW[i] - muB[i]))
  }

  # ── Dolan-style decomposition (post-hoc OLS) ────────────────────
  # Project mean difference vector onto ac and cc loading profiles:
  #   δ = κA * ac + κC * cc + residual
  delta <- muW - muB
  X_decomp <- cbind(ac_est, cc_est)
  kappa <- solve(t(X_decomp) %*% X_decomp, t(X_decomp) %*% delta)
  kA <- kappa[1]; kC <- kappa[2]

  pred_A <- kA * ac_est
  pred_C <- kC * cc_est
  pred_total <- pred_A + pred_C
  residual <- delta - pred_total

  ss_total <- sum(delta^2)
  ss_resid <- sum(residual^2)
  R2 <- 1 - ss_resid / ss_total

  # Naive OLS SEs (treat subtests as observations; caveat: not independent)
  sigma2 <- ss_resid / (nv - 2)
  se_kappa <- sqrt(diag(solve(t(X_decomp) %*% X_decomp)) * sigma2)

  # Unique R² via sequential decomposition
  kA_only <- solve(t(ac_est) %*% ac_est, t(ac_est) %*% delta)[1]
  R2_A_only <- 1 - sum((delta - kA_only * ac_est)^2) / ss_total
  kC_only <- solve(t(cc_est) %*% cc_est, t(cc_est) %*% delta)[1]
  R2_C_only <- 1 - sum((delta - kC_only * cc_est)^2) / ss_total
  unique_A <- R2 - R2_C_only
  unique_C <- R2 - R2_A_only
  shared_AC <- R2 - unique_A - unique_C

  cat(sprintf("\n  DOLAN DECOMPOSITION (post-hoc projection):\n"))
  cat(sprintf("    κA = %.4f (SE = %.4f)  [genetic scaling]\n", kA, se_kappa[1]))
  cat(sprintf("    κC = %.4f (SE = %.4f)  [environmental scaling]\n", kC, se_kappa[2]))
  cat(sprintf("    R² = %.4f (gap profile explained by ac + cc)\n", R2))
  cat(sprintf("    Unique R²_A = %.4f  (genetic, beyond environmental)\n", unique_A))
  cat(sprintf("    Unique R²_C = %.4f  (environmental, beyond genetic)\n", unique_C))
  cat(sprintf("    Shared R²   = %.4f  (collinear portion)\n", shared_AC))

  cat(sprintf("\n  %-10s  %8s  %8s  %8s  %8s  %8s\n",
              "Measure", "Gap", "κA·ac", "κC·cc", "Pred", "Resid"))
  cat("  ", strrep("-", 55), "\n")
  for (i in seq_along(sub_vars)) {
    cat(sprintf("  %-10s  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f\n",
                sub_labels[i], delta[i], pred_A[i], pred_C[i],
                pred_total[i], residual[i]))
  }

  # Between-group heritability (proportion of predicted gap from genetic channel)
  # Shapley-style: average marginal contribution
  shapley_A <- (unique_A + shared_AC / 2) / R2
  shapley_C <- (unique_C + shared_AC / 2) / R2
  cat(sprintf("\n    Between-group heritability (Shapley):\n"))
  cat(sprintf("      Genetic share:       %.1f%%\n", 100 * shapley_A))
  cat(sprintf("      Environmental share: %.1f%%\n", 100 * shapley_C))

  # ── TOTAL DECOMPOSITION (common + specific factors) ───────────────
  # Project gap onto 4 loading vectors: ac, cc, as, cs
  as_vec <- diag(m1_fit$as$values)
  cs_vec <- diag(m1_fit$cs$values)
  X4 <- cbind(ac = ac_est, cc = cc_est, as = as_vec, cs = cs_vec)

  # Shapley decomposition with 4 predictors
  # Compute R² for all 2^4 - 1 = 15 non-empty subsets
  pred_names <- c("ac", "cc", "as", "cs")
  all_R2 <- numeric(15)
  subsets <- list()
  idx <- 1
  for (k in 1:4) {
    combos <- combn(4, k, simplify = FALSE)
    for (s in combos) {
      Xs <- X4[, s, drop = FALSE]
      kap <- tryCatch(solve(t(Xs) %*% Xs, t(Xs) %*% delta), error = function(e) NULL)
      if (!is.null(kap)) {
        pred_s <- Xs %*% kap
        all_R2[idx] <- 1 - sum((delta - pred_s)^2) / ss_total
      }
      subsets[[idx]] <- s
      idx <- idx + 1
    }
  }

  # Compute Shapley values
  n_pred <- 4
  shapley_vals <- numeric(n_pred)
  for (j in 1:n_pred) {
    sv <- 0
    for (idx in seq_along(subsets)) {
      s <- subsets[[idx]]
      if (j %in% s) {
        s_without <- setdiff(s, j)
        if (length(s_without) == 0) {
          marginal <- all_R2[idx]
        } else {
          # Find the subset index for s_without
          for (idx2 in seq_along(subsets)) {
            if (setequal(subsets[[idx2]], s_without)) {
              marginal <- all_R2[idx] - all_R2[idx2]
              break
            }
          }
        }
        sz <- length(s_without)
        weight <- factorial(sz) * factorial(n_pred - sz - 1) / factorial(n_pred)
        sv <- sv + weight * marginal
      }
    }
    shapley_vals[j] <- sv
  }
  names(shapley_vals) <- pred_names
  R2_total_4 <- all_R2[15]  # Full 4-predictor R²

  # Normalize to shares
  shapley_pct <- shapley_vals / R2_total_4

  cat(sprintf("\n  TOTAL DECOMPOSITION (common + specific, 4 predictors):\n"))
  cat(sprintf("    R² (4-predictor) = %.4f\n", R2_total_4))
  cat(sprintf("    Shapley shares:\n"))
  cat(sprintf("      Common genetic (ac):       %.1f%%\n", 100 * shapley_pct["ac"]))
  cat(sprintf("      Common environmental (cc): %.1f%%\n", 100 * shapley_pct["cc"]))
  cat(sprintf("      Specific genetic (as):     %.1f%%\n", 100 * shapley_pct["as"]))
  cat(sprintf("      Specific environmental (cs): %.1f%%\n", 100 * shapley_pct["cs"]))
  cat(sprintf("    Total genetic:       %.1f%%\n",
              100 * (shapley_pct["ac"] + shapley_pct["as"])))
  cat(sprintf("    Total environmental: %.1f%%\n",
              100 * (shapley_pct["cc"] + shapley_pct["cs"])))

  # Store results
  results <- list(
    nv = nv,
    vars = sub_vars, labels = sub_labels,
    obs_gaps = obs_gaps,
    angle_deg = angle_deg, cos_ac_cc = cos_ac_cc,
    cond_num = cond_num, pearson_r = pearson_r,
    ac = ac_est, cc = cc_est, ec = ec_est,
    as_vec = as_vec, cs_vec = cs_vec,
    chi2_drop_c = chi2_c, p_drop_c = p_c,
    chi2_drop_a = chi2_a, p_drop_a = p_a,
    kA = kA, kC = kC, se_kA = se_kappa[1], se_kC = se_kappa[2],
    R2_decomp = R2, unique_A = unique_A, unique_C = unique_C,
    shapley_A = shapley_A, shapley_C = shapley_C,
    R2_total = R2_total_4,
    shapley_4way = shapley_pct,
    total_genetic_share = unname(shapley_pct["ac"] + shapley_pct["as"]),
    total_environmental_share = unname(shapley_pct["cc"] + shapley_pct["cs"]),
    m1_sum = m1_sum, m1_fit = m1_fit,
    total_n = total_n,
    z_means = z_means, z_sds = z_sds
  )

  # ── VP-SEPARATE BETWEEN-GROUP DECOMPOSITIONS ───────────────────────
cat("--- VP-SEPARATE BETWEEN-GROUP DECOMPOSITIONS ---
")

  v_idx <- c(1, 2, 3, 4, 8, 10, 11)  # Info, Comp, Vocab, Digit, WRAT Read, WRAT Spell, WRAT Arith
  p_idx <- c(5, 6, 7, 9, 12)          # PicArr, Block, Coding, Bender, Goodenough

  run_subset_decomp <- function(idx, label) {
    cat(sprintf("\n  === %s subset (%d tests) ===\n", label, length(idx)))
    nv_s <- length(idx)
    svars <- sub_vars[idx]
    slabs <- sub_labels[idx]
    vn1 <- paste0(svars, "_1")
    vn2 <- paste0(svars, "_2")
    vn_s <- c(vn1, vn2)

    # Subset builder
    mk_s <- function(p, sn, data, R_coeff, use_white) {
      mu_ref <- if (use_white) paste0(p, ".MuW") else paste0(p, ".MuB")
      b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C")
      mxModel(sn, mxData(data[, vn_s, drop = FALSE], "raw"),
        mxAlgebraFromString(b_str, name = "B"),
        mxAlgebraFromString(
          paste0("rbind(cbind(", p, ".V, B), cbind(B, ", p, ".V))"),
          name = "expCov"),
        mxAlgebraFromString(
          paste0("cbind(", mu_ref, ", ", mu_ref, ")"),
          name = "expMean"),
        mxExpectationNormal("expCov", "expMean", dimnames = vn_s),
        mxFitFunctionML())
    }

    eight_s <- function(p) {
      list(
        mk_s(p, "W_MZ", w_mz, 1,    TRUE),
        mk_s(p, "W_DZ", w_dz, 0.5,  TRUE),
        mk_s(p, "W_FS", w_fs, 0.5,  TRUE),
        mk_s(p, "W_HS", w_hs, 0.25, TRUE),
        mk_s(p, "B_MZ", b_mz, 1,    FALSE),
        mk_s(p, "B_DZ", b_dz, 0.5,  FALSE),
        mk_s(p, "B_FS", b_fs, 0.5,  FALSE),
        mk_s(p, "B_HS", b_hs, 0.25, FALSE),
        mxFitFunctionMultigroup(c("W_MZ","W_DZ","W_FS","W_HS",
                                  "B_MZ","B_DZ","B_FS","B_HS"))
      )
    }

    parts <- c(
      list(
        mxMatrix("Full", nv_s, 1, free = TRUE, values = rep(0.5, nv_s),
                 lbound = -5, name = "ac"),
        mxMatrix("Diag", nv_s, nv_s, free = TRUE, values = rep(0.5, nv_s),
                 lbound = 0.001, name = "as"),
        mxMatrix("Full", nv_s, 1, free = TRUE, values = rep(0.3, nv_s),
                 lbound = -5, name = "cc"),
        mxMatrix("Diag", nv_s, nv_s, free = TRUE, values = rep(0.3, nv_s),
                 lbound = 0.001, name = "cs"),
        mxMatrix("Full", nv_s, 1, free = TRUE, values = rep(0.4, nv_s),
                 lbound = -5, name = "ec"),
        mxMatrix("Diag", nv_s, nv_s, free = TRUE, values = rep(0.5, nv_s),
                 lbound = 0.001, name = "es"),
        mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
        mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
        mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
        mxAlgebra(A + C + E, name = "V"),
        mxMatrix("Full", 1, nv_s, free = TRUE, values = rep(-0.2, nv_s),
                 name = "MuB"),
        mxMatrix("Full", 1, nv_s, free = TRUE, values = rep(0.2, nv_s),
                 name = "MuW")
      ),
      eight_s(label)
    )
    mod <- do.call(mxModel, c(list(label), parts))
    fit <- mxTryHard(mod, extraTries = 100, silent = TRUE)
    s <- summary(fit)
    cat(sprintf("  %s: -2LL = %.2f, k = %d, status = %d\n",
                label, s$Minus2LogLikelihood, s$estimatedParameters,
                fit$output$status$code))

    # Extract loadings
    ac_s <- fit$ac$values[,1]
    cc_s <- fit$cc$values[,1]
    as_s <- diag(fit$as$values)
    cs_s <- diag(fit$cs$values)

    # Observed gaps for this subset
    delta_s <- obs_gaps[idx]

    # Common-variance Dolan decomposition
    X_s <- cbind(ac_s, cc_s)
    kap_s <- solve(t(X_s) %*% X_s, t(X_s) %*% delta_s)
    pred_s <- X_s %*% kap_s
    ss_tot_s <- sum(delta_s^2)
    R2_s <- 1 - sum((delta_s - pred_s)^2) / ss_tot_s

    # Common-variance Shapley
    R2_A <- 1 - sum((delta_s - solve(t(ac_s) %*% ac_s, t(ac_s) %*% delta_s)[1] * ac_s)^2) / ss_tot_s
    R2_C <- 1 - sum((delta_s - solve(t(cc_s) %*% cc_s, t(cc_s) %*% delta_s)[1] * cc_s)^2) / ss_tot_s
    uA <- R2_s - R2_C; uC <- R2_s - R2_A; shared <- R2_s - uA - uC
    shA <- (uA + shared/2) / R2_s
    shC <- (uC + shared/2) / R2_s

    cat(sprintf("  Common-variance: R² = %.3f, Shapley A = %.1f%%, C = %.1f%%\n",
                R2_s, 100*shA, 100*shC))

    # Total (4-predictor) Shapley decomposition
    X4_s <- cbind(ac = ac_s, cc = cc_s, as = as_s, cs = cs_s)
    pn <- c("ac", "cc", "as", "cs")
    all_R2_s <- numeric(15)
    subsets_s <- list()
    ix <- 1
    for (k in 1:4) {
      combos <- combn(4, k, simplify = FALSE)
      for (ss in combos) {
        Xs <- X4_s[, ss, drop = FALSE]
        kk <- tryCatch(solve(t(Xs) %*% Xs, t(Xs) %*% delta_s), error = function(e) NULL)
        if (!is.null(kk)) {
          all_R2_s[ix] <- 1 - sum((delta_s - Xs %*% kk)^2) / ss_tot_s
        }
        subsets_s[[ix]] <- ss
        ix <- ix + 1
      }
    }
    sh4 <- numeric(4)
    for (j in 1:4) {
      sv <- 0
      for (ix in seq_along(subsets_s)) {
        ss <- subsets_s[[ix]]
        if (j %in% ss) {
          sw <- setdiff(ss, j)
          if (length(sw) == 0) { mg <- all_R2_s[ix] }
          else {
            for (ix2 in seq_along(subsets_s)) {
              if (setequal(subsets_s[[ix2]], sw)) { mg <- all_R2_s[ix] - all_R2_s[ix2]; break }
            }
          }
          wt <- factorial(length(sw)) * factorial(4 - length(sw) - 1) / factorial(4)
          sv <- sv + wt * mg
        }
      }
      sh4[j] <- sv
    }
    names(sh4) <- pn
    R2_4_s <- all_R2_s[15]
    sh4_pct <- sh4 / R2_4_s
    tot_gen <- unname(sh4_pct["ac"] + sh4_pct["as"])
    tot_env <- unname(sh4_pct["cc"] + sh4_pct["cs"])

    cat(sprintf("  Total: R² = %.3f, Shapley gen = %.1f%%, env = %.1f%%\n",
                R2_4_s, 100*tot_gen, 100*tot_env))

    # Angle
    cos_s <- sum(ac_s * cc_s) / (sqrt(sum(ac_s^2)) * sqrt(sum(cc_s^2)))
    angle_s <- acos(min(abs(cos_s), 1)) * 180 / pi
    cat(sprintf("  Angle(ac,cc) = %.1f°\n", angle_s))

    list(R2_cv = R2_s, shapley_cv_A = shA, shapley_cv_C = shC,
         R2_total = R2_4_s, shapley_total_gen = tot_gen, shapley_total_env = tot_env,
         angle = angle_s, ac = ac_s, cc = cc_s,
         labels = slabs, fit_sum = s)
  }

  vp_verbal <- run_subset_decomp(v_idx, "Verbal")
  vp_perf   <- run_subset_decomp(p_idx, "Performance")

  results$vp_verbal <- vp_verbal
  results$vp_perf   <- vp_perf
}

# ── Save ──────────────────────────────────────────────────────────────
saveRDS(results, "results_between_group_expanded.rds")
cat("\nResults saved to results_between_group_expanded.rds\n")
