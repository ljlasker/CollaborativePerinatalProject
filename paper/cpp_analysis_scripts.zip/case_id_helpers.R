# Canonical CPP linkage-ID utilities.
#
# Some CPPVAR records have an eight-character pregnancy prefix because the
# ninth child digit is blank. Other source files represent the same linkage
# key as that prefix plus terminal 0. A legacy conversion used numeric
# left-padding instead, which shifts every component field. These helpers
# right-complete the source prefix and optionally recognize that legacy alias.

cppvar_id_aliases <- function(raw_ids) {
  value <- sub(" +$", "", as.character(raw_ids))
  canonical <- ifelse(nchar(value) == 8L, paste0(value, "0"), value)
  legacy <- ifelse(nchar(value) == 8L,
                   sprintf("%09d", as.integer(value)), value)
  aliases <- unique(data.table::data.table(
    alias = c(value, canonical, legacy),
    canonical = rep(canonical, 3L)
  ))
  if (aliases[, data.table::uniqueN(canonical), by = alias][V1 > 1L, .N])
    stop("Ambiguous CPP case-ID alias map")
  aliases
}

canonicalize_cpp_case_id <- function(x, raw_ids = NULL, strict = FALSE) {
  value <- sub(" +$", "", as.character(x))
  if (is.null(raw_ids)) {
    short <- nchar(value) == 8L
    value[short] <- paste0(value[short], "0")
  } else {
    aliases <- cppvar_id_aliases(raw_ids)
    hit <- match(value, aliases$alias)
    value[!is.na(hit)] <- aliases$canonical[hit[!is.na(hit)]]
    if (strict && anyNA(hit))
      stop(sprintf("%d case IDs have no CPPVAR alias match", sum(is.na(hit))))
  }
  if (strict && (anyNA(value) || any(nchar(value) != 9L)))
    stop("Missing or non-nine-character canonical case ID")
  value
}
