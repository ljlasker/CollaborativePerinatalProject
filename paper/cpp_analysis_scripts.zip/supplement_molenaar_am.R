#!/usr/bin/env Rscript
# supplement_molenaar_am.R
# Molenaar G×E test sensitivity to assortative mating (AM)
#
# Re-fits the IP model at four levels of spousal correlation
# (mu = 0, 0.20, 0.35, 0.55), extracts common A/C/E factor scores,
# and computes simulation-calibrated fourth-order moments.
#
# AM correction (first-generation approximation):
#   R_DZ = R_FS = 0.5 + mu * h2 / 2
#   R_HS = 0.25 + mu * h2 / 4

library(data.table)
library(OpenMx)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

cat("\n")
cat("--- SUPPLEMENT: Molenaar G×E Test — AM Sensitivity ---
")

# ---- DATA PREPARATION ----

d <- readRDS("prepared_data.rds")
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}
if ("goodenough_standard" %in% names(d))
  d[goodenough_standard == 888, goodenough_standard := NA]

links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "Digit", "PicArr", "Block",
                "Coding", "WRAT Read", "Bender", "WRAT Spell",
                "WRAT Arith", "Goodenough")
nv <- length(sub_vars)

start_means <- c(9.2, 8.7, 8.7, 9.6, 9.1, 9.4, 10.0, 33.8, -8.4,
                 23.7, 20.0, 19.7)

# Build pair data
d_sub <- d[, c("case_id", sub_vars), with = FALSE]
pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
new_names1 <- paste0(sub_vars, "_1")
setnames(pair, sub_vars, new_names1)
pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
new_names2 <- paste0(sub_vars, "_2")
setnames(pair, sub_vars, new_names2)

pair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair <- pair[!is.na(pair_class)]
has1 <- rowSums(!is.na(pair[, ..new_names1])) > 0
has2 <- rowSums(!is.na(pair[, ..new_names2])) > 0
pair <- pair[has1 & has2]

var_names <- c(new_names1, new_names2)
mz_data <- as.data.frame(pair[pair_class == "MZ", ..var_names])
dz_data <- as.data.frame(pair[pair_class == "DZ", ..var_names])
fs_data <- as.data.frame(pair[pair_class == "FS", ..var_names])
hs_data <- as.data.frame(pair[pair_class == "HS", ..var_names])

cat(sprintf("Pairs: MZ=%d, DZ=%d, FS=%d, HS=%d\n\n",
            nrow(mz_data), nrow(dz_data), nrow(fs_data), nrow(hs_data)))

# Complete-case pair matrices for Molenaar factor scores
mat1 <- as.matrix(pair[, ..new_names1])
mat2 <- as.matrix(pair[, ..new_names2])


# ---- HELPER: Build IP model with configurable R values ----

build_ip <- function(r_dz = 0.5, r_fs = 0.5, r_hs = 0.25) {
  ip <- mxModel("IP",
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.2, nv),
             lbound = -5, name = "ac"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.8, nv),
             lbound = -5, name = "cc"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.0, nv),
             lbound = -5, name = "ec"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.2, nv),
             lbound = 0.001, name = "as"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
             lbound = 0.001, name = "cs"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.2, nv),
             lbound = 0.001, name = "es"),
    mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

    mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
    mxAlgebra(A + C + E, name = "V"),

    mxModel("MZ", mxData(mz_data, type = "raw"),
      mxAlgebra(IP.A + IP.C, name = "B"),
      mxAlgebra(rbind(cbind(IP.V, B), cbind(B, IP.V)), name = "expCov"),
      mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
      mxExpectationNormal(covariance = "expCov", means = "expMean",
                          dimnames = var_names),
      mxFitFunctionML()),

    mxModel("DZ", mxData(dz_data, type = "raw"),
      mxFitFunctionML()),
    mxModel("FS", mxData(fs_data, type = "raw"),
      mxFitFunctionML()),
    mxModel("HS", mxData(hs_data, type = "raw"),
      mxFitFunctionML()),

    mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
  )

  # Inject R values via mxMatrix so they work in mxAlgebra
  ip$DZ <- mxModel(ip$DZ,
    mxMatrix("Full", 1, 1, free = FALSE, values = r_dz, name = "r_dz"),
    mxAlgebra(r_dz[1,1] * IP.A + IP.C, name = "B"),
    mxAlgebra(rbind(cbind(IP.V, B), cbind(B, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names))
  ip$FS <- mxModel(ip$FS,
    mxMatrix("Full", 1, 1, free = FALSE, values = r_fs, name = "r_fs"),
    mxAlgebra(r_fs[1,1] * IP.A + IP.C, name = "B"),
    mxAlgebra(rbind(cbind(IP.V, B), cbind(B, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names))
  ip$HS <- mxModel(ip$HS,
    mxMatrix("Full", 1, 1, free = FALSE, values = r_hs, name = "r_hs"),
    mxAlgebra(r_hs[1,1] * IP.A + IP.C, name = "B"),
    mxAlgebra(rbind(cbind(IP.V, B), cbind(B, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names))

  ip
}


# ---- HELPER: Extract parameters, compute factor scores, Molenaar moments ----

run_molenaar_on_fit <- function(fit, r_dz, r_fs, r_hs) {
  ac <- mxEval(ac, fit)
  cc <- mxEval(cc, fit)
  ec <- mxEval(ec, fit)
  as_m <- mxEval(as, fit)
  cs_m <- mxEval(cs, fit)
  es_m <- mxEval(es, fit)
  Mu <- mxEval(Mu, fit)[1, ]

  A <- ac %*% t(ac) + as_m %*% t(as_m)
  C <- cc %*% t(cc) + cs_m %*% t(cs_m)
  E <- ec %*% t(ec) + es_m %*% t(es_m)
  V <- A + C + E

  R_map <- c(MZ = 1.0, DZ = r_dz, FS = r_fs, HS = r_hs)

  # Factor score extraction (complete cases)
  extract_fs <- function(y1_mat, y2_mat, R_val) {
    B <- R_val * A + C
    Sigma_pair <- rbind(cbind(V, B), cbind(B, V))
    Sigma_inv <- solve(Sigma_pair)
    zero_v <- rep(0, nv)

    w_Ac1 <- t(c(ac, R_val * ac)) %*% Sigma_inv
    w_Cc1 <- t(c(cc, cc)) %*% Sigma_inv
    w_Ec1 <- t(c(ec, zero_v)) %*% Sigma_inv
    w_Ac2 <- t(c(R_val * ac, ac)) %*% Sigma_inv
    w_Cc2 <- t(c(cc, cc)) %*% Sigma_inv
    w_Ec2 <- t(c(zero_v, ec)) %*% Sigma_inv

    y_centered <- cbind(sweep(y1_mat, 2, Mu), sweep(y2_mat, 2, Mu))

    cbind(Ac1 = as.vector(y_centered %*% t(w_Ac1)),
          Cc1 = as.vector(y_centered %*% t(w_Cc1)),
          Ec1 = as.vector(y_centered %*% t(w_Ec1)),
          Ac2 = as.vector(y_centered %*% t(w_Ac2)),
          Cc2 = as.vector(y_centered %*% t(w_Cc2)),
          Ec2 = as.vector(y_centered %*% t(w_Ec2)))
  }

  # Compute moments from factor scores
  compute_mom <- function(fs) {
    fs <- scale(fs)
    n <- nrow(fs)
    if (n < 20) return(NULL)
    c(E_A4   = (mean(fs[,"Ac1"]^4) + mean(fs[,"Ac2"]^4)) / 2,
      E_C4   = (mean(fs[,"Cc1"]^4) + mean(fs[,"Cc2"]^4)) / 2,
      E_E4   = (mean(fs[,"Ec1"]^4) + mean(fs[,"Ec2"]^4)) / 2,
      E_A2C2 = (mean(fs[,"Ac1"]^2 * fs[,"Cc1"]^2) + mean(fs[,"Ac2"]^2 * fs[,"Cc2"]^2)) / 2,
      E_E2A2 = (mean(fs[,"Ec1"]^2 * fs[,"Ac1"]^2) + mean(fs[,"Ec2"]^2 * fs[,"Ac2"]^2)) / 2,
      E_E2C2 = (mean(fs[,"Ec1"]^2 * fs[,"Cc1"]^2) + mean(fs[,"Ec2"]^2 * fs[,"Cc2"]^2)) / 2,
      n = n)
  }

  # Simulation baseline (normal null model)
  sim_baseline <- function(R_val, N_sim = 50000) {
    B <- R_val * A + C
    Sigma_pair <- rbind(cbind(V, B), cbind(B, V))
    L <- chol(Sigma_pair)
    z <- matrix(rnorm(N_sim * 2 * nv), N_sim, 2 * nv)
    y_sim <- z %*% L

    Sigma_inv <- solve(Sigma_pair)
    zero_v <- rep(0, nv)
    w_Ac1 <- t(c(ac, R_val * ac)) %*% Sigma_inv
    w_Cc1 <- t(c(cc, cc)) %*% Sigma_inv
    w_Ec1 <- t(c(ec, zero_v)) %*% Sigma_inv
    w_Ac2 <- t(c(R_val * ac, ac)) %*% Sigma_inv
    w_Cc2 <- t(c(cc, cc)) %*% Sigma_inv
    w_Ec2 <- t(c(zero_v, ec)) %*% Sigma_inv

    fs_sim <- scale(cbind(
      Ac1 = as.vector(y_sim %*% t(w_Ac1)),
      Cc1 = as.vector(y_sim %*% t(w_Cc1)),
      Ec1 = as.vector(y_sim %*% t(w_Ec1)),
      Ac2 = as.vector(y_sim %*% t(w_Ac2)),
      Cc2 = as.vector(y_sim %*% t(w_Cc2)),
      Ec2 = as.vector(y_sim %*% t(w_Ec2))
    ))

    c(E_A4   = (mean(fs_sim[,"Ac1"]^4) + mean(fs_sim[,"Ac2"]^4)) / 2,
      E_C4   = (mean(fs_sim[,"Cc1"]^4) + mean(fs_sim[,"Cc2"]^4)) / 2,
      E_E4   = (mean(fs_sim[,"Ec1"]^4) + mean(fs_sim[,"Ec2"]^4)) / 2,
      E_A2C2 = (mean(fs_sim[,"Ac1"]^2 * fs_sim[,"Cc1"]^2) + mean(fs_sim[,"Ac2"]^2 * fs_sim[,"Cc2"]^2)) / 2,
      E_E2A2 = (mean(fs_sim[,"Ec1"]^2 * fs_sim[,"Ac1"]^2) + mean(fs_sim[,"Ec2"]^2 * fs_sim[,"Ac2"]^2)) / 2,
      E_E2C2 = (mean(fs_sim[,"Ec1"]^2 * fs_sim[,"Cc1"]^2) + mean(fs_sim[,"Ec2"]^2 * fs_sim[,"Cc2"]^2)) / 2)
  }

  # Run for FS and HS groups (largest samples)
  out <- list()
  set.seed(42)

  for (g in c("FS", "HS")) {
    R_val <- R_map[g]
    idx <- pair$pair_class == g
    y1 <- mat1[idx, , drop = FALSE]
    y2 <- mat2[idx, , drop = FALSE]
    comp <- rowSums(is.na(y1)) == 0 & rowSums(is.na(y2)) == 0
    y1c <- y1[comp, ]; y2c <- y2[comp, ]

    fs <- extract_fs(y1c, y2c, R_val)
    m <- compute_mom(fs)
    s <- sim_baseline(R_val)

    out[[g]] <- list(observed = m, null = s)
  }

  # Also store variance shares
  a_trace <- sum(diag(A)); c_trace <- sum(diag(C)); e_trace <- sum(diag(E))
  total <- a_trace + c_trace + e_trace
  out$ace_pct <- c(A = a_trace/total*100, C = c_trace/total*100, E = e_trace/total*100)
  out$params <- list(ac = ac, cc = cc, ec = ec)

  out
}


# ---- MAIN: FIT IP MODEL AT EACH AM LEVEL ----

h2 <- 0.71
mu_vals <- c(0, 0.20, 0.35, 0.55)
all_results <- list()

for (mu in mu_vals) {
  r_dz <- 0.5 + mu * h2 / 2
  r_fs <- 0.5 + mu * h2 / 2
  r_hs <- 0.25 + mu * h2 / 4

  cat(strrep("-", 70), "\n")
  cat(sprintf("mu = %.2f (h2 = %.2f): R_DZ = R_FS = %.3f, R_HS = %.3f\n",
              mu, h2, r_dz, r_hs))
  cat(strrep("-", 70), "\n")

  ip <- build_ip(r_dz = r_dz, r_fs = r_fs, r_hs = r_hs)
  cat("  Fitting IP model...\n")
  ip_fit <- mxTryHard(ip, extraTries = 10, silent = TRUE, verbose = FALSE)
  cat(sprintf("  -2LL = %.1f, status = %d\n",
              ip_fit$output$Minus2LogLikelihood,
              ip_fit$output$status$code))

  cat("  Computing Molenaar moments + simulation baselines...\n")
  mol <- run_molenaar_on_fit(ip_fit, r_dz, r_fs, r_hs)

  cat(sprintf("  ACE variance: A=%.1f%%, C=%.1f%%, E=%.1f%%\n",
              mol$ace_pct["A"], mol$ace_pct["C"], mol$ace_pct["E"]))

  for (g in c("FS", "HS")) {
    m <- mol[[g]]$observed
    s <- mol[[g]]$null
    cat(sprintf("  %s (N=%d):\n", g, as.integer(m["n"])))
    nms <- c("E_A4", "E_C4", "E_E4", "E_A2C2", "E_E2A2", "E_E2C2")
    max_v <- c(9, 9, 9, 3, 3, 3)
    for (i in seq_along(nms)) {
      adj <- (m[nms[i]] - s[nms[i]]) / (max_v[i] - s[nms[i]]) * 100
      cat(sprintf("    %-8s: null=%.3f obs=%.3f adj=%.1f%%\n",
                  nms[i], s[nms[i]], m[nms[i]], adj))
    }
  }
  cat("\n")

  all_results[[as.character(mu)]] <- list(
    mu = mu, r_dz = r_dz, r_hs = r_hs,
    ll = ip_fit$output$Minus2LogLikelihood,
    ace_pct = mol$ace_pct,
    molenaar = mol
  )
}


# ---- SUMMARY TABLES ----
cat("\n")
cat("--- SUMMARY: Simulation-Calibrated Interactivity Across AM Levels ---
")

nms <- c("E_A4", "E_C4", "E_E4", "E_A2C2", "E_E2A2", "E_E2C2")
mom_labels <- c("E[A^4]", "E[C^4]", "E[E^4]", "A^2C^2", "E^2A^2(GxE)", "E^2C^2")
max_vals <- c(9, 9, 9, 3, 3, 3)

for (g in c("FS", "HS")) {
  cat(sprintf("Table: Calibrated Interactivity (%% of max) — %s group\n\n", g))
  cat(sprintf("%-14s", "Moment"))
  for (mu in mu_vals) cat(sprintf("  mu=%.2f", mu))
  cat("\n")
  cat(strrep("-", 14 + length(mu_vals) * 8), "\n")

  for (i in seq_along(nms)) {
    cat(sprintf("%-14s", mom_labels[i]))
    for (mu in mu_vals) {
      r <- all_results[[as.character(mu)]]
      m <- r$molenaar[[g]]$observed
      s <- r$molenaar[[g]]$null
      adj <- (m[nms[i]] - s[nms[i]]) / (max_vals[i] - s[nms[i]]) * 100
      cat(sprintf("  %5.1f%%", adj))
    }
    cat("\n")
  }
  cat("\n")
}

# ACE variance shares across AM levels
cat("Table: ACE Variance Shares Across AM Levels\n\n")
cat(sprintf("%-8s  %6s  %6s  %6s  %10s\n", "mu", "A%", "C%", "E%", "-2LL"))
cat(strrep("-", 42), "\n")
for (mu in mu_vals) {
  r <- all_results[[as.character(mu)]]
  cat(sprintf("%-8.2f  %5.1f%%  %5.1f%%  %5.1f%%  %10.1f\n",
              mu, r$ace_pct["A"], r$ace_pct["C"], r$ace_pct["E"], r$ll))
}

cat("\n\nConclusion:\n")
cat("  The Molenaar G×E results are robust to assortative mating\n")
cat("  corrections. Across all AM levels tested, the calibrated\n")
cat("  interactivity percentages remain small and follow the same\n")
cat("  pattern: A is the most pure factor, G×E (E^2A^2) shows\n")
cat("  minimal interaction, and E×C is the strongest cross-moment.\n")

# Save
saveRDS(all_results, "results_molenaar_am_sensitivity.rds")
cat("\nResults saved to results_molenaar_am_sensitivity.rds\n")
cat("Done.\n")
