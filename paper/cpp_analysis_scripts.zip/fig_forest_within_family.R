#!/usr/bin/env Rscript
# fig_forest_within_family.R — Forest plot of OLS vs Mother FE estimates
# Breastfeeding, smoking, birth order, birth weight, maternal age

library(data.table)
library(fixest)

# ── Load results ──────────────────────────────────────────────────────
bf   <- readRDS("results_breastfeeding.rds")
sm   <- readRDS("results_smoking.rds")
bo   <- readRDS("results_birth_order.rds")
bw   <- readRDS("results_birthweight.rds")
ma   <- readRDS("results_maternal_age.rds")

# ── Extract WISC FSIQ estimates ───────────────────────────────────────
get_coef <- function(mod, var) {
  s <- summary(mod)
  ct <- s$coeftable  # fixest uses coeftable
  idx <- grep(paste0("^", var, "$"), rownames(ct))
  if (length(idx) == 0) idx <- grep(var, rownames(ct))[1]
  c(b = ct[idx, 1], se = ct[idx, 2])
}

# Breastfeeding (bf_any on wisc_fsiq_z)
bf_ols <- get_coef(bf$bf_results$wisc_fsiq_z$ols, "bf_any")
bf_fe  <- get_coef(bf$bf_results$wisc_fsiq_z$fe_all, "bf_any")

# Smoking (smoker on wisc_fsiq_z) — ols2 includes SES controls
sm_ols <- get_coef(sm$sm_results$wisc_fsiq_z$ols2, "smoker")
sm_fe  <- get_coef(sm$sm_results$wisc_fsiq_z$fe, "smoker")

# Birth order (parity on wisc_fsiq_z)
bo_ols <- get_coef(bo$fe_results$wisc_fsiq_z$ols, "parity")
bo_fe  <- get_coef(bo$fe_results$wisc_fsiq_z$fe, "parity")

# Birth weight (bw_100g on wisc_fsiq_z)
bw_ols <- get_coef(bw$bw_results$wisc_fsiq_z$ols, "bw_100g")
bw_fe  <- get_coef(bw$bw_results$wisc_fsiq_z$fe, "bw_100g")

# Maternal age — stored OLS omits race controls, inflating the coefficient
# Recompute with race + birth_order controls to match the text
ma_fe  <- get_coef(ma$ma_results$wisc_fsiq_z$fe_lin, "maternal_age")
d_raw <- as.data.table(readRDS("prepared_data.rds"))
d_raw <- d_raw[!is.na(wisc_fsiq) & !is.na(maternal_age) & race %in% c(1, 2)]
d_raw[, fsiq_z := (wisc_fsiq - mean(wisc_fsiq)) / sd(wisc_fsiq)]
ma_ols_fit <- feols(fsiq_z ~ maternal_age + factor(sex) + factor(race) + birth_order,
                    data = d_raw, vcov = "hetero")
ma_ols <- c(b = unname(coef(ma_ols_fit)["maternal_age"]),
            se = unname(se(ma_ols_fit)["maternal_age"]))

cat("=== Maternal age ===\n")
cat(sprintf("OLS (with race): b=%.4f (SE=%.4f)\n", ma_ols["b"], ma_ols["se"]))
cat(sprintf("FE:              b=%.4f (SE=%.4f)\n", ma_fe["b"], ma_fe["se"]))

# ── Build data frame ─────────────────────────────────────────────────
labs <- c("Breastfeeding\n(ever vs. never)",
          "Prenatal smoking\n(smoker vs. non)",
          "Birth order\n(per parity increment)",
          "Birth weight\n(per 100g)",
          "Maternal age\n(per year)")

d <- data.frame(
  analysis = rep(labs, each = 2),
  model    = rep(c("OLS", "Mother FE"), 5),
  b  = c(bf_ols["b"], bf_fe["b"],
         sm_ols["b"], sm_fe["b"],
         bo_ols["b"], bo_fe["b"],
         bw_ols["b"], bw_fe["b"],
         ma_ols["b"], ma_fe["b"]),
  se = c(bf_ols["se"], bf_fe["se"],
         sm_ols["se"], sm_fe["se"],
         bo_ols["se"], bo_fe["se"],
         bw_ols["se"], bw_fe["se"],
         ma_ols["se"], ma_fe["se"]),
  stringsAsFactors = FALSE
)
d$lo <- d$b - 1.96 * d$se
d$hi <- d$b + 1.96 * d$se

# Print all values for verification
cat("\n=== All estimates ===\n")
cat(sprintf("%-30s  %8s  %8s  %8s  %8s\n", "Analysis", "OLS_b", "OLS_se", "FE_b", "FE_se"))
for (i in seq(1, nrow(d), by = 2)) {
  cat(sprintf("%-30s  %8.4f  %8.4f  %8.4f  %8.4f\n",
              gsub("\n", " ", d$analysis[i]),
              d$b[i], d$se[i], d$b[i+1], d$se[i+1]))
}

# Row positions
n_analyses <- 5
d$y <- rep(seq(n_analyses, 1), each = 2) + rep(c(0.15, -0.15), n_analyses)

# Colors
col_ols <- "#2C3E50"
col_fe  <- "#8B1A1A"

# ── Plot ──────────────────────────────────────────────────────────────
pdf("fig_forest_within_family.pdf", width = 8, height = 5.5)
par(mar = c(4, 12, 3, 2), family = "serif")

xlim <- c(min(d$lo) - 0.05, max(d$hi) + 0.05)

plot(NULL, xlim = xlim, ylim = c(0.3, n_analyses + 0.7),
     xlab = "Coefficient (SD units)", ylab = "",
     yaxt = "n", bty = "n", las = 1, cex.axis = 0.9, cex.lab = 1)

# Vertical zero line
abline(v = 0, lty = 2, col = "gray50")

# Light horizontal separators
for (i in 1:(n_analyses - 1)) {
  abline(h = i + 0.5, col = "gray90", lty = 1)
}

# Plot points and CIs
for (i in 1:nrow(d)) {
  col <- if (d$model[i] == "OLS") col_ols else col_fe
  pch <- if (d$model[i] == "OLS") 16 else 18
  cex <- if (d$model[i] == "OLS") 1.2 else 1.4

  segments(d$lo[i], d$y[i], d$hi[i], d$y[i], col = col, lwd = 2)
  points(d$b[i], d$y[i], col = col, pch = pch, cex = cex)
}

# Y-axis labels
axis(2, at = n_analyses:1, labels = labs, las = 1, tick = FALSE,
     cex.axis = 0.85, line = -0.5)

# Legend
legend("bottomleft", legend = c("OLS (cross-sectional)", "Mother fixed effects"),
       col = c(col_ols, col_fe), pch = c(16, 18), pt.cex = c(1.2, 1.4),
       lwd = 2, bty = "n", cex = 0.9)

# Title
mtext("Within-Family vs. Cross-Sectional Effects on WISC FSIQ",
      side = 3, line = 1.5, cex = 1.1, font = 2)
mtext("OLS controls for sex, race, and birth order; 95% CIs shown",
      side = 3, line = 0.3, cex = 0.85, col = "gray40")

dev.off()
cat("\nSaved fig_forest_within_family.pdf\n")
