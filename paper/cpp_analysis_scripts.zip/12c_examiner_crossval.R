#!/usr/bin/env Rscript
# 12c_examiner_crossval.R — Cross-validate examiner ratings against
# (1) written-output tests (WRAT, Bender, Goodenough),
# (2) Stanford-Binet at age 4 (different examiner, different session),
# (3) higher-order latent model separating observed vs written-output tests.

library(data.table)
library(lavaan)
library(mirt)

cat("--- Examiner Cross-Validation: Observed vs Written-Output Tests ---\n\n")

# ---- Load data ----
d <- as.data.table(readRDS("prepared_data.rds"))
d[, case_id := as.character(case_id)]

# Load PSY25 examiner items from card 41300
beh7 <- fread("../clean/master/parsed/card_41300_parsed.csv")
beh7[, case_id := as.character(case_id)]

beh7_fields <- fread("../clean/master/parsed/card_41300_fields.csv")
psy25_fields <- beh7_fields[grepl("PSY25", data_id)]
psy25_fields[, col_key := paste(data_col_from, data_col_to, sep = "-")]
psy25_unique <- psy25_fields[!duplicated(col_key)]
psy25_vars <- intersect(psy25_unique$varname, names(beh7))

# Recode items
for (col in psy25_vars) {
  beh7[, (col) := suppressWarnings(as.integer(get(col)))]
  fw <- psy25_unique[varname == col, field_width]
  if (length(fw) > 0 && fw == 2) {
    beh7[!is.na(get(col)), (col) := as.integer(get(col) %/% 10)]
  }
  beh7[get(col) %in% c(8, 9, 88, 99), (col) := NA_integer_]
}

# Filter to items with sufficient variance
psy25_good <- character(0)
for (col in psy25_vars) {
  v <- beh7[[col]][!is.na(beh7[[col]])]
  if (length(unique(v)) >= 2 && length(v) >= 5000) {
    psy25_good <- c(psy25_good, col)
  }
}
cat(sprintf("PSY25 items: %d\n", length(psy25_good)))

# Domain classification
comp_items <- psy25_good[grepl("^comprehension", psy25_good)]
read_items <- psy25_good[grepl("^reading", psy25_good)]
pers_items <- psy25_good[grepl("^personality", psy25_good)]

# Merge examiner items with cognitive data
beh7_merged <- merge(
  beh7[, c("case_id", psy25_good), with = FALSE],
  d[, .(case_id, race,
        wisc_info, wisc_comp, wisc_vocab, wisc_digit,
        wisc_picarr, wisc_block, wisc_coding,
        wrat_read_raw, wrat_spell_raw, wrat_arith_raw,
        bender_gestalt, goodenough_raw,
        wisc_fsiq, sb_iq)],
  by = "case_id"
)

# Create examiner parcels (reverse-coded: higher = better)
beh7_merged[, comp_parcel := rowMeans(.SD, na.rm = FALSE), .SDcols = comp_items]
beh7_merged[, read_parcel := rowMeans(.SD, na.rm = FALSE), .SDcols = read_items]
beh7_merged[, pers_parcel := rowMeans(.SD, na.rm = FALSE), .SDcols = pers_items]
for (p in c("comp_parcel", "read_parcel", "pers_parcel")) {
  mx <- max(beh7_merged[[p]], na.rm = TRUE)
  beh7_merged[, (p) := mx - get(p)]
}

cat(sprintf("Merged sample: %d children\n", nrow(beh7_merged)))


# ===========================================================================
# SECTION A: Observed Correlations (Examiner IRT/PCA vs Various g Factors)
# ===========================================================================
cat("\n\n========== A. OBSERVED CORRELATIONS ==========\n")

# Compute examiner IRT score
items_mat <- as.data.frame(beh7_merged[, ..psy25_good])
mod_irt <- mirt(items_mat, 1, itemtype = "graded", verbose = FALSE,
                technical = list(NCYCLES = 2000))
beh7_merged[, examiner_irt := fscores(mod_irt, full.scores = TRUE)[, 1]]
mrel <- marginal_rxx(mod_irt)
cat(sprintf("Examiner IRT marginal reliability: %.3f\n", mrel))

# Compute examiner PCA score
items_cc <- beh7_merged[complete.cases(beh7_merged[, ..psy25_good])]
items_for_pca <- as.matrix(items_cc[, ..psy25_good])
pca_ex <- prcomp(items_for_pca, center = TRUE, scale. = TRUE)
pc1 <- pca_ex$x[, 1]
if (cor(pc1, items_cc$wisc_fsiq, use = "complete.obs") < 0) pc1 <- -pc1
items_cc[, examiner_pca := pc1]
beh7_merged <- merge(beh7_merged, items_cc[, .(case_id, examiner_pca)],
                     by = "case_id", all.x = TRUE)

# Define test groups
wisc_subtests <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit")
wisc_all7 <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
               "wisc_picarr", "wisc_block", "wisc_coding")
written_tests <- c("wrat_read_raw", "wrat_spell_raw", "wrat_arith_raw",
                    "bender_gestalt", "goodenough_raw")

# Compute PCA g for each test group
compute_pca_g <- function(dt, vars, label) {
  cc <- dt[complete.cases(dt[, ..vars])]
  mat <- scale(as.matrix(cc[, ..vars]))
  pca <- prcomp(mat, center = FALSE, scale. = FALSE)
  pc1 <- pca$x[, 1]
  # Orient positively with first var
  if (cor(pc1, cc[[vars[1]]]) < 0) pc1 <- -pc1
  pct <- summary(pca)$importance[2, 1] * 100
  cat(sprintf("  %s g: %d cases, %.1f%% var explained\n", label, nrow(cc), pct))
  cc[, g := pc1]
  cc[, .(case_id, g)]
}

cat("\nComputing PCA g factors:\n")
g_wisc4 <- compute_pca_g(beh7_merged, wisc_subtests, "WISC-4")
setnames(g_wisc4, "g", "g_wisc4")
g_wisc7 <- compute_pca_g(beh7_merged, wisc_all7, "WISC-7")
setnames(g_wisc7, "g", "g_wisc7")
g_written <- compute_pca_g(beh7_merged, written_tests, "Written-output")
setnames(g_written, "g", "g_written")

beh7_merged <- Reduce(function(a, b) merge(a, b, by = "case_id", all.x = TRUE),
                      list(beh7_merged, g_wisc4, g_wisc7, g_written))

cat("\nObserved correlations (examiner scores with various measures):\n")
cor_vars <- c("examiner_irt", "examiner_pca",
              "g_wisc4", "g_wisc7", "g_written",
              "wisc_fsiq", "sb_iq")
cor_mat <- cor(beh7_merged[, ..cor_vars], use = "pairwise.complete.obs")
cat(sprintf("  %-20s  %8s  %8s  %8s  %8s  %8s  %8s  %8s\n",
            "", "Ex_IRT", "Ex_PCA", "g_W4", "g_W7", "g_Writ", "WISC", "SB"))
for (v in cor_vars) {
  vals <- sapply(cor_vars, function(cv) cor_mat[v, cv])
  cat(sprintf("  %-20s", v))
  for (val in vals) cat(sprintf("  %8.3f", val))
  cat("\n")
}

cat("\nKey cross-validation results:\n")
r_irt_wisc <- cor(beh7_merged$examiner_irt, beh7_merged$wisc_fsiq, use = "complete.obs")
r_irt_written <- cor(beh7_merged$examiner_irt, beh7_merged$g_written, use = "complete.obs")
r_irt_sb <- cor(beh7_merged$examiner_irt, beh7_merged$sb_iq, use = "complete.obs")
n_wisc <- sum(!is.na(beh7_merged$examiner_irt) & !is.na(beh7_merged$wisc_fsiq))
n_written <- sum(!is.na(beh7_merged$examiner_irt) & !is.na(beh7_merged$g_written))
n_sb <- sum(!is.na(beh7_merged$examiner_irt) & !is.na(beh7_merged$sb_iq))

cat(sprintf("  Examiner IRT vs WISC FSIQ (observed):     r = %.3f (N = %d)\n", r_irt_wisc, n_wisc))
cat(sprintf("  Examiner IRT vs Written-output g (PCA):   r = %.3f (N = %d)\n", r_irt_written, n_written))
cat(sprintf("  Examiner IRT vs Stanford-Binet IQ (age 4): r = %.3f (N = %d)\n", r_irt_sb, n_sb))

cat("\n  Note: The WISC was individually administered — the examiner heard every\n")
cat("  verbal response and scored in real time. The WRAT, Bender, and Goodenough\n")
cat("  are scored from written/drawn work products. The Stanford-Binet was\n")
cat("  administered at age 4 by a different examiner in a different session.\n")


# ===========================================================================
# SECTION B: THREE-FACTOR LATENT MODEL
# Observed (WISC) g / Written-output g / Examiner g
# ===========================================================================
cat("\n\n========== B. THREE-FACTOR LATENT MODEL ==========\n")
cat("(WISC g, Written-output g, Examiner g — all latent correlations)\n\n")

# Z-score all indicators
all_indicators <- c(wisc_subtests, written_tests,
                    "comp_parcel", "read_parcel", "pers_parcel")
parcels <- c("comp_parcel", "read_parcel", "pers_parcel")
cc3 <- beh7_merged[complete.cases(beh7_merged[, ..all_indicators])]
cat(sprintf("Complete cases for 3-factor model: %d\n", nrow(cc3)))

for (v in all_indicators) {
  vz <- paste0(v, "_z")
  cc3[, (vz) := scale(get(v))]
}
wisc_z <- paste0(wisc_subtests, "_z")
written_z <- paste0(written_tests, "_z")
parcels_z <- paste0(parcels, "_z")

three_factor_model <- paste0('
  # WISC g (individually administered, examiner directly observed)
  g_observed =~ ', paste(wisc_z, collapse = " + "), '

  # Written-output g (scored from written/drawn work)
  g_written =~ ', paste(written_z, collapse = " + "), '

  # Examiner-rated g (clinical impressions)
  g_examiner =~ ', paste(parcels_z, collapse = " + "), '

  # All pairwise latent correlations
  g_observed ~~ g_written
  g_observed ~~ g_examiner
  g_written ~~ g_examiner
')

cat("\nFitting three-factor model...\n")
fit3 <- cfa(three_factor_model, data = cc3, std.lv = TRUE)
cat(sprintf("  Converged: %s\n", lavInspect(fit3, "converged")))

fm3 <- fitMeasures(fit3, c("chisq", "df", "cfi", "tli", "rmsea", "srmr"))
cat(sprintf("  Chi-sq = %.1f, df = %.0f\n", fm3["chisq"], fm3["df"]))
cat(sprintf("  CFI = %.4f, TLI = %.4f\n", fm3["cfi"], fm3["tli"]))
cat(sprintf("  RMSEA = %.4f, SRMR = %.4f\n", fm3["rmsea"], fm3["srmr"]))

pe3 <- parameterEstimates(fit3, standardized = TRUE)
pe3 <- as.data.table(pe3)

cat("\nFactor loadings (standardized):\n")
loadings3 <- pe3[op == "=~"]
cat(sprintf("  %-25s  %8s  %8s  %8s\n", "Indicator", "Loading", "SE", "Factor"))
for (i in 1:nrow(loadings3)) {
  cat(sprintf("  %-25s  %8.3f  %8.3f  %s\n",
              loadings3$rhs[i], loadings3$std.all[i], loadings3$se[i],
              loadings3$lhs[i]))
}

cat("\nLatent correlations:\n")
latcors <- pe3[op == "~~" & lhs != rhs &
               lhs %in% c("g_observed", "g_written", "g_examiner") &
               rhs %in% c("g_observed", "g_written", "g_examiner")]
for (i in 1:nrow(latcors)) {
  cat(sprintf("  %s ~~ %s: r = %.3f (SE = %.3f)\n",
              latcors$lhs[i], latcors$rhs[i],
              latcors$std.all[i], latcors$se[i]))
}


# ===========================================================================
# SECTION C: HIGHER-ORDER g MODEL
# ===========================================================================
cat("\n\n========== C. HIGHER-ORDER g MODEL ==========\n")
cat("(General g → WISC g, Written g, Examiner g)\n\n")

higher_order_model <- paste0('
  # First-order factors
  g_observed =~ ', paste(wisc_z, collapse = " + "), '
  g_written =~ ', paste(written_z, collapse = " + "), '
  g_examiner =~ ', paste(parcels_z, collapse = " + "), '

  # Higher-order g
  G =~ g_observed + g_written + g_examiner
')

cat("Fitting higher-order model...\n")
fit_ho <- cfa(higher_order_model, data = cc3, std.lv = TRUE)
cat(sprintf("  Converged: %s\n", lavInspect(fit_ho, "converged")))

fm_ho <- fitMeasures(fit_ho, c("chisq", "df", "cfi", "tli", "rmsea", "srmr"))
cat(sprintf("  Chi-sq = %.1f, df = %.0f\n", fm_ho["chisq"], fm_ho["df"]))
cat(sprintf("  CFI = %.4f, TLI = %.4f\n", fm_ho["cfi"], fm_ho["tli"]))
cat(sprintf("  RMSEA = %.4f, SRMR = %.4f\n", fm_ho["rmsea"], fm_ho["srmr"]))

pe_ho <- parameterEstimates(fit_ho, standardized = TRUE)
pe_ho <- as.data.table(pe_ho)

cat("\nHigher-order loadings (G → first-order factors):\n")
ho_loadings <- pe_ho[op == "=~" & lhs == "G"]
for (i in 1:nrow(ho_loadings)) {
  cat(sprintf("  G → %s: loading = %.3f (SE = %.3f)\n",
              ho_loadings$rhs[i], ho_loadings$std.all[i], ho_loadings$se[i]))
}

cat("\nFirst-order loadings:\n")
fo_loadings <- pe_ho[op == "=~" & lhs != "G"]
for (i in 1:nrow(fo_loadings)) {
  cat(sprintf("  %s → %s: loading = %.3f\n",
              fo_loadings$lhs[i], fo_loadings$rhs[i], fo_loadings$std.all[i]))
}


# ===========================================================================
# SECTION D: EXAMINER vs STANFORD-BINET (age 4, latent)
# ===========================================================================
cat("\n\n========== D. EXAMINER vs STANFORD-BINET (LATENT) ==========\n")
cat("(SB administered at age 4 by a different examiner entirely)\n\n")

# For this we need SB IQ as a single indicator. We can use SB IQ directly
# or use a reliability-corrected single-indicator factor.
# SB IQ has reliability ~ 0.90 (published for this age range).

sb_vars <- c("comp_parcel", "read_parcel", "pers_parcel", "sb_iq")
cc_sb <- beh7_merged[complete.cases(beh7_merged[, ..sb_vars])]
cat(sprintf("Complete cases with both examiner parcels and SB IQ: %d\n", nrow(cc_sb)))

for (v in sb_vars) {
  vz <- paste0(v, "_z")
  cc_sb[, (vz) := scale(get(v))]
}

# Single-indicator SB factor with fixed reliability
sb_rel <- 0.90  # published SB reliability
sb_var <- var(cc_sb$sb_iq_z)
sb_error_var <- sb_var * (1 - sb_rel)

sb_examiner_model <- paste0('
  g_examiner =~ comp_parcel_z + read_parcel_z + pers_parcel_z
  g_sb =~ sb_iq_z
  sb_iq_z ~~ ', sb_error_var, ' * sb_iq_z
  g_examiner ~~ g_sb
')

cat("Fitting examiner vs SB model (single-indicator SB, reliability-corrected)...\n")
fit_sb <- cfa(sb_examiner_model, data = cc_sb, std.lv = TRUE)
cat(sprintf("  Converged: %s\n", lavInspect(fit_sb, "converged")))

if (lavInspect(fit_sb, "converged")) {
  fm_sb <- fitMeasures(fit_sb, c("chisq", "df", "cfi", "tli", "rmsea", "srmr"))
  cat(sprintf("  CFI = %.4f, RMSEA = %.4f\n", fm_sb["cfi"], fm_sb["rmsea"]))

  pe_sb <- parameterEstimates(fit_sb, standardized = TRUE)
  pe_sb <- as.data.table(pe_sb)

  lat_cor_sb <- pe_sb[op == "~~" & lhs == "g_examiner" & rhs == "g_sb"]
  cat(sprintf("\n  Latent r(Examiner g, SB g): %.3f (SE = %.3f)\n",
              lat_cor_sb$std.all, lat_cor_sb$se))
  cat(sprintf("  Shared variance: %.1f%%\n", lat_cor_sb$std.all^2 * 100))
}

# Also do a joint model with all three: WISC g, Examiner g, SB g
cat("\n--- Joint three-factor model with SB ---\n")
all_sb_vars <- c(wisc_subtests, "comp_parcel", "read_parcel", "pers_parcel", "sb_iq")
cc_all <- beh7_merged[complete.cases(beh7_merged[, ..all_sb_vars])]
cat(sprintf("Complete cases: %d\n", nrow(cc_all)))

for (v in all_sb_vars) {
  vz <- paste0(v, "_z")
  cc_all[, (vz) := scale(get(v))]
}

wisc_z4 <- paste0(wisc_subtests, "_z")
parcels_z2 <- paste0(c("comp_parcel", "read_parcel", "pers_parcel"), "_z")

joint_sb_model <- paste0('
  g_wisc =~ ', paste(wisc_z4, collapse = " + "), '
  g_examiner =~ ', paste(parcels_z2, collapse = " + "), '
  g_sb =~ sb_iq_z
  sb_iq_z ~~ ', sb_error_var, ' * sb_iq_z
  g_wisc ~~ g_examiner
  g_wisc ~~ g_sb
  g_examiner ~~ g_sb
')

fit_joint_sb <- cfa(joint_sb_model, data = cc_all, std.lv = TRUE)
cat(sprintf("  Converged: %s\n", lavInspect(fit_joint_sb, "converged")))

if (lavInspect(fit_joint_sb, "converged")) {
  fm_jsb <- fitMeasures(fit_joint_sb, c("chisq", "df", "cfi", "rmsea"))
  cat(sprintf("  CFI = %.4f, RMSEA = %.4f\n", fm_jsb["cfi"], fm_jsb["rmsea"]))

  pe_jsb <- parameterEstimates(fit_joint_sb, standardized = TRUE)
  pe_jsb <- as.data.table(pe_jsb)

  cat("\n  Latent correlations:\n")
  latcors_sb <- pe_jsb[op == "~~" & lhs != rhs &
                        lhs %in% c("g_wisc", "g_examiner", "g_sb") &
                        rhs %in% c("g_wisc", "g_examiner", "g_sb")]
  for (i in 1:nrow(latcors_sb)) {
    cat(sprintf("    %s ~~ %s: r = %.3f (SE = %.3f)\n",
                latcors_sb$lhs[i], latcors_sb$rhs[i],
                latcors_sb$std.all[i], latcors_sb$se[i]))
  }
}


# ===========================================================================
# SECTION E: FOUR-FACTOR MODEL (WISC / Written / Examiner / SB)
# ===========================================================================
cat("\n\n========== E. FOUR-FACTOR MODEL ==========\n")
cat("(WISC g / Written g / Examiner g / SB g — all latent correlations)\n\n")

all4_vars <- c(wisc_subtests, written_tests,
               "comp_parcel", "read_parcel", "pers_parcel", "sb_iq")
cc4 <- beh7_merged[complete.cases(beh7_merged[, ..all4_vars])]
cat(sprintf("Complete cases: %d\n", nrow(cc4)))

for (v in all4_vars) {
  vz <- paste0(v, "_z")
  cc4[, (vz) := scale(get(v))]
}

written_z4 <- paste0(written_tests, "_z")

sb_var4 <- var(cc4$sb_iq_z)
sb_error_var4 <- sb_var4 * (1 - sb_rel)

four_factor_model <- paste0('
  g_wisc =~ ', paste(wisc_z4, collapse = " + "), '
  g_written =~ ', paste(written_z4, collapse = " + "), '
  g_examiner =~ ', paste(parcels_z2, collapse = " + "), '
  g_sb =~ sb_iq_z
  sb_iq_z ~~ ', sb_error_var4, ' * sb_iq_z

  g_wisc ~~ g_written
  g_wisc ~~ g_examiner
  g_wisc ~~ g_sb
  g_written ~~ g_examiner
  g_written ~~ g_sb
  g_examiner ~~ g_sb
')

cat("Fitting four-factor model...\n")
fit4 <- cfa(four_factor_model, data = cc4, std.lv = TRUE)
cat(sprintf("  Converged: %s\n", lavInspect(fit4, "converged")))

if (lavInspect(fit4, "converged")) {
  fm4 <- fitMeasures(fit4, c("chisq", "df", "cfi", "tli", "rmsea", "srmr"))
  cat(sprintf("  Chi-sq = %.1f, df = %.0f\n", fm4["chisq"], fm4["df"]))
  cat(sprintf("  CFI = %.4f, TLI = %.4f\n", fm4["cfi"], fm4["tli"]))
  cat(sprintf("  RMSEA = %.4f, SRMR = %.4f\n", fm4["rmsea"], fm4["srmr"]))

  pe4 <- parameterEstimates(fit4, standardized = TRUE)
  pe4 <- as.data.table(pe4)

  cat("\nLatent correlation matrix:\n")
  factors <- c("g_wisc", "g_written", "g_examiner", "g_sb")
  cat(sprintf("  %-15s", ""))
  for (f in factors) cat(sprintf("  %12s", f))
  cat("\n")

  for (fi in factors) {
    cat(sprintf("  %-15s", fi))
    for (fj in factors) {
      if (fi == fj) {
        cat(sprintf("  %12s", "1.000"))
      } else {
        r <- pe4[op == "~~" & ((lhs == fi & rhs == fj) | (lhs == fj & rhs == fi))]
        if (nrow(r) > 0) {
          cat(sprintf("  %12.3f", r$std.all[1]))
        } else {
          cat(sprintf("  %12s", "---"))
        }
      }
    }
    cat("\n")
  }

  cat("\n  Key results:\n")
  r_ex_wisc <- pe4[op == "~~" & lhs == "g_wisc" & rhs == "g_examiner"]$std.all
  r_ex_writ <- pe4[op == "~~" & lhs == "g_written" & rhs == "g_examiner"]$std.all
  r_ex_sb <- pe4[op == "~~" & lhs == "g_examiner" & rhs == "g_sb"]$std.all
  r_wisc_writ <- pe4[op == "~~" & lhs == "g_wisc" & rhs == "g_written"]$std.all
  r_wisc_sb <- pe4[op == "~~" & lhs == "g_wisc" & rhs == "g_sb"]$std.all

  if (length(r_ex_wisc) == 0) {
    r_ex_wisc <- pe4[op == "~~" & lhs == "g_examiner" & rhs == "g_wisc"]$std.all
  }
  if (length(r_ex_writ) == 0) {
    r_ex_writ <- pe4[op == "~~" & lhs == "g_examiner" & rhs == "g_written"]$std.all
  }
  if (length(r_ex_sb) == 0) {
    r_ex_sb <- pe4[op == "~~" & lhs == "g_sb" & rhs == "g_examiner"]$std.all
  }
  if (length(r_wisc_writ) == 0) {
    r_wisc_writ <- pe4[op == "~~" & lhs == "g_written" & rhs == "g_wisc"]$std.all
  }
  if (length(r_wisc_sb) == 0) {
    r_wisc_sb <- pe4[op == "~~" & lhs == "g_sb" & rhs == "g_wisc"]$std.all
  }

  cat(sprintf("  Examiner g vs WISC g (observed tests):   r = %.3f\n", r_ex_wisc[1]))
  cat(sprintf("  Examiner g vs Written g (written work):  r = %.3f\n", r_ex_writ[1]))
  cat(sprintf("  Examiner g vs SB g (age 4, diff exam):   r = %.3f\n", r_ex_sb[1]))
  cat(sprintf("  WISC g vs Written g:                     r = %.3f\n", r_wisc_writ[1]))
  cat(sprintf("  WISC g vs SB g:                          r = %.3f\n", r_wisc_sb[1]))
}


# ===========================================================================
# SECTION F: HIGHER-ORDER MODEL WITH ALL FOUR FACTORS
# ===========================================================================
cat("\n\n========== F. HIGHER-ORDER g WITH FOUR FACTORS ==========\n")

higher_order_4 <- paste0('
  g_wisc =~ ', paste(wisc_z4, collapse = " + "), '
  g_written =~ ', paste(written_z4, collapse = " + "), '
  g_examiner =~ ', paste(parcels_z2, collapse = " + "), '
  g_sb =~ sb_iq_z
  sb_iq_z ~~ ', sb_error_var4, ' * sb_iq_z

  G =~ g_wisc + g_written + g_examiner + g_sb
')

cat("Fitting higher-order model (4 first-order factors)...\n")
fit_ho4 <- cfa(higher_order_4, data = cc4, std.lv = TRUE)
cat(sprintf("  Converged: %s\n", lavInspect(fit_ho4, "converged")))

if (lavInspect(fit_ho4, "converged")) {
  fm_ho4 <- fitMeasures(fit_ho4, c("chisq", "df", "cfi", "tli", "rmsea", "srmr"))
  cat(sprintf("  CFI = %.4f, TLI = %.4f, RMSEA = %.4f\n",
              fm_ho4["cfi"], fm_ho4["tli"], fm_ho4["rmsea"]))

  pe_ho4 <- parameterEstimates(fit_ho4, standardized = TRUE)
  pe_ho4 <- as.data.table(pe_ho4)

  cat("\nHigher-order loadings (G → first-order factors):\n")
  ho4_loadings <- pe_ho4[op == "=~" & lhs == "G"]
  for (i in 1:nrow(ho4_loadings)) {
    cat(sprintf("  G → %-15s: loading = %.3f (SE = %.3f)\n",
                ho4_loadings$rhs[i], ho4_loadings$std.all[i], ho4_loadings$se[i]))
  }
}


# ===========================================================================
# SECTION G: SUMMARY
# ===========================================================================
cat("\n\n========== SUMMARY ==========\n\n")

cat("OBSERVATION STATUS OF AGE-7 TESTS:\n")
cat("  OBSERVED by examiner (individually administered, verbal responses):\n")
cat("    WISC subtests — examiner reads questions, listens to answers, scores live\n\n")
cat("  SCORED FROM WRITTEN/DRAWN WORK (examiner present but scoring is objective):\n")
cat("    WRAT Reading/Spelling/Arithmetic — child writes answers on paper\n")
cat("    Bender Gestalt — child copies geometric figures (scored from drawings)\n")
cat("    Goodenough Draw-a-Person — child draws (scored from drawing)\n\n")
cat("  COMPLETELY INDEPENDENT (different examiner, different session, age 4):\n")
cat("    Stanford-Binet IQ — administered 3 years earlier by different examiner\n\n")

cat("KEY FINDINGS:\n")
cat(sprintf("  1. Examiner IRT vs WISC FSIQ (observed):         r = %.3f\n", r_irt_wisc))
cat(sprintf("  2. Examiner IRT vs Written-output g (objective):  r = %.3f\n", r_irt_written))
cat(sprintf("  3. Examiner IRT vs SB IQ (independent):          r = %.3f\n", r_irt_sb))

if (exists("fit4") && lavInspect(fit4, "converged")) {
  cat(sprintf("\n  4. Latent Examiner g vs WISC g:     r = %.3f\n", r_ex_wisc[1]))
  cat(sprintf("  5. Latent Examiner g vs Written g:   r = %.3f\n", r_ex_writ[1]))
  cat(sprintf("  6. Latent Examiner g vs SB g:        r = %.3f\n", r_ex_sb[1]))
}

if (exists("fit_ho4") && lavInspect(fit_ho4, "converged")) {
  cat("\n  Higher-order g loadings:\n")
  for (i in 1:nrow(ho4_loadings)) {
    cat(sprintf("    G → %s: %.3f\n", ho4_loadings$rhs[i], ho4_loadings$std.all[i]))
  }
}

cat("\nDone.\n")
