#!/usr/bin/env Rscript
# fig_sibling_regression.R — Differential Sibling Regression to the Mean
# Shows that siblings regress toward their own racial group mean, not a common mean

library(data.table)

BASE <- ".."

# Load data
iq <- fread(file.path(BASE, "clean/cpp_clean_expanded.csv"),
            colClasses = c(case_id = "character"))
kin <- fread(file.path(BASE, "clean/cpp_kinship_links.csv"),
             colClasses = c(id_1 = "character", id_2 = "character"))

# Combine DZ twin types
kin[pair_type %in% c("DZ_twin", "DZ_twin_probable"), pair_type := "DZ_twin"]

# Use full siblings + DZ twins (R = 0.5 pairs)
pairs <- kin[pair_type %in% c("full_sibling", "DZ_twin")]

# Merge IQ + race
sub <- iq[, .(case_id, race, wisc_fsiq)]
pairs <- merge(pairs, sub, by.x = "id_1", by.y = "case_id", all.x = TRUE)
setnames(pairs, c("race", "wisc_fsiq"), c("race_1", "iq_1"))
pairs <- merge(pairs, sub, by.x = "id_2", by.y = "case_id", all.x = TRUE)
setnames(pairs, c("race", "wisc_fsiq"), c("race_2", "iq_2"))

# Keep same-race Black or White pairs with both WISC scores
pairs <- pairs[!is.na(iq_1) & !is.na(iq_2) & race_1 == race_2 & race_1 %in% c(1, 2)]
pairs[, race := ifelse(race_1 == 1, "White", "Black")]

cat(sprintf("Full sibling + DZ twin pairs with WISC data:\n"))
cat(sprintf("  White: %d pairs\n", sum(pairs$race == "White")))
cat(sprintf("  Black: %d pairs\n", sum(pairs$race == "Black")))

# For each pair, randomly assign proband vs sibling (use both directions for power)
# Double the data: each pair contributes two observations (A->B and B->A)
dt1 <- pairs[, .(proband_iq = iq_1, sibling_iq = iq_2, race)]
dt2 <- pairs[, .(proband_iq = iq_2, sibling_iq = iq_1, race)]
dt <- rbind(dt1, dt2)

# Group means and sibling correlations
mu_w <- dt[race == "White", mean(proband_iq)]
mu_b <- dt[race == "Black", mean(proband_iq)]
r_w <- pairs[race == "White", cor(iq_1, iq_2)]
r_b <- pairs[race == "Black", cor(iq_1, iq_2)]

cat(sprintf("\nWhite mean = %.1f, r = %.3f\n", mu_w, r_w))
cat(sprintf("Black mean = %.1f, r = %.3f\n", mu_b, r_b))

# Bin proband IQ into 10-point bins
dt[, iq_bin := floor(proband_iq / 10) * 10 + 5]

# Compute bin means for each race
bin_stats <- dt[, .(mean_sib = mean(sibling_iq),
                     sd_sib = sd(sibling_iq),
                     mean_prob = mean(proband_iq),
                     n = .N),
                by = .(race, iq_bin)]
bin_stats[, se := sd_sib / sqrt(n)]
bin_stats[, ci_lo := mean_sib - 1.96 * se]
bin_stats[, ci_hi := mean_sib + 1.96 * se]

# Drop bins with < 30 observations (avoids noisy tails)
bin_stats <- bin_stats[n >= 30]

cat("\n=== Bin statistics ===\n")
print(bin_stats[order(race, iq_bin)])

# Theoretical regression lines
x_range <- seq(55, 145, by = 1)
pred_w <- mu_w + r_w * (x_range - mu_w)
pred_b <- mu_b + r_b * (x_range - mu_b)

# ── Create figure ──────────────────────────────────────────────────
pdf("fig_sibling_regression.pdf", width = 8, height = 7)

par(mar = c(5, 5, 2, 2), family = "serif")

# Empty plot
plot(NULL, xlim = c(60, 140), ylim = c(70, 125),
     xlab = "Proband IQ (WISC FSIQ)", ylab = "Sibling IQ (WISC FSIQ)",
     main = "", cex.lab = 1.2, cex.axis = 1, las = 1,
     xaxp = c(60, 140, 8), yaxp = c(70, 120, 5))

# Light grid
abline(h = seq(70, 120, 10), col = "gray92", lwd = 0.5)
abline(v = seq(60, 140, 10), col = "gray92", lwd = 0.5)

# Raw scatter points (low alpha, behind everything)
w_raw <- dt[race == "White"]
b_raw <- dt[race == "Black"]
points(w_raw$proband_iq, w_raw$sibling_iq, pch = 16,
       col = adjustcolor("#2166AC", alpha.f = 0.12), cex = 0.4)
points(b_raw$proband_iq, b_raw$sibling_iq, pch = 16,
       col = adjustcolor("#B2182B", alpha.f = 0.12), cex = 0.4)


# Group mean horizontal lines
abline(h = mu_w, col = "#2166AC", lty = 2, lwd = 1)
abline(h = mu_b, col = "#B2182B", lty = 2, lwd = 1)

# Theoretical regression lines
lines(x_range, pred_w, col = "#2166AC", lwd = 2.5, lty = 1)
lines(x_range, pred_b, col = "#B2182B", lwd = 2.5, lty = 1)

# Binned means as points
w_bins <- bin_stats[race == "White"]
b_bins <- bin_stats[race == "Black"]

# Scale point size by sqrt(n)
w_cex <- 0.8 + 1.5 * sqrt(w_bins$n) / max(sqrt(c(w_bins$n, b_bins$n)))
b_cex <- 0.8 + 1.5 * sqrt(b_bins$n) / max(sqrt(c(w_bins$n, b_bins$n)))

# 95% CI error bars
arrows(w_bins$iq_bin, w_bins$ci_lo, w_bins$iq_bin, w_bins$ci_hi,
       code = 3, angle = 90, length = 0.04, col = "#2166AC", lwd = 1.2)
arrows(b_bins$iq_bin, b_bins$ci_lo, b_bins$iq_bin, b_bins$ci_hi,
       code = 3, angle = 90, length = 0.04, col = "#B2182B", lwd = 1.2)

# Points on top of CIs
points(w_bins$iq_bin, w_bins$mean_sib, pch = 16, col = "#2166AC", cex = w_cex)
points(b_bins$iq_bin, b_bins$mean_sib, pch = 17, col = "#B2182B", cex = b_cex)

# Group mean labels on right side (inside plot area)
text(138, mu_w + 1.8, sprintf("%.1f", mu_w),
     col = "#2166AC", cex = 0.75, font = 2, adj = 1)
text(138, mu_b - 1.8, sprintf("%.1f", mu_b),
     col = "#B2182B", cex = 0.75, font = 2, adj = 1)

# Annotation: expected difference at matched proband IQ
gap <- mu_w - mu_b
exp_diff <- gap * (1 - (r_w + r_b)/2)
# Compute observed gap across bins for annotation (need merged_bins early)
merged_bins_early <- merge(
  bin_stats[race == "White", .(iq_bin, sib_w = mean_sib)],
  bin_stats[race == "Black", .(iq_bin, sib_b = mean_sib)],
  by = "iq_bin")
obs_gap_mean <- mean(merged_bins_early$sib_w - merged_bins_early$sib_b)

text(62, 123,
     sprintf("At matched proband IQ, expected sibling\ngap = %.1f \u00d7 (1 \u2212 %.2f) = %.1f pts\nObserved mean gap across bins: %.1f pts",
             gap, (r_w + r_b)/2, exp_diff, obs_gap_mean),
     cex = 0.75, adj = 0, col = "gray30")

# Legend — bottom right to avoid overlap
legend("bottomright",
       legend = c(
         sprintf("White (n = %s pairs, r = %.2f)", format(sum(pairs$race == "White"), big.mark = ","), r_w),
         sprintf("Black (n = %s pairs, r = %.2f)", format(sum(pairs$race == "Black"), big.mark = ","), r_b),
         "95% CI",
         "Group mean"
       ),
       col = c("#2166AC", "#B2182B", "gray50", "gray50"),
       pch = c(16, 17, NA, NA),
       lty = c(NA, NA, 1, 2),
       lwd = c(NA, NA, 1.2, 1),
       pt.cex = c(1.5, 1.5, NA, NA),
       cex = 0.8, bty = "o", bg = "white", box.col = "gray80")

dev.off()
cat("\nFigure saved: fig_sibling_regression.pdf\n")

# ── Also compute the actual observed differential regression ────────
cat("\n=== OBSERVED DIFFERENTIAL REGRESSION ===\n")
cat("At matched proband IQ bins, what is the B-W sibling gap?\n\n")

merged_bins <- merge(w_bins[, .(iq_bin, sib_w = mean_sib, n_w = n)],
                     b_bins[, .(iq_bin, sib_b = mean_sib, n_b = n)],
                     by = "iq_bin")
merged_bins[, gap := sib_w - sib_b]

cat(sprintf("%-10s  %8s  %8s  %8s  %6s  %6s\n",
            "Bin", "Sib_W", "Sib_B", "Gap", "n_W", "n_B"))
for (i in seq_len(nrow(merged_bins))) {
  row <- merged_bins[i]
  cat(sprintf("%-10d  %8.1f  %8.1f  %8.1f  %6d  %6d\n",
              row$iq_bin, row$sib_w, row$sib_b, row$gap, row$n_w, row$n_b))
}
cat(sprintf("\nMean gap across bins: %.1f\n", mean(merged_bins$gap)))
cat(sprintf("Expected (theoretical): %.1f * (1 - %.3f) = %.1f\n",
            gap, (r_w + r_b)/2, exp_diff))
