#!/usr/bin/env Rscript
# 12e_examiner_sex_variance.R — Examiner MI by child sex + latent variance test

library(data.table)
library(lavaan)

cat("--- Examiner MI by Child Sex (with variance homogeneity) ---\n")

d <- as.data.table(readRDS("prepared_data.rds"))
d[, case_id := as.character(case_id)]

beh7 <- fread("../clean/master/parsed/card_41300_parsed.csv")
beh7[, case_id := as.character(case_id)]

beh7_fields <- fread("../clean/master/parsed/card_41300_fields.csv")
psy25_fields <- beh7_fields[grepl("PSY25", data_id)]
psy25_fields[, col_key := paste(data_col_from, data_col_to, sep = "-")]
psy25_unique <- psy25_fields[!duplicated(col_key)]
psy25_vars <- intersect(psy25_unique$varname, names(beh7))

for (col in psy25_vars) {
  beh7[, (col) := suppressWarnings(as.integer(get(col)))]
  fw <- psy25_unique[varname == col, field_width]
  if (length(fw) > 0 && fw == 2) {
    beh7[!is.na(get(col)), (col) := as.integer(get(col) %/% 10)]
  }
  beh7[get(col) %in% c(8, 9, 88, 99), (col) := NA_integer_]
}

psy25_good <- character(0)
for (col in psy25_vars) {
  v <- beh7[[col]][!is.na(beh7[[col]])]
  if (length(unique(v)) >= 2 && length(v) >= 5000)
    psy25_good <- c(psy25_good, col)
}

beh7_merged <- merge(beh7[, c("case_id", psy25_good), with = FALSE],
                     d[, .(case_id, sex)],
                     by = "case_id")

# Filter items with sufficient variance in both sex groups
psy25_cfa <- character(0)
for (col in psy25_good) {
  ok <- TRUE
  for (s in c(1, 2)) {
    vals <- beh7_merged[sex == s][[col]]
    vals <- vals[!is.na(vals)]
    tab <- table(vals)
    if (sum(tab >= 10) < 2) { ok <- FALSE; break }
  }
  if (ok) psy25_cfa <- c(psy25_cfa, col)
}
cat(sprintf("Items usable for sex MI: %d of %d\n", length(psy25_cfa), length(psy25_good)))

item_data <- copy(beh7_merged)
for (col in psy25_cfa) {
  item_data[, (col) := ordered(get(col))]
}
item_data[, sex_group := factor(ifelse(sex == 1, "Male", "Female"))]
item_cc <- item_data[complete.cases(item_data[, ..psy25_cfa])]
cat(sprintf("Complete cases: %d (Male=%d, Female=%d)\n",
            nrow(item_cc), sum(item_cc$sex_group == "Male"), sum(item_cc$sex_group == "Female")))

item_model <- paste0("examiner_g =~ ", paste(psy25_cfa, collapse = " + "))

# ---- MI sequence ----
cat("\n--- Configural ---\n")
fit_c <- cfa(item_model, data = item_cc, group = "sex_group",
             ordered = psy25_cfa, estimator = "WLSMV")
fm_c <- fitMeasures(fit_c, c("chisq", "df", "cfi", "rmsea"))
cat(sprintf("CFI=%.4f, RMSEA=%.4f\n", fm_c["cfi"], fm_c["rmsea"]))

cat("\n--- Metric (equal loadings) ---\n")
fit_m <- cfa(item_model, data = item_cc, group = "sex_group",
             ordered = psy25_cfa, estimator = "WLSMV",
             group.equal = "loadings")
fm_m <- fitMeasures(fit_m, c("chisq", "df", "cfi", "rmsea"))
cat(sprintf("CFI=%.4f, RMSEA=%.4f, dCFI=%.4f\n",
            fm_m["cfi"], fm_m["rmsea"], fm_c["cfi"] - fm_m["cfi"]))

cat("\n--- Scalar (equal loadings + thresholds) ---\n")
fit_s <- cfa(item_model, data = item_cc, group = "sex_group",
             ordered = psy25_cfa, estimator = "WLSMV",
             group.equal = c("loadings", "thresholds"))
fm_s <- fitMeasures(fit_s, c("chisq", "df", "cfi", "rmsea"))
cat(sprintf("CFI=%.4f, RMSEA=%.4f, dCFI=%.4f\n",
            fm_s["cfi"], fm_s["rmsea"], fm_m["cfi"] - fm_s["cfi"]))

# ---- Latent variance under scalar invariance ----
cat("\n--- Latent Variances Under Scalar Invariance ---\n")
lv_var <- lavInspect(fit_s, "cov.lv")
cat(sprintf("Male latent variance:   %.4f\n", lv_var$Male[1,1]))
cat(sprintf("Female latent variance: %.4f\n", lv_var$Female[1,1]))
cat(sprintf("Ratio (M/F): %.3f\n", lv_var$Male[1,1] / lv_var$Female[1,1]))

# ---- Latent means under scalar invariance ----
cat("\n--- Latent Means Under Scalar Invariance ---\n")
lv_means <- lavInspect(fit_s, "mean.lv")
cat(sprintf("Male latent mean:   %.4f\n", lv_means$Male[1]))
cat(sprintf("Female latent mean: %.4f\n", lv_means$Female[1]))

# ---- Test variance homogeneity ----
cat("\n--- Variance Homogeneity Test ---\n")
cat("Constraining latent variance equal across sexes...\n")

fit_s_eqvar <- cfa(item_model, data = item_cc, group = "sex_group",
                   ordered = psy25_cfa, estimator = "WLSMV",
                   group.equal = c("loadings", "thresholds", "lv.variances"))
fm_sv <- fitMeasures(fit_s_eqvar, c("chisq", "df", "cfi", "rmsea"))
cat(sprintf("Scalar + equal variance: CFI=%.4f, RMSEA=%.4f, dCFI=%.4f\n",
            fm_sv["cfi"], fm_sv["rmsea"], fm_s["cfi"] - fm_sv["cfi"]))

# LRT
lrt_var <- lavTestLRT(fit_s, fit_s_eqvar)
cat(sprintf("LRT: delta chi-sq=%.2f, df=%d, p=%.4f\n",
            lrt_var[["Chisq diff"]][2], lrt_var[["Df diff"]][2], lrt_var[["Pr(>Chisq)"]][2]))

# ---- Also test strict invariance (equal residuals) ----
cat("\n--- Strict (equal loadings + thresholds + residuals) ---\n")
fit_strict <- tryCatch(
  cfa(item_model, data = item_cc, group = "sex_group",
      ordered = psy25_cfa, estimator = "WLSMV",
      group.equal = c("loadings", "thresholds", "residuals")),
  error = function(e) { cat(sprintf("ERROR: %s\n", conditionMessage(e))); NULL }
)
if (!is.null(fit_strict)) {
  fm_str <- fitMeasures(fit_strict, c("chisq", "df", "cfi", "rmsea"))
  cat(sprintf("CFI=%.4f, RMSEA=%.4f, dCFI=%.4f\n",
              fm_str["cfi"], fm_str["rmsea"], fm_s["cfi"] - fm_str["cfi"]))
}

cat("\nDone.\n")
