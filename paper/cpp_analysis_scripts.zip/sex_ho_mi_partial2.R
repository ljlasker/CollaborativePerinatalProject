#!/usr/bin/env Rscript
# sex_ho_mi_partial2.R — Partial scalar using lavTestScore

library(data.table)
library(lavaan)

d <- as.data.table(readRDS("prepared_data.rds"))

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "wrat_spell_raw", "wrat_arith_raw",
              "bender_gestalt", "goodenough_raw")

dat <- d[complete.cases(d[, ..sub_vars]) & !is.na(sex)]
dat[, sex_label := factor(ifelse(sex == 1, "Male", "Female"), levels = c("Male", "Female"))]

ho_model <- '
  Gc  =~ wisc_info + wisc_comp + wisc_vocab
  Gv  =~ wisc_picarr + wisc_block + goodenough_raw
  Grw =~ wrat_read_raw + wrat_spell_raw + wrat_arith_raw
  Gs  =~ wisc_digit + bender_gestalt + wisc_coding
  g   =~ Gc + Gv + Grw + Gs
  Gs ~~ 0*Gs
'

report <- function(fit, label) {
  fm <- fitMeasures(fit, c("chisq", "df", "cfi", "rmsea"))
  cat(sprintf("%-35s: CFI=%.4f, RMSEA=%.4f (chi2=%.1f, df=%.0f)\n",
              label, fm["cfi"], fm["rmsea"], fm["chisq"], fm["df"]))
  invisible(fm)
}

# Metric baseline
fit_m <- cfa(ho_model, data = dat, group = "sex_label", estimator = "MLR",
             group.equal = "loadings")
fm_m <- report(fit_m, "Metric")

# Try freeing intercepts one at a time using brute force
# Fit scalar with each intercept freed individually, pick best improvement
all_indicators <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
                    "wisc_picarr", "wisc_block", "wisc_coding",
                    "wrat_read_raw", "wrat_spell_raw", "wrat_arith_raw",
                    "bender_gestalt", "goodenough_raw")

freed <- character(0)

for (iter in 1:6) {
  cat(sprintf("\n=== Iteration %d ===\n", iter))
  best_cfi <- 0
  best_var <- NULL

  remaining <- setdiff(all_indicators, freed)
  if (length(remaining) == 0) break

  for (v in remaining) {
    test_freed <- c(freed, v)
    partial_spec <- paste0(test_freed, "~1")
    fit_test <- tryCatch(
      cfa(ho_model, data = dat, group = "sex_label", estimator = "MLR",
          group.equal = c("loadings", "intercepts"),
          group.partial = partial_spec),
      warning = function(w) suppressWarnings(
        cfa(ho_model, data = dat, group = "sex_label", estimator = "MLR",
            group.equal = c("loadings", "intercepts"),
            group.partial = partial_spec)
      ),
      error = function(e) NULL
    )
    if (!is.null(fit_test)) {
      cfi <- fitMeasures(fit_test, "cfi")
      if (cfi > best_cfi) {
        best_cfi <- cfi
        best_var <- v
      }
    }
  }

  if (is.null(best_var)) break
  freed <- c(freed, best_var)
  dcfi <- fm_m["cfi"] - best_cfi
  cat(sprintf("  Freed: %s -> CFI=%.4f, dCFI from metric=%.4f\n", best_var, best_cfi, dcfi))

  if (abs(dcfi) < 0.010) {
    cat("  -> PASSES threshold.\n")
    break
  }
}

cat(sprintf("\nFinal freed intercepts: %s\n", paste(freed, collapse = ", ")))

# Fit the final partial scalar
partial_spec <- paste0(freed, "~1")
fit_ps <- cfa(ho_model, data = dat, group = "sex_label", estimator = "MLR",
              group.equal = c("loadings", "intercepts"),
              group.partial = partial_spec)
fm_ps <- report(fit_ps, "Partial Scalar")
cat(sprintf("   dCFI from metric = %.4f\n", fm_m["cfi"] - fm_ps["cfi"]))

# Strict from partial scalar
cat("\n--- Strict from Partial Scalar ---\n")
fit_strict <- cfa(ho_model, data = dat, group = "sex_label", estimator = "MLR",
                  group.equal = c("loadings", "intercepts", "residuals"),
                  group.partial = partial_spec)
fm_strict <- report(fit_strict, "Partial Strict")
cat(sprintf("   dCFI from partial scalar = %.4f\n", fm_ps["cfi"] - fm_strict["cfi"]))

# Latent means
cat("\n--- Latent Means (Partial Strict) ---\n")
means <- lavInspect(fit_strict, "mean.lv")
vars <- lavInspect(fit_strict, "cov.lv")
for (g in names(means)) {
  g_sd <- sqrt(vars[[g]]["g","g"])
  cat(sprintf("  %s: g mean=%.4f, g SD=%.4f\n", g, means[[g]]["g"], g_sd))
}

g_sd_male <- sqrt(vars$Male["g","g"])
g_gap <- means$Female["g"] - means$Male["g"]
cat(sprintf("\nLatent g gap (F-M): %.4f raw = %.3f male-SD\n", g_gap, g_gap/g_sd_male))
cat(sprintf("Variance ratio (F/M): %.3f\n", vars$Female["g","g"] / vars$Male["g","g"]))

# + equal variances
cat("\n--- + Equal Variances ---\n")
fit_eqv <- cfa(ho_model, data = dat, group = "sex_label", estimator = "MLR",
               group.equal = c("loadings", "intercepts", "residuals", "lv.variances"),
               group.partial = partial_spec)
fm_eqv <- report(fit_eqv, "Partial Strict + equal lv.var")
cat(sprintf("   dCFI from partial strict = %.4f\n", fm_strict["cfi"] - fm_eqv["cfi"]))

cat("\nDone.\n")
