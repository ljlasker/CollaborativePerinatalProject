#!/usr/bin/env Rscript
# 02d_between_group.R
# Between-Group Heritability Decomposition (Dolan et al., 1992; Rowe et al., 1996)
#
# Tests whether Black-White mean differences in WISC subtests can be
# decomposed into genetic and environmental components, using the IP model's
# distinct genetic vs environmental loading patterns.
#
# The IP model has separate A-common and C-common factor loadings. If these
# loading profiles differ, the racial mean difference can be attributed to
# genetic (A-factor mean shift) or environmental (C-factor mean shift) sources.
#
# Uses 8 groups: {White, Black} x {MZ, DZ, FS, HS}
# IP model structure constrained equal across races (measurement invariance)
# Only means differ by race.
#
# Models tested:
#   M1: Saturated means (free means per race)
#   M2: Full decomposition (Δμ = ac*κA + cc*κC)
#   M3: Genetic only (Δμ = ac*κA)
#   M4: Environmental only (Δμ = cc*κC)
#   M5: Equal means (no race difference)

library(data.table)
library(OpenMx)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")

# Clean sentinel values
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}

links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

cat("\n")
cat("--- BETWEEN-GROUP HERITABILITY DECOMPOSITION Black-White Mean Differences in 7 WISC Subtests Dolan et al. (1992) / Rowe et al. (1996) Framework ---
")

# ── Define subtests ────────────────────────────────────────────────────
sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding")
sub_labels <- c("Information", "Comprehension", "Vocabulary", "Digit Span",
                "Pic. Arrangement", "Block Design", "Coding")
nv <- length(sub_vars)

# ---- PART A: DATA PREPARATION (Race-Stratified) ----
cat("\n")
cat("--- PART A: Data Preparation ---
")

# Build pair-level data with race
d_sub <- d[, c("case_id", "race", sub_vars), with = FALSE]

pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
setnames(pair, "race", "race_1")
old_names <- sub_vars
new_names1 <- paste0(sub_vars, "_1")
setnames(pair, old_names, new_names1)

pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
setnames(pair, "race", "race_2")
new_names2 <- paste0(sub_vars, "_2")
setnames(pair, old_names, new_names2)

# Classify pair types
pair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair <- pair[!is.na(pair_class)]

# Restrict to same-race Black (2) and White (1) pairs
pair <- pair[race_1 == race_2 & race_1 %in% c(1, 2)]
pair[, race := ifelse(race_1 == 1, "White", "Black")]

# Require at least one subtest per member
has_any_1 <- rowSums(!is.na(pair[, ..new_names1])) > 0
has_any_2 <- rowSums(!is.na(pair[, ..new_names2])) > 0
pair <- pair[has_any_1 & has_any_2]

cat("\nPair counts (Race x Kinship):\n")
ct <- pair[, .N, by = .(race, pair_class)]
ct <- dcast(ct, race ~ pair_class, value.var = "N", fill = 0)
print(ct)

# Observed mean differences
cat("\nObserved subtest means by race:\n")
cat(sprintf("  %-15s  %8s  %8s  %8s\n", "Subtest", "White", "Black", "Diff"))
cat("  ", strrep("-", 45), "\n")
for (i in seq_along(sub_vars)) {
  # Pool individual-level from pair data
  v1 <- pair[[new_names1[i]]]; v2 <- pair[[new_names2[i]]]
  r1 <- pair$race; r2 <- pair$race
  vals_w <- c(v1[r1 == "White"], v2[r2 == "White"])
  vals_b <- c(v1[r1 == "Black"], v2[r2 == "Black"])
  mw <- mean(vals_w, na.rm = TRUE); mb <- mean(vals_b, na.rm = TRUE)
  cat(sprintf("  %-15s  %8.2f  %8.2f  %8.2f\n",
              sub_labels[i], mw, mb, mw - mb))
}

# ---- PART B: RACE-STRATIFIED IP MODEL ----
cat("\n")
cat("--- PART B: IP Model with Race-Structured Means ---
")

var_names <- c(new_names1, new_names2)

# Split into 8 groups
make_group_data <- function(pair, race_val, pc) {
  as.data.frame(pair[race == race_val & pair_class == pc, ..var_names])
}

w_mz <- make_group_data(pair, "White", "MZ")
w_dz <- make_group_data(pair, "White", "DZ")
w_fs <- make_group_data(pair, "White", "FS")
w_hs <- make_group_data(pair, "White", "HS")
b_mz <- make_group_data(pair, "Black", "MZ")
b_dz <- make_group_data(pair, "Black", "DZ")
b_fs <- make_group_data(pair, "Black", "FS")
b_hs <- make_group_data(pair, "Black", "HS")

cat(sprintf("\n  White: MZ=%d, DZ=%d, FS=%d, HS=%d (total=%d)\n",
            nrow(w_mz), nrow(w_dz), nrow(w_fs), nrow(w_hs),
            nrow(w_mz) + nrow(w_dz) + nrow(w_fs) + nrow(w_hs)))
cat(sprintf("  Black: MZ=%d, DZ=%d, FS=%d, HS=%d (total=%d)\n",
            nrow(b_mz), nrow(b_dz), nrow(b_fs), nrow(b_hs),
            nrow(b_mz) + nrow(b_dz) + nrow(b_fs) + nrow(b_hs)))

total_n <- nrow(w_mz) + nrow(w_dz) + nrow(w_fs) + nrow(w_hs) +
           nrow(b_mz) + nrow(b_dz) + nrow(b_fs) + nrow(b_hs)

# ── Helper: build decomposition model with given kA/kC constraints ────
build_decomp <- function(model_name, kA_free, kC_free,
                         kA_val = 0.5, kC_val = 0.5) {
  p <- model_name  # prefix for references

  # Helper to build a kinship submodel with string-based algebra
  make_sub <- function(sub_name, data, R_coeff, has_twin, use_white) {
    mu_ref <- if (use_white) paste0(p, ".MuW") else paste0(p, ".MuB")
    if (has_twin) {
      b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C + ", p, ".Tt")
    } else {
      b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C")
    }
    cov_str <- paste0("rbind(cbind(", p, ".V, B), cbind(B, ", p, ".V))")
    mean_str <- paste0("cbind(", mu_ref, ", ", mu_ref, ")")

    mxModel(sub_name, mxData(data, type = "raw"),
      mxAlgebraFromString(b_str, name = "B"),
      mxAlgebraFromString(cov_str, name = "expCov"),
      mxAlgebraFromString(mean_str, name = "expMean"),
      mxExpectationNormal("expCov", "expMean", dimnames = var_names),
      mxFitFunctionML())
  }

  mxModel(model_name,
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.5, nv),
             lbound = -5, name = "ac"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.8, nv),
             lbound = -5, name = "cc"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.3, nv),
             lbound = -5, name = "tc"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.0, nv),
             lbound = -5, name = "ec"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
             lbound = 0.001, name = "as"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
             lbound = 0.001, name = "cs"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.3, nv),
             lbound = 0.001, name = "ts"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
             lbound = 0.001, name = "es"),
    mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
    mxAlgebra(tc %*% t(tc) + ts %*% t(ts), name = "Tt"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
    mxAlgebra(A + C + Tt + E, name = "V"),
    mxMatrix("Full", 1, nv, free = TRUE,
             values = c(8.5, 8.1, 7.5, 9.0, 8.3, 8.6, 9.8), name = "MuB"),
    mxMatrix("Full", 1, 1, free = kA_free, values = kA_val, name = "kA"),
    mxMatrix("Full", 1, 1, free = kC_free, values = kC_val, name = "kC"),
    mxAlgebra(MuB + t(ac) * kA + t(cc) * kC, name = "MuW"),

    make_sub("W_MZ", w_mz, 1,    TRUE,  TRUE),
    make_sub("W_DZ", w_dz, 0.5,  TRUE,  TRUE),
    make_sub("W_FS", w_fs, 0.5,  FALSE, TRUE),
    make_sub("W_HS", w_hs, 0.25, FALSE, TRUE),
    make_sub("B_MZ", b_mz, 1,    TRUE,  FALSE),
    make_sub("B_DZ", b_dz, 0.5,  TRUE,  FALSE),
    make_sub("B_FS", b_fs, 0.5,  FALSE, FALSE),
    make_sub("B_HS", b_hs, 0.25, FALSE, FALSE),

    mxFitFunctionMultigroup(c("W_MZ","W_DZ","W_FS","W_HS",
                              "B_MZ","B_DZ","B_FS","B_HS"))
  )
}

# ── Build all 8-group models ─────────────────────────────────────────

# M1: Saturated means - built separately (free MuW, no decomposition)
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model M1: IP with Free Means per Race\n")
cat(strrep("-", 70), "\n")

# M1 needs free MuW, so build inline using mxAlgebraFromString
m1 <- mxModel("M1",
  mxMatrix("Full", nv, 1, free=TRUE, values=rep(1.5,nv), lbound=-5, name="ac"),
  mxMatrix("Full", nv, 1, free=TRUE, values=rep(0.8,nv), lbound=-5, name="cc"),
  mxMatrix("Full", nv, 1, free=TRUE, values=rep(0.3,nv), lbound=-5, name="tc"),
  mxMatrix("Full", nv, 1, free=TRUE, values=rep(1.0,nv), lbound=-5, name="ec"),
  mxMatrix("Diag", nv, nv, free=TRUE, values=rep(1.5,nv), lbound=0.001, name="as"),
  mxMatrix("Diag", nv, nv, free=TRUE, values=rep(0.5,nv), lbound=0.001, name="cs"),
  mxMatrix("Diag", nv, nv, free=TRUE, values=rep(0.3,nv), lbound=0.001, name="ts"),
  mxMatrix("Diag", nv, nv, free=TRUE, values=rep(1.5,nv), lbound=0.001, name="es"),
  mxAlgebra(ac %*% t(ac) + as %*% t(as), name="A"),
  mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name="C"),
  mxAlgebra(tc %*% t(tc) + ts %*% t(ts), name="Tt"),
  mxAlgebra(ec %*% t(ec) + es %*% t(es), name="E"),
  mxAlgebra(A + C + Tt + E, name="V"),
  mxMatrix("Full",1,nv,free=TRUE,values=c(8.5,8.1,7.5,9.0,8.3,8.6,9.8),name="MuB"),
  mxMatrix("Full",1,nv,free=TRUE,values=c(10.1,9.5,10.2,10.4,10.7,10.6,10.2),name="MuW"),

  mxModel("W_MZ", mxData(w_mz,"raw"), mxAlgebraFromString("M1.A+M1.C+M1.Tt",name="B"),
    mxAlgebraFromString("rbind(cbind(M1.V,B),cbind(B,M1.V))",name="expCov"),
    mxAlgebraFromString("cbind(M1.MuW,M1.MuW)",name="expMean"),
    mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
  mxModel("W_DZ", mxData(w_dz,"raw"), mxAlgebraFromString("0.5*M1.A+M1.C+M1.Tt",name="B"),
    mxAlgebraFromString("rbind(cbind(M1.V,B),cbind(B,M1.V))",name="expCov"),
    mxAlgebraFromString("cbind(M1.MuW,M1.MuW)",name="expMean"),
    mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
  mxModel("W_FS", mxData(w_fs,"raw"), mxAlgebraFromString("0.5*M1.A+M1.C",name="B"),
    mxAlgebraFromString("rbind(cbind(M1.V,B),cbind(B,M1.V))",name="expCov"),
    mxAlgebraFromString("cbind(M1.MuW,M1.MuW)",name="expMean"),
    mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
  mxModel("W_HS", mxData(w_hs,"raw"), mxAlgebraFromString("0.25*M1.A+M1.C",name="B"),
    mxAlgebraFromString("rbind(cbind(M1.V,B),cbind(B,M1.V))",name="expCov"),
    mxAlgebraFromString("cbind(M1.MuW,M1.MuW)",name="expMean"),
    mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
  mxModel("B_MZ", mxData(b_mz,"raw"), mxAlgebraFromString("M1.A+M1.C+M1.Tt",name="B"),
    mxAlgebraFromString("rbind(cbind(M1.V,B),cbind(B,M1.V))",name="expCov"),
    mxAlgebraFromString("cbind(M1.MuB,M1.MuB)",name="expMean"),
    mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
  mxModel("B_DZ", mxData(b_dz,"raw"), mxAlgebraFromString("0.5*M1.A+M1.C+M1.Tt",name="B"),
    mxAlgebraFromString("rbind(cbind(M1.V,B),cbind(B,M1.V))",name="expCov"),
    mxAlgebraFromString("cbind(M1.MuB,M1.MuB)",name="expMean"),
    mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
  mxModel("B_FS", mxData(b_fs,"raw"), mxAlgebraFromString("0.5*M1.A+M1.C",name="B"),
    mxAlgebraFromString("rbind(cbind(M1.V,B),cbind(B,M1.V))",name="expCov"),
    mxAlgebraFromString("cbind(M1.MuB,M1.MuB)",name="expMean"),
    mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
  mxModel("B_HS", mxData(b_hs,"raw"), mxAlgebraFromString("0.25*M1.A+M1.C",name="B"),
    mxAlgebraFromString("rbind(cbind(M1.V,B),cbind(B,M1.V))",name="expCov"),
    mxAlgebraFromString("cbind(M1.MuB,M1.MuB)",name="expMean"),
    mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
  mxFitFunctionMultigroup(c("W_MZ","W_DZ","W_FS","W_HS","B_MZ","B_DZ","B_FS","B_HS"))
)

cat("  Fitting M1 (free means)...\n")
m1_fit <- mxTryHard(m1, extraTries = 30, silent = TRUE)
m1_sum <- summary(m1_fit)
cat(sprintf("  M1: -2LL = %.2f, k = %d, status = %d\n",
            m1_sum$Minus2LogLikelihood, m1_sum$estimatedParameters,
            m1_fit$output$status$code))

# ── M2: Full decomposition ──────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model M2: Means Decomposed via A + C Loadings\n")
cat("  MuW = MuB + ac*kA + cc*kC\n")
cat(strrep("-", 70), "\n")

m2 <- build_decomp("M2", kA_free = TRUE, kC_free = TRUE)

cat("  Fitting M2 (A+C decomposition)...\n")
m2_fit <- mxTryHard(m2, extraTries = 30, silent = TRUE)
m2_sum <- summary(m2_fit)
cat(sprintf("  M2: -2LL = %.2f, k = %d, status = %d\n",
            m2_sum$Minus2LogLikelihood, m2_sum$estimatedParameters,
            m2_fit$output$status$code))

# ── Model M3: Genetic only ───────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model M3: Genetic Only (Δμ = ac*κA)\n")
cat(strrep("-", 70), "\n")

m3 <- build_decomp("M3", kA_free = TRUE, kC_free = FALSE,
                    kA_val = 0.5, kC_val = 0)

cat("  Fitting M3 (genetic only)...\n")
m3_fit <- mxTryHard(m3, extraTries = 30, silent = TRUE)
m3_sum <- summary(m3_fit)
cat(sprintf("  M3: -2LL = %.2f, k = %d, status = %d\n",
            m3_sum$Minus2LogLikelihood, m3_sum$estimatedParameters,
            m3_fit$output$status$code))

# ── Model M4: Environmental only ─────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model M4: Environmental Only (Δμ = cc*κC)\n")
cat(strrep("-", 70), "\n")

m4 <- build_decomp("M4", kA_free = FALSE, kC_free = TRUE,
                    kA_val = 0, kC_val = 0.5)

cat("  Fitting M4 (environmental only)...\n")
m4_fit <- mxTryHard(m4, extraTries = 30, silent = TRUE)
m4_sum <- summary(m4_fit)
cat(sprintf("  M4: -2LL = %.2f, k = %d, status = %d\n",
            m4_sum$Minus2LogLikelihood, m4_sum$estimatedParameters,
            m4_fit$output$status$code))

# ── Model M5: Equal means ────────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model M5: Equal Means (no race difference)\n")
cat(strrep("-", 70), "\n")

m5 <- build_decomp("M5", kA_free = FALSE, kC_free = FALSE,
                    kA_val = 0, kC_val = 0)

cat("  Fitting M5 (equal means)...\n")
m5_fit <- mxTryHard(m5, extraTries = 30, silent = TRUE)
m5_sum <- summary(m5_fit)
cat(sprintf("  M5: -2LL = %.2f, k = %d, status = %d\n",
            m5_sum$Minus2LogLikelihood, m5_sum$estimatedParameters,
            m5_fit$output$status$code))

# ---- PART C: MODEL COMPARISON ----
cat("\n")
cat("--- PART C: Model Comparison ---
")

fits <- list(M1 = m1_fit, M2 = m2_fit, M3 = m3_fit,
             M4 = m4_fit, M5 = m5_fit)
sums <- list(M1 = m1_sum, M2 = m2_sum, M3 = m3_sum,
             M4 = m4_sum, M5 = m5_sum)

cat(sprintf("\n  %-25s  %5s  %12s  %12s  %12s  %6s\n",
            "Model", "k", "-2LL", "AIC", "BIC", "Status"))
cat("  ", strrep("-", 75), "\n")

for (nm in names(sums)) {
  s <- sums[[nm]]
  k <- s$estimatedParameters
  ll <- s$Minus2LogLikelihood
  aic <- s$AIC.Mx
  bic <- ll + k * log(total_n)
  label <- switch(nm,
    M1 = "M1: Free means",
    M2 = "M2: A + C decomp.",
    M3 = "M3: Genetic only",
    M4 = "M4: Environmental only",
    M5 = "M5: Equal means")
  cat(sprintf("  %-25s  %5d  %12.2f  %12.2f  %12.2f  %6d\n",
              label, k, ll, aic, bic, fits[[nm]]$output$status$code))
}

# LRTs
cat("\n  Likelihood Ratio Tests:\n")

# M2 vs M1: Does the 2-parameter decomposition fit as well as free means?
chi2_21 <- sums$M2$Minus2LogLikelihood - sums$M1$Minus2LogLikelihood
df_21 <- sums$M1$estimatedParameters - sums$M2$estimatedParameters
if (df_21 > 0) {
  p_21 <- pchisq(chi2_21, df_21, lower.tail = FALSE)
  cat(sprintf("    M2 vs M1: chi2 = %.2f, df = %d, p = %.4f\n",
              chi2_21, df_21, p_21))
  cat(sprintf("    → Decomposition %s\n",
              ifelse(p_21 > 0.05, "fits as well as free means",
                     "loses significant fit vs free means")))
}

# M3 vs M2: Is environmental component needed?
chi2_32 <- sums$M3$Minus2LogLikelihood - sums$M2$Minus2LogLikelihood
df_32 <- sums$M2$estimatedParameters - sums$M3$estimatedParameters
p_32 <- pchisq(chi2_32, df_32, lower.tail = FALSE)
cat(sprintf("    M3 vs M2: chi2 = %.2f, df = %d, p = %.4f\n",
            chi2_32, df_32, p_32))
cat(sprintf("    → Environmental component %s\n",
            ifelse(p_32 < 0.05, "NEEDED (genetic alone insufficient)",
                   "not needed (genetic alone sufficient)")))

# M4 vs M2: Is genetic component needed?
chi2_42 <- sums$M4$Minus2LogLikelihood - sums$M2$Minus2LogLikelihood
df_42 <- sums$M2$estimatedParameters - sums$M4$estimatedParameters
p_42 <- pchisq(chi2_42, df_42, lower.tail = FALSE)
cat(sprintf("    M4 vs M2: chi2 = %.2f, df = %d, p = %.4f\n",
            chi2_42, df_42, p_42))
cat(sprintf("    → Genetic component %s\n",
            ifelse(p_42 < 0.05, "NEEDED (environmental alone insufficient)",
                   "not needed (environmental alone sufficient)")))

# M5 vs M2: Any race difference?
chi2_52 <- sums$M5$Minus2LogLikelihood - sums$M2$Minus2LogLikelihood
df_52 <- sums$M2$estimatedParameters - sums$M5$estimatedParameters
p_52 <- pchisq(chi2_52, df_52, lower.tail = FALSE)
cat(sprintf("    M5 vs M2: chi2 = %.2f, df = %d, p = %.4f\n",
            chi2_52, df_52, p_52))

# Best by BIC
all_bic <- sapply(names(sums), function(nm) {
  s <- sums[[nm]]
  s$Minus2LogLikelihood + s$estimatedParameters * log(total_n)
})
cat(sprintf("\n  Best by BIC: %s (%.2f)\n", names(which.min(all_bic)),
            min(all_bic)))

# ---- PART D: PARAMETER ESTIMATES ----
cat("\n")
cat("--- PART D: Parameter Estimates from M2 (Full Decomposition) ---
")

if (m2_fit$output$status$code == 0) {
  kA_est <- m2_fit$kA$values[1,1]
  kC_est <- m2_fit$kC$values[1,1]

  cat(sprintf("\n  Genetic factor mean shift (κA):       %8.4f\n", kA_est))
  cat(sprintf("  Environmental factor mean shift (κC):  %8.4f\n", kC_est))

  ac_est <- m2_fit$ac$values[,1]
  cc_est <- m2_fit$cc$values[,1]

  cat(sprintf("\n  %-15s  %8s  %8s  %8s  %8s  %8s\n",
              "Subtest", "ac_load", "cc_load", "ΔA", "ΔC", "ΔTotal"))
  cat("  ", strrep("-", 60), "\n")

  delta_a <- ac_est * kA_est
  delta_c <- cc_est * kC_est
  delta_total <- delta_a + delta_c

  for (i in seq_along(sub_vars)) {
    cat(sprintf("  %-15s  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f\n",
                sub_labels[i], ac_est[i], cc_est[i],
                delta_a[i], delta_c[i], delta_total[i]))
  }

  # Proportion of total gap through A vs C
  cat("\n  Proportion of predicted gap through genetic vs environmental:\n")
  for (i in seq_along(sub_vars)) {
    if (abs(delta_total[i]) > 0.001) {
      pct_a <- 100 * delta_a[i] / delta_total[i]
      pct_c <- 100 * delta_c[i] / delta_total[i]
      cat(sprintf("    %-15s  A: %5.1f%%  C: %5.1f%%\n",
                  sub_labels[i], pct_a, pct_c))
    }
  }

  # Compare predicted vs observed gaps
  cat("\n  Predicted vs Observed Mean Differences:\n")
  cat(sprintf("  %-15s  %8s  %8s  %8s\n",
              "Subtest", "Observed", "Predicted", "Residual"))
  cat("  ", strrep("-", 45), "\n")

  muB <- mxEval(MuB, m2_fit)[1,]
  muW <- mxEval(MuW, m2_fit)[1,]
  obs_diff <- muW - muB

  # Also get M1 free means for comparison
  muB_free <- mxEval(MuB, m1_fit)[1,]
  muW_free <- mxEval(MuW, m1_fit)[1,]
  obs_free <- muW_free - muB_free

  for (i in seq_along(sub_vars)) {
    cat(sprintf("  %-15s  %8.3f  %8.3f  %8.3f\n",
                sub_labels[i], obs_free[i], delta_total[i],
                obs_free[i] - delta_total[i]))
  }

  # Summary statistics
  cat(sprintf("\n  R² of predicted mean differences: %.3f\n",
              cor(obs_free, delta_total)^2))
  cat(sprintf("  RMSE of residual: %.3f\n",
              sqrt(mean((obs_free - delta_total)^2))))
}

# Also report M3 and M4 estimates for comparison
cat("\n")
cat(strrep("-", 70), "\n")
cat("M3 (Genetic Only) Estimates\n")
cat(strrep("-", 70), "\n")
if (m3_fit$output$status$code == 0) {
  kA3 <- m3_fit$kA$values[1,1]
  ac3 <- m3_fit$ac$values[,1]
  cat(sprintf("  κA = %.4f\n", kA3))
  cat(sprintf("  Predicted gaps: "))
  cat(paste(sprintf("%.2f", ac3 * kA3), collapse = ", "))
  cat("\n")
}

cat("\n")
cat(strrep("-", 70), "\n")
cat("M4 (Environmental Only) Estimates\n")
cat(strrep("-", 70), "\n")
if (m4_fit$output$status$code == 0) {
  kC4 <- m4_fit$kC$values[1,1]
  cc4 <- m4_fit$cc$values[,1]
  cat(sprintf("  κC = %.4f\n", kC4))
  cat(sprintf("  Predicted gaps: "))
  cat(paste(sprintf("%.2f", cc4 * kC4), collapse = ", "))
  cat("\n")
}

# ---- PART E: SUPPLEMENTARY — Sibling-Only Analysis (FS + HS) ----
cat("\n")
cat("--- PART E: Sibling-Only Sensitivity (FS + HS, no twins) Following Rowe et al. (1996) ---
")

# Sibling-only helper (ACE, no T)
build_sib <- function(model_name, kA_free, kC_free,
                      kA_val = 0.5, kC_val = 0.5, free_muW = FALSE) {
  p <- model_name
  make_sib_sub <- function(sub_name, data, R_coeff, use_white) {
    mu_ref <- if (use_white) paste0(p, ".MuW") else paste0(p, ".MuB")
    b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C")
    cov_str <- paste0("rbind(cbind(", p, ".V, B), cbind(B, ", p, ".V))")
    mean_str <- paste0("cbind(", mu_ref, ", ", mu_ref, ")")
    mxModel(sub_name, mxData(data, "raw"),
      mxAlgebraFromString(b_str, name="B"),
      mxAlgebraFromString(cov_str, name="expCov"),
      mxAlgebraFromString(mean_str, name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),
      mxFitFunctionML())
  }

  model_parts <- list(
    mxMatrix("Full",nv,1,free=TRUE,values=rep(1.5,nv),lbound=-5,name="ac"),
    mxMatrix("Full",nv,1,free=TRUE,values=rep(0.8,nv),lbound=-5,name="cc"),
    mxMatrix("Full",nv,1,free=TRUE,values=rep(1.0,nv),lbound=-5,name="ec"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=rep(1.5,nv),lbound=0.001,name="as"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=rep(0.5,nv),lbound=0.001,name="cs"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=rep(1.5,nv),lbound=0.001,name="es"),
    mxAlgebra(ac %*% t(ac) + as %*% t(as), name="A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name="C"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name="E"),
    mxAlgebra(A + C + E, name="V"),
    mxMatrix("Full",1,nv,free=TRUE,values=c(8.5,8.1,7.5,9.0,8.3,8.6,9.8),name="MuB")
  )

  if (free_muW) {
    model_parts <- c(model_parts, list(
      mxMatrix("Full",1,nv,free=TRUE,
               values=c(10.1,9.5,10.2,10.4,10.7,10.6,10.2),name="MuW")))
  } else {
    model_parts <- c(model_parts, list(
      mxMatrix("Full",1,1,free=kA_free,values=kA_val,name="kA"),
      mxMatrix("Full",1,1,free=kC_free,values=kC_val,name="kC"),
      mxAlgebra(MuB + t(ac)*kA + t(cc)*kC, name="MuW")))
  }

  do.call(mxModel, c(list(model_name),
    model_parts,
    list(
      make_sib_sub("W_FS", w_fs, 0.5,  TRUE),
      make_sib_sub("W_HS", w_hs, 0.25, TRUE),
      make_sib_sub("B_FS", b_fs, 0.5,  FALSE),
      make_sib_sub("B_HS", b_hs, 0.25, FALSE),
      mxFitFunctionMultigroup(c("W_FS","W_HS","B_FS","B_HS"))
    )))
}

# M1s: Free means
cat("  Fitting sibling-only M1s (free means)...\n")
m1s <- build_sib("M1s", FALSE, FALSE, free_muW = TRUE)
m1s_fit <- mxTryHard(m1s, extraTries = 30, silent = TRUE)
m1s_sum <- summary(m1s_fit)

# M2s: Full decomposition
cat("  Fitting sibling-only M2s (A+C)...\n")
m2s <- build_sib("M2s", kA_free = TRUE, kC_free = TRUE)
m2s_fit <- mxTryHard(m2s, extraTries = 30, silent = TRUE)
m2s_sum <- summary(m2s_fit)
cat(sprintf("  M2s: -2LL = %.2f, k = %d, status = %d\n",
            m2s_sum$Minus2LogLikelihood, m2s_sum$estimatedParameters,
            m2s_fit$output$status$code))

# M3s: Genetic only
cat("  Fitting sibling-only M3s (genetic only)...\n")
m3s <- build_sib("M3s", kA_free = TRUE, kC_free = FALSE, kC_val = 0)
m3s_fit <- mxTryHard(m3s, extraTries = 30, silent = TRUE)
m3s_sum <- summary(m3s_fit)

# M4s: Environmental only
cat("  Fitting sibling-only M4s (environmental only)...\n")
m4s <- build_sib("M4s", kA_free = FALSE, kC_free = TRUE, kA_val = 0)
m4s_fit <- mxTryHard(m4s, extraTries = 30, silent = TRUE)
m4s_sum <- summary(m4s_fit)

sib_n <- nrow(w_fs) + nrow(w_hs) + nrow(b_fs) + nrow(b_hs)
cat(sprintf("\n  Sibling-only results (N = %d pairs):\n", sib_n))
cat(sprintf("  %-25s  %5s  %12s  %12s\n", "Model", "k", "-2LL", "BIC"))
cat("  ", strrep("-", 55), "\n")
for (nm in c("m1s", "m2s", "m3s", "m4s")) {
  s <- get(paste0(nm, "_sum"))
  f <- get(paste0(nm, "_fit"))
  k <- s$estimatedParameters
  ll <- s$Minus2LogLikelihood
  bic <- ll + k * log(sib_n)
  cat(sprintf("  %-25s  %5d  %12.2f  %12.2f  (status=%d)\n",
              toupper(nm), k, ll, bic, f$output$status$code))
}

# Sibling-only decomposition
if (m2s_fit$output$status$code == 0) {
  kAs <- m2s_fit$kA$values[1,1]
  kCs <- m2s_fit$kC$values[1,1]
  cat(sprintf("\n  Sibling-only estimates:\n"))
  cat(sprintf("    κA = %.4f, κC = %.4f\n", kAs, kCs))

  acs <- m2s_fit$ac$values[,1]
  ccs <- m2s_fit$cc$values[,1]
  da <- acs * kAs; dc <- ccs * kCs
  cat(sprintf("    Predicted gap (A): %s\n",
              paste(sprintf("%.2f", da), collapse = ", ")))
  cat(sprintf("    Predicted gap (C): %s\n",
              paste(sprintf("%.2f", dc), collapse = ", ")))
  cat(sprintf("    Predicted total:   %s\n",
              paste(sprintf("%.2f", da + dc), collapse = ", ")))
}

# ── Save results ──────────────────────────────────────────────────────
cat("\n\nSaving results...\n")
results <- list(
  m1_sum = m1_sum, m2_sum = m2_sum, m3_sum = m3_sum,
  m4_sum = m4_sum, m5_sum = m5_sum,
  m1s_sum = m1s_sum, m2s_sum = m2s_sum, m3s_sum = m3s_sum, m4s_sum = m4s_sum,
  m2_fit = m2_fit, m3_fit = m3_fit, m4_fit = m4_fit,
  m2s_fit = m2s_fit,
  pair_counts = pair[, .N, by = .(race, pair_class)],
  total_n = total_n, sib_n = sib_n
)
saveRDS(results, "results_between_group.rds")
cat("Results saved to results_between_group.rds\n")
