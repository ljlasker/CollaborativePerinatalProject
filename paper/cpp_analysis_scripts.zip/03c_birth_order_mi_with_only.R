#!/usr/bin/env Rscript
# 03c_birth_order_mi_with_only.R — Birth order MI with only-child group

library(data.table)
library(lavaan)

cat("--- Birth Order MI: 4 Groups (Only, First, Second, Later) ---\n")

d <- as.data.table(readRDS("prepared_data.rds"))
d[, parity := birth_order]  # zero-based live-birth order; do not use obstetric parity
d[, n_in_study := .N, by = mother_id]

wisc_subtests <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
                   "wisc_picarr", "wisc_block", "wisc_coding")

mi_data <- d[!is.na(wisc_fsiq) & !is.na(parity)]
mi_data[, bo_group := fcase(
  parity == 0 & n_in_study == 1, "only_child",
  parity == 0 & n_in_study > 1, "firstborn",
  parity == 1, "secondborn",
  parity >= 2, "laterborn"
)]
mi_data[, bo_group := factor(bo_group, levels = c("firstborn", "only_child", "secondborn", "laterborn"))]

mi_complete <- mi_data[complete.cases(mi_data[, ..wisc_subtests])]
cat(sprintf("Complete cases: %d\n", nrow(mi_complete)))
cat("Group sizes:\n")
print(mi_complete[, .N, by = bo_group][order(bo_group)])

cfa_model <- paste0("g =~ ", paste(wisc_subtests, collapse = " + "))

report <- function(fit, label) {
  fm <- fitMeasures(fit, c("chisq", "df", "cfi", "rmsea"))
  cat(sprintf("%-25s: CFI=%.4f, RMSEA=%.4f (chi2=%.1f, df=%.0f)\n",
              label, fm["cfi"], fm["rmsea"], fm["chisq"], fm["df"]))
  invisible(fm)
}

# Configural
fit_c <- cfa(cfa_model, data = mi_complete, group = "bo_group", std.lv = TRUE)
fm_c <- report(fit_c, "1. Configural")

# Metric
fit_m <- cfa(cfa_model, data = mi_complete, group = "bo_group",
             std.lv = TRUE, group.equal = "loadings")
fm_m <- report(fit_m, "2. Metric")
cat(sprintf("   dCFI = %.4f\n", fm_c["cfi"] - fm_m["cfi"]))

# Scalar
fit_s <- cfa(cfa_model, data = mi_complete, group = "bo_group",
             std.lv = TRUE, group.equal = c("loadings", "intercepts"))
fm_s <- report(fit_s, "3. Scalar")
cat(sprintf("   dCFI = %.4f\n", fm_m["cfi"] - fm_s["cfi"]))

# Strict
fit_str <- cfa(cfa_model, data = mi_complete, group = "bo_group",
               std.lv = TRUE, group.equal = c("loadings", "intercepts", "residuals"))
fm_str <- report(fit_str, "4. Strict")
cat(sprintf("   dCFI = %.4f\n", fm_s["cfi"] - fm_str["cfi"]))

# Latent variance homogeneity
fit_v <- cfa(cfa_model, data = mi_complete, group = "bo_group",
             std.lv = FALSE,
             group.equal = c("loadings", "intercepts", "residuals", "lv.variances"))
fm_v <- report(fit_v, "5. + Equal variances")
cat(sprintf("   dCFI = %.4f\n", fm_str["cfi"] - fm_v["cfi"]))

# Latent variances under strict
cat("\nLatent variances (strict):\n")
lv <- lavInspect(fit_str, "cov.lv")
for (g in names(lv)) cat(sprintf("  %-12s: %.4f\n", g, lv[[g]][1,1]))

# Latent mean homogeneity
fit_mu <- cfa(cfa_model, data = mi_complete, group = "bo_group",
              std.lv = FALSE,
              group.equal = c("loadings", "intercepts", "residuals",
                              "lv.variances", "means"))
fm_mu <- report(fit_mu, "6. + Equal means")
cat(sprintf("   dCFI = %.4f\n", fm_v["cfi"] - fm_mu["cfi"]))

# Latent means under strict
cat("\nLatent means (strict, firstborn = reference):\n")
lm_means <- lavInspect(fit_str, "mean.lv")
for (g in names(lm_means)) cat(sprintf("  %-12s: %.4f\n", g, lm_means[[g]][1]))

# LRT for mean homogeneity
lrt <- anova(fit_v, fit_mu)
cat(sprintf("\nLRT (equal means): chi2=%.2f, df=%d, p=%.4f\n",
            lrt[["Chisq diff"]][2], lrt[["Df diff"]][2], lrt[["Pr(>Chisq)"]][2]))

# Also try 3-group: merge only_child + firstborn (since they're so similar)
cat("\n\n=== ALTERNATIVE: 3 groups (firstborn+only merged, secondborn, laterborn) ===\n")
mi_data[, bo_group3 := fcase(
  parity == 0, "firstborn",
  parity == 1, "secondborn",
  parity >= 2, "laterborn"
)]
mi_data[, bo_group3 := factor(bo_group3, levels = c("firstborn", "secondborn", "laterborn"))]
mi3 <- mi_data[complete.cases(mi_data[, ..wisc_subtests])]
cat("Group sizes:\n")
print(mi3[, .N, by = bo_group3][order(bo_group3)])

fit3_str <- cfa(cfa_model, data = mi3, group = "bo_group3",
                std.lv = TRUE, group.equal = c("loadings", "intercepts", "residuals"))
fm3 <- report(fit3_str, "Strict (3-group)")

lm3 <- lavInspect(fit3_str, "mean.lv")
cat("Latent means (firstborn = ref):\n")
for (g in names(lm3)) cat(sprintf("  %-12s: %.4f\n", g, lm3[[g]][1]))

cat("\nDone.\n")
