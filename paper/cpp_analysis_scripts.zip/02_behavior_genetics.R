#!/usr/bin/env Rscript
# 02_behavior_genetics.R — ACE decomposition using 4 relatedness levels

library(data.table)

cat("--- ACE Decomposition ---\n")

d <- readRDS("prepared_data.rds")
iq_links <- readRDS("prepared_iq_links.rds")

# ---- 1. IQ correlations by relatedness level ----
cat("--- IQ Correlations by Pair Type ---\n\n")

# Map pair types to R values
r_map <- c(MZ_twin = 1.0, DZ_twin = 0.5, DZ_twin_probable = 0.5,
           full_sibling = 0.5, half_sibling = 0.25,
           ambiguous_twin = 0.625, ambiguous_sibling = 0.375)

iq_links[, R_expected := r_map[pair_type]]

# For the main analysis, use clean categories
iq_links[, r_group := fcase(
  pair_type == "MZ_twin", "MZ (R=1.0)",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ twin (R=0.5)",
  pair_type == "full_sibling", "Full sibling (R=0.5)",
  pair_type == "half_sibling", "Half-sibling (R=0.25)",
  default = NA_character_
)]

# Drop ambiguous pairs for main analysis
iq_clean <- iq_links[!is.na(r_group)]

outcomes <- list(
  wisc_fsiq = c("iq_1", "iq_2"),
  wisc_viq  = c("viq_1", "viq_2"),
  wisc_piq  = c("piq_1", "piq_2"),
  sb_iq     = c("sb_1", "sb_2"),
  g_factor  = c("g_1", "g_2")
)

outcome_labels <- c(wisc_fsiq="WISC FSIQ", wisc_viq="WISC VIQ",
                    wisc_piq="WISC PIQ", sb_iq="SB IQ (4yr)",
                    g_factor="Latent g")

# Compute correlations
results <- list()
for (outcome_name in names(outcomes)) {
  cols <- outcomes[[outcome_name]]
  for (rg in c("MZ (R=1.0)", "DZ twin (R=0.5)", "Full sibling (R=0.5)",
               "Half-sibling (R=0.25)")) {
    sub <- iq_clean[r_group == rg & !is.na(get(cols[1])) & !is.na(get(cols[2]))]
    n <- nrow(sub)
    if (n >= 10) {
      r <- cor(sub[[cols[1]]], sub[[cols[2]]], use = "complete.obs")
      se <- sqrt((1 - r^2)^2 / (n - 2))
      R_val <- sub$R_expected[1]
      results[[length(results) + 1]] <- data.table(
        outcome = outcome_name, group = rg, R = R_val, n = n,
        r_iq = r, se = se
      )
    }
  }
}
cor_table <- rbindlist(results)

cat("Pairwise IQ Correlations:\n")
for (outcome_name in names(outcomes)) {
  cat(sprintf("\n  %s:\n", outcome_labels[outcome_name]))
  sub <- cor_table[outcome == outcome_name]
  for (i in 1:nrow(sub)) {
    cat(sprintf("    %-25s  n=%-5d  r = %.3f (SE=%.3f)\n",
                sub$group[i], sub$n[i], sub$r_iq[i], sub$se[i]))
  }
}

# ---- 2. Falconer multi-level ACE ----
cat("\n\n--- Method 1: Falconer Multi-Level ACE ---\n")
cat("Model: r(IQ) = R * a² + c²\n\n")

ace_results <- list()
for (outcome_name in names(outcomes)) {
  sub <- cor_table[outcome == outcome_name]

  # Combine DZ twins and full siblings (both R=0.5)
  dz_fs <- sub[R == 0.5]
  if (nrow(dz_fs) > 1) {
    # Weighted average correlation for R=0.5
    w <- dz_fs$n
    r_05 <- sum(dz_fs$r_iq * w) / sum(w)
    n_05 <- sum(dz_fs$n)
    combined <- rbind(
      sub[R == 1.0],
      data.table(outcome=outcome_name, group="DZ+FS (R=0.5)", R=0.5,
                 n=n_05, r_iq=r_05, se=sqrt((1-r_05^2)^2/(n_05-2))),
      sub[R == 0.25]
    )
  } else {
    combined <- sub
  }

  # WLS: r_iq = a² * R + c²
  fit <- lm(r_iq ~ R, data = combined, weights = n)
  a2 <- coef(fit)["R"]
  c2 <- coef(fit)["(Intercept)"]
  e2 <- 1 - a2 - c2

  # Constrain to [0,1]
  a2_c <- max(0, min(1, a2))
  c2_c <- max(0, min(1 - a2_c, c2))
  e2_c <- 1 - a2_c - c2_c

  ace_results[[outcome_name]] <- data.table(
    outcome = outcome_name,
    a2 = a2_c, c2 = c2_c, e2 = e2_c,
    a2_raw = as.numeric(a2), c2_raw = as.numeric(c2)
  )

  cat(sprintf("  %s:\n", outcome_labels[outcome_name]))
  cat(sprintf("    a² = %.3f, c² = %.3f, e² = %.3f\n", a2_c, c2_c, e2_c))
  for (i in 1:nrow(combined)) {
    cat(sprintf("    %-25s R=%.2f  r=%.3f  n=%d\n",
                combined$group[i], combined$R[i], combined$r_iq[i], combined$n[i]))
  }
}

ace_table <- rbindlist(ace_results)

# ---- 3. Classic Twin ACE ----
cat("\n--- Method 2: Classic Twin-Only ACE ---\n")
cat("a² = 2(rMZ - rDZ), c² = 2rDZ - rMZ, e² = 1 - rMZ\n\n")

twin_ace <- list()
for (outcome_name in names(outcomes)) {
  mz <- cor_table[outcome == outcome_name & R == 1.0]
  dz <- cor_table[outcome == outcome_name & R == 0.5 &
                  grepl("twin", group, ignore.case=TRUE)]

  if (nrow(mz) > 0 && nrow(dz) > 0) {
    rMZ <- mz$r_iq[1]
    rDZ <- dz$r_iq[1]
    a2 <- 2 * (rMZ - rDZ)
    c2 <- 2 * rDZ - rMZ
    e2 <- 1 - rMZ

    a2_c <- max(0, min(1, a2))
    c2_c <- max(0, min(1 - a2_c, c2))
    e2_c <- 1 - a2_c - c2_c

    twin_ace[[outcome_name]] <- data.table(
      outcome = outcome_name, rMZ = rMZ, rDZ = rDZ, nMZ = mz$n[1], nDZ = dz$n[1],
      a2 = a2_c, c2 = c2_c, e2 = e2_c
    )

    cat(sprintf("  %s: rMZ=%.3f (n=%d), rDZ=%.3f (n=%d)\n",
                outcome_labels[outcome_name], rMZ, mz$n[1], rDZ, dz$n[1]))
    cat(sprintf("    a² = %.3f, c² = %.3f, e² = %.3f\n", a2_c, c2_c, e2_c))
  }
}
twin_ace_table <- rbindlist(twin_ace)

# ---- 4. DeFries-Fulker Regression ----
cat("\n--- Method 3: DeFries-Fulker Regression ---\n")
cat("y_cotwin = b0 + b1*y_proband + b2*R + b3*(y_proband * R)\n")
cat("  b1 = c², b1 + b3 = h², so h² = b1 + b3\n\n")

df_results <- list()
for (outcome_name in names(outcomes)) {
  cols <- outcomes[[outcome_name]]
  col_z <- paste0(sub("_[12]$", "", cols), "z")  # z-scored versions

  # Use z-scored outcomes
  zcols <- c(paste0(sub("_[12]$", "", cols[1]), "_1z"),
             paste0(sub("_[12]$", "", cols[1]), "_2z"))
  # Actually let's just standardize the raw values
  sub_data <- iq_clean[!is.na(get(cols[1])) & !is.na(get(cols[2]))]

  if (nrow(sub_data) > 100) {
    # Standardize
    all_vals <- c(sub_data[[cols[1]]], sub_data[[cols[2]]])
    m <- mean(all_vals, na.rm = TRUE)
    s <- sd(all_vals, na.rm = TRUE)
    sub_data[, y1_z := (get(cols[1]) - m) / s]
    sub_data[, y2_z := (get(cols[2]) - m) / s]

    # Double-enter: each pair contributes twice (swap proband/cotwin)
    de <- rbind(
      sub_data[, .(y_proband = y1_z, y_cotwin = y2_z, R = R_expected)],
      sub_data[, .(y_proband = y2_z, y_cotwin = y1_z, R = R_expected)]
    )

    fit <- lm(y_cotwin ~ y_proband * R, data = de)
    b1 <- coef(fit)["y_proband"]
    b3 <- coef(fit)["y_proband:R"]
    h2 <- b1 + b3
    c2 <- as.numeric(b1)

    h2_c <- max(0, min(1, h2))
    c2_c <- max(0, min(1 - h2_c, c2))
    e2_c <- 1 - h2_c - c2_c

    df_results[[outcome_name]] <- data.table(
      outcome = outcome_name, h2 = h2_c, c2 = c2_c, e2 = e2_c,
      b1 = as.numeric(b1), b3 = as.numeric(b3), n_pairs = nrow(sub_data)
    )

    cat(sprintf("  %s (n=%d pairs):\n", outcome_labels[outcome_name], nrow(sub_data)))
    cat(sprintf("    b1=%.3f, b3=%.3f → h²=%.3f, c²=%.3f, e²=%.3f\n",
                b1, b3, h2_c, c2_c, e2_c))
  }
}
df_table <- rbindlist(df_results)

# ---- 5. Bootstrap CIs for multi-level ACE ----
cat("\n--- Bootstrap CIs (multi-level Falconer) ---\n")

set.seed(42)
n_boot <- 1000

boot_ace <- function(iq_data, outcome_cols, n_iter = 1000) {
  cols <- outcome_cols
  valid <- iq_data[!is.na(get(cols[1])) & !is.na(get(cols[2])) & !is.na(mother_id)]
  mothers <- unique(valid$mother_id)
  mother_index <- match(valid$mother_id, mothers)
  a2_boot <- c2_boot <- e2_boot <- rep(NA_real_, n_iter)

  for (b in 1:n_iter) {
    # Resample whole maternal families. This preserves dependence among all
    # pair rows contributed by a mother, including cross-kinship overlap.
    sampled_counts <- tabulate(
      sample.int(length(mothers), length(mothers), replace = TRUE),
      nbins = length(mothers)
    )
    boot_rows <- rep(seq_len(nrow(valid)), sampled_counts[mother_index])
    boot_data <- valid[boot_rows]
    boot_cors <- list()
    for (R_val in c(1.0, 0.5, 0.25)) {
      sub <- boot_data[R_expected == R_val]
      if (nrow(sub) < 10) next
      r <- cor(sub[[cols[1]]], sub[[cols[2]]], use = "complete.obs")
      boot_cors[[length(boot_cors) + 1]] <- data.table(R = R_val, r_iq = r, n = nrow(sub))
    }
    bc <- rbindlist(boot_cors)
    if (nrow(bc) < 2) next
    fit <- lm(r_iq ~ R, data = bc, weights = n)
    a2_boot[b] <- max(0, min(1, coef(fit)["R"]))
    c2_boot[b] <- max(0, min(1 - a2_boot[b], coef(fit)["(Intercept)"]))
    e2_boot[b] <- 1 - a2_boot[b] - c2_boot[b]
  }

  data.table(
    a2_lo = quantile(a2_boot, 0.025, na.rm=TRUE),
    a2_hi = quantile(a2_boot, 0.975, na.rm=TRUE),
    c2_lo = quantile(c2_boot, 0.025, na.rm=TRUE),
    c2_hi = quantile(c2_boot, 0.975, na.rm=TRUE),
    e2_lo = quantile(e2_boot, 0.025, na.rm=TRUE),
    e2_hi = quantile(e2_boot, 0.975, na.rm=TRUE)
  )
}

for (outcome_name in names(outcomes)) {
  ci <- boot_ace(iq_clean, outcomes[[outcome_name]], n_boot)
  ace <- ace_table[outcome == outcome_name]
  cat(sprintf("  %s:\n", outcome_labels[outcome_name]))
  cat(sprintf("    a² = %.3f [%.3f, %.3f]\n", ace$a2, ci$a2_lo, ci$a2_hi))
  cat(sprintf("    c² = %.3f [%.3f, %.3f]\n", ace$c2, ci$c2_lo, ci$c2_hi))
  cat(sprintf("    e² = %.3f [%.3f, %.3f]\n", ace$e2, ci$e2_lo, ci$e2_hi))

  # Save CIs to ace_table
  ace_table[outcome == outcome_name,
            `:=`(a2_lo = ci$a2_lo, a2_hi = ci$a2_hi,
                 c2_lo = ci$c2_lo, c2_hi = ci$c2_hi,
                 e2_lo = ci$e2_lo, e2_hi = ci$e2_hi)]
}

# ---- 6. Summary comparison table ----
cat("\n\n--- ACE Estimates Comparison ---\n\n")
cat(sprintf("%-12s  %-8s %-8s %-8s  %-8s %-8s %-8s  %-8s %-8s %-8s\n",
            "Outcome", "a²(ML)", "c²(ML)", "e²(ML)",
            "a²(Tw)", "c²(Tw)", "e²(Tw)",
            "h²(DF)", "c²(DF)", "e²(DF)"))
cat(paste(rep("-", 100), collapse=""), "\n")

for (on in names(outcomes)) {
  ml <- ace_table[outcome == on]
  tw <- twin_ace_table[outcome == on]
  df <- df_table[outcome == on]
  cat(sprintf("%-12s  %-8.3f %-8.3f %-8.3f  %-8.3f %-8.3f %-8.3f  %-8.3f %-8.3f %-8.3f\n",
              on,
              ml$a2, ml$c2, ml$e2,
              ifelse(nrow(tw)>0, tw$a2, NA), ifelse(nrow(tw)>0, tw$c2, NA), ifelse(nrow(tw)>0, tw$e2, NA),
              ifelse(nrow(df)>0, df$h2, NA), ifelse(nrow(df)>0, df$c2, NA), ifelse(nrow(df)>0, df$e2, NA)))
}

# ---- 7. Save results ----
saveRDS(list(
  cor_table = cor_table,
  ace_multilevel = ace_table,
  ace_twin = twin_ace_table,
  ace_defries_fulker = df_table,
  outcome_labels = outcome_labels
), "results_behavior_genetics.rds")

cat("Done.\n")
