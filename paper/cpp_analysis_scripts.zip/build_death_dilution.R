#!/usr/bin/env Rscript
# build_death_dilution.R — Extract death variables, recover additional links,
# run the full sibling death dilution analysis

library(data.table)
library(fixest)
source("case_id_helpers.R")

cat("=== SIBLING DEATH DILUTION ANALYSIS ===\n\n")

# ---- 1. Pull death variables from raw CPPVAR ----
cat("--- 1. Extracting death variables ---\n")

raw <- fread("../clean/cppvar_all_columns.csv",
             select = c("case_id",
                        "v48_deaths_total_number_prior",
                        "v389_fetal_deaths_abortion_less",
                        "v391_stillbirths_deaths_20_weeks",
                        "v392_deaths_neonatal_stillbirths_total",
                        "v394_pregnancy_last_prior_outcome",
                        "v399_siblings_full_stillborn_fetal",
                        "v405_siblings_full_death_neonatal",
                        "v406_siblings_full_death_28",
                        "v432_siblings_total_fetal_death",
                        "v439_siblings_total_death_neonatal",
                        "v440_siblings_total_death_28",
                        "v1091_infant_death_12_months",
                        "v1092_outcome_study_pregnancy_deaths",
                        "v1094_outcome_study_pregnancy_deaths"),
             colClasses = list(character = "case_id"),
             strip.white = FALSE)
raw[, case_id := canonicalize_cpp_case_id(case_id, strict = TRUE)]

# v48 is a count: 88 means no prior pregnancy (structural zero), 99 means
# unknown, and 8 is a valid top-coded count.
raw[v48_deaths_total_number_prior == 88, v48_deaths_total_number_prior := 0L]
raw[v48_deaths_total_number_prior == 99, v48_deaths_total_number_prior := NA_integer_]

# The prior-pregnancy breakdown fields use variable-specific structural-zero
# codes.  Do not pass them through the generic sibling-history cleaner below.
raw[v389_fetal_deaths_abortion_less == 8, v389_fetal_deaths_abortion_less := 0L]
raw[v389_fetal_deaths_abortion_less == 9, v389_fetal_deaths_abortion_less := NA_integer_]
raw[v391_stillbirths_deaths_20_weeks == 8, v391_stillbirths_deaths_20_weeks := 0L]
raw[v391_stillbirths_deaths_20_weeks == 9, v391_stillbirths_deaths_20_weeks := NA_integer_]
raw[v392_deaths_neonatal_stillbirths_total == 88, v392_deaths_neonatal_stillbirths_total := 0L]
raw[v392_deaths_neonatal_stillbirths_total == 99, v392_deaths_neonatal_stillbirths_total := NA_integer_]

# The sibling-history subcounts likewise use 8 for no prior pregnancy and 9
# for unknown.
for (v in c("v399_siblings_full_stillborn_fetal", "v405_siblings_full_death_neonatal",
            "v406_siblings_full_death_28", "v432_siblings_total_fetal_death",
            "v439_siblings_total_death_neonatal", "v440_siblings_total_death_28")) {
  raw[get(v) == 8, (v) := 0L]
  raw[get(v) == 9, (v) := NA_integer_]
}

# Rename for clarity
setnames(raw, c("case_id",
                "prior_deaths_total", "prior_fetal_deaths", "prior_stillbirths",
                "prior_neonatal_deaths_total", "last_prior_outcome",
                "full_sib_fetal_death", "full_sib_neonatal_death", "full_sib_death_post28d",
                "total_sib_fetal_death", "total_sib_neonatal_death", "total_sib_death_post28d",
                "infant_death_v1091", "outcome_detail_v1092", "outcome_category_v1094"))

cat(sprintf("Raw records: %d\n", nrow(raw)))

# ---- 2. Recover additional links via gravida_id ----
cat("\n--- 2. Recovering additional links via gravida_id ---\n")

d <- as.data.table(readRDS("prepared_data.rds"))
links <- fread("../clean/cpp_kinship_links.csv",
               colClasses = c(id_1 = "character", id_2 = "character"))

# Merge death outcome onto all raw records
raw_out <- raw[, .(case_id, outcome_category_v1094, outcome_detail_v1092, infant_death_v1091)]

# Load the full raw to get gravida_id for all records including deaths
grav <- fread("../clean/cppvar_all_columns.csv",
              select = c("case_id", "v1094_outcome_study_pregnancy_deaths"),
              colClasses = list(character = "case_id"),
              strip.white = FALSE)
grav[, case_id := canonicalize_cpp_case_id(case_id, strict = TRUE)]

# Get gravida_id from prepared data (which has it for survivors)
# But dead children aren't in prepared_data. We need gravida from the raw structure.
# case_id format: site/selection + gravida + pregnancy + child/linkage digit.
# Extract gravida_id from case_id
grav[, institution := substr(case_id, 1, 3)]
grav[, gravida_id := substr(case_id, 4, 7)]
grav[, preg_order := as.integer(substr(case_id, 8, 9))]
grav[, mother_key := paste0(institution, gravida_id)]

# Identify fetal/neonatal deaths
grav[, died_early := as.integer(v1094_outcome_study_pregnancy_deaths %in% c(1, 2))]

cat(sprintf("Total raw records: %d\n", nrow(grav)))
cat(sprintf("Fetal/neonatal deaths: %d\n", sum(grav$died_early == 1, na.rm=TRUE)))

# Find mothers (by mother_key) who have both dead and surviving children
grav[, survived := as.integer(v1094_outcome_study_pregnancy_deaths == 3 | is.na(v1094_outcome_study_pregnancy_deaths))]
mother_stats <- grav[, .(n_total = .N,
                          n_died = sum(died_early == 1, na.rm=TRUE),
                          n_survived = sum(survived == 1, na.rm=TRUE)),
                      by = mother_key]

mixed_mothers <- mother_stats[n_died > 0 & n_survived > 0]
cat(sprintf("\nMothers with both dead and surviving pregnancies: %d\n", nrow(mixed_mothers)))
cat(sprintf("  Total pregnancies in these families: %d\n", sum(mixed_mothers$n_total)))
cat(sprintf("  Dead: %d, Survived: %d\n", sum(mixed_mothers$n_died), sum(mixed_mothers$n_survived)))

# Among surviving children in these families, how many have IQ?
surviving_in_mixed <- grav[mother_key %in% mixed_mothers$mother_key & survived == 1]
surviving_with_iq <- merge(surviving_in_mixed, d[, .(case_id, wisc_fsiq, sb_iq, race)],
                           by = "case_id")
cat(sprintf("Surviving children in mixed families with WISC: %d\n",
            sum(!is.na(surviving_with_iq$wisc_fsiq))))

# ---- 3. Merge death vars into prepared data ----
cat("\n--- 3. Merging death variables ---\n")

death_extract <- raw[, .(
  case_id, prior_deaths_total, prior_fetal_deaths, prior_stillbirths,
  prior_neonatal_deaths_total,
  full_sib_fetal_death, full_sib_neonatal_death, full_sib_death_post28d,
  total_sib_fetal_death, total_sib_neonatal_death, total_sib_death_post28d
)]
if (anyDuplicated(death_extract$case_id) || anyDuplicated(d$case_id)) {
  stop("Death-history case_id is not unique")
}
death_index <- match(d$case_id, death_extract$case_id)
if (anyNA(death_index)) {
  stop(sprintf("%d prepared-data rows lack a raw death-history match", sum(is.na(death_index))))
}
d2 <- copy(d)
for (v in setdiff(names(death_extract), "case_id")) {
  set(d2, j = v, value = death_extract[[v]][death_index])
}
cat("Authoritatively replaced death-history fields from raw CPPVAR\n")

# Also add: number of dead siblings from gravida structure
d2[, institution := substr(case_id, 1, 3)]
d2[, gravida_id_ext := substr(case_id, 4, 7)]
d2[, mother_key := paste0(institution, gravida_id_ext)]

# Count dead pregnancies per mother from the full raw data
dead_per_mother <- grav[died_early == 1, .(n_dead_pregnancies = .N), by = mother_key]
d2 <- merge(d2, dead_per_mother, by = "mother_key", all.x = TRUE)
d2[is.na(n_dead_pregnancies), n_dead_pregnancies := 0]

cat(sprintf("Children with dead-pregnancy count from gravida: %d with >0\n",
            sum(d2$n_dead_pregnancies > 0)))

# ---- 4. Full dilution analysis ----
cat("\n--- 4. Full dilution analysis ---\n")

bw <- d2[race %in% c(1, 2) & !is.na(wisc_fsiq) & !is.na(prior_deaths_total)]

# Decompose
bw[, prior_surviving := pmax(prior_preg - prior_deaths_total, 0)]
bw[, prior_dead := prior_deaths_total]

cat(sprintf("Analysis sample: %d\n", nrow(bw)))

# --- 4a. Main result: living vs dead siblings ---
cat("\n=== MAIN RESULT: OLS ===\n")
m_ols <- feols(wisc_fsiq ~ prior_surviving + prior_dead + factor(sex) + factor(race) + maternal_age,
               data = bw, vcov = "hetero")
cat(sprintf("  Prior surviving: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_ols)["prior_surviving"], se(m_ols)["prior_surviving"],
            2*pnorm(-abs(coef(m_ols)["prior_surviving"]/se(m_ols)["prior_surviving"]))))
cat(sprintf("  Prior dead:      b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_ols)["prior_dead"], se(m_ols)["prior_dead"],
            2*pnorm(-abs(coef(m_ols)["prior_dead"]/se(m_ols)["prior_dead"]))))

cat("\n=== MAIN RESULT: MOTHER FE ===\n")
bw[, n_sibs := .N, by = mother_id]
bw_sib <- bw[n_sibs >= 2]
m_fe <- feols(wisc_fsiq ~ prior_surviving + prior_dead + factor(sex) | mother_id,
              data = bw_sib, vcov = ~mother_id)
cat(sprintf("  Prior surviving: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_fe)["prior_surviving"], se(m_fe)["prior_surviving"],
            2*pnorm(-abs(coef(m_fe)["prior_surviving"]/se(m_fe)["prior_surviving"]))))
cat(sprintf("  Prior dead:      b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_fe)["prior_dead"], se(m_fe)["prior_dead"],
            2*pnorm(-abs(coef(m_fe)["prior_dead"]/se(m_fe)["prior_dead"]))))

# --- 4b. Decompose by type of death ---
cat("\n=== DECOMPOSE BY DEATH TYPE (OLS) ===\n")
# prior_fetal = abortions/miscarriages < 20 weeks
# prior_stillbirths = deaths >= 20 weeks gestation
# prior_neonatal = neonatal deaths
# prior_surviving = living siblings
bw[, prior_fetal := prior_fetal_deaths]
bw[, prior_still := prior_stillbirths]
# neonatal = total - fetal - stillbirths (approximately)
bw[, prior_neonatal := pmax(prior_deaths_total - prior_fetal_deaths - prior_stillbirths, 0)]
bw[is.na(prior_fetal) | is.na(prior_still), prior_neonatal := NA]

sub_type <- bw[!is.na(prior_fetal) & !is.na(prior_still) & !is.na(prior_neonatal)]
cat(sprintf("Sample with type breakdown: %d\n", nrow(sub_type)))

m_type_ols <- feols(wisc_fsiq ~ prior_surviving + prior_fetal + prior_still + prior_neonatal +
                      factor(sex) + factor(race) + maternal_age,
                    data = sub_type, vcov = "hetero")
cat("OLS by type:\n")
for (v in c("prior_surviving", "prior_fetal", "prior_still", "prior_neonatal")) {
  cat(sprintf("  %-20s: b=%7.3f (SE=%.3f), p=%.4f\n", v,
              coef(m_type_ols)[v], se(m_type_ols)[v],
              2*pnorm(-abs(coef(m_type_ols)[v]/se(m_type_ols)[v]))))
}

# Mother FE by type
sub_type[, n_sibs := .N, by = mother_id]
sub_sib <- sub_type[n_sibs >= 2]
m_type_fe <- feols(wisc_fsiq ~ prior_surviving + prior_fetal + prior_still + prior_neonatal +
                     factor(sex) | mother_id,
                   data = sub_sib, vcov = ~mother_id)
cat("\nMother FE by type:\n")
for (v in c("prior_surviving", "prior_fetal", "prior_still", "prior_neonatal")) {
  if (v %in% names(coef(m_type_fe))) {
    cat(sprintf("  %-20s: b=%7.3f (SE=%.3f), p=%.4f\n", v,
                coef(m_type_fe)[v], se(m_type_fe)[v],
                2*pnorm(-abs(coef(m_type_fe)[v]/se(m_type_fe)[v]))))
  } else {
    cat(sprintf("  %-20s: dropped (collinear)\n", v))
  }
}

# --- 4c. By race ---
cat("\n=== BY RACE (MOTHER FE) ===\n")
for (r in c(1, 2)) {
  rl <- ifelse(r == 1, "White", "Black")
  sub <- bw_sib[race == r]
  m <- feols(wisc_fsiq ~ prior_surviving + prior_dead + factor(sex) | mother_id,
             data = sub, vcov = ~mother_id)
  cat(sprintf("%s:\n", rl))
  cat(sprintf("  Prior surviving: b=%.3f (SE=%.3f), p=%.4f\n",
              coef(m)["prior_surviving"], se(m)["prior_surviving"],
              2*pnorm(-abs(coef(m)["prior_surviving"]/se(m)["prior_surviving"]))))
  cat(sprintf("  Prior dead:      b=%.3f (SE=%.3f), p=%.4f\n",
              coef(m)["prior_dead"], se(m)["prior_dead"],
              2*pnorm(-abs(coef(m)["prior_dead"]/se(m)["prior_dead"]))))
}

# --- 4d. SES interaction ---
cat("\n=== SES INTERACTION ===\n")
bw_sib[, low_ses := as.integer(sei_decimal < median(sei_decimal, na.rm=TRUE))]
m_ses <- feols(wisc_fsiq ~ prior_surviving * low_ses + prior_dead * low_ses + factor(sex) | mother_id,
               data = bw_sib[!is.na(low_ses)], vcov = ~mother_id)
cat("FE with SES interaction:\n")
for (v in names(coef(m_ses))) {
  cat(sprintf("  %-30s: b=%7.3f (SE=%.3f), p=%.4f\n", v,
              coef(m_ses)[v], se(m_ses)[v],
              2*pnorm(-abs(coef(m_ses)[v]/se(m_ses)[v]))))
}

# --- 4e. SB IQ ---
cat("\n=== SB IQ (AGE 4) ===\n")
bw_sb <- d2[race %in% c(1, 2) & !is.na(sb_iq) & !is.na(prior_deaths_total)]
bw_sb[, prior_surviving := pmax(prior_preg - prior_deaths_total, 0)]
bw_sb[, prior_dead := prior_deaths_total]
bw_sb[, n_sibs := .N, by = mother_id]
bw_sb_sib <- bw_sb[n_sibs >= 2]

m_sb_fe <- feols(sb_iq ~ prior_surviving + prior_dead + factor(sex) | mother_id,
                 data = bw_sb_sib, vcov = ~mother_id)
cat(sprintf("FE:\n"))
cat(sprintf("  Prior surviving: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_sb_fe)["prior_surviving"], se(m_sb_fe)["prior_surviving"],
            2*pnorm(-abs(coef(m_sb_fe)["prior_surviving"]/se(m_sb_fe)["prior_surviving"]))))
cat(sprintf("  Prior dead:      b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_sb_fe)["prior_dead"], se(m_sb_fe)["prior_dead"],
            2*pnorm(-abs(coef(m_sb_fe)["prior_dead"]/se(m_sb_fe)["prior_dead"]))))

# --- 4f. Summary ---
cat("\n=== SUMMARY ===\n")
cat("Under dilution theory, prior living siblings should be MORE negative than\n")
cat("prior dead siblings (living = dilution, dead = birth event only).\n")
cat("Within families, the surviving-sibling coefficient is positive, while the\n")
cat("dead-sibling coefficient is imprecise. There is no evidence that a prior\n")
cat("death lowers IQ, but the contrast is not precise enough to claim channel\n")
cat("equivalence or to rule out all resource-dilution effects.\n")

# Machine-readable audit outputs used by the manuscript and release checks.
tidy_fixest <- function(model, model_name) {
  ct <- as.data.table(coeftable(model), keep.rownames = "term")
  setnames(ct, c("Estimate", "Std. Error", "t value", "Pr(>|t|)"),
           c("estimate", "std_error", "statistic", "p_value"), skip_absent = TRUE)
  ct[, `:=`(model = model_name, n = nobs(model))]
  setcolorder(ct, c("model", "term", "estimate", "std_error", "statistic", "p_value", "n"))
  ct
}

death_results <- rbindlist(list(
  tidy_fixest(m_ols, "wisc_ols_living_vs_dead"),
  tidy_fixest(m_fe, "wisc_mother_fe_living_vs_dead"),
  tidy_fixest(m_type_ols, "wisc_ols_death_type"),
  tidy_fixest(m_type_fe, "wisc_mother_fe_death_type"),
  tidy_fixest(m_ses, "wisc_mother_fe_ses_interaction"),
  tidy_fixest(m_sb_fe, "sb_mother_fe_living_vs_dead")
), fill = TRUE)
fwrite(death_results, "results_death_dilution.csv")
saveRDS(
  list(
    results = death_results,
    models = list(
      wisc_ols = m_ols,
      wisc_fe = m_fe,
      type_ols = m_type_ols,
      type_fe = m_type_fe,
      ses_fe = m_ses,
      sb_fe = m_sb_fe
    )
  ),
  "results_death_dilution.rds"
)
cat("Saved results_death_dilution.csv and results_death_dilution.rds\n")

cat("\nDone.\n")
