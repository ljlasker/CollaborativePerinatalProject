#!/usr/bin/env Rscript
# 01_data_prep.R — Prepare analysis datasets for CPP analysis paper

library(data.table)
library(psych)

BASE <- ".."
cat("--- Data Preparation ---\n")

# ---- 1. Load core datasets ----
d <- as.data.table(readRDS(file.path(BASE, "clean", "cpp_clean_expanded.rds")))
d[, case_id := as.character(case_id)]
d[, mother_id := as.character(mother_id)]
cat(sprintf("Loaded: %d records, %d variables\n", nrow(d), ncol(d)))

# ---- 1a. Apply documented pregnancy-history sentinel semantics ----
# In these count fields, 88 means no prior pregnancy and is represented as
# zero; 99 means unknown and remains missing. Read the source columns directly
# so the analytical definitions are explicit and independently checkable.
pregnancy_history_columns <- c(
  parity = "v46_parity_pregnancies_total_number",
  prior_perinatal_loss = "v48_deaths_total_number_prior",
  prior_livebirths = "v50_livebirths_total_number_prior"
)

pregnancy_history_raw <- fread(
  file.path(BASE, "clean", "cppvar_all_columns.csv"),
  select = c("case_id", unname(pregnancy_history_columns)),
  colClasses = "character",
  strip.white = FALSE,
  showProgress = FALSE
)
if (anyDuplicated(pregnancy_history_raw$case_id)) {
  stop("Duplicate case_id in raw CPPVAR pregnancy-history extraction")
}

# Canonical linkage right-completes eight-character pregnancy prefixes with a
# terminal 0. The alias map also recognizes the numeric rendering of the same
# source key and normalizes every input to the source-linked identifier.
trimmed_case_id <- sub(" +$", "", pregnancy_history_raw$case_id)
canonical_case_id <- ifelse(nchar(trimmed_case_id) == 8L,
                            paste0(trimmed_case_id, "0"), trimmed_case_id)
legacy_case_id <- ifelse(nchar(trimmed_case_id) == 8L,
                         sprintf("%09d", as.integer(trimmed_case_id)),
                         trimmed_case_id)
id_aliases <- unique(data.table(
  alias = c(trimmed_case_id, canonical_case_id, legacy_case_id),
  canonical = rep(canonical_case_id, 3L)
))
if (id_aliases[, uniqueN(canonical), by = alias][V1 > 1L, .N])
  stop("Ambiguous raw CPPVAR case_id alias map")

d_case_before <- d$case_id
d_alias_index <- match(d$case_id, id_aliases$alias)
if (anyNA(d_alias_index))
  stop(sprintf("%d analysis-ready case IDs have no raw alias match", sum(is.na(d_alias_index))))
d[, case_id := id_aliases$canonical[d_alias_index]]
d[, mother_id := substr(case_id, 1L, 7L)]

raw_index <- match(d$case_id, canonical_case_id)
fallback_match <- d_case_before != d$case_id
if (anyNA(raw_index)) {
  stop(sprintf("%d analysis rows had no raw CPPVAR case_id match", sum(is.na(raw_index))))
}

for (clean_name in names(pregnancy_history_columns)) {
  raw_name <- pregnancy_history_columns[[clean_name]]
  raw_value <- trimws(pregnancy_history_raw[[raw_name]][raw_index])
  clean_value <- suppressWarnings(as.integer(raw_value))
  clean_value[is.na(raw_value) | raw_value == "" | raw_value == "99"] <- NA_integer_
  clean_value[raw_value == "88"] <- 0L
  set(d, j = clean_name, value = clean_value)

  structural_zero <- raw_value == "88"
  unknown <- raw_value == "99"
  stopifnot(
    all(d[[clean_name]][structural_zero] == 0L),
    all(is.na(d[[clean_name]][unknown]))
  )
  cat(sprintf(
    "Prepared %s: %s structural zeros (88 -> 0); %s unknowns (99 -> NA)\n",
    clean_name,
    format(sum(structural_zero), big.mark = ","),
    format(sum(unknown), big.mark = ",")
  ))
}
cat(sprintf(
  "Pregnancy-history ID matches: %s exact, %s normalized fallback\n",
  format(sum(!fallback_match), big.mark = ","),
  format(sum(fallback_match), big.mark = ",")
))

links <- fread(file.path(BASE, "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

growth <- fread(file.path(BASE, "clean", "cpp_growth_trajectories.csv"),
                colClasses = c(case_id = "character"))

bwz <- fread(file.path(BASE, "clean", "cpp_birthweight_zscores.csv"),
             colClasses = c(case_id = "character"))

ses <- fread(file.path(BASE, "clean", "cpp_ses_detailed.csv"),
             colClasses = c(case_id = "character"))

# ---- 2. Merge BW z-scores ----
d <- merge(d, bwz[, .(case_id, bw_zscore)], by = "case_id", all.x = TRUE)

# ---- 3. Restrict to live births with known sex ----
d <- d[outcome_grp == 3 & sex %in% c(1, 2)]
cat(sprintf("Live births with known sex: %d\n", nrow(d)))

# ---- 4. Clean key variables ----
# Birth order: use prior live births as a zero-based count (0 = firstborn)
d[, birth_order := as.integer(prior_livebirths)]
d[birth_order %in% c(88, 99), birth_order := NA_integer_]
d[birth_order > 15, birth_order := NA_integer_]  # implausible

# Maternal age
d[maternal_age %in% c(0, 99), maternal_age := NA_integer_]
d[, maternal_age_sq := maternal_age^2]

# Smoking
d[, smoker := as.integer(smoker)]
d[, cigs_day := as.integer(cigs_per_day)]
d[cigs_day %in% c(99), cigs_day := NA_integer_]
d[cigs_day == 70, cigs_day := 1L]   # <1/day regular
d[cigs_day == 80, cigs_day := 1L]   # irregular
d[cigs_day > 60 & !is.na(cigs_day), cigs_day := 60L]

# Breastfeeding
d[, bf_any := as.integer(bf_ever)]
d[, bf_days_clean := as.integer(bf_days)]
d[bf_days_clean > 8, bf_days_clean := NA_integer_]

# Education
d[educ_yrs == 99, educ_yrs := NA_integer_]

# SEI
d[sei == 99, sei := NA_integer_]
d[, sei_decimal := as.numeric(sei_decimal)]

# Gestational age
d[gest_age %in% c(0, 51, 99), gest_age := NA_integer_]

# Non-WISC cognitive measures
# bender_gestalt_errors is the Bender total from CPPVAR (r=.55 with FSIQ).
# ps30_col71 is a weak proxy (r=.32 with FSIQ), and picarr_raw contains
# Picture Arrangement raw scores.
d[, bender_gestalt := -bender_gestalt_errors]  # reverse so higher = better
cat(sprintf("Real Bender: N=%d, mean=%.1f (reversed), cor(FSIQ)=%.3f\n",
    sum(!is.na(d$bender_gestalt)),
    mean(d$bender_gestalt, na.rm=TRUE),
    cor(d$bender_gestalt, d$wisc_fsiq, use="complete.obs")))
# NOTE: ps30_col43 is identical to wisc_coding (r=1.000). The
# "auditory_vocal" variable is the
# sum of the 3 WISC Performance subtests (PicArr+Block+Coding), not an ITPA
# score. No real ITPA/AVAT exists in this dataset.

# Clean sentinel values in additional cognitive tests
# goodenough_raw: max = 61 is fine; goodenough_standard has 888 sentinel
if ("goodenough_standard" %in% names(d)) d[goodenough_standard == 888, goodenough_standard := NA]
# wrat_spell_raw, wrat_arith_raw: check for 99-type sentinels
# (ranges look clean in practice: spell [0,62], arith [0,82])

# Family size
d[, n_kids := .N, by = mother_id]

# ---- 5. Extract latent g factor (PCA PC1 on 12-test battery) ----
cat("\n--- Latent g Factor Extraction (PCA) ---\n")

g_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
            "wisc_picarr", "wisc_block", "wisc_coding",
            "wrat_read_raw", "bender_gestalt",
            "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")

# Standardize
for (v in g_vars) {
  z_name <- paste0(v, "_z")
  d[, (z_name) := scale(get(v))]
}
z_vars <- paste0(g_vars, "_z")

# Complete cases for PCA
g_complete <- d[complete.cases(d[, ..g_vars])]
cat(sprintf("Complete cases for g (12 tests): %d\n", nrow(g_complete)))

g_mat <- as.matrix(g_complete[, ..z_vars])
pca_result <- prcomp(g_mat, center = FALSE, scale. = FALSE)  # already z-scored

pc1_loadings <- pca_result$rotation[, 1]
# Ensure positive orientation (majority of loadings positive)
if (sum(pc1_loadings < 0) > sum(pc1_loadings > 0)) {
  pc1_loadings <- -pc1_loadings
  pca_result$x[, 1] <- -pca_result$x[, 1]
}

cat("PCA PC1 loadings:\n")
print(round(pc1_loadings, 3))
pct_var <- summary(pca_result)$importance[2, 1] * 100
cat(sprintf("Variance explained by PC1: %.1f%%\n", pct_var))

g_scores <- pca_result$x[, 1]
g_complete[, g_factor := g_scores]
d <- merge(d, g_complete[, .(case_id, g_factor)], by = "case_id", all.x = TRUE)
cat(sprintf("Children with g scores: %d\n", sum(!is.na(d$g_factor))))

# Also save PCA loadings for reference (as a list, replacing old fa_result)
fa_result <- list(
  method = "PCA_PC1",
  loadings = pc1_loadings,
  pct_variance = pct_var,
  n_tests = length(g_vars),
  test_names = g_vars
)

# ---- 5b. WISC-only g (PCA PC1 on 7 WISC subtests) ----
cat("\n--- WISC-Only g Factor (7 subtests) ---\n")
wisc_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
               "wisc_picarr", "wisc_block", "wisc_coding")
wisc_z <- paste0(wisc_vars, "_z")
wisc_complete <- d[complete.cases(d[, ..wisc_vars])]
cat(sprintf("Complete cases for WISC g (7 tests): %d\n", nrow(wisc_complete)))
wisc_mat <- as.matrix(wisc_complete[, ..wisc_z])
pca_wisc <- prcomp(wisc_mat, center = FALSE, scale. = FALSE)
pc1_wisc <- pca_wisc$rotation[, 1]
if (sum(pc1_wisc < 0) > sum(pc1_wisc > 0)) {
  pc1_wisc <- -pc1_wisc
  pca_wisc$x[, 1] <- -pca_wisc$x[, 1]
}
cat("WISC PCA PC1 loadings:\n")
print(round(pc1_wisc, 3))
pct_wisc <- summary(pca_wisc)$importance[2, 1] * 100
cat(sprintf("Variance explained: %.1f%%\n", pct_wisc))
wisc_complete[, g_wisc7 := pca_wisc$x[, 1]]
d <- merge(d, wisc_complete[, .(case_id, g_wisc7)], by = "case_id", all.x = TRUE)
cat(sprintf("Children with WISC g: %d\n", sum(!is.na(d$g_wisc7))))

# ---- 5c. Achievement g (PCA PC1 on 3 WRAT + Bender + Goodenough) ----
cat("\n--- Non-WISC g Factor (5 tests) ---\n")
nonwisc_vars <- c("wrat_read_raw", "wrat_spell_raw", "wrat_arith_raw",
                   "bender_gestalt", "goodenough_raw")
nonwisc_z <- paste0(nonwisc_vars, "_z")
nonwisc_complete <- d[complete.cases(d[, ..nonwisc_vars])]
cat(sprintf("Complete cases for non-WISC g (5 tests): %d\n", nrow(nonwisc_complete)))
nonwisc_mat <- as.matrix(nonwisc_complete[, ..nonwisc_z])
pca_nonwisc <- prcomp(nonwisc_mat, center = FALSE, scale. = FALSE)
pc1_nonwisc <- pca_nonwisc$rotation[, 1]
if (sum(pc1_nonwisc < 0) > sum(pc1_nonwisc > 0)) {
  pc1_nonwisc <- -pc1_nonwisc
  pca_nonwisc$x[, 1] <- -pca_nonwisc$x[, 1]
}
cat("Non-WISC PCA PC1 loadings:\n")
print(round(pc1_nonwisc, 3))
pct_nonwisc <- summary(pca_nonwisc)$importance[2, 1] * 100
cat(sprintf("Variance explained: %.1f%%\n", pct_nonwisc))
nonwisc_complete[, g_nonwisc5 := pca_nonwisc$x[, 1]]
d <- merge(d, nonwisc_complete[, .(case_id, g_nonwisc5)], by = "case_id", all.x = TRUE)
cat(sprintf("Children with non-WISC g: %d\n", sum(!is.na(d$g_nonwisc5))))

# ---- 6. Standardize all IQ outcomes ----
iq_vars <- c("sb_iq", "wisc_fsiq", "wisc_viq", "wisc_piq",
             "g_factor", "g_wisc7", "g_nonwisc5")
for (v in iq_vars) {
  z_name <- paste0(v, "_z")
  d[, (z_name) := as.numeric(scale(get(v)))]
}

# ---- 7. Summary statistics ----
cat("\n--- Sample Summary ---\n")
cat(sprintf("Total live births: %d\n", nrow(d)))
cat(sprintf("With SB IQ (4yr): %d\n", sum(!is.na(d$sb_iq))))
cat(sprintf("With WISC FSIQ (7yr): %d\n", sum(!is.na(d$wisc_fsiq))))
cat(sprintf("With latent g: %d\n", sum(!is.na(d$g_factor))))
cat(sprintf("With WISC g: %d\n", sum(!is.na(d$g_wisc7))))
cat(sprintf("With non-WISC g: %d\n", sum(!is.na(d$g_nonwisc5))))
cat(sprintf("Families with 2+ children: %d\n", sum(d[, .N, by=mother_id]$N >= 2)))
cat(sprintf("White: %d (%.1f%%)\n", sum(d$race == 1, na.rm = TRUE), 100 * mean(d$race == 1, na.rm = TRUE)))
cat(sprintf("Black: %d (%.1f%%)\n", sum(d$race == 2, na.rm = TRUE), 100 * mean(d$race == 2, na.rm = TRUE)))
cat(sprintf("Male: %d (%.1f%%)\n", sum(d$sex==1), 100*mean(d$sex==1)))
cat(sprintf("Mean maternal age: %.1f\n", mean(d$maternal_age, na.rm=TRUE)))
cat(sprintf("Mean birth weight: %.0f g\n", mean(d$birth_wt_g, na.rm=TRUE)))
cat(sprintf("Smokers: %.1f%%\n", 100*mean(d$smoker==1, na.rm=TRUE)))
cat(sprintf("Ever breastfed: %.1f%%\n", 100*mean(d$bf_any==1, na.rm=TRUE)))

# IQ means
for (v in c("sb_iq", "wisc_fsiq", "wisc_viq", "wisc_piq")) {
  cat(sprintf("Mean %s: %.1f (SD=%.1f, N=%d)\n",
              v, mean(d[[v]], na.rm=TRUE), sd(d[[v]], na.rm=TRUE),
              sum(!is.na(d[[v]]))))
}

# ---- 8. Kinship pair summary ----
cat("\n--- Kinship Pairs ---\n")
print(links[, .N, by = pair_type][order(-N)])

# Pairs with IQ data
iq_1 <- d[!is.na(wisc_fsiq), .(id_1 = case_id, iq_1 = wisc_fsiq, iq_1z = wisc_fsiq_z,
                                 sb_1 = sb_iq, sb_1z = sb_iq_z,
                                 g_1 = g_factor, g_1z = g_factor_z,
                                 viq_1 = wisc_viq, viq_1z = wisc_viq_z,
                                 piq_1 = wisc_piq, piq_1z = wisc_piq_z,
                                 gw7_1 = g_wisc7, gw7_1z = g_wisc7_z,
                                 gnw5_1 = g_nonwisc5, gnw5_1z = g_nonwisc5_z)]
iq_2 <- d[!is.na(wisc_fsiq), .(id_2 = case_id, iq_2 = wisc_fsiq, iq_2z = wisc_fsiq_z,
                                 sb_2 = sb_iq, sb_2z = sb_iq_z,
                                 g_2 = g_factor, g_2z = g_factor_z,
                                 viq_2 = wisc_viq, viq_2z = wisc_viq_z,
                                 piq_2 = wisc_piq, piq_2z = wisc_piq_z,
                                 gw7_2 = g_wisc7, gw7_2z = g_wisc7_z,
                                 gnw5_2 = g_nonwisc5, gnw5_2z = g_nonwisc5_z)]

iq_links <- merge(links, iq_1, by = "id_1")
iq_links <- merge(iq_links, iq_2, by = "id_2")
cat(sprintf("Pairs with WISC FSIQ for both: %d\n", nrow(iq_links)))

# ---- 9. Save prepared datasets ----
saveRDS(d, "prepared_data.rds")
saveRDS(links, "prepared_links.rds")
saveRDS(iq_links, "prepared_iq_links.rds")
saveRDS(growth, "prepared_growth.rds")
saveRDS(ses, "prepared_ses.rds")
saveRDS(fa_result, "g_factor_model.rds")

cat("Done.\n")
cat("Saved: prepared_data.rds, prepared_links.rds, prepared_iq_links.rds,\n")
cat("       prepared_growth.rds, prepared_ses.rds, g_factor_model.rds\n")
