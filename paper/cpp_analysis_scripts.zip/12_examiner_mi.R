#!/usr/bin/env Rscript
# 12_examiner_mi.R — Examiner ratings: DIF, g-validity, Jensen's method

library(data.table)
library(mirt)
library(psych)

cat("--- Examiner Ratings: MI & g Validity ---\n")

# ---- Load and prepare data ----
d <- as.data.table(readRDS("prepared_data.rds"))
d[, case_id := as.character(case_id)]

# Load PSY25 items from card 41300 (same recoding as build_item_batteries.R)
beh7 <- fread("../clean/master/parsed/card_41300_parsed.csv")
beh7[, case_id := as.character(case_id)]

beh7_fields <- fread("../clean/master/parsed/card_41300_fields.csv")
psy25_fields <- beh7_fields[grepl("PSY25", data_id)]
psy25_fields[, col_key := paste(data_col_from, data_col_to, sep = "-")]
psy25_unique <- psy25_fields[!duplicated(col_key)]
psy25_vars <- intersect(psy25_unique$varname, names(beh7))

for (col in psy25_vars) {
  beh7[, (col) := suppressWarnings(as.integer(get(col)))]
  fw <- psy25_unique[varname == col, field_width]
  if (length(fw) > 0 && fw == 2) {
    beh7[!is.na(get(col)), (col) := as.integer(get(col) %/% 10)]
  }
  beh7[get(col) %in% c(8, 9, 88, 99), (col) := NA_integer_]
}

# Filter to items with sufficient variance (same as build_item_batteries.R)
psy25_good <- character(0)
for (col in psy25_vars) {
  v <- beh7[[col]][!is.na(beh7[[col]])]
  if (length(unique(v)) >= 2 && length(v) >= 5000) {
    psy25_good <- c(psy25_good, col)
  }
}
cat(sprintf("PSY25 items passing filters: %d\n", length(psy25_good)))
cat(sprintf("  Items: %s\n", paste(psy25_good, collapse = ", ")))

# Merge with race
beh7_race <- merge(beh7[, c("case_id", psy25_good), with = FALSE],
                   d[, .(case_id, race, wisc_fsiq, sb_iq)],
                   by = "case_id")

# Restrict to Black (race=2) and White (race=1) for DIF
beh7_bw <- beh7_race[race %in% c(1, 2)]
beh7_bw[, group := factor(ifelse(race == 1, "White", "Black"))]
cat(sprintf("\nSample for DIF: N=%d (White=%d, Black=%d)\n",
            nrow(beh7_bw), sum(beh7_bw$group == "White"), sum(beh7_bw$group == "Black")))

# ---- A. IRT-Based DIF Analysis ----
cat("\n--- A. IRT-Based DIF Analysis (Black vs White) ---\n")

# Prepare item matrix
items_df <- as.data.frame(beh7_bw[, ..psy25_good])

# Fit multi-group GRM with all parameters constrained equal
cat("Fitting multi-group GRM (constrained)...\n")
mg_model <- multipleGroup(items_df, model = 1, group = beh7_bw$group,
                          itemtype = "graded", verbose = FALSE,
                          invariance = c("free_means", "free_var",
                                         colnames(items_df)),
                          technical = list(NCYCLES = 2000))
cat(sprintf("  Converged: %s\n", ifelse(mg_model@OptimInfo$converged, "YES", "NO")))

# DIF analysis: drop-one-at-a-time anchoring with Bonferroni
cat("\nRunning DIF analysis (scheme='drop', Bonferroni correction)...\n")
# Test slope (a1) DIF first — this is metric invariance (most important)
cat("  Testing slope (a1) DIF...\n")
dif_slope <- DIF(mg_model, which.par = c("a1"),
                 scheme = "drop", p.adjust = "bonferroni",
                 verbose = FALSE)

# Also test intercept DIF (d parameters) — this is scalar invariance
# Find max number of categories across items to get valid d parameter names
max_cats <- max(sapply(as.data.frame(items_df), function(x) length(unique(x[!is.na(x)]))))
d_pars <- paste0("d", 1:(max_cats - 1))
cat(sprintf("  Testing intercept (%s) DIF...\n", paste(d_pars, collapse=",")))
dif_intercept <- tryCatch(
  DIF(mg_model, which.par = d_pars,
      scheme = "drop", p.adjust = "bonferroni",
      verbose = FALSE),
  error = function(e) {
    # Some items have fewer categories; fall back to d1 only
    cat(sprintf("  Full intercept DIF failed (%s), testing d1 only...\n", conditionMessage(e)))
    DIF(mg_model, which.par = c("d1"),
        scheme = "drop", p.adjust = "bonferroni",
        verbose = FALSE)
  }
)
dif_result <- dif_slope  # Use slope DIF as primary

cat("\nSlope (a1) DIF Results:\n")
cat(sprintf("  %-25s  %10s  %6s  %10s  %s\n", "Item", "X2", "df", "p(adj)", "DIF?"))
print(dif_slope)
n_slope_dif <- sum(dif_slope$adj_p < 0.05, na.rm = TRUE)
cat(sprintf("\n  Items with slope DIF (Bonferroni p < .05): %d of %d\n",
            n_slope_dif, nrow(dif_slope)))

cat("\nIntercept DIF Results:\n")
print(dif_intercept)
n_int_dif <- sum(dif_intercept$adj_p < 0.05, na.rm = TRUE)
cat(sprintf("\n  Items with intercept DIF (Bonferroni p < .05): %d of %d\n",
            n_int_dif, nrow(dif_intercept)))

# Empirical effect sizes
cat("\nEmpirical effect sizes (impact of DIF on group scores):\n")
tryCatch({
  es <- empirical_ES(mg_model, DIF = FALSE)
  cat("  Signed ES (constrained model — no DIF modeled):\n")
  print(round(head(es, 20), 4))
}, error = function(e) cat(sprintf("  empirical_ES failed: %s\n", conditionMessage(e))))

# Item parameters from constrained model (equal across groups by design)
cat("\nItem discrimination parameters (constrained model):\n")
pars_constrained <- coef(mg_model, IRTpars = TRUE, simplify = TRUE)$White$items
cat(sprintf("  %-25s  %8s\n", "Item", "a"))
for (i in 1:nrow(pars_constrained)) {
  cat(sprintf("  %-25s  %8.2f\n", rownames(pars_constrained)[i], pars_constrained[i, 1]))
}

# ---- B. Examiner Ratings and g ----
cat("\n--- B. Examiner Ratings and g: Latent Correlation ---\n")

# Load g factor scores
g <- fread("../clean/cpp_g_factors.csv")
g[, case_id := as.character(case_id)]

# Load examiner IRT scores
item_scores <- fread("../clean/cpp_item_scores.csv")
item_scores[, case_id := as.character(case_id)]

# Merge
val <- merge(item_scores[, .(case_id, examiner_7yr_pca, examiner_7yr_irt)],
             g[, .(case_id, g_pca_wisc4, g_pca_9, g_pca_broad, g_irt_sb_adaptive)],
             by = "case_id")
val <- merge(val, d[, .(case_id, wisc_fsiq, sb_iq, race)], by = "case_id")

cat("Observed correlations (examiner scores with g factors and IQ):\n")
cor_vars <- c("examiner_7yr_pca", "examiner_7yr_irt",
              "g_pca_wisc4", "g_pca_9", "g_pca_broad", "g_irt_sb_adaptive",
              "wisc_fsiq", "sb_iq")
cor_mat <- cor(val[, ..cor_vars], use = "pairwise.complete.obs")
cat(sprintf("  %-25s  %8s  %8s  %8s  %8s  %8s  %8s\n",
            "", "g_PCA4", "g_PCA9", "g_Broad", "g_IRT_SB", "WISC", "SB_IQ"))
for (v in c("examiner_7yr_pca", "examiner_7yr_irt")) {
  cat(sprintf("  %-25s  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f\n",
              v,
              cor_mat[v, "g_pca_wisc4"], cor_mat[v, "g_pca_9"],
              cor_mat[v, "g_pca_broad"], cor_mat[v, "g_irt_sb_adaptive"],
              cor_mat[v, "wisc_fsiq"], cor_mat[v, "sb_iq"]))
}

# Correction for attenuation: r_latent = r_obs / sqrt(rel_x * rel_y)
# Reliability of examiner IRT: approximate from IRT model marginal reliability
# For g factors: PCA-7 r(WISC) = 0.97 → rel ≈ 0.97^2 ≈ 0.94 (conservative)
# For examiner IRT: r(WISC) = 0.798, and the factor has 14 items
# More accurate: fit the model and get marginal reliability
cat("\nEstimating marginal reliability of examiner IRT score...\n")
mod_full <- mirt(as.data.frame(beh7_race[, ..psy25_good]), 1,
                 itemtype = "graded", verbose = FALSE,
                 technical = list(NCYCLES = 2000))
mrel <- marginal_rxx(mod_full)
cat(sprintf("  Marginal reliability (examiner IRT): %.3f\n", mrel))

# g_pca_9 reliability: it correlates 0.97 with WISC FSIQ and explains 54.6% var
# Omega for 7-measure battery ≈ 0.90 (typical for cognitive batteries)
g_rel <- 0.90  # conservative estimate
cat(sprintf("  Assumed reliability (g_PCA9): %.2f\n", g_rel))

r_obs <- cor(val$examiner_7yr_irt, val$g_pca_9, use = "complete.obs")
r_latent <- r_obs / sqrt(mrel * g_rel)
cat(sprintf("\n  Observed r(examiner_IRT, g_PCA9) = %.3f\n", r_obs))
cat(sprintf("  Corrected for attenuation: r_latent = %.3f / sqrt(%.3f * %.3f) = %.3f\n",
            r_obs, mrel, g_rel, r_latent))
cat(sprintf("  → Examiner-rated cognitive factor shares ~%.0f%% of variance with g\n",
            min(r_latent^2 * 100, 100)))

# By race
cat("\nCorrelations by race:\n")
for (rc in c(1, 2)) {
  rc_label <- ifelse(rc == 1, "White", "Black")
  sub <- val[race == rc]
  r_irt <- cor(sub$examiner_7yr_irt, sub$g_pca_9, use = "complete.obs")
  r_wisc <- cor(sub$examiner_7yr_irt, sub$wisc_fsiq, use = "complete.obs")
  n <- sum(!is.na(sub$examiner_7yr_irt) & !is.na(sub$g_pca_9))
  cat(sprintf("  %s (N=%d): r(examiner_IRT, g_PCA9) = %.3f, r(examiner_IRT, WISC) = %.3f\n",
              rc_label, n, r_irt, r_wisc))
}

# ---- C. Jensen's Method ----
cat("\n--- C. Jensen's Method: g-Loadings vs Item-Level Race Gaps ---\n")

# Get IRT discrimination parameters (g-loadings) from full-sample model
pars_full <- coef(mod_full, IRTpars = TRUE, simplify = TRUE)$items
g_loadings <- pars_full[, 1]
cat("IRT discrimination parameters (g-loadings):\n")
for (i in seq_along(g_loadings)) {
  cat(sprintf("  %-25s  a = %.3f\n", names(g_loadings)[i], g_loadings[i]))
}

# Item-level race gaps (Cohen's d using means)
cat("\nItem-level race gaps (White - Black, in pooled SD units):\n")
item_gaps <- numeric(length(psy25_good))
names(item_gaps) <- psy25_good
for (col in psy25_good) {
  w <- beh7_bw[group == "White"][[col]]
  b <- beh7_bw[group == "Black"][[col]]
  w <- w[!is.na(w)]; b <- b[!is.na(b)]
  pooled_sd <- sqrt(((length(w)-1)*var(w) + (length(b)-1)*var(b)) / (length(w)+length(b)-2))
  item_gaps[col] <- (mean(w) - mean(b)) / pooled_sd
  cat(sprintf("  %-25s  d = %+.3f  (White: %.2f, Black: %.2f, SD_p: %.2f)\n",
              col, item_gaps[col], mean(w), mean(b), pooled_sd))
}

# Correlation of g-loadings with race gaps (Jensen's method)
r_jensen <- cor(g_loadings[psy25_good], item_gaps[psy25_good])
cat(sprintf("\nJensen's method: r(g-loading, BW gap) = %.3f (k=%d items)\n",
            r_jensen, length(psy25_good)))

# Test significance
ct <- cor.test(g_loadings[psy25_good], item_gaps[psy25_good])
cat(sprintf("  95%% CI: [%.3f, %.3f], t(%d) = %.2f, p = %.4f\n",
            ct$conf.int[1], ct$conf.int[2], ct$parameter, ct$statistic, ct$p.value))

cat("\nInterpretation:\n")
if (r_jensen > 0.3) {
  cat("  Positive Jensen effect: items with higher g-loading show larger race gaps.\n")
  cat("  This is consistent with Spearman's hypothesis — race differences are on g.\n")
  cat("  Examiner ratings capture the same g-loaded ability differences as standardized tests.\n")
} else if (r_jensen > -0.3) {
  cat("  Weak/null Jensen effect: g-loading and race gap size are unrelated.\n")
  cat("  Examiner race gaps may not primarily reflect g differences.\n")
} else {
  cat("  Negative Jensen effect: higher g-loaded items show SMALLER race gaps.\n")
  cat("  This would suggest examiner ratings have a different structure by race.\n")
}

# ---- D. Score-Level Race Gaps ----
cat("\n--- D. Race Gaps in Examiner Ratings vs Standardized Tests ---\n")

cat("Group means and gaps (Cohen's d):\n")
for (v in c("examiner_7yr_pca", "examiner_7yr_irt", "wisc_fsiq", "sb_iq",
            "g_pca_9", "g_irt_sb_adaptive")) {
  w <- val[race == 1][[v]]; w <- w[!is.na(w)]
  b <- val[race == 2][[v]]; b <- b[!is.na(b)]
  pooled_sd <- sqrt(((length(w)-1)*var(w) + (length(b)-1)*var(b)) / (length(w)+length(b)-2))
  d_gap <- (mean(w) - mean(b)) / pooled_sd
  cat(sprintf("  %-25s  White=%.2f  Black=%.2f  d=%+.3f  (N_W=%d, N_B=%d)\n",
              v, mean(w), mean(b), d_gap, length(w), length(b)))
}

# ---- E. Differential Prediction ----
cat("\n--- E. Differential Prediction by Race ---\n")

# Test if examiner_7yr_irt predicts WISC differently for Black vs White
mod_base <- lm(wisc_fsiq ~ examiner_7yr_irt, data = val[race %in% c(1,2)])
mod_race <- lm(wisc_fsiq ~ examiner_7yr_irt * factor(race), data = val[race %in% c(1,2)])

cat("Model: WISC FSIQ ~ examiner_IRT\n")
cat(sprintf("  Overall: b = %.2f (SE = %.2f), R² = %.3f\n",
            coef(mod_base)[2], summary(mod_base)$coefficients[2, 2],
            summary(mod_base)$r.squared))

cat("\nModel: WISC FSIQ ~ examiner_IRT * race\n")
s <- summary(mod_race)
cat(sprintf("  examiner_IRT (White slope):    b = %.2f (SE = %.2f)\n",
            coef(mod_race)[2], s$coefficients[2, 2]))
cat(sprintf("  race (Black intercept shift):  b = %.2f (SE = %.2f)\n",
            coef(mod_race)[3], s$coefficients[3, 2]))
cat(sprintf("  interaction (slope diff):      b = %.2f (SE = %.2f), p = %.4f\n",
            coef(mod_race)[4], s$coefficients[4, 2], s$coefficients[4, 4]))

if (abs(s$coefficients[4, 4]) < 0.05) {
  cat("  → Significant interaction: examiner ratings predict IQ differently by race.\n")
} else {
  cat("  → No significant interaction: examiner ratings predict IQ equally well for both races.\n")
}

cat("Done.\n")
