#!/usr/bin/env Rscript
# 03d_flynn_cohort.R -- Reproducible NCPP cohort/Flynn sensitivity models

library(data.table)
library(fixest)

cat("--- NCPP cohort/Flynn sensitivity ---\n")

d <- as.data.table(readRDS("prepared_data.rds"))

# CPP birth_date is stored as MMDDYY. Use the actual birth date rather than
# enrollment-order proxies, which are confounded with institution composition.
birth_text <- sprintf("%06d", as.integer(d$birth_date))
d[, birth_month := suppressWarnings(as.integer(substr(birth_text, 1L, 2L)))]
d[, birth_day := suppressWarnings(as.integer(substr(birth_text, 3L, 4L)))]
d[, birth_short_year := suppressWarnings(as.integer(substr(birth_text, 5L, 6L)))]
d[, valid_birth_date := birth_month %between% c(1L, 12L) &
    birth_day %between% c(1L, 31L) & birth_short_year %between% c(50L, 79L)]
d[, birth_year := fifelse(valid_birth_date, 1900L + birth_short_year, NA_integer_)]
d[, cohort := fifelse(
  valid_birth_date,
  birth_year + (birth_month - 0.5) / 12 + (birth_day - 15.5) / 365.25,
  NA_real_
)]

d[!wisc_fsiq %between% c(40, 160), wisc_fsiq := NA_real_]
d[!sb_iq %between% c(40, 160), sb_iq := NA_real_]
d[, wisc_cohort_z := as.numeric(scale(wisc_fsiq))]
d[, sb_cohort_z := as.numeric(scale(sb_iq))]
d[, male := fifelse(sex == 1L, 1, fifelse(sex == 2L, 0, NA_real_))]
d[, cohort_c := cohort - 1962.5]

tidy_cohort <- function(model, outcome, label) {
  data.table(
    outcome = outcome,
    specification = label,
    estimate_sd_decade = 10 * coef(model)["cohort_c"],
    se_sd_decade = 10 * se(model)["cohort_c"],
    p_value = pvalue(model)["cohort_c"],
    n = nobs(model),
    fe_groups = if (length(model$fixef_id)) length(unique(model$fixef_id[[1L]])) else 0L
  )
}

fit_outcome <- function(zvar, outcome_label) {
  analytic <- d[!is.na(get(zvar)) & !is.na(cohort_c) & !is.na(mother_id)]
  f <- function(rhs, fe = NULL) {
    formula_text <- paste0(zvar, " ~ ", rhs, if (!is.null(fe)) paste0(" | ", fe) else "")
    as.formula(formula_text)
  }
  models <- list(
    ols_raw = feols(f("cohort_c"), data = analytic, vcov = "hetero"),
    ols_site = feols(f("cohort_c", "institution"), data = analytic, vcov = "hetero"),
    ols_full = feols(
      f("cohort_c + factor(race) + sei_decimal", "institution"),
      data = analytic,
      vcov = "hetero"
    ),
    fe_raw = feols(f("cohort_c", "mother_id"), data = analytic, vcov = ~mother_id),
    fe_rank = feols(
      f("cohort_c + male + birth_order", "mother_id"),
      data = analytic,
      vcov = ~mother_id
    ),
    fe_preg = feols(
      f("cohort_c + male + preg_order", "mother_id"),
      data = analytic,
      vcov = ~mother_id
    )
  )
  labels <- c(
    "OLS, unadjusted",
    "OLS + institution FE",
    "OLS + institution FE + race + SEI",
    "Mother FE, unadjusted",
    "Mother FE + sex + live-birth order",
    "Mother FE + sex + study pregnancy order"
  )
  list(
    models = models,
    results = rbindlist(Map(
      function(model, label) tidy_cohort(model, outcome_label, label),
      models,
      labels
    ))
  )
}

fits <- list(
  wisc = fit_outcome("wisc_cohort_z", "WISC FSIQ"),
  sb = fit_outcome("sb_cohort_z", "Stanford-Binet IQ")
)
results <- rbindlist(lapply(fits, `[[`, "results"))
results[, `:=`(
  ci_low = estimate_sd_decade - 1.96 * se_sd_decade,
  ci_high = estimate_sd_decade + 1.96 * se_sd_decade
)]

fwrite(results, "results_flynn_cohort.csv")
saveRDS(
  list(
    results = results,
    models = lapply(fits, `[[`, "models")
  ),
  "results_flynn_cohort.rds"
)

print(results)
cat("Wrote results_flynn_cohort.csv and results_flynn_cohort.rds.\n")
