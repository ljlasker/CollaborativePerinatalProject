#!/usr/bin/env Rscript
# 07b_ses_within_family.R — Within-Family SES-IQ Analysis
# Tests whether changes in SES between siblings predict IQ differences
# Uses income, SEI, and housing density as time-varying indicators

library(data.table)
library(fixest)

cat("--- Within-Family SES-IQ Analysis ---\n")

d <- readRDS("prepared_data.rds")

# ---- 1. Identify sibling groups with IQ data ----
sib <- d[!is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
sib[, race_label := ifelse(race == 1, "White", "Black")]

# Count siblings per mother
sib[, n_sibs := .N, by = mother_id]
sib_fam <- sib[n_sibs >= 2]

cat(sprintf("Children in sibling families with WISC: %d\n", nrow(sib_fam)))
cat(sprintf("  Unique mothers: %d\n", uniqueN(sib_fam$mother_id)))
cat(sprintf("  White: %d children, %d mothers\n",
            nrow(sib_fam[race == 1]), uniqueN(sib_fam[race == 1]$mother_id)))
cat(sprintf("  Black: %d children, %d mothers\n",
            nrow(sib_fam[race == 2]), uniqueN(sib_fam[race == 2]$mother_id)))

# ---- 2. SES variation between siblings ----
cat("\n--- SES Variation Between Siblings ---\n\n")

ses_vars <- c("income", "sei_decimal", "housing_density", "educ_yrs")
ses_labels <- c("Family income", "SEI (decimal)", "Housing density", "Education (yrs)")

for (i in seq_along(ses_vars)) {
  v <- ses_vars[i]
  if (!v %in% names(sib_fam)) {
    cat(sprintf("  %s: variable not found\n", ses_labels[i]))
    next
  }
  sub <- sib_fam[!is.na(get(v))]
  sub[, n_valid := sum(!is.na(get(v))), by = mother_id]
  sub2 <- sub[n_valid >= 2]
  sub2[, ses_sd := sd(get(v)), by = mother_id]

  n_moms <- uniqueN(sub2$mother_id)
  n_vary <- uniqueN(sub2[ses_sd > 0]$mother_id)
  mean_sd <- mean(sub2[, .(sd = sd(get(v))), by = mother_id]$sd)

  cat(sprintf("  %s: %d mothers with 2+ valid, %d (%.1f%%) have within-family variation, mean within-SD = %.2f\n",
              ses_labels[i], n_moms, n_vary, 100 * n_vary / n_moms, mean_sd))
}

# ---- 3. OLS vs Mother FE regressions ----
cat("\n--- OLS vs Mother FE: SES -> WISC FSIQ ---\n\n")

run_models <- function(ses_var, ses_label, data) {
  sub <- data[!is.na(get(ses_var)) & !is.na(wisc_fsiq)]

  # OLS (pooled)
  f_ols <- as.formula(paste("wisc_fsiq ~", ses_var, "+ factor(sex) + birth_order"))
  m_ols <- feols(f_ols, data = sub, vcov = "hetero")

  # Mother FE
  f_fe <- as.formula(paste("wisc_fsiq ~", ses_var, "+ factor(sex) + birth_order | mother_id"))
  m_fe <- tryCatch(
    feols(f_fe, data = sub, vcov = ~mother_id),
    error = function(e) NULL
  )

  list(ols = m_ols, fe = m_fe, n = nrow(sub), n_moms = uniqueN(sub$mother_id))
}

# Run for each SES variable, pooled and by race
results <- list()

for (i in seq_along(ses_vars)) {
  v <- ses_vars[i]
  lab <- ses_labels[i]
  if (!v %in% names(sib_fam)) next

  cat(sprintf("=== %s ===\n", lab))

  # Pooled
  res_all <- run_models(v, lab, sib_fam)
  cat(sprintf("  Pooled OLS: b=%.3f (SE=%.3f), n=%d\n",
              coef(res_all$ols)[v], se(res_all$ols)[v], res_all$n))
  if (!is.null(res_all$fe)) {
    cat(sprintf("  Pooled  FE: b=%.3f (SE=%.3f), n=%d, %d mothers\n",
                coef(res_all$fe)[v], se(res_all$fe)[v], res_all$n, res_all$n_moms))
  }

  # By race
  for (rv in c(1, 2)) {
    rl <- ifelse(rv == 1, "White", "Black")
    res_r <- run_models(v, lab, sib_fam[race == rv])
    cat(sprintf("  %s OLS: b=%.3f (SE=%.3f), n=%d\n",
                rl, coef(res_r$ols)[v], se(res_r$ols)[v], res_r$n))
    if (!is.null(res_r$fe)) {
      cat(sprintf("  %s  FE: b=%.3f (SE=%.3f), n=%d, %d mothers\n",
                  rl, coef(res_r$fe)[v], se(res_r$fe)[v], res_r$n, res_r$n_moms))
    }
    results[[paste(lab, rl)]] <- res_r
  }
  results[[paste(lab, "Pooled")]] <- res_all
  cat("\n")
}

# ---- 4. Multiple SES indicators simultaneously ----
cat("--- Multiple SES Indicators (Mother FE) ---\n\n")

# Build formula with all available SES vars
avail <- ses_vars[ses_vars %in% names(sib_fam)]
sub_multi <- sib_fam[complete.cases(sib_fam[, ..avail]) & !is.na(wisc_fsiq)]
cat(sprintf("Complete cases for all SES vars + WISC: %d children, %d mothers\n",
            nrow(sub_multi), uniqueN(sub_multi$mother_id)))

rhs <- paste(c(avail, "factor(sex)", "birth_order"), collapse = " + ")
f_multi_ols <- as.formula(paste("wisc_fsiq ~", rhs))
f_multi_fe  <- as.formula(paste("wisc_fsiq ~", rhs, "| mother_id"))

m_multi_ols <- feols(f_multi_ols, data = sub_multi, vcov = "hetero")
m_multi_fe  <- tryCatch(feols(f_multi_fe, data = sub_multi, vcov = ~mother_id), error = function(e) NULL)

cat("\nOLS (all SES vars):\n")
for (v in avail) {
  cat(sprintf("  %-18s: b=%7.3f (SE=%.3f), t=%.2f\n",
              v, coef(m_multi_ols)[v], se(m_multi_ols)[v],
              coef(m_multi_ols)[v] / se(m_multi_ols)[v]))
}
if (!is.null(m_multi_fe)) {
  cat("\nMother FE (all SES vars):\n")
  for (v in avail) {
    cat(sprintf("  %-18s: b=%7.3f (SE=%.3f), t=%.2f\n",
                v, coef(m_multi_fe)[v], se(m_multi_fe)[v],
                coef(m_multi_fe)[v] / se(m_multi_fe)[v]))
  }
}

# ---- 5. By race, multiple SES ----
cat("\n--- Multiple SES, Mother FE, by Race ---\n\n")
for (rv in c(1, 2)) {
  rl <- ifelse(rv == 1, "White", "Black")
  sub_r <- sub_multi[race == rv]
  m_r <- tryCatch(
    feols(f_multi_fe, data = sub_r, vcov = ~mother_id),
    error = function(e) NULL
  )
  if (!is.null(m_r)) {
    cat(sprintf("%s (n=%d, %d mothers):\n", rl, nrow(sub_r), uniqueN(sub_r$mother_id)))
    for (v in avail) {
      p <- 2 * pnorm(-abs(coef(m_r)[v] / se(m_r)[v]))
      cat(sprintf("  %-18s: b=%7.3f (SE=%.3f), p=%.4f\n",
                  v, coef(m_r)[v], se(m_r)[v], p))
    }
  }
  cat("\n")
}

# ---- 6. Effect size interpretation ----
cat("--- Effect Size Summary ---\n\n")
cat("Interpretation: Mother FE coefficients represent the IQ difference\n")
cat("between siblings born to the same mother when SES changed between births.\n")
cat("A null FE coefficient with a significant OLS coefficient indicates\n")
cat("the OLS association was driven by between-family confounding.\n\n")

# Compute OLS-to-FE attenuation
for (v in avail) {
  sub_v <- sib_fam[!is.na(get(v)) & !is.na(wisc_fsiq)]
  f_ols <- as.formula(paste("wisc_fsiq ~", v, "+ factor(sex) + birth_order"))
  f_fe  <- as.formula(paste("wisc_fsiq ~", v, "+ factor(sex) + birth_order | mother_id"))
  m_ols <- feols(f_ols, data = sub_v, vcov = "hetero")
  m_fe  <- tryCatch(feols(f_fe, data = sub_v, vcov = ~mother_id), error = function(e) NULL)

  if (!is.null(m_fe)) {
    atten <- 1 - coef(m_fe)[v] / coef(m_ols)[v]
    cat(sprintf("  %-18s: OLS=%.3f -> FE=%.3f (%.0f%% attenuation)\n",
                v, coef(m_ols)[v], coef(m_fe)[v], 100 * atten))
  }
}

# ---- 7. Income change direction ----
cat("\n--- Income Change Direction ---\n")
if ("income" %in% names(sib_fam)) {
  inc_fam <- sib_fam[!is.na(income) & !is.na(wisc_fsiq)]
  inc_fam <- inc_fam[order(mother_id, birth_order)]

  # For each child, compute deviation from family mean income
  inc_fam[, fam_mean_inc := mean(income), by = mother_id]
  inc_fam[, inc_dev := income - fam_mean_inc]
  inc_fam[, fam_mean_iq := mean(wisc_fsiq), by = mother_id]
  inc_fam[, iq_dev := wisc_fsiq - fam_mean_iq]

  # Correlation between income deviation and IQ deviation
  r_all <- cor(inc_fam$inc_dev, inc_fam$iq_dev, use = "complete.obs")
  r_w <- cor(inc_fam[race == 1]$inc_dev, inc_fam[race == 1]$iq_dev, use = "complete.obs")
  r_b <- cor(inc_fam[race == 2]$inc_dev, inc_fam[race == 2]$iq_dev, use = "complete.obs")

  cat(sprintf("  Within-family r(income_dev, IQ_dev): All=%.3f, White=%.3f, Black=%.3f\n",
              r_all, r_w, r_b))

  # Quartile analysis: children born during higher vs lower income periods
  inc_fam[, inc_above := inc_dev > 0]
  tab <- inc_fam[, .(mean_iq = mean(wisc_fsiq), mean_iq_dev = mean(iq_dev), n = .N),
                 by = .(race_label, inc_above)]
  cat("\n  Mean IQ by whether born during above-family-mean income:\n")
  print(tab[order(race_label, inc_above)])

  # Large income changes: consecutive sibling pairs (paper value)
  inc_fam[, income_lag := shift(income, 1), by = mother_id]
  inc_fam[, iq_lag := shift(wisc_fsiq, 1), by = mother_id]
  inc_fam[, is_first := seq_len(.N) == 1, by = mother_id]
  consec <- inc_fam[!is_first & !is.na(income_lag)]
  consec[, inc_change := income - income_lag]
  consec[, iq_change := wisc_fsiq - iq_lag]
  big <- consec[abs(inc_change) >= 30]
  cat(sprintf("\n  Consecutive pairs with |income change| >= 30: %d\n", nrow(big)))
  cat(sprintf("  r(income_change, iq_change): %.3f\n", cor(big$inc_change, big$iq_change)))
}

# ---- 8. Save ----
saveRDS(results, "results_ses_within_family.rds")
cat("\nDone.\n")
