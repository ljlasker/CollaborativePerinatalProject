#!/usr/bin/env Rscript
# Diagnose pair reuse and estimate family-block-bootstrap CIs for WISC sibling
# correlations. This does not alter OpenMx point estimates; it supplies an
# independence-aware sensitivity check for pair-level precision.

library(data.table)
set.seed(20260823)

pairs <- as.data.table(readRDS("prepared_iq_links.rds"))
pairs <- pairs[complete.cases(iq_1z, iq_2z) & !is.na(mother_id)]
pairs[, group := fcase(
  pair_type == "MZ_twin", "MZ twin",
  pair_type %chin% c("DZ_twin", "DZ_twin_probable"), "DZ twin",
  pair_type == "half_sibling", "Half sibling",
  pair_type == "full_sibling", "Full sibling",
  default = NA_character_
)]
pairs <- pairs[!is.na(group)]
setorder(pairs, group, mother_id, id_1, id_2)

family_reuse <- pairs[, .(
  pairs = .N,
  unique_children = uniqueN(c(id_1, id_2)),
  groups = uniqueN(group)
), by = mother_id]

one_pair <- pairs[, .SD[1L], by = .(group, mother_id)]

cor_rows <- function(x, label) {
  x[, .(
    specification = label,
    pairs = .N,
    families = uniqueN(mother_id),
    correlation = cor(iq_1z, iq_2z)
  ), by = group]
}

point <- rbindlist(list(
  cor_rows(pairs, "All available pairs"),
  cor_rows(one_pair, "One pair per family")
))

# Resample independent mothers, retaining all pair rows contributed by each
# sampled mother. Sampling multiplicities are represented as frequency weights
# in the correlation calculation.
B <- 1000L
boot <- vector("list", B)
mothers <- unique(pairs$mother_id)
weighted_group_cor <- function(source, weights, label, iteration) {
  z <- merge(source, weights, by = "mother_id", all = FALSE)
  z[, {
    wx <- weighted.mean(iq_1z, weight)
    wy <- weighted.mean(iq_2z, weight)
    covxy <- sum(weight * (iq_1z - wx) * (iq_2z - wy)) / sum(weight)
    vx <- sum(weight * (iq_1z - wx)^2) / sum(weight)
    vy <- sum(weight * (iq_2z - wy)^2) / sum(weight)
    .(correlation = covxy / sqrt(vx * vy))
  }, by = group][, `:=`(specification = label, iteration = iteration)]
}
for (b in seq_len(B)) {
  draw <- sample(mothers, length(mothers), replace = TRUE)
  w <- as.data.table(table(draw))
  setnames(w, c("draw", "N"), c("mother_id", "weight"))
  boot[[b]] <- rbindlist(list(
    weighted_group_cor(pairs, w, "All available pairs", b),
    weighted_group_cor(one_pair, w, "One pair per family", b)
  ))
}
boot <- rbindlist(boot)
ci <- boot[, .(
  cluster_boot_se = sd(correlation),
  ci_low = quantile(correlation, .025),
  ci_high = quantile(correlation, .975)
), by = .(group, specification)]
point <- merge(point, ci, by = c("group", "specification"), all.x = TRUE)

diagnostics <- data.table(
  metric = c(
    "pair_rows", "unique_mothers", "mothers_with_multiple_pairs",
    "pair_rows_from_multi_pair_mothers", "mothers_spanning_multiple_groups",
    "maximum_pairs_from_one_mother"
  ),
  value = c(
    nrow(pairs), uniqueN(pairs$mother_id), sum(family_reuse$pairs > 1),
    sum(family_reuse[pairs > 1]$pairs), sum(family_reuse$groups > 1),
    max(family_reuse$pairs)
  )
)

fwrite(point, "results_pair_reuse_sensitivity.csv")
fwrite(diagnostics, "results_pair_reuse_diagnostics.csv")
saveRDS(list(point = point, bootstrap = boot, diagnostics = diagnostics),
        "results_pair_reuse_sensitivity.rds")
cat("--- Pair-reuse sensitivity ---\n")
print(diagnostics)
print(point[order(group, specification)])
