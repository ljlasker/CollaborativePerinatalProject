#!/usr/bin/env Rscript
# fig_ip_heatmap.R — IP common-factor ACE decomposition heatmap
# Left: stacked h²_com, c²_com, e²_com per subtest
# Right: communality and g-loading

setwd("C:/Users/14787/Documents/Research/Miscellaneous/Substack/Claude Code/breastfeeding_iq/cpp_data/analysis_paper")

bg <- readRDS("results_between_group_expanded.rds")
pw <- readRDS("results_pathway_models.rds")

sub_labels <- c("Information", "Comprehension", "Vocabulary", "Digit Span",
                "Picture Arr.", "Block Design", "Coding",
                "WRAT Reading", "Bender-Gestalt", "WRAT Spelling",
                "WRAT Arithmetic", "Goodenough")

# IP common-factor loadings from between-group results
ac <- bg$ac   # genetic common-factor
cc <- bg$cc   # shared-env common-factor
ec <- bg$ec   # unique-env common-factor

# Common-factor variance per subtest
a2 <- ac^2
c2 <- cc^2
e2 <- ec^2
total_com <- a2 + c2 + e2

# Common-factor ACE proportions
h2_com <- a2 / total_com
c2_com <- c2 / total_com
e2_com <- e2 / total_com

# Specific residuals (from between-group results)
as_vec <- bg$as_vec
cs_vec <- bg$cs_vec

# Total variance approximation (specific E not stored, use remainder)
# Use Cholesky per-test values from the paper as ground truth for communality
# Cholesky total h², c², e² (from Table 7):
chol_h2 <- c(.39, .11, .26, .36, .32, .24, .27, .71, .56, .63, .64, .36)
chol_c2 <- c(.20, .19, .43, .18, .26, .24, .09, .08, .06, .06, .05, .12)
chol_e2 <- c(.41, .71, .31, .46, .42, .52, .64, .21, .38, .31, .31, .52)

# IP communality = fraction of total variance through common factor
# Use IP total = a2 + c2 + e2 + as² + cs² + es²
# (es not stored, but we can approximate communality from the paper's Table 5 values)
# Better: use the paper's communality values directly from the text
communality <- c(.496, .348, .682, .436, .470, .345, .128,
                 .872, .187, .889, .712, .283)

# PCA g-loadings
g_load <- pw$pca_loadings
nv <- length(sub_labels)

# ── Order subtests by communality ────────────────────────────────────
ord <- order(communality, decreasing = TRUE)

# ── Figure ───────────────────────────────────────────────────────────
pdf("fig_ip_heatmap.pdf", width = 9, height = 7)
layout(matrix(c(1, 2), nrow = 1), widths = c(3, 1.2))

# ── Left panel: Stacked bar of h², c², e² (common factor) ───────────
par(mar = c(5, 8.5, 3, 1), family = "serif")

y <- nv:1
bar_h <- 0.6

plot(NULL, xlim = c(0, 1), ylim = c(0.5, nv + 0.5),
     xlab = "", ylab = "",
     yaxt = "n", bty = "n", cex.axis = 0.9, cex.lab = 1)
mtext("Common-factor variance proportion", side = 1, line = 2.5, cex = 0.85)

# Draw stacked bars
for (i in seq_along(ord)) {
  idx <- ord[i]
  yi <- y[i]

  # Genetic (h²)
  rect(0, yi - bar_h/2, h2_com[idx], yi + bar_h/2,
       col = "#8B1A1A", border = "white", lwd = 0.5)
  # Shared env (c²)
  rect(h2_com[idx], yi - bar_h/2, h2_com[idx] + c2_com[idx], yi + bar_h/2,
       col = "#2C3E50", border = "white", lwd = 0.5)
  # Unique env (e²)
  rect(h2_com[idx] + c2_com[idx], yi - bar_h/2, 1, yi + bar_h/2,
       col = "#C0C0C0", border = "white", lwd = 0.5)
}

axis(2, at = y, labels = sub_labels[ord], las = 1, tick = FALSE,
     cex.axis = 0.85, line = -0.5)

# ── Right panel: Communality + g-loading ─────────────────────────────
par(mar = c(5, 0.5, 3, 3))

plot(NULL, xlim = c(0, 1), ylim = c(0.5, nv + 0.5),
     xlab = "", ylab = "", yaxt = "n", xaxt = "n", bty = "n")

# Plot communality as dots
points(communality[ord], y, pch = 16, col = "#8B1A1A", cex = 1.3)
# Plot g-loading as open circles
points(abs(g_load[ord]), y, pch = 1, col = "#2C3E50", cex = 1.3, lwd = 1.5)

# Connect pairs
segments(communality[ord], y, abs(g_load[ord]), y,
         col = "gray70", lty = 3)

axis(1, at = seq(0, 1, 0.25), cex.axis = 0.8)
mtext("Value", side = 1, line = 2.5, cex = 0.85)

# ACE legend (from left panel) placed in top-left of right panel, aligned with top bar
legend(x = -0.15, y = nv + 0.5, yjust = 1, xpd = TRUE,
       legend = c(expression(h[com]^2 ~ "(genetic)"),
                  expression(c[com]^2 ~ "(shared env)"),
                  expression(e[com]^2 ~ "(unique env)")),
       fill = c("#8B1A1A", "#2C3E50", "#C0C0C0"),
       border = "white", bty = "n", cex = 0.95)

legend("bottomright",
       legend = c("Communality", expression("|" * g * "-loading|")),
       col = c("#8B1A1A", "#2C3E50"),
       pch = c(16, 1), pt.cex = 1.3, pt.lwd = c(NA, 1.5),
       bty = "n", cex = 0.8)

dev.off()
cat("Saved fig_ip_heatmap.pdf\n")
