#!/usr/bin/env Rscript
# 05_birthweight.R — Birth weight and IQ (OLS, sibling FE, twin discordance)

library(data.table)
library(fixest)

cat("--- Birth Weight and IQ ---\n")

d <- readRDS("prepared_data.rds")
iq_links <- readRDS("prepared_iq_links.rds")

# ---- 1. Descriptive ----
bw <- d[!is.na(wisc_fsiq) & !is.na(birth_wt_g) & birth_wt_g > 400]
cat(sprintf("Children with WISC FSIQ and birth weight: %d\n", nrow(bw)))
cat(sprintf("Mean BW: %.0f g (SD=%.0f)\n", mean(bw$birth_wt_g), sd(bw$birth_wt_g)))

# BW z-score
if (!"bw_zscore" %in% names(bw) || all(is.na(bw$bw_zscore))) {
  bw[, bw_z := as.numeric(scale(birth_wt_g))]
} else {
  bw[, bw_z := bw_zscore]
}

# IQ by BW quintile
bw[, bw_q := cut(birth_wt_g, quantile(birth_wt_g, probs=0:5/5, na.rm=TRUE),
                 include.lowest=TRUE, labels=paste0("Q", 1:5))]
desc <- bw[, .(mean_iq = mean(wisc_fsiq), mean_bw = mean(birth_wt_g), n = .N), by = bw_q]
desc <- desc[order(bw_q)]
cat("\nIQ by BW quintile:\n")
for (i in 1:nrow(desc)) {
  cat(sprintf("  %s: BW=%.0fg, FSIQ=%.1f (n=%d)\n",
              desc$bw_q[i], desc$mean_bw[i], desc$mean_iq[i], desc$n[i]))
}

# ---- 2. OLS specifications ----
cat("\n--- OLS Regressions (per 100g BW) ---\n\n")

outcomes <- c("wisc_fsiq_z", "wisc_viq_z", "wisc_piq_z", "sb_iq_z", "g_factor_z")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

# Scale BW to per-100g
bw[, bw_100g := birth_wt_g / 100]

cat(sprintf("%-12s  %10s  %10s\n", "Outcome", "Bivar", "Adjusted"))
cat(paste(rep("-", 38), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  m1 <- feols(as.formula(paste(y, "~ bw_100g")), data = bw, vcov = "hetero")
  m2 <- feols(as.formula(paste(y, "~ bw_100g + factor(sex) + factor(race) + gest_age + maternal_age + educ_yrs + sei_decimal + smoker + birth_order")),
              data = bw, vcov = "hetero")
  cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)\n",
              outcome_labels[i],
              coef(m1)["bw_100g"], sprintf("%.4f", se(m1)["bw_100g"]),
              coef(m2)["bw_100g"], sprintf("%.4f", se(m2)["bw_100g"])))
}

# ---- 3. Sibling Fixed Effects ----
cat("\n--- Sibling Fixed Effects (per 100g BW) ---\n\n")

bw[, n_tested := .N, by = mother_id]
bw_fe <- bw[n_tested >= 2]
cat(sprintf("Siblings with BW+IQ: %d children, %d families\n",
            nrow(bw_fe), uniqueN(bw_fe$mother_id)))

cat(sprintf("%-12s  %10s  %10s\n", "Outcome", "OLS_adj", "Mother_FE"))
cat(paste(rep("-", 38), collapse=""), "\n")

bw_results <- list()
for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  ols <- feols(as.formula(paste(y, "~ bw_100g + factor(sex) + gest_age + birth_order")),
               data = bw, vcov = "hetero")
  fe <- feols(as.formula(paste(y, "~ bw_100g + factor(sex) + gest_age + birth_order | mother_id")),
              data = bw_fe, vcov = ~mother_id)

  bw_results[[outcomes[i]]] <- list(ols = ols, fe = fe)
  cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)\n",
              outcome_labels[i],
              coef(ols)["bw_100g"], sprintf("%.4f", se(ols)["bw_100g"]),
              coef(fe)["bw_100g"], sprintf("%.4f", se(fe)["bw_100g"])))
}

# ---- 4. DZ Twin Discordance ----
cat("\n--- DZ Twin Discordance Analysis ---\n\n")

# Get DZ twin pairs with both IQ and BW
r_map <- c(MZ_twin = 1.0, DZ_twin = 0.5, DZ_twin_probable = 0.5,
           full_sibling = 0.5, half_sibling = 0.25)
iq_links[, R := r_map[pair_type]]

# Merge BW data
bw_1 <- d[!is.na(birth_wt_g), .(id_1 = case_id, bw_1 = birth_wt_g, sex_1 = sex)]
bw_2 <- d[!is.na(birth_wt_g), .(id_2 = case_id, bw_2 = birth_wt_g, sex_2 = sex)]
twin_pairs <- iq_links[pair_type %in% c("DZ_twin", "DZ_twin_probable")]
twin_pairs <- merge(twin_pairs, bw_1, by = "id_1")
twin_pairs <- merge(twin_pairs, bw_2, by = "id_2")

cat(sprintf("DZ twin pairs with IQ and BW: %d\n", nrow(twin_pairs)))

# Within-pair differences
twin_pairs[, delta_bw := bw_1 - bw_2]
twin_pairs[, delta_iq := iq_1 - iq_2]
twin_pairs[, delta_viq := viq_1 - viq_2]
twin_pairs[, delta_piq := piq_1 - piq_2]

# Scale delta BW to per-100g
twin_pairs[, delta_bw_100 := delta_bw / 100]

# Regression: delta_IQ ~ delta_BW (no intercept = within-pair)
if (nrow(twin_pairs) >= 20) {
  for (dv in c("delta_iq", "delta_viq", "delta_piq")) {
    dv_label <- gsub("delta_", "", dv)
    fit <- lm(as.formula(paste(dv, "~ delta_bw_100")), data = twin_pairs)
    cat(sprintf("  delta_%s ~ delta_BW/100: b=%.3f (se=%.3f), p=%.4f, n=%d\n",
                toupper(dv_label), coef(fit)["delta_bw_100"],
                summary(fit)$coefficients["delta_bw_100", "Std. Error"],
                summary(fit)$coefficients["delta_bw_100", "Pr(>|t|)"],
                nrow(twin_pairs)))
  }

  cat(sprintf("\n  Mean |delta_BW|: %.0f g\n", mean(abs(twin_pairs$delta_bw))))
  cat(sprintf("  Mean |delta_IQ|: %.1f points\n", mean(abs(twin_pairs$delta_iq))))
  cat(sprintf("  Correlation(delta_BW, delta_IQ): r=%.3f\n",
              cor(twin_pairs$delta_bw, twin_pairs$delta_iq, use="complete.obs")))
}

# ---- 5. MZ Twin Discordance (benchmark) ----
cat("\n--- MZ Twin Discordance (benchmark) ---\n")
mz_pairs <- iq_links[pair_type == "MZ_twin"]
mz_pairs <- merge(mz_pairs, bw_1, by = "id_1")
mz_pairs <- merge(mz_pairs, bw_2, by = "id_2")
cat(sprintf("MZ pairs with IQ and BW: %d\n", nrow(mz_pairs)))

if (nrow(mz_pairs) >= 20) {
  mz_pairs[, delta_bw_100 := (bw_1 - bw_2) / 100]
  mz_pairs[, delta_iq := iq_1 - iq_2]
  fit_mz <- lm(delta_iq ~ delta_bw_100, data = mz_pairs)
  cat(sprintf("  delta_IQ ~ delta_BW/100: b=%.3f (se=%.3f), p=%.4f\n",
              coef(fit_mz)["delta_bw_100"],
              summary(fit_mz)$coefficients["delta_bw_100", "Std. Error"],
              summary(fit_mz)$coefficients["delta_bw_100", "Pr(>|t|)"]))
  cat(sprintf("  Mean |delta_BW|: %.0f g, Mean |delta_IQ|: %.1f\n",
              mean(abs(mz_pairs$bw_1 - mz_pairs$bw_2)),
              mean(abs(mz_pairs$delta_iq))))
}

# ---- 6. Save ----
saveRDS(list(bw_results = bw_results, twin_pairs = twin_pairs),
        "results_birthweight.rds")
cat("Done.\n")
