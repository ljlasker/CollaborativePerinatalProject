#!/usr/bin/env Rscript
# 10_growth_iq.R — Early growth trajectories, catch-up growth, and IQ

library(data.table)
library(fixest)

cat("--- Early Growth and IQ ---\n")

d <- readRDS("prepared_data.rds")
growth <- as.data.table(readRDS("prepared_growth.rds"))

# ---- 1. Reshape growth data from long to wide ----
cat(sprintf("Growth records: %d\n", nrow(growth)))
cat("Measures: "); print(growth[, .N, by = measure][order(-N)])
cat("\nWeight age points:\n"); print(growth[measure == "weight_g", .N, by = age_months][order(age_months)])

# Pivot weight at key ages (already in grams)
wt <- dcast(growth[measure == "weight_g"],
            case_id ~ paste0("wt_", age_months, "mo"),
            value.var = "value", fun.aggregate = mean)
cat(sprintf("\nChildren with weight data: %d\n", nrow(wt)))

# Pivot head circumference
hc <- dcast(growth[measure == "head_circ_cm"],
            case_id ~ paste0("hc_", age_months, "mo"),
            value.var = "value", fun.aggregate = mean)
cat(sprintf("Children with HC data: %d\n", nrow(hc)))

# Merge all
g <- merge(d, wt, by = "case_id", all.x = TRUE)
g <- merge(g, hc, by = "case_id", all.x = TRUE)

# ---- 2. Weight gain velocity: birth to 4 months ----
cat("\n--- Weight Gain Velocity (Birth to 4 months) ---\n\n")

gv <- g[!is.na(wisc_fsiq) & !is.na(wt_4mo) & !is.na(birth_wt_g) & birth_wt_g > 400]
gv[, wt_gain_04 := wt_4mo - birth_wt_g]
gv[, wt_gain_04_z := as.numeric(scale(wt_gain_04))]

cat(sprintf("Children with BW, 4mo weight, and WISC: %d\n", nrow(gv)))
cat(sprintf("Mean weight gain 0-4mo: %.0f g (SD=%.0f)\n",
            mean(gv$wt_gain_04, na.rm=TRUE), sd(gv$wt_gain_04, na.rm=TRUE)))

outcomes <- c("wisc_fsiq_z", "wisc_viq_z", "wisc_piq_z", "sb_iq_z", "g_factor_z")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

cat(sprintf("\n%-12s  %10s  %10s\n", "Outcome", "Bivar", "Adjusted"))
cat(paste(rep("-", 38), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  sub <- gv[!is.na(get(y))]
  if (nrow(sub) < 50) next
  m1 <- feols(as.formula(paste(y, "~ wt_gain_04_z")), data = sub, vcov = "hetero")
  m2 <- feols(as.formula(paste(y, "~ wt_gain_04_z + factor(sex) + factor(race) + birth_wt_g + gest_age + maternal_age + educ_yrs + birth_order")),
              data = sub, vcov = "hetero")
  cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)\n",
              outcome_labels[i],
              coef(m1)["wt_gain_04_z"], sprintf("%.4f", se(m1)["wt_gain_04_z"]),
              coef(m2)["wt_gain_04_z"], sprintf("%.4f", se(m2)["wt_gain_04_z"])))
}

# ---- 3. Sibling FE ----
cat("\n--- Weight Gain -> IQ (Mother FE) ---\n\n")

gv[, n_tested := .N, by = mother_id]
gv_fe <- gv[n_tested >= 2]
cat(sprintf("Siblings: %d children, %d families\n", nrow(gv_fe), uniqueN(gv_fe$mother_id)))

if (nrow(gv_fe) > 100) {
  for (i in 1:3) {
    y <- outcomes[i]
    fe <- feols(as.formula(paste(y, "~ wt_gain_04_z + factor(sex) + birth_order | mother_id")),
                data = gv_fe, vcov = ~mother_id)
    cat(sprintf("  %s: b=%.4f (se=%.4f), n=%d\n",
                outcome_labels[i], coef(fe)["wt_gain_04_z"],
                se(fe)["wt_gain_04_z"], nobs(fe)))
  }
}

# ---- 4. Weight at 12 months and IQ ----
cat("\n--- Weight at 12 Months and IQ ---\n\n")

if ("wt_12mo" %in% names(g)) {
  w12 <- g[!is.na(wisc_fsiq) & !is.na(wt_12mo)]
  w12[, wt_12mo_z := as.numeric(scale(wt_12mo))]
  cat(sprintf("Children with 12mo weight and WISC: %d\n", nrow(w12)))

  if (nrow(w12) > 100) {
    m <- feols(wisc_fsiq_z ~ wt_12mo_z + factor(sex) + factor(race) + birth_wt_g + maternal_age + educ_yrs,
               data = w12, vcov = "hetero")
    cat(sprintf("  FSIQ ~ wt_12mo_z (adj): b=%.4f (se=%.4f)\n",
                coef(m)["wt_12mo_z"], se(m)["wt_12mo_z"]))
  }
}

# ---- 5. Head circumference at birth and IQ ----
cat("\n--- Head Circumference at Birth and IQ ---\n\n")

if ("hc_0mo" %in% names(g)) {
  hc_iq <- g[!is.na(wisc_fsiq) & !is.na(hc_0mo)]
  hc_iq[, hc_z := as.numeric(scale(hc_0mo))]
  cat(sprintf("Children with birth HC and WISC: %d\n", nrow(hc_iq)))

  if (nrow(hc_iq) > 100) {
    m1 <- feols(wisc_fsiq_z ~ hc_z, data = hc_iq, vcov = "hetero")
    m2 <- feols(wisc_fsiq_z ~ hc_z + factor(sex) + factor(race) + birth_wt_g + maternal_age + educ_yrs,
                data = hc_iq, vcov = "hetero")
    cat(sprintf("  Bivariate: b=%.4f (se=%.4f)\n", coef(m1)["hc_z"], se(m1)["hc_z"]))
    cat(sprintf("  Adjusted:  b=%.4f (se=%.4f)\n", coef(m2)["hc_z"], se(m2)["hc_z"]))
  }
} else {
  cat("No birth head circumference data available.\n")
}

# ---- 6. Catch-Up Growth for LBW Children ----
cat("\n--- Catch-Up Growth for LBW Children ---\n")

# Define LBW groups
g[, lbw_group := ifelse(birth_wt_g < 1500, "VLBW (<1500g)",
                 ifelse(birth_wt_g < 2500, "LBW (1500-2499g)", "NBW (>=2500g)"))]
g[, lbw := as.integer(birth_wt_g < 2500)]

# ---- 6a. Do LBW children catch up in weight? ----
cat("--- 6a. Weight Catch-Up Trajectories ---\n\n")

# Weight z-scores within sex at each age
wt_ages <- c("wt_0mo", "wt_4mo", "wt_12mo", "wt_48mo", "wt_84mo")
wt_labels <- c("Birth", "4mo", "12mo", "4yr", "7yr")

cat(sprintf("%-15s  %-10s  %6s  %8s  %8s  %8s\n",
            "Group", "Age", "N", "Mean(g)", "SD(g)", "Gap(SD)"))
cat(paste(rep("-", 65), collapse=""), "\n")

for (i in seq_along(wt_ages)) {
  va <- wt_ages[i]
  if (!va %in% names(g)) next
  sub <- g[!is.na(get(va)) & !is.na(lbw)]
  # Compute z-scores within sex
  sub[, wt_z := as.numeric(scale(get(va))), by = sex]
  for (grp in c("NBW (>=2500g)", "LBW (1500-2499g)", "VLBW (<1500g)")) {
    ss <- sub[lbw_group == grp]
    if (nrow(ss) < 10) next
    gap <- mean(ss$wt_z, na.rm=TRUE)
    cat(sprintf("%-15s  %-10s  %6d  %8.0f  %8.0f  %8.3f\n",
                grp, wt_labels[i], nrow(ss),
                mean(ss[[va]], na.rm=TRUE), sd(ss[[va]], na.rm=TRUE), gap))
  }
  cat("\n")
}

# Combined <2500g z-gaps (used in paper; includes both LBW and VLBW)
cat("--- Combined <2500g weight z-gaps (paper values) ---\n")
for (i in seq_along(wt_ages)) {
  va <- wt_ages[i]
  if (!va %in% names(g)) next
  sub <- g[!is.na(get(va)) & !is.na(lbw)]
  sub[, wt_z := as.numeric(scale(get(va))), by = sex]
  ss <- sub[lbw == 1]
  if (nrow(ss) >= 10) {
    cat(sprintf("  %-10s  N=%5d  mean z = %.2f\n", wt_labels[i], nrow(ss), mean(ss$wt_z, na.rm=TRUE)))
  }
}

# ---- 6b. Do LBW children catch up in head circumference? ----
cat("--- 6b. Head Circumference Catch-Up Trajectories ---\n\n")

hc_ages <- c("hc_0mo", "hc_4mo", "hc_12mo", "hc_48mo", "hc_84mo")
hc_labels <- c("Birth", "4mo", "12mo", "4yr", "7yr")

cat(sprintf("%-15s  %-10s  %6s  %8s  %8s  %8s\n",
            "Group", "Age", "N", "Mean(cm)", "SD(cm)", "Gap(SD)"))
cat(paste(rep("-", 65), collapse=""), "\n")

for (i in seq_along(hc_ages)) {
  va <- hc_ages[i]
  if (!va %in% names(g)) next
  sub <- g[!is.na(get(va)) & !is.na(lbw)]
  sub[, hc_z := as.numeric(scale(get(va))), by = sex]
  for (grp in c("NBW (>=2500g)", "LBW (1500-2499g)", "VLBW (<1500g)")) {
    ss <- sub[lbw_group == grp]
    if (nrow(ss) < 10) next
    gap <- mean(ss$hc_z, na.rm=TRUE)
    cat(sprintf("%-15s  %-10s  %6d  %8.1f  %8.1f  %8.3f\n",
                grp, hc_labels[i], nrow(ss),
                mean(ss[[va]], na.rm=TRUE), sd(ss[[va]], na.rm=TRUE), gap))
  }
  cat("\n")
}

# Combined <2500g HC z-gaps (used in paper)
cat("--- Combined <2500g HC z-gaps (paper values) ---\n")
for (i in seq_along(hc_ages)) {
  va <- hc_ages[i]
  if (!va %in% names(g)) next
  sub <- g[!is.na(get(va)) & !is.na(lbw)]
  sub[, hc_z := as.numeric(scale(get(va))), by = sex]
  ss <- sub[lbw == 1]
  if (nrow(ss) >= 10) {
    cat(sprintf("  %-10s  N=%5d  mean z = %.2f\n", hc_labels[i], nrow(ss), mean(ss$hc_z, na.rm=TRUE)))
  }
}

# ---- 6c. LBW catch-up and IQ outcomes ----
cat("--- 6c. LBW Status and 7-Year IQ ---\n\n")

iq_lbw <- g[!is.na(wisc_fsiq) & !is.na(lbw)]
cat(sprintf("%-15s  %6s  %8s  %8s\n", "Group", "N", "FSIQ M", "FSIQ SD"))
cat(paste(rep("-", 42), collapse=""), "\n")
for (grp in c("NBW (>=2500g)", "LBW (1500-2499g)", "VLBW (<1500g)")) {
  ss <- iq_lbw[lbw_group == grp]
  cat(sprintf("%-15s  %6d  %8.1f  %8.1f\n", grp, nrow(ss),
              mean(ss$wisc_fsiq, na.rm=TRUE), sd(ss$wisc_fsiq, na.rm=TRUE)))
}

# LBW gap adjusted
cat("\nLBW -> IQ (adjusted for gest age, sex, race, SES):\n")
ols_lbw <- feols(wisc_fsiq_z ~ lbw + gest_age + factor(sex) + factor(race) + educ_yrs + sei_decimal + birth_order,
                 data = iq_lbw, vcov = "hetero")
cat(sprintf("  LBW effect: b=%.3f (se=%.3f)\n", coef(ols_lbw)["lbw"], se(ols_lbw)["lbw"]))

# ---- 6c.1. Does the LBW cognitive penalty narrow from age 4 to age 7? ----
cat("\n--- 6c.1. Same-Sample LBW Cognitive Change, Age 4 to Age 7 ---\n\n")

lbw_age_vars <- c(
  "sb_iq", "wisc_fsiq", "lbw", "race", "sex", "educ_yrs",
  "sei_decimal", "maternal_age", "gest_age", "institution", "mother_id",
  "birth_order"
)
lbw_age <- g[birth_wt_g > 400 & complete.cases(g[, ..lbw_age_vars])]
lbw_age[, `:=`(
  sb_z_same = as.numeric(scale(sb_iq)),
  wisc_z_same = as.numeric(scale(wisc_fsiq))
)]
lbw_age[, `:=`(
  delta_z = wisc_z_same - sb_z_same,
  delta_iq_points = wisc_fsiq - sb_iq
)]

lbw_age_adjustment <- paste(
  "factor(race) + factor(sex) + educ_yrs + sei_decimal +",
  "maternal_age + gest_age + factor(institution)"
)
fit_lbw_age_ols <- function(outcome) {
  feols(
    as.formula(paste(outcome, "~ lbw +", lbw_age_adjustment)),
    data = lbw_age,
    vcov = ~mother_id
  )
}

lbw_age[, sibling_n := .N, by = mother_id]
lbw_age_siblings <- lbw_age[sibling_n >= 2]
fit_lbw_age_fe <- function(outcome) {
  feols(
    as.formula(paste(
      outcome,
      "~ lbw + factor(sex) + gest_age + birth_order | mother_id"
    )),
    data = lbw_age_siblings,
    vcov = ~mother_id
  )
}

tidy_lbw_age <- function(model, design, outcome) {
  estimate <- unname(coef(model)["lbw"])
  standard_error <- unname(se(model)["lbw"])
  data.table(
    design = design,
    outcome = outcome,
    estimate = estimate,
    se = standard_error,
    ci_low = estimate - 1.96 * standard_error,
    ci_high = estimate + 1.96 * standard_error,
    p_value = unname(pvalue(model)["lbw"]),
    children = nobs(model)
  )
}

lbw_age_results <- rbindlist(list(
  tidy_lbw_age(fit_lbw_age_ols("sb_z_same"),
               "Adjusted same-sample OLS", "SB age 4, SD"),
  tidy_lbw_age(fit_lbw_age_ols("wisc_z_same"),
               "Adjusted same-sample OLS", "WISC age 7, SD"),
  tidy_lbw_age(fit_lbw_age_ols("sb_iq"),
               "Adjusted same-sample OLS", "SB age 4, IQ points"),
  tidy_lbw_age(fit_lbw_age_ols("wisc_fsiq"),
               "Adjusted same-sample OLS", "WISC age 7, IQ points"),
  tidy_lbw_age(fit_lbw_age_ols("delta_z"),
               "Adjusted same-sample OLS", "WISC minus SB, SD"),
  tidy_lbw_age(fit_lbw_age_ols("delta_iq_points"),
               "Adjusted same-sample OLS", "WISC minus SB, IQ points"),
  tidy_lbw_age(fit_lbw_age_fe("sb_z_same"),
               "Mother fixed effects", "SB age 4, SD"),
  tidy_lbw_age(fit_lbw_age_fe("wisc_z_same"),
               "Mother fixed effects", "WISC age 7, SD"),
  tidy_lbw_age(fit_lbw_age_fe("sb_iq"),
               "Mother fixed effects", "SB age 4, IQ points"),
  tidy_lbw_age(fit_lbw_age_fe("wisc_fsiq"),
               "Mother fixed effects", "WISC age 7, IQ points"),
  tidy_lbw_age(fit_lbw_age_fe("delta_z"),
               "Mother fixed effects", "WISC minus SB, SD"),
  tidy_lbw_age(fit_lbw_age_fe("delta_iq_points"),
               "Mother fixed effects", "WISC minus SB, IQ points")
))

cat(sprintf(
  "Same sample: %d children, %d mothers, %d LBW children\n",
  nrow(lbw_age), uniqueN(lbw_age$mother_id), sum(lbw_age$lbw)
))
cat(sprintf(
  "Sibling sample: %d children, %d mothers; %d mothers vary in LBW status\n",
  nrow(lbw_age_siblings), uniqueN(lbw_age_siblings$mother_id),
  lbw_age_siblings[, uniqueN(lbw), by = mother_id][V1 > 1, .N]
))
print(lbw_age_results)
fwrite(lbw_age_results, "results_lbw_age_change.csv")

# ---- 6d. Does catch-up growth predict IQ recovery for LBW? ----
cat("\n--- 6d. Catch-Up Growth and IQ Recovery (LBW Only) ---\n\n")

lbw_sub <- g[birth_wt_g < 2500 & birth_wt_g > 400 & !is.na(wisc_fsiq)]
cat(sprintf("LBW children with WISC: %d\n", nrow(lbw_sub)))

# Weight catch-up: gain from birth to 12 months
if ("wt_12mo" %in% names(lbw_sub) && sum(!is.na(lbw_sub$wt_12mo)) > 50) {
  cu <- lbw_sub[!is.na(wt_12mo)]
  cu[, wt_gain_012 := wt_12mo - birth_wt_g]
  cu[, wt_gain_z := as.numeric(scale(wt_gain_012))]

  cat(sprintf("LBW with 12mo weight: %d\n", nrow(cu)))
  cat(sprintf("Mean weight gain 0-12mo: %.0f g (SD=%.0f)\n",
              mean(cu$wt_gain_012, na.rm=TRUE), sd(cu$wt_gain_012, na.rm=TRUE)))

  m1 <- feols(wisc_fsiq_z ~ wt_gain_z, data = cu, vcov = "hetero")
  m2 <- feols(wisc_fsiq_z ~ wt_gain_z + birth_wt_g + gest_age + factor(sex) + factor(race) + educ_yrs,
              data = cu, vcov = "hetero")
  cat(sprintf("  Weight catch-up -> FSIQ (bivar): b=%.4f (se=%.4f)\n",
              coef(m1)["wt_gain_z"], se(m1)["wt_gain_z"]))
  cat(sprintf("  Weight catch-up -> FSIQ (adj):   b=%.4f (se=%.4f)\n",
              coef(m2)["wt_gain_z"], se(m2)["wt_gain_z"]))
}

# HC catch-up: gain from birth to 12 months
if ("hc_0mo" %in% names(lbw_sub) && "hc_12mo" %in% names(lbw_sub)) {
  cu_hc <- lbw_sub[!is.na(hc_0mo) & !is.na(hc_12mo)]
  cu_hc[, hc_gain_012 := hc_12mo - hc_0mo]
  cu_hc[, hc_gain_z := as.numeric(scale(hc_gain_012))]

  cat(sprintf("\nLBW with birth + 12mo HC: %d\n", nrow(cu_hc)))
  cat(sprintf("Mean HC gain 0-12mo: %.1f cm (SD=%.1f)\n",
              mean(cu_hc$hc_gain_012, na.rm=TRUE), sd(cu_hc$hc_gain_012, na.rm=TRUE)))

  m1 <- feols(wisc_fsiq_z ~ hc_gain_z, data = cu_hc, vcov = "hetero")
  m2 <- feols(wisc_fsiq_z ~ hc_gain_z + birth_wt_g + gest_age + factor(sex) + factor(race) + educ_yrs,
              data = cu_hc, vcov = "hetero")
  cat(sprintf("  HC catch-up -> FSIQ (bivar): b=%.4f (se=%.4f)\n",
              coef(m1)["hc_gain_z"], se(m1)["hc_gain_z"]))
  cat(sprintf("  HC catch-up -> FSIQ (adj):   b=%.4f (se=%.4f)\n",
              coef(m2)["hc_gain_z"], se(m2)["hc_gain_z"]))
}

# ---- 6e. Does HC gain mediate weight catch-up → IQ? ----
cat("\n--- 6e. HC as Mediator of Weight Catch-Up -> IQ (LBW) ---\n\n")

if ("hc_0mo" %in% names(lbw_sub) && "hc_12mo" %in% names(lbw_sub) && "wt_12mo" %in% names(lbw_sub)) {
  med <- lbw_sub[!is.na(wt_12mo) & !is.na(hc_0mo) & !is.na(hc_12mo)]
  med[, wt_gain_z := as.numeric(scale(wt_12mo - birth_wt_g))]
  med[, hc_gain_z := as.numeric(scale(hc_12mo - hc_0mo))]

  cat(sprintf("LBW with weight + HC + WISC: %d\n", nrow(med)))

  m_no_hc <- feols(wisc_fsiq_z ~ wt_gain_z + birth_wt_g + gest_age + factor(sex) + factor(race) + educ_yrs,
                   data = med, vcov = "hetero")
  m_with_hc <- feols(wisc_fsiq_z ~ wt_gain_z + hc_gain_z + birth_wt_g + gest_age + factor(sex) + factor(race) + educ_yrs,
                     data = med, vcov = "hetero")

  cat(sprintf("  Without HC control: b(wt_gain)=%.4f (se=%.4f)\n",
              coef(m_no_hc)["wt_gain_z"], se(m_no_hc)["wt_gain_z"]))
  cat(sprintf("  With HC control:    b(wt_gain)=%.4f (se=%.4f)\n",
              coef(m_with_hc)["wt_gain_z"], se(m_with_hc)["wt_gain_z"]))
  cat(sprintf("  HC gain effect:     b(hc_gain)=%.4f (se=%.4f)\n",
              coef(m_with_hc)["hc_gain_z"], se(m_with_hc)["hc_gain_z"]))
  if (coef(m_no_hc)["wt_gain_z"] != 0) {
    cat(sprintf("  Attenuation: %.1f%%\n",
                100 * (1 - coef(m_with_hc)["wt_gain_z"] / coef(m_no_hc)["wt_gain_z"])))
  }
}

# ---- 6f. Within-Family Catch-Up Growth (Sibling FE) ----
cat("\n--- Within-Family Catch-Up Growth (Sibling FE) ---\n")

# For the full sample: weight catch-up → IQ within families
cat("--- 6f. Weight Catch-Up -> IQ (Mother FE, Full Sample) ---\n\n")

if ("wt_12mo" %in% names(g)) {
  cu_full <- g[!is.na(wisc_fsiq) & !is.na(wt_12mo) & !is.na(birth_wt_g) & birth_wt_g > 400]
  cu_full[, wt_gain_012 := wt_12mo - birth_wt_g]
  cu_full[, wt_gain_z := as.numeric(scale(wt_gain_012))]
  cu_full[, n_sibs := .N, by = mother_id]
  cu_fe <- cu_full[n_sibs >= 2]
  cat(sprintf("Full sample siblings with 12mo weight: %d children, %d families\n",
              nrow(cu_fe), uniqueN(cu_fe$mother_id)))

  # Catch-up → IQ within families
  fe1 <- feols(wisc_fsiq_z ~ wt_gain_z + factor(sex) + birth_order | mother_id,
               data = cu_fe, vcov = ~mother_id)
  cat(sprintf("  Weight gain 0-12mo -> FSIQ (FE): b=%.4f (se=%.4f)\n",
              coef(fe1)["wt_gain_z"], se(fe1)["wt_gain_z"]))

  # HC mediation within families
  if ("hc_0mo" %in% names(cu_fe) && "hc_12mo" %in% names(cu_fe)) {
    cu_fe2 <- cu_fe[!is.na(hc_0mo) & !is.na(hc_12mo)]
    cu_fe2[, hc_gain_z := as.numeric(scale(hc_12mo - hc_0mo))]
    cat(sprintf("  With HC data: %d children, %d families\n",
                nrow(cu_fe2), uniqueN(cu_fe2$mother_id)))

    fe_no_hc <- feols(wisc_fsiq_z ~ wt_gain_z + factor(sex) + birth_order | mother_id,
                      data = cu_fe2, vcov = ~mother_id)
    fe_with_hc <- feols(wisc_fsiq_z ~ wt_gain_z + hc_gain_z + factor(sex) + birth_order | mother_id,
                        data = cu_fe2, vcov = ~mother_id)

    cat(sprintf("  [Mother FE] Without HC: b(wt_gain)=%.4f (se=%.4f)\n",
                coef(fe_no_hc)["wt_gain_z"], se(fe_no_hc)["wt_gain_z"]))
    cat(sprintf("  [Mother FE] With HC:    b(wt_gain)=%.4f (se=%.4f)\n",
                coef(fe_with_hc)["wt_gain_z"], se(fe_with_hc)["wt_gain_z"]))
    cat(sprintf("  [Mother FE] HC gain:    b(hc_gain)=%.4f (se=%.4f)\n",
                coef(fe_with_hc)["hc_gain_z"], se(fe_with_hc)["hc_gain_z"]))
    if (coef(fe_no_hc)["wt_gain_z"] != 0) {
      cat(sprintf("  [Mother FE] Attenuation: %.1f%%\n",
                  100 * (1 - coef(fe_with_hc)["wt_gain_z"] / coef(fe_no_hc)["wt_gain_z"])))
    }
  }
}

# For LBW specifically: catch-up within families
cat("\n--- 6g. Catch-Up -> IQ (Mother FE, LBW Only) ---\n\n")

if ("wt_12mo" %in% names(g)) {
  lbw_fe <- g[birth_wt_g < 2500 & birth_wt_g > 400 & !is.na(wisc_fsiq) & !is.na(wt_12mo)]
  lbw_fe[, wt_gain_z := as.numeric(scale(wt_12mo - birth_wt_g))]
  lbw_fe[, n_sibs := .N, by = mother_id]
  lbw_fe_sib <- lbw_fe[n_sibs >= 2]
  cat(sprintf("LBW siblings with 12mo weight: %d children, %d families\n",
              nrow(lbw_fe_sib), uniqueN(lbw_fe_sib$mother_id)))

  if (nrow(lbw_fe_sib) > 50) {
    fe_lbw <- feols(wisc_fsiq_z ~ wt_gain_z + factor(sex) + birth_order | mother_id,
                    data = lbw_fe_sib, vcov = ~mother_id)
    cat(sprintf("  Weight catch-up -> FSIQ (FE, LBW): b=%.4f (se=%.4f), n=%d\n",
                coef(fe_lbw)["wt_gain_z"], se(fe_lbw)["wt_gain_z"], nobs(fe_lbw)))

    # HC mediation within families (LBW)
    if ("hc_0mo" %in% names(lbw_fe_sib) && "hc_12mo" %in% names(lbw_fe_sib)) {
      lbw_fe_hc <- lbw_fe_sib[!is.na(hc_0mo) & !is.na(hc_12mo)]
      lbw_fe_hc[, hc_gain_z := as.numeric(scale(hc_12mo - hc_0mo))]
      cat(sprintf("  LBW siblings with HC: %d children, %d families\n",
                  nrow(lbw_fe_hc), uniqueN(lbw_fe_hc$mother_id)))

      if (nrow(lbw_fe_hc) > 50) {
        fe_no <- feols(wisc_fsiq_z ~ wt_gain_z + factor(sex) + birth_order | mother_id,
                       data = lbw_fe_hc, vcov = ~mother_id)
        fe_yes <- feols(wisc_fsiq_z ~ wt_gain_z + hc_gain_z + factor(sex) + birth_order | mother_id,
                        data = lbw_fe_hc, vcov = ~mother_id)
        cat(sprintf("  [FE, LBW] Without HC: b(wt)=%.4f (se=%.4f)\n",
                    coef(fe_no)["wt_gain_z"], se(fe_no)["wt_gain_z"]))
        cat(sprintf("  [FE, LBW] With HC:    b(wt)=%.4f (se=%.4f)\n",
                    coef(fe_yes)["wt_gain_z"], se(fe_yes)["wt_gain_z"]))
        cat(sprintf("  [FE, LBW] HC gain:    b(hc)=%.4f (se=%.4f)\n",
                    coef(fe_yes)["hc_gain_z"], se(fe_yes)["hc_gain_z"]))
        if (coef(fe_no)["wt_gain_z"] != 0) {
          cat(sprintf("  [FE, LBW] Attenuation: %.1f%%\n",
                      100 * (1 - coef(fe_yes)["wt_gain_z"] / coef(fe_no)["wt_gain_z"])))
        }
      }
    }
  } else {
    cat("  Insufficient LBW sibling pairs for FE analysis\n")
  }
}

# ---- 7. G-Specificity: Are Birth Deficits on g? ----
cat("\n--- G-Specificity Analysis ---\n")

# ---- 7a. LBW effects on individual subtests and g ----
cat("--- 7a. LBW Effects by Subtest ---\n\n")

subtests <- c("wisc_info_z", "wisc_comp_z", "wisc_vocab_z", "wisc_digit_z", "wisc_piq_z", "g_factor_z")
subtest_labels <- c("Information", "Comprehension", "Vocabulary", "Digit Span", "PIQ", "Latent g")

iq_lbw2 <- g[!is.na(lbw) & birth_wt_g > 400]

cat(sprintf("%-16s  %8s  %8s  %6s\n", "Subtest", "b(LBW)", "SE", "N"))
cat(paste(rep("-", 46), collapse=""), "\n")

lbw_betas <- numeric(length(subtests))
for (i in seq_along(subtests)) {
  y <- subtests[i]
  sub <- iq_lbw2[!is.na(get(y))]
  if (nrow(sub) < 100) next
  m <- feols(as.formula(paste(y, "~ lbw + gest_age + factor(sex) + factor(race) + educ_yrs + sei_decimal")),
             data = sub, vcov = "hetero")
  lbw_betas[i] <- coef(m)["lbw"]
  cat(sprintf("%-16s  %8.4f  %8.4f  %6d\n",
              subtest_labels[i], coef(m)["lbw"], se(m)["lbw"], nobs(m)))
}

# ---- 7b. Correlation of LBW effects with g-loadings ----
cat("\n--- 7b. Are LBW Effects Correlated with g-Loadings? ---\n\n")

# g-loadings from main 12-test PCA (cor with g_factor), restricted to subtests used here
subtests_for_g <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit")
g_complete <- g[!is.na(g_factor)]
if (nrow(g_complete) > 500) {
  g_loadings <- sapply(subtests_for_g, function(sv) {
    cor(g_complete[[sv]], g_complete[["g_factor"]], use = "pairwise.complete.obs")
  })

  # Match to LBW betas (first 4 subtests)
  cat("Subtest g-loadings (r with g factor) vs LBW effects:\n")
  cat(sprintf("%-16s  %8s  %8s\n", "Subtest", "g-load", "LBW b"))
  cat(paste(rep("-", 36), collapse=""), "\n")
  for (i in 1:4) {
    cat(sprintf("%-16s  %8.3f  %8.4f\n",
                subtest_labels[i], g_loadings[i], lbw_betas[i]))
  }
  r_gl <- cor(g_loadings, lbw_betas[1:4])
  cat(sprintf("\nCorrelation (g-loading, LBW effect): r = %.3f\n", r_gl))
  cat("(Negative r means larger deficits on more g-loaded subtests = g-specific)\n")
}

# ---- 7c. Is catch-up growth on g specifically? ----
cat("\n--- 7c. Catch-Up Growth Effects by Subtest (LBW Only) ---\n\n")

if ("wt_12mo" %in% names(g)) {
  cu_all <- g[birth_wt_g < 2500 & birth_wt_g > 400 & !is.na(wt_12mo)]
  cu_all[, wt_gain_z := as.numeric(scale(wt_12mo - birth_wt_g))]

  cat(sprintf("%-16s  %8s  %8s  %6s\n", "Subtest", "b(catch-up)", "SE", "N"))
  cat(paste(rep("-", 46), collapse=""), "\n")

  cu_betas <- numeric(length(subtests))
  for (i in seq_along(subtests)) {
    y <- subtests[i]
    sub <- cu_all[!is.na(get(y))]
    if (nrow(sub) < 50) next
    m <- feols(as.formula(paste(y, "~ wt_gain_z + birth_wt_g + gest_age + factor(sex) + factor(race) + educ_yrs")),
               data = sub, vcov = "hetero")
    cu_betas[i] <- coef(m)["wt_gain_z"]
    cat(sprintf("%-16s  %8.4f  %8.4f  %6d\n",
                subtest_labels[i], coef(m)["wt_gain_z"], se(m)["wt_gain_z"], nobs(m)))
  }

  # Correlation with g-loadings
  if (exists("g_loadings")) {
    r_cu <- cor(g_loadings, cu_betas[1:4])
    cat(sprintf("\nCorrelation (g-loading, catch-up effect): r = %.3f\n", r_cu))
    cat("(Positive r means catch-up benefits are larger on more g-loaded subtests)\n")
  }
}

# ---- 7d. HC catch-up effects by subtest (LBW only) ----
cat("\n--- 7d. HC Catch-Up Effects by Subtest (LBW Only) ---\n\n")

if ("hc_0mo" %in% names(g) && "hc_12mo" %in% names(g)) {
  cu_hc_all <- g[birth_wt_g < 2500 & birth_wt_g > 400 & !is.na(hc_0mo) & !is.na(hc_12mo)]
  cu_hc_all[, hc_gain_z := as.numeric(scale(hc_12mo - hc_0mo))]

  cat(sprintf("%-16s  %8s  %8s  %6s\n", "Subtest", "b(HC gain)", "SE", "N"))
  cat(paste(rep("-", 46), collapse=""), "\n")

  hc_betas <- numeric(length(subtests))
  for (i in seq_along(subtests)) {
    y <- subtests[i]
    sub <- cu_hc_all[!is.na(get(y))]
    if (nrow(sub) < 50) next
    m <- feols(as.formula(paste(y, "~ hc_gain_z + birth_wt_g + gest_age + factor(sex) + factor(race) + educ_yrs")),
               data = sub, vcov = "hetero")
    hc_betas[i] <- coef(m)["hc_gain_z"]
    cat(sprintf("%-16s  %8.4f  %8.4f  %6d\n",
                subtest_labels[i], coef(m)["hc_gain_z"], se(m)["hc_gain_z"], nobs(m)))
  }

  if (exists("g_loadings")) {
    r_hc <- cor(g_loadings, hc_betas[1:4])
    cat(sprintf("\nCorrelation (g-loading, HC catch-up effect): r = %.3f\n", r_hc))
  }
}

# ---- 8. HC at 7yr as Mediator of BW -> IQ ----
cat("\n--- 8. Head Circumference at 7yr as Mediator of BW -> IQ ---\n\n")

if ("hc_84mo" %in% names(g)) {
  med_all <- g[!is.na(wisc_fsiq) & !is.na(hc_84mo) & !is.na(birth_wt_g) & birth_wt_g > 400]
  med_all[, bw_z := as.numeric(scale(birth_wt_g))]
  med_all[, hc7_z := as.numeric(scale(hc_84mo))]

  cat(sprintf("Children with BW, 7yr HC, and WISC: %d\n", nrow(med_all)))

  m1 <- feols(wisc_fsiq_z ~ bw_z + gest_age + factor(sex) + factor(race) + educ_yrs,
              data = med_all, vcov = "hetero")
  m2 <- feols(wisc_fsiq_z ~ bw_z + hc7_z + gest_age + factor(sex) + factor(race) + educ_yrs,
              data = med_all, vcov = "hetero")

  cat(sprintf("  BW -> FSIQ (no HC):   b=%.4f (se=%.4f)\n",
              coef(m1)["bw_z"], se(m1)["bw_z"]))
  cat(sprintf("  BW -> FSIQ (with HC): b=%.4f (se=%.4f)\n",
              coef(m2)["bw_z"], se(m2)["bw_z"]))
  cat(sprintf("  7yr HC effect:        b=%.4f (se=%.4f)\n",
              coef(m2)["hc7_z"], se(m2)["hc7_z"]))
  cat(sprintf("  Attenuation of BW: %.1f%%\n",
              100 * (1 - coef(m2)["bw_z"] / coef(m1)["bw_z"])))

  # Sibling FE version
  med_all[, n_sibs := .N, by = mother_id]
  med_fe <- med_all[n_sibs >= 2]
  if (nrow(med_fe) > 200) {
    fe1 <- feols(wisc_fsiq_z ~ bw_z + factor(sex) + birth_order | mother_id,
                 data = med_fe, vcov = ~mother_id)
    fe2 <- feols(wisc_fsiq_z ~ bw_z + hc7_z + factor(sex) + birth_order | mother_id,
                 data = med_fe, vcov = ~mother_id)
    cat(sprintf("\n  [Mother FE] BW -> FSIQ (no HC):   b=%.4f (se=%.4f)\n",
                coef(fe1)["bw_z"], se(fe1)["bw_z"]))
    cat(sprintf("  [Mother FE] BW -> FSIQ (with HC): b=%.4f (se=%.4f)\n",
                coef(fe2)["bw_z"], se(fe2)["bw_z"]))
    cat(sprintf("  [Mother FE] 7yr HC effect:        b=%.4f (se=%.4f)\n",
                coef(fe2)["hc7_z"], se(fe2)["hc7_z"]))
    cat(sprintf("  [Mother FE] Attenuation of BW: %.1f%%\n",
                100 * (1 - coef(fe2)["bw_z"] / coef(fe1)["bw_z"])))
  }
}

# ---- 9. Save ----
saveRDS(
  list(nrow_growth = nrow(gv), lbw_age_change = lbw_age_results),
  "results_growth_iq.rds"
)
cat("Done.\n")
