#!/usr/bin/env Rscript
# 02c_congruence_benchmarks.R
# CP-IP congruence metrics, PCA/CFA g comparison, WISC-only benchmark, bootstrap CIs
# Requires: results_pathway_models.rds, prepared_data.rds, cpp_kinship_links.csv

library(data.table)
library(OpenMx)
library(lavaan)
library(MASS)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

cat("\n--- CP-IP CONGRUENCE BENCHMARKS ---\n")

tucker <- function(x, y) sum(x * y) / (sqrt(sum(x^2)) * sqrt(sum(y^2)))

# ── Load data ───────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")
pw <- readRDS("results_pathway_models.rds")
links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "Digit", "PicArr", "Block",
                "Coding", "WRAT Read", "Bender", "WRAT Spell",
                "WRAT Arith", "Goodenough")
nv <- 12

for (v in c("wisc_picarr", "wisc_block", "wisc_coding"))
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]

# ── Extract model parameters ────────────────────────────────────────────
ip_p <- pw$ip_fit_sum$parameters
ip_ac <- ip_p$Estimate[1:12];  ip_cc <- ip_p$Estimate[13:24]
ip_ec <- ip_p$Estimate[25:36]; ip_as <- ip_p$Estimate[37:48]
ip_cs <- ip_p$Estimate[49:60]; ip_es <- ip_p$Estimate[61:72]

cp_p <- pw$cp_fit_sum$parameters
cp_lambda <- cp_p$Estimate[1:12]; cp_af <- cp_p$Estimate[13]; cp_cf <- cp_p$Estimate[14]
cp_ef <- sqrt(1 - cp_af^2 - cp_cf^2)
cp_as <- cp_p$Estimate[15:26]; cp_cs <- cp_p$Estimate[27:38]; cp_es <- cp_p$Estimate[39:50]

cp_eff_a <- cp_lambda * cp_af; cp_eff_c <- cp_lambda * cp_cf; cp_eff_e <- cp_lambda * cp_ef
L_ip <- cbind(ip_ac, ip_cc, ip_ec); L_cp <- cbind(cp_eff_a, cp_eff_c, cp_eff_e)

# ======================================================================
#  SECTION 1: Structural congruence metrics
# ======================================================================
cat("\n=== SECTION 1: CP-IP Structural Congruence ===\n")

# SVD of IP loading matrix
sv <- svd(L_ip)$d
svd_rank1 <- sv[1]^2 / sum(sv^2)

# Per-component Tucker
tuck_a <- tucker(cp_eff_a, ip_ac)
tuck_c <- tucker(cp_eff_c, ip_cc)
tuck_e <- tucker(cp_eff_e, ip_ec)
tuck_ac <- tucker(ip_ac, ip_cc)

# Combined vectorized Tucker
tuck_vec <- tucker(as.vector(L_cp), as.vector(L_ip))

# Variance-weighted Tucker
va <- sum(cp_eff_a^2) + sum(ip_ac^2)
vc <- sum(cp_eff_c^2) + sum(ip_cc^2)
ve <- sum(cp_eff_e^2) + sum(ip_ec^2)
tot <- va + vc + ve
tuck_wt <- (va/tot)*tuck_a + (vc/tot)*tuck_c + (ve/tot)*tuck_e

# RV coefficient
XtY <- crossprod(L_cp, L_ip); XtX <- crossprod(L_cp); YtY <- crossprod(L_ip)
rv <- sum(XtY^2) / sqrt(sum(XtX^2) * sum(YtY^2))

# Implied covariance Tucker
cp_cov <- outer(cp_eff_a, cp_eff_a) + outer(cp_eff_c, cp_eff_c) + outer(cp_eff_e, cp_eff_e)
ip_cov <- outer(ip_ac, ip_ac) + outer(ip_cc, ip_cc) + outer(ip_ec, ip_ec)
idx_lt <- which(lower.tri(diag(nv), diag = TRUE))
tuck_cov <- tucker(cp_cov[idx_lt], ip_cov[idx_lt])

cat(sprintf("  SVD rank-1 share:           %.4f\n", svd_rank1))
cat(sprintf("  Tucker(a_c, c_c):           %.4f\n", tuck_ac))
cat(sprintf("  Combined vectorized Tucker: %.4f\n", tuck_vec))
cat(sprintf("  Variance-weighted Tucker:   %.4f\n", tuck_wt))
cat(sprintf("  RV coefficient:             %.4f\n", rv))
cat(sprintf("  Implied covariance Tucker:  %.4f\n", tuck_cov))

# IP-CP communality and std loading comparison
ip_com <- ip_ac^2 + ip_cc^2 + ip_ec^2
ip_tot <- ip_com + ip_as^2 + ip_cs^2 + ip_es^2
ip_communality <- ip_com / ip_tot
ip_std <- sqrt(ip_communality)

cp_com <- cp_lambda^2
cp_tot <- cp_com + cp_as^2 + cp_cs^2 + cp_es^2
cp_communality <- cp_com / cp_tot
cp_std <- sqrt(cp_communality)

ip_cp_comm  <- tucker(ip_communality, cp_communality)
ip_cp_std   <- tucker(ip_std, cp_std)
r_ip_cp_comm <- cor(ip_communality, cp_communality)
r_ip_cp_std  <- cor(ip_std, cp_std)

cat(sprintf("\n  IP-CP communality Tucker:   %.4f (r = %.4f)\n", ip_cp_comm, r_ip_cp_comm))
cat(sprintf("  IP-CP std loading Tucker:   %.4f (r = %.4f)\n", ip_cp_std, r_ip_cp_std))

# ======================================================================
#  SECTION 2: PCA vs CFA g comparison
# ======================================================================
cat("\n=== SECTION 2: PCA vs CFA g Comparison ===\n")

# PCA g
pca_data <- d[, ..sub_vars]
pca_fit <- prcomp(pca_data[complete.cases(pca_data)], center = TRUE, scale. = TRUE)
pca_g <- pca_fit$rotation[, 1] * sqrt(pca_fit$sdev[1]^2)
if (mean(pca_g) < 0) pca_g <- -pca_g

# CFA g (single-factor model)
cfa_model <- paste0("g =~ ", paste(sub_vars, collapse = " + "))
cfa_fit <- cfa(cfa_model, data = as.data.frame(d[, ..sub_vars]),
               std.lv = TRUE, missing = "fiml")
cfa_std <- standardizedSolution(cfa_fit)
cfa_g_std <- cfa_std$est.std[cfa_std$op == "=~"]
names(cfa_g_std) <- sub_vars

cat(sprintf("  PCA g vs CFA g:             Tucker = %.4f, r = %.4f\n",
            tucker(pca_g, cfa_g_std), cor(pca_g, cfa_g_std)))

# IP vs both
cat(sprintf("\n  IP std loading vs PCA g:    Tucker = %.4f, r = %.4f\n",
            tucker(ip_std, pca_g), cor(ip_std, pca_g)))
cat(sprintf("  IP std loading vs CFA g:    Tucker = %.4f, r = %.4f\n",
            tucker(ip_std, cfa_g_std), cor(ip_std, cfa_g_std)))

# CP vs both
cat(sprintf("  CP std loading vs PCA g:    Tucker = %.4f, r = %.4f\n",
            tucker(cp_std, pca_g), cor(cp_std, pca_g)))
cat(sprintf("  CP std loading vs CFA g:    Tucker = %.4f, r = %.4f\n",
            tucker(cp_std, cfa_g_std), cor(cp_std, cfa_g_std)))

# Communality comparisons
cat(sprintf("\n  IP communality vs PCA g^2:  Tucker = %.4f, r = %.4f\n",
            tucker(ip_communality, pca_g^2), cor(ip_communality, pca_g^2)))
cat(sprintf("  IP communality vs CFA g^2:  Tucker = %.4f, r = %.4f\n",
            tucker(ip_communality, cfa_g_std^2), cor(ip_communality, cfa_g_std^2)))
cat(sprintf("  CP communality vs PCA g^2:  Tucker = %.4f, r = %.4f\n",
            tucker(cp_communality, pca_g^2), cor(cp_communality, pca_g^2)))
cat(sprintf("  CP communality vs CFA g^2:  Tucker = %.4f, r = %.4f\n",
            tucker(cp_communality, cfa_g_std^2), cor(cp_communality, cfa_g_std^2)))

# CFA fit indices
cat(sprintf("\n  CFA single-factor: chi2 = %.1f, df = %d, CFI = %.3f, RMSEA = %.3f\n",
            fitMeasures(cfa_fit, "chisq"), fitMeasures(cfa_fit, "df"),
            fitMeasures(cfa_fit, "cfi"), fitMeasures(cfa_fit, "rmsea")))

# ======================================================================
#  SECTION 3: WISC-only CP vs IP (7 subtests)
# ======================================================================
cat("\n=== SECTION 3: WISC-Only CP vs IP (7 subtests) ===\n")

wisc_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
               "wisc_picarr", "wisc_block", "wisc_coding")
nv_w <- 7
start_means_w <- c(9.2, 8.7, 8.7, 9.6, 9.1, 9.4, 10.0)

d_sub <- d[, c("case_id", wisc_vars), with = FALSE]
pair_w <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
wn1 <- paste0(wisc_vars, "_1"); setnames(pair_w, wisc_vars, wn1)
pair_w <- merge(pair_w, d_sub, by.x = "id_2", by.y = "case_id")
wn2 <- paste0(wisc_vars, "_2"); setnames(pair_w, wisc_vars, wn2)
pair_w[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_)]
pair_w <- pair_w[!is.na(pair_class)]
pair_w <- pair_w[rowSums(!is.na(pair_w[, ..wn1])) > 0 &
                 rowSums(!is.na(pair_w[, ..wn2])) > 0]

wvn <- c(wn1, wn2)
w_mz <- as.data.frame(pair_w[pair_class == "MZ", ..wvn])
w_dz <- as.data.frame(pair_w[pair_class == "DZ", ..wvn])
w_fs <- as.data.frame(pair_w[pair_class == "FS", ..wvn])
w_hs <- as.data.frame(pair_w[pair_class == "HS", ..wvn])

cat(sprintf("  Pairs: MZ=%d, DZ=%d, FS=%d, HS=%d\n",
            nrow(w_mz), nrow(w_dz), nrow(w_fs), nrow(w_hs)))

# IP model (WISC 7)
w_ip <- mxModel("IP",
  mxMatrix("Full", nv_w, 1, free = TRUE, values = rep(1.2, nv_w), lbound = -5, name = "ac"),
  mxMatrix("Full", nv_w, 1, free = TRUE, values = rep(0.8, nv_w), lbound = -5, name = "cc"),
  mxMatrix("Full", nv_w, 1, free = TRUE, values = rep(1.0, nv_w), lbound = -5, name = "ec"),
  mxMatrix("Diag", nv_w, nv_w, free = TRUE, values = rep(1.2, nv_w), lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv_w, nv_w, free = TRUE, values = rep(0.5, nv_w), lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv_w, nv_w, free = TRUE, values = rep(1.2, nv_w), lbound = 0.001, name = "es"),
  mxMatrix("Full", 1, nv_w, free = TRUE, values = start_means_w, name = "Mu"),
  mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
  mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
  mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),
  mxModel("MZ", mxData(w_mz, "raw"), mxAlgebra(IP.A + IP.C, name = "B"),
    mxAlgebra(rbind(cbind(IP.V, B), cbind(B, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = wvn), mxFitFunctionML()),
  mxModel("DZ", mxData(w_dz, "raw"), mxAlgebra(0.5*IP.A + IP.C, name = "B"),
    mxAlgebra(rbind(cbind(IP.V, B), cbind(B, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = wvn), mxFitFunctionML()),
  mxModel("FS", mxData(w_fs, "raw"), mxAlgebra(0.5*IP.A + IP.C, name = "B"),
    mxAlgebra(rbind(cbind(IP.V, B), cbind(B, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = wvn), mxFitFunctionML()),
  mxModel("HS", mxData(w_hs, "raw"), mxAlgebra(0.25*IP.A + IP.C, name = "B"),
    mxAlgebra(rbind(cbind(IP.V, B), cbind(B, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = wvn), mxFitFunctionML()),
  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS")))

cat("  Fitting WISC-only IP...\n")
w_ip_fit <- mxTryHard(w_ip, extraTries = 50, silent = TRUE)
w_ip_sum <- summary(w_ip_fit)

# CP model (WISC 7)
w_cp <- mxModel("CP",
  mxMatrix("Full", nv_w, 1, free = TRUE, values = rep(1.8, nv_w), lbound = 0.01, name = "lambda"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.65, lbound = 0.01, ubound = 0.99, name = "af"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.45, lbound = 0.01, ubound = 0.99, name = "cf"),
  mxAlgebra(sqrt(1 - af*af - cf*cf), name = "ef"),
  mxConstraint(af*af + cf*cf < 0.999, name = "con"),
  mxMatrix("Diag", nv_w, nv_w, free = TRUE, values = rep(1.5, nv_w), lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv_w, nv_w, free = TRUE, values = rep(0.5, nv_w), lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv_w, nv_w, free = TRUE, values = rep(1.5, nv_w), lbound = 0.001, name = "es"),
  mxMatrix("Full", 1, nv_w, free = TRUE, values = start_means_w, name = "Mu"),
  mxAlgebra(lambda %*% (af*af) %*% t(lambda) + as %*% t(as), name = "A"),
  mxAlgebra(lambda %*% (cf*cf) %*% t(lambda) + cs %*% t(cs), name = "C"),
  mxAlgebra(lambda %*% (ef*ef) %*% t(lambda) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),
  mxModel("MZ", mxData(w_mz, "raw"), mxAlgebra(CP.A + CP.C, name = "B"),
    mxAlgebra(rbind(cbind(CP.V, B), cbind(B, CP.V)), name = "expCov"),
    mxAlgebra(cbind(CP.Mu, CP.Mu), name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = wvn), mxFitFunctionML()),
  mxModel("DZ", mxData(w_dz, "raw"), mxAlgebra(0.5*CP.A + CP.C, name = "B"),
    mxAlgebra(rbind(cbind(CP.V, B), cbind(B, CP.V)), name = "expCov"),
    mxAlgebra(cbind(CP.Mu, CP.Mu), name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = wvn), mxFitFunctionML()),
  mxModel("FS", mxData(w_fs, "raw"), mxAlgebra(0.5*CP.A + CP.C, name = "B"),
    mxAlgebra(rbind(cbind(CP.V, B), cbind(B, CP.V)), name = "expCov"),
    mxAlgebra(cbind(CP.Mu, CP.Mu), name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = wvn), mxFitFunctionML()),
  mxModel("HS", mxData(w_hs, "raw"), mxAlgebra(0.25*CP.A + CP.C, name = "B"),
    mxAlgebra(rbind(cbind(CP.V, B), cbind(B, CP.V)), name = "expCov"),
    mxAlgebra(cbind(CP.Mu, CP.Mu), name = "expMean"),
    mxExpectationNormal("expCov", "expMean", dimnames = wvn), mxFitFunctionML()),
  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS")))

cat("  Fitting WISC-only CP...\n")
w_cp_fit <- mxTryHard(w_cp, extraTries = 50, silent = TRUE)
w_cp_sum <- summary(w_cp_fit)

# WISC-only comparison
k_ip_w <- length(w_ip_sum$parameters$Estimate)
k_cp_w <- length(w_cp_sum$parameters$Estimate)
chi2_w <- w_cp_sum$Minus2LogLikelihood - w_ip_sum$Minus2LogLikelihood
df_w <- k_ip_w - k_cp_w
p_w <- pchisq(chi2_w, df = max(df_w, 1), lower.tail = FALSE)

# WISC-only congruence metrics
w_ip_p <- w_ip_sum$parameters
w_ac <- w_ip_p$Estimate[1:7]; w_cc <- w_ip_p$Estimate[8:14]; w_ec <- w_ip_p$Estimate[15:21]
w_cp_p <- w_cp_sum$parameters
w_lam <- w_cp_p$Estimate[1:7]; w_af <- w_cp_p$Estimate[8]; w_cf <- w_cp_p$Estimate[9]
w_ef <- sqrt(1 - w_af^2 - w_cf^2)
wL_ip <- cbind(w_ac, w_cc, w_ec)
wL_cp <- cbind(w_lam*w_af, w_lam*w_cf, w_lam*w_ef)
w_sv <- svd(wL_ip)$d

cat(sprintf("\n  IP: -2LL = %.2f, k = %d\n", w_ip_sum$Minus2LogLikelihood, k_ip_w))
cat(sprintf("  CP: -2LL = %.2f, k = %d\n", w_cp_sum$Minus2LogLikelihood, k_cp_w))
cat(sprintf("  Delta chi2 = %.1f, df = %d, p = %.2e, chi2/df = %.1f\n",
            chi2_w, df_w, p_w, chi2_w / max(df_w, 1)))
cat(sprintf("  SVD rank-1: %.1f%%, Tucker(a_c,c_c): %.3f\n",
            100 * w_sv[1]^2 / sum(w_sv^2), tucker(w_ac, w_cc)))
cat(sprintf("  Vectorized Tucker: %.3f\n",
            tucker(as.vector(wL_cp), as.vector(wL_ip))))
cat(sprintf("  CP factor ACE: a2=%.3f, c2=%.3f, e2=%.3f\n", w_af^2, w_cf^2, w_ef^2))

# ======================================================================
#  SECTION 4: Bootstrap CIs for observed metrics
# ======================================================================
cat("\n=== SECTION 4: Bootstrap CIs (25 iterations) ===\n")

compute_boot_metrics <- function(ip_est, cp_est, g_load) {
  b_ac <- ip_est[1:12]; b_cc <- ip_est[13:24]; b_ec <- ip_est[25:36]
  b_as <- ip_est[37:48]; b_cs <- ip_est[49:60]; b_es <- ip_est[61:72]
  b_lam <- cp_est[1:12]; b_af <- cp_est[13]; b_cf <- cp_est[14]
  b_ef <- sqrt(max(0, 1 - b_af^2 - b_cf^2))
  b_eff_a <- b_lam*b_af; b_eff_c <- b_lam*b_cf; b_eff_e <- b_lam*b_ef
  bL_ip <- cbind(b_ac, b_cc, b_ec); bL_cp <- cbind(b_eff_a, b_eff_c, b_eff_e)
  b_sv <- svd(bL_ip)$d
  b_ta <- tucker(b_eff_a, b_ac); b_tc <- tucker(b_eff_c, b_cc); b_te <- tucker(b_eff_e, b_ec)
  b_va <- sum(b_eff_a^2)+sum(b_ac^2); b_vc <- sum(b_eff_c^2)+sum(b_cc^2)
  b_ve <- sum(b_eff_e^2)+sum(b_ec^2); b_tot <- b_va+b_vc+b_ve
  b_XtY <- crossprod(bL_cp, bL_ip); b_XtX <- crossprod(bL_cp); b_YtY <- crossprod(bL_ip)
  b_ip_com <- b_ac^2+b_cc^2+b_ec^2; b_ip_tot <- b_ip_com+b_as^2+b_cs^2+b_es^2
  b_ip_std <- sqrt(b_ip_com/b_ip_tot)
  c(svd_rank1 = b_sv[1]^2/sum(b_sv^2),
    tuck_ac = tucker(b_ac, b_cc),
    tuck_vec = tucker(as.vector(bL_cp), as.vector(bL_ip)),
    tuck_wt = (b_va/b_tot)*b_ta + (b_vc/b_tot)*b_tc + (b_ve/b_tot)*b_te,
    rv = sum(b_XtY^2)/sqrt(sum(b_XtX^2)*sum(b_YtY^2)),
    tuck_ip_g = tucker(b_ip_std, g_load))
}

# Build pair data for bootstrapping
d_sub12 <- d[, c("case_id", sub_vars), with = FALSE]
pair12 <- merge(links, d_sub12, by.x = "id_1", by.y = "case_id")
n1 <- paste0(sub_vars, "_1"); setnames(pair12, sub_vars, n1)
pair12 <- merge(pair12, d_sub12, by.x = "id_2", by.y = "case_id")
n2 <- paste0(sub_vars, "_2"); setnames(pair12, sub_vars, n2)
pair12[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_)]
pair12 <- pair12[!is.na(pair_class)]
pair12 <- pair12[rowSums(!is.na(pair12[, ..n1])) > 0 & rowSums(!is.na(pair12[, ..n2])) > 0]
component_map <- as.data.table(
  readRDS("results_family_dependence_robustness.rds")$component_map
)
missing_mothers <- setdiff(unique(pair12$mother_id), component_map$mother_id)
if (length(missing_mothers)) {
  component_map <- rbind(
    component_map,
    data.table(mother_id = missing_mothers, component_id = missing_mothers)
  )
}
pair12 <- merge(pair12, component_map, by = "mother_id", all.x = TRUE)
stopifnot(!anyNA(pair12$component_id))
var_names <- c(n1, n2)
start_means <- c(9.2, 8.7, 8.7, 9.6, 9.1, 9.4, 10.0, 33.8, -8.4, 23.7, 20.0, 19.7)

ip_obs <- ip_p$Estimate[1:72]; cp_obs <- cp_p$Estimate[1:50]
obs <- compute_boot_metrics(ip_obs, cp_obs, pca_g)

build_ip_boot <- function(mz, dz, fs, hs) {
  mxModel("IP",
    mxMatrix("Full",nv,1,free=TRUE,values=ip_obs[1:12],lbound=-5,name="ac"),
    mxMatrix("Full",nv,1,free=TRUE,values=ip_obs[13:24],lbound=-5,name="cc"),
    mxMatrix("Full",nv,1,free=TRUE,values=ip_obs[25:36],lbound=-5,name="ec"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=ip_obs[37:48],lbound=0.001,name="as"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=ip_obs[49:60],lbound=0.001,name="cs"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=ip_obs[61:72],lbound=0.001,name="es"),
    mxMatrix("Full",1,nv,free=TRUE,values=start_means,name="Mu"),
    mxAlgebra(ac%*%t(ac)+as%*%t(as),name="A"), mxAlgebra(cc%*%t(cc)+cs%*%t(cs),name="C"),
    mxAlgebra(ec%*%t(ec)+es%*%t(es),name="E"), mxAlgebra(A+C+E,name="V"),
    mxModel("MZ",mxData(mz,"raw"),mxAlgebra(IP.A+IP.C,name="B"),
      mxAlgebra(rbind(cbind(IP.V,B),cbind(B,IP.V)),name="expCov"),
      mxAlgebra(cbind(IP.Mu,IP.Mu),name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
    mxModel("DZ",mxData(dz,"raw"),mxAlgebra(0.5*IP.A+IP.C,name="B"),
      mxAlgebra(rbind(cbind(IP.V,B),cbind(B,IP.V)),name="expCov"),
      mxAlgebra(cbind(IP.Mu,IP.Mu),name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
    mxModel("FS",mxData(fs,"raw"),mxAlgebra(0.5*IP.A+IP.C,name="B"),
      mxAlgebra(rbind(cbind(IP.V,B),cbind(B,IP.V)),name="expCov"),
      mxAlgebra(cbind(IP.Mu,IP.Mu),name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
    mxModel("HS",mxData(hs,"raw"),mxAlgebra(0.25*IP.A+IP.C,name="B"),
      mxAlgebra(rbind(cbind(IP.V,B),cbind(B,IP.V)),name="expCov"),
      mxAlgebra(cbind(IP.Mu,IP.Mu),name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
    mxFitFunctionMultigroup(c("MZ","DZ","FS","HS")))
}
build_cp_boot <- function(mz, dz, fs, hs) {
  mxModel("CP",
    mxMatrix("Full",nv,1,free=TRUE,values=cp_obs[1:12],lbound=0.01,name="lambda"),
    mxMatrix("Full",1,1,free=TRUE,values=cp_obs[13],lbound=0.01,ubound=0.99,name="af"),
    mxMatrix("Full",1,1,free=TRUE,values=cp_obs[14],lbound=0.01,ubound=0.99,name="cf"),
    mxAlgebra(sqrt(1-af*af-cf*cf),name="ef"),
    mxConstraint(af*af+cf*cf<0.999,name="con"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=cp_obs[15:26],lbound=0.001,name="as"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=cp_obs[27:38],lbound=0.001,name="cs"),
    mxMatrix("Diag",nv,nv,free=TRUE,values=cp_obs[39:50],lbound=0.001,name="es"),
    mxMatrix("Full",1,nv,free=TRUE,values=start_means,name="Mu"),
    mxAlgebra(lambda%*%(af*af)%*%t(lambda)+as%*%t(as),name="A"),
    mxAlgebra(lambda%*%(cf*cf)%*%t(lambda)+cs%*%t(cs),name="C"),
    mxAlgebra(lambda%*%(ef*ef)%*%t(lambda)+es%*%t(es),name="E"),
    mxAlgebra(A+C+E,name="V"),
    mxModel("MZ",mxData(mz,"raw"),mxAlgebra(CP.A+CP.C,name="B"),
      mxAlgebra(rbind(cbind(CP.V,B),cbind(B,CP.V)),name="expCov"),
      mxAlgebra(cbind(CP.Mu,CP.Mu),name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
    mxModel("DZ",mxData(dz,"raw"),mxAlgebra(0.5*CP.A+CP.C,name="B"),
      mxAlgebra(rbind(cbind(CP.V,B),cbind(B,CP.V)),name="expCov"),
      mxAlgebra(cbind(CP.Mu,CP.Mu),name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
    mxModel("FS",mxData(fs,"raw"),mxAlgebra(0.5*CP.A+CP.C,name="B"),
      mxAlgebra(rbind(cbind(CP.V,B),cbind(B,CP.V)),name="expCov"),
      mxAlgebra(cbind(CP.Mu,CP.Mu),name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
    mxModel("HS",mxData(hs,"raw"),mxAlgebra(0.25*CP.A+CP.C,name="B"),
      mxAlgebra(rbind(cbind(CP.V,B),cbind(B,CP.V)),name="expCov"),
      mxAlgebra(cbind(CP.Mu,CP.Mu),name="expMean"),
      mxExpectationNormal("expCov","expMean",dimnames=var_names),mxFitFunctionML()),
    mxFitFunctionMultigroup(c("MZ","DZ","FS","HS")))
}

N_boot <- 25
res_boot <- matrix(NA, N_boot, length(obs)); colnames(res_boot) <- names(obs)
ok_boot <- logical(N_boot)
components <- unique(pair12$component_id)

for (i in 1:N_boot) {
  t0 <- Sys.time()
  set.seed(2000 + i)
  sampled_components <- sample(components, length(components), replace = TRUE)
  component_weights <- data.table(component_id = sampled_components)[
    , .(weight = .N), by = component_id
  ]
  b_pair <- merge(pair12, component_weights, by = "component_id", all = FALSE)
  b_pair <- b_pair[rep(seq_len(.N), weight)]
  b_mz <- as.data.frame(b_pair[pair_class == "MZ", ..var_names])
  b_dz <- as.data.frame(b_pair[pair_class == "DZ", ..var_names])
  b_fs <- as.data.frame(b_pair[pair_class == "FS", ..var_names])
  b_hs <- as.data.frame(b_pair[pair_class == "HS", ..var_names])
  ip_f <- tryCatch(mxTryHard(build_ip_boot(b_mz, b_dz, b_fs, b_hs),
                              extraTries = 1, silent = TRUE), error = function(e) NULL)
  cp_f <- tryCatch(mxTryHard(build_cp_boot(b_mz, b_dz, b_fs, b_hs),
                              extraTries = 1, silent = TRUE), error = function(e) NULL)
  if (!is.null(ip_f) && !is.null(cp_f) &&
      ip_f$output$status$code %in% c(0, 6) &&
      cp_f$output$status$code %in% c(0, 6)) {
    res_boot[i, ] <- compute_boot_metrics(
      summary(ip_f)$parameters$Estimate[1:72],
      summary(cp_f)$parameters$Estimate[1:50], pca_g)
    ok_boot[i] <- TRUE
  }
  cat(sprintf("  Boot %2d/%d: %.0fs %s\n", i, N_boot,
              difftime(Sys.time(), t0, units = "secs"),
              ifelse(ok_boot[i], "OK", "FAIL")))
  flush.console()
}

cat(sprintf("\n  Converged: %d/%d\n", sum(ok_boot), N_boot))
cat(sprintf("\n  %-15s  %8s  %8s  %8s  %8s\n", "Metric", "Observed", "Boot.Mean", "2.5%", "97.5%"))
cat(strrep("-", 55), "\n")
r_boot <- res_boot[ok_boot, , drop = FALSE]
for (nm in colnames(r_boot)) {
  v <- r_boot[, nm]
  cat(sprintf("  %-15s  %8.4f  %8.4f  %8.4f  %8.4f\n",
              nm, obs[nm], mean(v), quantile(v, 0.025), quantile(v, 0.975)))
}

# ======================================================================
#  Save results
# ======================================================================
congruence_results <- list(
  structural = list(
    svd_rank1 = svd_rank1, tuck_ac = tuck_ac,
    tuck_vec = tuck_vec, tuck_wt = tuck_wt,
    rv = rv, tuck_cov = tuck_cov),
  communality = list(
    ip_communality = ip_communality, cp_communality = cp_communality,
    ip_std = ip_std, cp_std = cp_std,
    ip_cp_comm = ip_cp_comm, ip_cp_std = ip_cp_std),
  pca_cfa = list(
    pca_g = pca_g, cfa_g_std = cfa_g_std,
    ip_std_pca = tucker(ip_std, pca_g), ip_std_cfa = tucker(ip_std, cfa_g_std),
    cp_std_pca = tucker(cp_std, pca_g), cp_std_cfa = tucker(cp_std, cfa_g_std)),
  wisc_only = list(
    ip_sum = w_ip_sum, cp_sum = w_cp_sum,
    chi2 = chi2_w, df = df_w, p = p_w),
  bootstrap = list(
    obs = obs, boot = res_boot, boot_ok = ok_boot, N = N_boot)
)
saveRDS(congruence_results, "results_congruence_benchmarks.rds")
cat("\nSaved to results_congruence_benchmarks.rds\n")
