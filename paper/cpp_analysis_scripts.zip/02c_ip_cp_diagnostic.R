#!/usr/bin/env Rscript
# 02c_ip_cp_diagnostic.R
# Diagnostic: Structure of the IP departure from the CP model
#
# 1A. No-Specific-A/C Models (IP-NoAC, CP-NoAC)
# 1B. Pruned Models (fix boundary-specific params to 0, test remaining)
# 1C. Cholesky Benchmark (per-test h², c², e²)
# 1D. V-only and P-only Separate IP Models
# 1E. Observed Cross-Pair Correlations

library(data.table)
library(OpenMx)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

cat("\n")
cat("--- IP vs CP DIAGNOSTIC MODELS ---
")

# ── Load data (same pattern as 02c_pathway_models.R) ─────────────────
d <- readRDS("prepared_data.rds")
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}
links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "Digit",
                "PicArr", "Block", "Coding",
                "WRAT Read", "Bender",
                "WRAT Spell", "WRAT Arith", "Goodenough")
nv <- length(sub_vars)
v_idx <- c(1, 2, 3, 4, 8, 10, 11)
p_idx <- c(5, 6, 7, 9, 12)

# Approximate means for starting values
start_means <- c(9.2, 8.7, 8.7, 9.6, 9.1, 9.4, 10.0, 33.8, -8.4,
                 23.7, 20.0, 19.7)

# Build pair data
d_sub <- d[, c("case_id", sub_vars), with = FALSE]
pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
new_names1 <- paste0(sub_vars, "_1")
setnames(pair, sub_vars, new_names1)
pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
new_names2 <- paste0(sub_vars, "_2")
setnames(pair, sub_vars, new_names2)
pair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair <- pair[!is.na(pair_class)]
has_any_1 <- rowSums(!is.na(pair[, ..new_names1])) > 0
has_any_2 <- rowSums(!is.na(pair[, ..new_names2])) > 0
pair <- pair[has_any_1 & has_any_2]

var_names <- c(new_names1, new_names2)
mz_data <- as.data.frame(pair[pair_class == "MZ", ..var_names])
dz_data <- as.data.frame(pair[pair_class == "DZ", ..var_names])
fs_data <- as.data.frame(pair[pair_class == "FS", ..var_names])
hs_data <- as.data.frame(pair[pair_class == "HS", ..var_names])

cat(sprintf("  MZ=%d, DZ=%d, FS=%d, HS=%d\n",
            nrow(mz_data), nrow(dz_data), nrow(fs_data), nrow(hs_data)))

# Load existing results for reference
existing <- readRDS("results_pathway_models.rds")
cat(sprintf("\n  Reference -2LL values:\n"))
cat(sprintf("    Cholesky: %.2f (k=%d)\n",
            existing$chol_fit$Minus2LogLikelihood,
            existing$chol_fit$estimatedParameters))
cat(sprintf("    IP:       %.2f (k=%d)\n",
            existing$ip_fit_sum$Minus2LogLikelihood,
            existing$ip_fit_sum$estimatedParameters))
cat(sprintf("    CP:       %.2f (k=%d)\n",
            existing$cp_fit_sum$Minus2LogLikelihood,
            existing$cp_fit_sum$estimatedParameters))

# ---- 1C. CHOLESKY BENCHMARK: Per-test h², c², e² ----
cat("\n")
cat("--- 1C. CHOLESKY BENCHMARK: Per-Test ACE ---
")

# Extract Cholesky lower-triangular parameters
chol_p <- existing$chol_fit$parameters
aL_vals <- chol_p[chol_p$matrix == "aL", ]
cL_vals <- chol_p[chol_p$matrix == "cL", ]
eL_vals <- chol_p[chol_p$matrix == "eL", ]

# Reconstruct lower-triangular matrices
aL <- matrix(0, nv, nv)
for (r in seq_len(nrow(aL_vals))) {
  aL[aL_vals$row[r], aL_vals$col[r]] <- aL_vals$Estimate[r]
}
cL <- matrix(0, nv, nv)
for (r in seq_len(nrow(cL_vals))) {
  cL[cL_vals$row[r], cL_vals$col[r]] <- cL_vals$Estimate[r]
}
eL <- matrix(0, nv, nv)
for (r in seq_len(nrow(eL_vals))) {
  eL[eL_vals$row[r], eL_vals$col[r]] <- eL_vals$Estimate[r]
}

# Compute covariance matrices
A_chol <- aL %*% t(aL)
C_chol <- cL %*% t(cL)
E_chol <- eL %*% t(eL)
V_chol <- A_chol + C_chol + E_chol

# Per-test heritability
h2_chol <- diag(A_chol) / diag(V_chol)
c2_chol <- diag(C_chol) / diag(V_chol)
e2_chol <- diag(E_chol) / diag(V_chol)

cat("\n  Per-test ACE from Cholesky:\n")
cat(sprintf("  %-10s %8s %8s %8s %8s\n", "Measure", "h2", "c2", "e2", "total"))
cat("  ", strrep("-", 50), "\n")
for (i in seq_len(nv)) {
  cat(sprintf("  %-10s %8.3f %8.3f %8.3f %8.3f\n",
              sub_labels[i], h2_chol[i], c2_chol[i], e2_chol[i],
              h2_chol[i] + c2_chol[i] + e2_chol[i]))
}
cat(sprintf("\n  Verbal mean:      h2=%.3f, c2=%.3f, e2=%.3f\n",
            mean(h2_chol[v_idx]), mean(c2_chol[v_idx]), mean(e2_chol[v_idx])))
cat(sprintf("  Performance mean: h2=%.3f, c2=%.3f, e2=%.3f\n",
            mean(h2_chol[p_idx]), mean(c2_chol[p_idx]), mean(e2_chol[p_idx])))

# IP-implied per-test ACE for comparison
ip_p <- existing$ip_fit_sum$parameters
ac <- ip_p[ip_p$matrix == "ac", "Estimate"]
cc_v <- ip_p[ip_p$matrix == "cc", "Estimate"]
ec <- ip_p[ip_p$matrix == "ec", "Estimate"]
as_v <- ip_p[ip_p$matrix == "as", "Estimate"]
cs_v <- ip_p[ip_p$matrix == "cs", "Estimate"]
es_v <- ip_p[ip_p$matrix == "es", "Estimate"]

# IP total per-test ACE
h2_ip_tot <- (ac^2 + as_v^2) / (ac^2 + cc_v^2 + ec^2 + as_v^2 + cs_v^2 + es_v^2)
c2_ip_tot <- (cc_v^2 + cs_v^2) / (ac^2 + cc_v^2 + ec^2 + as_v^2 + cs_v^2 + es_v^2)

# IP common-factor ACE
h2_ip_com <- ac^2 / (ac^2 + cc_v^2 + ec^2)
c2_ip_com <- cc_v^2 / (ac^2 + cc_v^2 + ec^2)

cat("\n  Comparison: Cholesky total h2 vs IP total h2 vs IP common h2:\n")
cat(sprintf("  %-10s %10s %10s %10s\n", "Measure", "Chol h2", "IP h2_tot", "IP h2_com"))
cat("  ", strrep("-", 45), "\n")
for (i in seq_len(nv)) {
  cat(sprintf("  %-10s %10.3f %10.3f %10.3f\n",
              sub_labels[i], h2_chol[i], h2_ip_tot[i], h2_ip_com[i]))
}
cat(sprintf("\n  Verbal mean:   Chol=%.3f, IP_tot=%.3f, IP_com=%.3f\n",
            mean(h2_chol[v_idx]), mean(h2_ip_tot[v_idx]), mean(h2_ip_com[v_idx])))
cat(sprintf("  Perf. mean:    Chol=%.3f, IP_tot=%.3f, IP_com=%.3f\n",
            mean(h2_chol[p_idx]), mean(h2_ip_tot[p_idx]), mean(h2_ip_com[p_idx])))

cat("\n  KEY: Does the Cholesky confirm low verbal h2?\n")
cat(sprintf("  Verbal Cholesky h2 range: %.3f to %.3f\n",
            min(h2_chol[v_idx]), max(h2_chol[v_idx])))
cat(sprintf("  Perf.  Cholesky h2 range: %.3f to %.3f\n",
            min(h2_chol[p_idx]), max(h2_chol[p_idx])))

# ---- 1A. NO-SPECIFIC-A/C MODELS ----
cat("\n")
cat("--- 1A. NO-SPECIFIC-A/C MODELS ---
")

# ── IP-NoAC: V = ac*ac' + cc*cc' + ec*ec' + diag(es^2) ──
cat("\n  IP-NoAC: Remove specific A and C, keep specific E\n")
cat(sprintf("  k = %d(ac) + %d(cc) + %d(ec) + %d(es) + %d(Mu) = %d\n\n",
    nv, nv, nv, nv, nv, 5*nv))

ip_noac <- mxModel("IPnoAC",
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.2, nv),
           lbound = -5, name = "ac"),
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.8, nv),
           lbound = -5, name = "cc"),
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.0, nv),
           lbound = -5, name = "ec"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "es"),
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  mxAlgebra(ac %*% t(ac), name = "A"),
  mxAlgebra(cc %*% t(cc), name = "C"),
  mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(IPnoAC.A + IPnoAC.C, name = "B"),
    mxAlgebra(rbind(cbind(IPnoAC.V, B), cbind(B, IPnoAC.V)), name = "expCov"),
    mxAlgebra(cbind(IPnoAC.Mu, IPnoAC.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * IPnoAC.A + IPnoAC.C, name = "B"),
    mxAlgebra(rbind(cbind(IPnoAC.V, B), cbind(B, IPnoAC.V)), name = "expCov"),
    mxAlgebra(cbind(IPnoAC.Mu, IPnoAC.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("FS",
    mxData(fs_data, type = "raw"),
    mxAlgebra(0.5 * IPnoAC.A + IPnoAC.C, name = "B"),
    mxAlgebra(rbind(cbind(IPnoAC.V, B), cbind(B, IPnoAC.V)), name = "expCov"),
    mxAlgebra(cbind(IPnoAC.Mu, IPnoAC.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("HS",
    mxData(hs_data, type = "raw"),
    mxAlgebra(0.25 * IPnoAC.A + IPnoAC.C, name = "B"),
    mxAlgebra(rbind(cbind(IPnoAC.V, B), cbind(B, IPnoAC.V)), name = "expCov"),
    mxAlgebra(cbind(IPnoAC.Mu, IPnoAC.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
)

cat("  Fitting IP-NoAC...\n")
ip_noac_fit <- mxTryHard(ip_noac, extraTries = 100, silent = TRUE)
ip_noac_sum <- summary(ip_noac_fit)
cat(sprintf("  IP-NoAC: -2LL = %.2f, k = %d, AIC = %.2f, status = %d\n",
            ip_noac_sum$Minus2LogLikelihood, ip_noac_sum$estimatedParameters,
            ip_noac_sum$AIC.Mx, ip_noac_fit$output$status$code))

# ── CP-NoAC: V = lambda*lambda'*(af^2 + cf^2 + ef^2) + diag(es^2) ──
cat("\n  CP-NoAC: Remove specific A and C from CP, keep specific E\n")
cat(sprintf("  k = %d(lambda) + 1(af) + 1(cf) + %d(es) + %d(Mu) = %d\n\n",
    nv, nv, nv, nv + 2 + 2*nv))

cp_noac <- mxModel("CPnoAC",
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.8, nv),
           lbound = 0.01, name = "lambda"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.65, lbound = 0.01,
           ubound = 0.99, name = "af"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.45, lbound = 0.01,
           ubound = 0.99, name = "cf"),
  mxAlgebra(sqrt(1 - af*af - cf*cf), name = "ef"),
  mxConstraint(af*af + cf*cf < 0.999, name = "factorVarConstraint"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "es"),
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  mxAlgebra(lambda %*% (af*af) %*% t(lambda), name = "A"),
  mxAlgebra(lambda %*% (cf*cf) %*% t(lambda), name = "C"),
  mxAlgebra(lambda %*% (ef*ef) %*% t(lambda) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(CPnoAC.A + CPnoAC.C, name = "B"),
    mxAlgebra(rbind(cbind(CPnoAC.V, B), cbind(B, CPnoAC.V)), name = "expCov"),
    mxAlgebra(cbind(CPnoAC.Mu, CPnoAC.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * CPnoAC.A + CPnoAC.C, name = "B"),
    mxAlgebra(rbind(cbind(CPnoAC.V, B), cbind(B, CPnoAC.V)), name = "expCov"),
    mxAlgebra(cbind(CPnoAC.Mu, CPnoAC.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("FS",
    mxData(fs_data, type = "raw"),
    mxAlgebra(0.5 * CPnoAC.A + CPnoAC.C, name = "B"),
    mxAlgebra(rbind(cbind(CPnoAC.V, B), cbind(B, CPnoAC.V)), name = "expCov"),
    mxAlgebra(cbind(CPnoAC.Mu, CPnoAC.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("HS",
    mxData(hs_data, type = "raw"),
    mxAlgebra(0.25 * CPnoAC.A + CPnoAC.C, name = "B"),
    mxAlgebra(rbind(cbind(CPnoAC.V, B), cbind(B, CPnoAC.V)), name = "expCov"),
    mxAlgebra(cbind(CPnoAC.Mu, CPnoAC.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
)

cat("  Fitting CP-NoAC...\n")
cp_noac_fit <- mxTryHard(cp_noac, extraTries = 100, silent = TRUE)
cp_noac_sum <- summary(cp_noac_fit)
cat(sprintf("  CP-NoAC: -2LL = %.2f, k = %d, AIC = %.2f, status = %d\n",
            cp_noac_sum$Minus2LogLikelihood, cp_noac_sum$estimatedParameters,
            cp_noac_sum$AIC.Mx, cp_noac_fit$output$status$code))

# IP-NoAC vs CP-NoAC
chi2_noac <- cp_noac_sum$Minus2LogLikelihood - ip_noac_sum$Minus2LogLikelihood
df_noac <- ip_noac_sum$estimatedParameters - cp_noac_sum$estimatedParameters
p_noac <- pchisq(chi2_noac, df_noac, lower.tail = FALSE)
cat(sprintf("\n  IP-NoAC vs CP-NoAC: chi2 = %.2f, df = %d, p = %.2e\n",
            chi2_noac, df_noac, p_noac))
cat("  (Tests whether V/P ACE split is in common factor, not specific residuals)\n")

# IP-NoAC loading profiles
ip_noac_p <- ip_noac_sum$parameters
ac_noac <- ip_noac_p[ip_noac_p$matrix == "ac", "Estimate"]
cc_noac <- ip_noac_p[ip_noac_p$matrix == "cc", "Estimate"]
ec_noac <- ip_noac_p[ip_noac_p$matrix == "ec", "Estimate"]

h2_noac <- ac_noac^2 / (ac_noac^2 + cc_noac^2 + ec_noac^2)
c2_noac <- cc_noac^2 / (ac_noac^2 + cc_noac^2 + ec_noac^2)
e2_noac <- ec_noac^2 / (ac_noac^2 + cc_noac^2 + ec_noac^2)

cat("\n  IP-NoAC common-factor ACE decomposition:\n")
cat(sprintf("  %-10s %8s %8s %8s\n", "Measure", "h2_com", "c2_com", "e2_com"))
cat("  ", strrep("-", 40), "\n")
for (i in seq_len(nv)) {
  cat(sprintf("  %-10s %8.3f %8.3f %8.3f\n",
              sub_labels[i], h2_noac[i], c2_noac[i], e2_noac[i]))
}
cat(sprintf("\n  Verbal mean:      h2=%.3f, c2=%.3f, e2=%.3f\n",
            mean(h2_noac[v_idx]), mean(c2_noac[v_idx]), mean(e2_noac[v_idx])))
cat(sprintf("  Performance mean: h2=%.3f, c2=%.3f, e2=%.3f\n",
            mean(h2_noac[p_idx]), mean(c2_noac[p_idx]), mean(e2_noac[p_idx])))

# ---- 1B. PRUNED IP MODEL (fix boundary specifics to 0) ----
cat("\n")
cat("--- 1B. PRUNED IP MODEL (fix boundary specifics to 0) ---
")

# Dynamically detect boundary parameters from full IP
ip_pars <- existing$ip_fit_sum$parameters
as_est <- ip_pars[ip_pars$matrix == "as", "Estimate"]
cs_est <- ip_pars[ip_pars$matrix == "cs", "Estimate"]
es_est <- ip_pars[ip_pars$matrix == "es", "Estimate"]
as_bnd <- ip_pars[ip_pars$matrix == "as", "lboundMet"]
cs_bnd <- ip_pars[ip_pars$matrix == "cs", "lboundMet"]
es_bnd <- ip_pars[ip_pars$matrix == "es", "lboundMet"]

n_bnd <- sum(as_bnd) + sum(cs_bnd) + sum(es_bnd)
cat(sprintf("\n  Step 1: Fix all %d boundary parameters to 0\n", n_bnd))
cat(sprintf("  as at boundary: %d/%d, cs at boundary: %d/%d, es at boundary: %d/%d\n",
    sum(as_bnd), nv, sum(cs_bnd), nv, sum(es_bnd), nv))

as_free <- !as_bnd
as_start <- ifelse(as_bnd, 0, as_est)

cs_free <- !cs_bnd
cs_start <- ifelse(cs_bnd, 0, cs_est)

es_free <- !es_bnd
es_start <- ifelse(es_bnd, 0, es_est)

ip_pruned <- mxModel("IPpruned",
  mxMatrix("Full", nv, 1, free = TRUE, values = ac,
           lbound = -5, name = "ac"),
  mxMatrix("Full", nv, 1, free = TRUE, values = cc_v,
           lbound = -5, name = "cc"),
  mxMatrix("Full", nv, 1, free = TRUE, values = ec,
           lbound = -5, name = "ec"),
  mxMatrix("Diag", nv, nv, free = as_free, values = as_start,
           lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv, nv, free = cs_free, values = cs_start,
           lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv, nv, free = es_free, values = es_start,
           lbound = 0.001, name = "es"),
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
  mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
  mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(IPpruned.A + IPpruned.C, name = "B"),
    mxAlgebra(rbind(cbind(IPpruned.V, B), cbind(B, IPpruned.V)), name = "expCov"),
    mxAlgebra(cbind(IPpruned.Mu, IPpruned.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * IPpruned.A + IPpruned.C, name = "B"),
    mxAlgebra(rbind(cbind(IPpruned.V, B), cbind(B, IPpruned.V)), name = "expCov"),
    mxAlgebra(cbind(IPpruned.Mu, IPpruned.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("FS",
    mxData(fs_data, type = "raw"),
    mxAlgebra(0.5 * IPpruned.A + IPpruned.C, name = "B"),
    mxAlgebra(rbind(cbind(IPpruned.V, B), cbind(B, IPpruned.V)), name = "expCov"),
    mxAlgebra(cbind(IPpruned.Mu, IPpruned.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("HS",
    mxData(hs_data, type = "raw"),
    mxAlgebra(0.25 * IPpruned.A + IPpruned.C, name = "B"),
    mxAlgebra(rbind(cbind(IPpruned.V, B), cbind(B, IPpruned.V)), name = "expCov"),
    mxAlgebra(cbind(IPpruned.Mu, IPpruned.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = var_names),
    mxFitFunctionML()
  ),
  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
)

cat("  Fitting IP-BoundaryFixed...\n")
ip_pruned_fit <- mxTryHard(ip_pruned, extraTries = 100, silent = TRUE)
ip_pruned_sum <- summary(ip_pruned_fit)
cat(sprintf("  IP-BoundaryFixed: -2LL = %.2f, k = %d, status = %d\n",
            ip_pruned_sum$Minus2LogLikelihood, ip_pruned_sum$estimatedParameters,
            ip_pruned_fit$output$status$code))

# Compare with full IP
ip_full_ll <- existing$ip_fit_sum$Minus2LogLikelihood
chi2_prune <- ip_pruned_sum$Minus2LogLikelihood - ip_full_ll
df_prune <- existing$ip_fit_sum$estimatedParameters - ip_pruned_sum$estimatedParameters
p_prune <- pchisq(chi2_prune, df_prune, lower.tail = FALSE)
cat(sprintf("  vs Full IP: chi2 = %.2f, df = %d, p = %.4f\n",
            chi2_prune, df_prune, p_prune))

# Step 2: Test each remaining non-boundary specific individually
cat("\n  Step 2: LRT for each remaining non-boundary specific:\n")
remaining <- list()
for (i in which(as_free)) {
  remaining <- c(remaining, list(list(matrix = "as", idx = i,
    label = paste0("as_", sub_labels[i]))))
}
for (i in which(cs_free)) {
  remaining <- c(remaining, list(list(matrix = "cs", idx = i,
    label = paste0("cs_", sub_labels[i]))))
}
for (i in which(es_free)) {
  remaining <- c(remaining, list(list(matrix = "es", idx = i,
    label = paste0("es_", sub_labels[i]))))
}
cat(sprintf("  Testing %d non-boundary specifics\n", length(remaining)))

lrt_results <- list()
for (item in remaining) {
  test_model <- ip_pruned_fit
  mat <- item$matrix
  idx <- item$idx
  test_model[[paste0("IPpruned.", mat)]]$free[idx, idx] <- FALSE
  test_model[[paste0("IPpruned.", mat)]]$values[idx, idx] <- 0

  test_fit <- mxTryHard(test_model, extraTries = 10, silent = TRUE)
  test_sum <- summary(test_fit)
  chi2_1 <- test_sum$Minus2LogLikelihood - ip_pruned_sum$Minus2LogLikelihood
  p_1 <- pchisq(chi2_1, 1, lower.tail = FALSE)
  sig <- ifelse(p_1 < 0.05, "*** RETAIN", "    drop")
  cat(sprintf("    %s: chi2(1) = %.2f, p = %.4f %s\n",
              item$label, chi2_1, p_1, sig))
  lrt_results[[item$label]] <- list(chi2 = chi2_1, p = p_1, sig = p_1 < 0.05)
}

# IP-Pruned loadings
ip_pr_p <- ip_pruned_sum$parameters
ac_pr <- ip_pr_p[ip_pr_p$matrix == "ac", "Estimate"]
cc_pr <- ip_pr_p[ip_pr_p$matrix == "cc", "Estimate"]
ec_pr <- ip_pr_p[ip_pr_p$matrix == "ec", "Estimate"]

h2_pr_com <- ac_pr^2 / (ac_pr^2 + cc_pr^2 + ec_pr^2)
c2_pr_com <- cc_pr^2 / (ac_pr^2 + cc_pr^2 + ec_pr^2)
e2_pr_com <- ec_pr^2 / (ac_pr^2 + cc_pr^2 + ec_pr^2)

cat("\n  IP-Pruned common-factor ACE:\n")
cat(sprintf("  %-10s %8s %8s %8s\n", "Measure", "h2_com", "c2_com", "e2_com"))
cat("  ", strrep("-", 40), "\n")
for (i in seq_len(nv)) {
  cat(sprintf("  %-10s %8.3f %8.3f %8.3f\n",
              sub_labels[i], h2_pr_com[i], c2_pr_com[i], e2_pr_com[i]))
}
cat(sprintf("\n  Verbal mean:      h2=%.3f, c2=%.3f\n",
            mean(h2_pr_com[v_idx]), mean(c2_pr_com[v_idx])))
cat(sprintf("  Performance mean: h2=%.3f, c2=%.3f\n",
            mean(h2_pr_com[p_idx]), mean(c2_pr_com[p_idx])))

# ---- 1D. V-ONLY AND P-ONLY SEPARATE IP MODELS ----
cat("\n")
cat("--- 1D. SEPARATE V-ONLY AND P-ONLY IP MODELS ---
")

sub_ip_results <- list()

# Helper: build a sub-battery IP model using mxAlgebraFromString
build_sub_ip <- function(pn, nv_sub, vn_all, mz_sub, dz_sub, fs_sub, hs_sub) {
  mxModel(pn,
    mxMatrix("Full", nv_sub, 1, free = TRUE, values = rep(1.2, nv_sub),
             lbound = -5, name = "ac"),
    mxMatrix("Full", nv_sub, 1, free = TRUE, values = rep(0.8, nv_sub),
             lbound = -5, name = "cc"),
    mxMatrix("Full", nv_sub, 1, free = TRUE, values = rep(1.0, nv_sub),
             lbound = -5, name = "ec"),
    mxMatrix("Diag", nv_sub, nv_sub, free = TRUE, values = rep(1.2, nv_sub),
             lbound = 0.001, name = "as"),
    mxMatrix("Diag", nv_sub, nv_sub, free = TRUE, values = rep(0.5, nv_sub),
             lbound = 0.001, name = "cs"),
    mxMatrix("Diag", nv_sub, nv_sub, free = TRUE, values = rep(1.2, nv_sub),
             lbound = 0.001, name = "es"),
    mxMatrix("Full", 1, nv_sub, free = TRUE, values = rep(9, nv_sub), name = "Mu"),

    mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
    mxAlgebra(A + C + E, name = "V"),

    mxModel("MZ",
      mxData(mz_sub, type = "raw"),
      mxAlgebraFromString(paste0(pn, ".A + ", pn, ".C"), name = "B"),
      mxAlgebraFromString(paste0("rbind(cbind(", pn, ".V, B), cbind(B, ", pn, ".V))"), name = "expCov"),
      mxAlgebraFromString(paste0("cbind(", pn, ".Mu, ", pn, ".Mu)"), name = "expMean"),
      mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = vn_all),
      mxFitFunctionML()
    ),
    mxModel("DZ",
      mxData(dz_sub, type = "raw"),
      mxAlgebraFromString(paste0("0.5 * ", pn, ".A + ", pn, ".C"), name = "B"),
      mxAlgebraFromString(paste0("rbind(cbind(", pn, ".V, B), cbind(B, ", pn, ".V))"), name = "expCov"),
      mxAlgebraFromString(paste0("cbind(", pn, ".Mu, ", pn, ".Mu)"), name = "expMean"),
      mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = vn_all),
      mxFitFunctionML()
    ),
    mxModel("FS",
      mxData(fs_sub, type = "raw"),
      mxAlgebraFromString(paste0("0.5 * ", pn, ".A + ", pn, ".C"), name = "B"),
      mxAlgebraFromString(paste0("rbind(cbind(", pn, ".V, B), cbind(B, ", pn, ".V))"), name = "expCov"),
      mxAlgebraFromString(paste0("cbind(", pn, ".Mu, ", pn, ".Mu)"), name = "expMean"),
      mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = vn_all),
      mxFitFunctionML()
    ),
    mxModel("HS",
      mxData(hs_sub, type = "raw"),
      mxAlgebraFromString(paste0("0.25 * ", pn, ".A + ", pn, ".C"), name = "B"),
      mxAlgebraFromString(paste0("rbind(cbind(", pn, ".V, B), cbind(B, ", pn, ".V))"), name = "expCov"),
      mxAlgebraFromString(paste0("cbind(", pn, ".Mu, ", pn, ".Mu)"), name = "expMean"),
      mxExpectationNormal(covariance = "expCov", means = "expMean", dimnames = vn_all),
      mxFitFunctionML()
    ),
    mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
  )
}

for (group_name in c("Verbal", "Performance")) {
  sel_idx <- if (group_name == "Verbal") v_idx else p_idx
  nv_sub <- length(sel_idx)
  sub_vars_sel <- sub_vars[sel_idx]
  sub_labels_sel <- sub_labels[sel_idx]

  vn1 <- paste0(sub_vars_sel, "_1")
  vn2 <- paste0(sub_vars_sel, "_2")
  vn_all <- c(vn1, vn2)

  mz_sub <- as.data.frame(pair[pair_class == "MZ", ..vn_all])
  dz_sub <- as.data.frame(pair[pair_class == "DZ", ..vn_all])
  fs_sub <- as.data.frame(pair[pair_class == "FS", ..vn_all])
  hs_sub <- as.data.frame(pair[pair_class == "HS", ..vn_all])

  cat(sprintf("\n  %s-only IP (nv=%d): %s\n", group_name, nv_sub,
              paste(sub_labels_sel, collapse = ", ")))

  pn <- paste0("IP", group_name)
  sub_ip <- build_sub_ip(pn, nv_sub, vn_all, mz_sub, dz_sub, fs_sub, hs_sub)

  cat(sprintf("  Fitting %s-only IP...\n", group_name))
  sub_fit <- mxTryHard(sub_ip, extraTries = 100, silent = TRUE)
  sub_sum <- summary(sub_fit)
  cat(sprintf("  %s-only IP: -2LL = %.2f, k = %d, status = %d\n",
              group_name, sub_sum$Minus2LogLikelihood, sub_sum$estimatedParameters,
              sub_fit$output$status$code))

  sub_p <- sub_sum$parameters
  ac_sub <- sub_p[sub_p$matrix == "ac", "Estimate"]
  cc_sub <- sub_p[sub_p$matrix == "cc", "Estimate"]
  ec_sub <- sub_p[sub_p$matrix == "ec", "Estimate"]

  h2_sub <- ac_sub^2 / (ac_sub^2 + cc_sub^2 + ec_sub^2)
  c2_sub <- cc_sub^2 / (ac_sub^2 + cc_sub^2 + ec_sub^2)
  e2_sub <- ec_sub^2 / (ac_sub^2 + cc_sub^2 + ec_sub^2)

  cat(sprintf("\n  %s-only IP common-factor ACE:\n", group_name))
  cat(sprintf("  %-10s %8s %8s %8s | %8s %8s\n",
              "Measure", "h2_com", "c2_com", "e2_com", "joint_h2", "joint_c2"))
  cat("  ", strrep("-", 62), "\n")
  for (i in seq_along(sel_idx)) {
    cat(sprintf("  %-10s %8.3f %8.3f %8.3f | %8.3f %8.3f\n",
                sub_labels_sel[i], h2_sub[i], c2_sub[i], e2_sub[i],
                h2_ip_com[sel_idx[i]], c2_ip_com[sel_idx[i]]))
  }
  cat(sprintf("\n  %s-only mean: h2=%.3f, c2=%.3f, e2=%.3f\n",
              group_name, mean(h2_sub), mean(c2_sub), mean(e2_sub)))
  cat(sprintf("  Joint 12-test:    h2=%.3f, c2=%.3f\n",
              mean(h2_ip_com[sel_idx]), mean(c2_ip_com[sel_idx])))

  sub_ip_results[[group_name]] <- list(
    fit_sum = sub_sum,
    h2_common = h2_sub, c2_common = c2_sub, e2_common = e2_sub,
    labels = sub_labels_sel
  )
}

# ---- 1E. OBSERVED CROSS-PAIR CORRELATIONS ----
cat("\n")
cat("--- 1E. OBSERVED CROSS-PAIR CORRELATIONS ---
")

cors_matrix <- matrix(NA, nv, 4)
colnames(cors_matrix) <- c("MZ", "DZ", "FS", "HS")
rownames(cors_matrix) <- sub_labels

cat(sprintf("\n  %-10s %6s %6s %6s %6s  %6s %6s\n",
            "Measure", "MZ", "DZ", "FS", "HS", "MZ-DZ", "MZ-FS"))
cat("  ", strrep("-", 56), "\n")
for (i in seq_len(nv)) {
  for (j in 1:4) {
    pc <- c("MZ", "DZ", "FS", "HS")[j]
    sub <- pair[pair_class == pc]
    cc_pair <- sub[!is.na(get(new_names1[i])) & !is.na(get(new_names2[i]))]
    if (nrow(cc_pair) >= 10) {
      cors_matrix[i, j] <- cor(cc_pair[[new_names1[i]]], cc_pair[[new_names2[i]]])
    }
  }
  mz_dz <- cors_matrix[i, 1] - cors_matrix[i, 2]
  mz_fs <- cors_matrix[i, 1] - cors_matrix[i, 3]
  type_label <- ifelse(i %in% v_idx, " (V)", " (P)")
  cat(sprintf("  %-10s %6.3f %6.3f %6.3f %6.3f  %6.3f %6.3f%s\n",
              sub_labels[i], cors_matrix[i, 1], cors_matrix[i, 2],
              cors_matrix[i, 3], cors_matrix[i, 4], mz_dz, mz_fs, type_label))
}

# V vs P summary
cat("\n  Verbal vs Performance averages:\n")
mz_dz_v <- mean(cors_matrix[v_idx, 1] - cors_matrix[v_idx, 2])
mz_dz_p <- mean(cors_matrix[p_idx, 1] - cors_matrix[p_idx, 2])
mz_fs_v <- mean(cors_matrix[v_idx, 1] - cors_matrix[v_idx, 3])
mz_fs_p <- mean(cors_matrix[p_idx, 1] - cors_matrix[p_idx, 3])
cat(sprintf("    Verbal:  MZ-DZ=%.3f (Falc h2=%.3f), MZ-FS=%.3f\n",
            mz_dz_v, 2 * mz_dz_v, mz_fs_v))
cat(sprintf("    Perform: MZ-DZ=%.3f (Falc h2=%.3f), MZ-FS=%.3f\n",
            mz_dz_p, 2 * mz_dz_p, mz_fs_p))
cat(sprintf("    FS correlations: V mean=%.3f, P mean=%.3f\n",
            mean(cors_matrix[v_idx, 3]), mean(cors_matrix[p_idx, 3])))

# ---- SUMMARY ----
cat("\n")
cat("--- GRAND SUMMARY ---
")

cat("\n  MODEL COMPARISON:\n")
models <- data.frame(
  Model = c("Cholesky", "IP (full)", "IP-BoundaryFixed", "IP-NoAC",
            "Bifactor", "Higher-Order", "CP (full)", "CP-NoAC"),
  k = c(existing$chol_fit$estimatedParameters,
        existing$ip_fit_sum$estimatedParameters,
        ip_pruned_sum$estimatedParameters,
        ip_noac_sum$estimatedParameters,
        existing$bf_fit_sum$estimatedParameters,
        existing$ho_fit_sum$estimatedParameters,
        existing$cp_fit_sum$estimatedParameters,
        cp_noac_sum$estimatedParameters),
  minus2LL = c(existing$chol_fit$Minus2LogLikelihood,
               existing$ip_fit_sum$Minus2LogLikelihood,
               ip_pruned_sum$Minus2LogLikelihood,
               ip_noac_sum$Minus2LogLikelihood,
               existing$bf_fit_sum$Minus2LogLikelihood,
               existing$ho_fit_sum$Minus2LogLikelihood,
               existing$cp_fit_sum$Minus2LogLikelihood,
               cp_noac_sum$Minus2LogLikelihood)
)
nobs <- existing$chol_fit$observedStatistics
models$AIC <- models$minus2LL - 2 * (nobs - models$k)

cat(sprintf("  %-20s %5s %15s %15s\n", "Model", "k", "-2LL", "AIC"))
cat("  ", strrep("-", 60), "\n")
for (i in seq_len(nrow(models))) {
  cat(sprintf("  %-20s %5d %15.2f %15.2f\n",
              models$Model[i], models$k[i], models$minus2LL[i], models$AIC[i]))
}

cat("\n  STABILITY: Verbal h2_common across specifications:\n")
cat(sprintf("  %-25s %8s %8s\n", "Specification", "V h2_com", "P h2_com"))
cat("  ", strrep("-", 45), "\n")
cat(sprintf("  %-25s %8.3f %8.3f\n",
            sprintf("IP (full, k=%d)", existing$ip_fit_sum$estimatedParameters),
            mean(h2_ip_com[v_idx]), mean(h2_ip_com[p_idx])))
cat(sprintf("  %-25s %8.3f %8.3f\n",
            sprintf("IP-Pruned (k=%d)", ip_pruned_sum$estimatedParameters),
            mean(h2_pr_com[v_idx]), mean(h2_pr_com[p_idx])))
cat(sprintf("  %-25s %8.3f %8.3f\n",
            sprintf("IP-NoAC (k=%d)", ip_noac_sum$estimatedParameters),
            mean(h2_noac[v_idx]), mean(h2_noac[p_idx])))
cat(sprintf("  %-25s %8.3f %8.3f\n", "Cholesky (total h2)",
            mean(h2_chol[v_idx]), mean(h2_chol[p_idx])))
cat(sprintf("  %-25s %8.3f %8.3f\n", "V-only / P-only IP",
            mean(sub_ip_results$Verbal$h2_common),
            mean(sub_ip_results$Performance$h2_common)))

# Save
diag_results <- list(
  cholesky_ace = data.frame(
    measure = sub_labels,
    h2 = h2_chol, c2 = c2_chol, e2 = e2_chol,
    verbal = seq_len(nv) %in% v_idx
  ),
  ip_common_ace = data.frame(
    measure = sub_labels,
    h2 = h2_ip_com, c2 = c2_ip_com,
    verbal = seq_len(nv) %in% v_idx
  ),
  ip_noac = list(
    fit_sum = ip_noac_sum,
    h2_common = h2_noac, c2_common = c2_noac, e2_common = e2_noac
  ),
  cp_noac = list(fit_sum = cp_noac_sum),
  ip_pruned = list(
    fit_sum = ip_pruned_sum,
    h2_common = h2_pr_com, c2_common = c2_pr_com
  ),
  noac_comparison = list(chi2 = chi2_noac, df = df_noac, p = p_noac),
  prune_comparison = list(chi2 = chi2_prune, df = df_prune, p = p_prune),
  lrt_specifics = lrt_results,
  separate_ip = sub_ip_results,
  cross_pair_cors = cors_matrix,
  model_table = models
)
saveRDS(diag_results, "results_ip_cp_diagnostic.rds")
cat("\nSaved to results_ip_cp_diagnostic.rds\n")
