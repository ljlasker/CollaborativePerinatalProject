#!/usr/bin/env Rscript
# 18_replication_nelson.R
# Replication: Nelson & Ellenberg (1986)
# "Antecedents of cerebral palsy: Multivariate analysis of risk" (NEJM)
#
# Original finding: In CPP data, most CP cases had no identifiable perinatal
# cause. Maternal mental retardation, low birth weight, and fetal malformation
# were stronger predictors than birth asphyxia. Multivariate logistic
# regression identified key risk factors.
#
# Our approach: Extract CP diagnosis from CPPVAR columns (v816-v820 for
# specific CP subtypes, v814/v1156 for neurological abnormalities), then
# run multivariate logistic regression comparing risk factor profiles.

library(data.table)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")

cat("\n")
cat("--- REPLICATION: Nelson & Ellenberg (1986) Antecedents of Cerebral Palsy ---
")

# ── Extract CP variables from CPPVAR ──────────────────────────────────
# CP diagnosis comes from CPPVAR columns 816-820
cppvar_path <- file.path("..", "clean", "cppvar_all_columns.csv")

if (file.exists(cppvar_path)) {
  cat("\nLoading CPPVAR for CP diagnosis variables...\n")

  # Read just the header to find CP columns
  hdr <- names(fread(cppvar_path, nrows = 0))
  cp_cols <- hdr[grepl("paresis|cerebral|palsy|v816|v817|v818|v819|v820|v814|v1156|neuro.*abnorm",
                        hdr, ignore.case = TRUE)]
  cat(sprintf("  CP-related columns found: %d\n", length(cp_cols)))
  if (length(cp_cols) > 0) cat("  ", paste(cp_cols, collapse = ", "), "\n")

  # Also look for neurological abnormality columns
  neuro_cols <- hdr[grepl("neurological_abnormalities|neuro_abnorm", hdr, ignore.case = TRUE)]
  cat(sprintf("  Neuro abnormality columns: %d\n", length(neuro_cols)))
  if (length(neuro_cols) > 0) cat("  ", paste(neuro_cols, collapse = ", "), "\n")

  # Read case_id + CP columns + neuro columns
  read_cols <- unique(c("case_id", cp_cols, neuro_cols))
  read_cols <- intersect(read_cols, hdr)

  if (length(read_cols) > 1) {
    cpv <- fread(cppvar_path, select = read_cols,
                 colClasses = c(case_id = "character"))

    # Create binary CP indicator from any CP subtype
    cp_type_cols <- grep("paresis.*cerebral|cerebral.*spastic|v81[6-9]|v820",
                         names(cpv), ignore.case = TRUE, value = TRUE)

    if (length(cp_type_cols) > 0) {
      cat(sprintf("\n  CP subtype columns used: %s\n", paste(cp_type_cols, collapse = ", ")))
      # Code 2 = definite diagnosis; code 1 = suspected. Use definite only.
      cpv[, cp_definite := as.integer(rowSums(.SD == 2, na.rm = TRUE) > 0),
          .SDcols = cp_type_cols]
      cpv[, cp_suspected := as.integer(rowSums(.SD >= 1, na.rm = TRUE) > 0),
          .SDcols = cp_type_cols]
      cpv[, cp_any := cp_definite]
      cat(sprintf("  Definite CP (code=2): %d cases\n", cpv[cp_definite == 1, .N]))
      cat(sprintf("  Suspected or definite (code>=1): %d cases\n", cpv[cp_suspected == 1, .N]))
    } else {
      # Fallback: use neurological abnormality = 2 (definite) as proxy
      neuro_def_col <- grep("neurological_abnormalities_7|v1156", names(cpv),
                            ignore.case = TRUE, value = TRUE)
      if (length(neuro_def_col) > 0) {
        cat(sprintf("\n  Using neurological abnormality at 7yr as proxy: %s\n",
                    neuro_def_col[1]))
        cpv[, cp_any := as.integer(get(neuro_def_col[1]) == 2)]
      } else {
        cat("\n  WARNING: No CP or neurological abnormality columns found.\n")
        cpv[, cp_any := NA_integer_]
      }
    }

    # Merge into main data
    d <- merge(d, cpv[, .(case_id, cp_any)], by = "case_id", all.x = TRUE)
  } else {
    cat("\n  WARNING: Could not find CP columns in CPPVAR.\n")
    d[, cp_any := NA_integer_]
  }
} else {
  cat("\n  WARNING: cppvar_all_columns.csv not found.\n")
  cat("  Attempting to use neurological abnormality from prepared data...\n")
  d[, cp_any := NA_integer_]
}

# ── Check if we also have 7-year neurological abnormality in clean data ──
neuro_cols_clean <- grep("neuro|abnorm", names(d), ignore.case = TRUE, value = TRUE)
if (length(neuro_cols_clean) > 0) {
  cat(sprintf("\nNeurological columns in clean data: %s\n",
              paste(neuro_cols_clean, collapse = ", ")))
}

# ── Also try v1156 (7-year neurological abnormalities) as tighter proxy ──
neuro7_col <- hdr[grepl("neurological_abnormalities_7|v1156", hdr, ignore.case = TRUE)]
if (length(neuro7_col) > 0 && file.exists(cppvar_path)) {
  cat(sprintf("\n  Trying alternative CP definition: %s\n", neuro7_col[1]))
  neuro7 <- fread(cppvar_path, select = c("case_id", neuro7_col[1]),
                  colClasses = c(case_id = "character"))
  neuro7[, cp_neuro7 := as.integer(get(neuro7_col[1]) == 2)]
  d <- merge(d, neuro7[, .(case_id, cp_neuro7)], by = "case_id", all.x = TRUE)
  cat(sprintf("  v1156 definite (code=2): %d cases (%.2f%%)\n",
              d[cp_neuro7 == 1, .N],
              100 * d[cp_neuro7 == 1, .N] / d[!is.na(cp_neuro7), .N]))
}

# PART A: CLOSE REPLICATION — Nelson & Ellenberg (1986)
# Original: 189 CP cases among ~54,000 children.
# We report both our v816-v820 definition and v1156 alternative.
cat("\n")
cat("--- PART A: CLOSE REPLICATION — Nelson & Ellenberg (1986) ---
")

cat("\n")
cat(strrep("-", 70), "\n")
cat("CP Prevalence by Definition\n")
cat(strrep("-", 70), "\n")

if (d[!is.na(cp_any), .N] > 0) {
  cat(sprintf("\n  Total with CP data: %d\n", d[!is.na(cp_any), .N]))
  cat(sprintf("  CP cases:           %d (%.2f%%)\n",
              d[cp_any == 1, .N],
              100 * d[cp_any == 1, .N] / d[!is.na(cp_any), .N]))
  cat(sprintf("  Non-CP:             %d\n", d[cp_any == 0, .N]))
  cat(sprintf("  Nelson & Ellenberg original: ~189 CP cases in ~54,000 children\n"))

  # ---- TABLE 1: CP Risk Factor Prevalence ----
  cat("\n")
  cat(strrep("-", 70), "\n")
  cat("TABLE 1: Characteristics by CP Status\n")
  cat(strrep("-", 70), "\n")

  # Create risk factor variables
  d[, low_bw := as.integer(birth_wt_g < 2500)]
  d[, very_low_bw := as.integer(birth_wt_g < 1500)]
  d[, preterm := as.integer(gest_age < 37)]
  d[, low_apgar := as.integer(apgar_total < 7)]
  d[, young_mother := as.integer(maternal_age < 20)]
  d[, low_educ := as.integer(educ_yrs < 9)]
  d[, smoker_binary := as.integer(smoker == 1)]

  risk_vars <- c("low_bw", "very_low_bw", "preterm", "low_apgar",
                 "young_mother", "low_educ", "smoker_binary")
  risk_labels <- c("Birth weight <2500g", "Birth weight <1500g",
                   "Preterm (<37 wk)", "5-min Apgar <7",
                   "Maternal age <20", "Education <9 yr", "Smoker")

  cat(sprintf("\n  %-25s  %10s  %10s\n", "Risk Factor", "CP (%)", "Non-CP (%)"))
  cat("  ", strrep("-", 50), "\n")

  for (i in seq_along(risk_vars)) {
    v <- risk_vars[i]
    if (v %in% names(d)) {
      cp_pct <- d[cp_any == 1 & !is.na(get(v)), mean(get(v), na.rm = TRUE)] * 100
      nocp_pct <- d[cp_any == 0 & !is.na(get(v)), mean(get(v), na.rm = TRUE)] * 100
      cat(sprintf("  %-25s  %9.1f%%  %9.1f%%\n", risk_labels[i], cp_pct, nocp_pct))
    }
  }

  # Continuous variables
  cat(sprintf("\n  %-25s  %10s  %10s\n", "Variable", "CP Mean", "Non-CP Mean"))
  cat("  ", strrep("-", 50), "\n")

  cont_vars <- c("birth_wt_g", "gest_age", "maternal_age", "educ_yrs", "sei_decimal")
  cont_labels <- c("Birth weight (g)", "Gest. age (wk)", "Maternal age",
                   "Education (yr)", "SEI")
  for (i in seq_along(cont_vars)) {
    v <- cont_vars[i]
    if (v %in% names(d)) {
      cp_m <- d[cp_any == 1, mean(get(v), na.rm = TRUE)]
      nocp_m <- d[cp_any == 0, mean(get(v), na.rm = TRUE)]
      cat(sprintf("  %-25s  %10.1f  %10.1f\n", cont_labels[i], cp_m, nocp_m))
    }
  }

  # IQ comparison
  cat(sprintf("\n  %-25s  %10s  %10s\n", "Outcome", "CP Mean", "Non-CP Mean"))
  cat("  ", strrep("-", 50), "\n")

  for (iq_var in c("sb_iq", "wisc_fsiq")) {
    if (iq_var %in% names(d)) {
      cp_m <- d[cp_any == 1, mean(get(iq_var), na.rm = TRUE)]
      nocp_m <- d[cp_any == 0, mean(get(iq_var), na.rm = TRUE)]
      n_cp <- d[cp_any == 1 & !is.na(get(iq_var)), .N]
      n_nocp <- d[cp_any == 0 & !is.na(get(iq_var)), .N]
      cat(sprintf("  %-25s  %6.1f (%3d)  %6.1f (%5d)\n",
                  iq_var, cp_m, n_cp, nocp_m, n_nocp))
    }
  }

  # ---- PART B: EXTENSION — Multivariate Logistic Regression with SES ----
  cat("\n")
cat("--- PART B: EXTENSION — Logistic Regression Predicting CP ---
")

  # Model 1: Birth/neonatal factors
  fit1 <- glm(cp_any ~ low_bw + preterm + low_apgar + sex,
              data = d, family = binomial)

  cat("\nModel 1: Birth/Neonatal Factors\n")
  s1 <- summary(fit1)$coefficients
  cat(sprintf("  %-20s  %8s  %8s  %8s\n", "Variable", "OR", "95% CI", "p"))
  cat("  ", strrep("-", 50), "\n")
  for (nm in rownames(s1)[-1]) {
    or <- exp(s1[nm, 1])
    ci_lo <- exp(s1[nm, 1] - 1.96 * s1[nm, 2])
    ci_hi <- exp(s1[nm, 1] + 1.96 * s1[nm, 2])
    cat(sprintf("  %-20s  %8.2f  [%.2f-%.2f]  %8.4f\n",
                nm, or, ci_lo, ci_hi, s1[nm, 4]))
  }

  # Model 2: + maternal/SES factors
  fit2 <- glm(cp_any ~ low_bw + preterm + low_apgar + sex +
                maternal_age + educ_yrs + sei_decimal + race + smoker_binary,
              data = d, family = binomial)

  cat("\nModel 2: + Maternal/SES Factors\n")
  s2 <- summary(fit2)$coefficients
  cat(sprintf("  %-20s  %8s  %8s  %8s\n", "Variable", "OR", "95% CI", "p"))
  cat("  ", strrep("-", 50), "\n")
  for (nm in rownames(s2)[-1]) {
    or <- exp(s2[nm, 1])
    ci_lo <- exp(s2[nm, 1] - 1.96 * s2[nm, 2])
    ci_hi <- exp(s2[nm, 1] + 1.96 * s2[nm, 2])
    cat(sprintf("  %-20s  %8.2f  [%.2f-%.2f]  %8.4f\n",
                nm, or, ci_lo, ci_hi, s2[nm, 4]))
  }

  cat(sprintf("\n  Model 1 N = %d, Model 2 N = %d\n", nobs(fit1), nobs(fit2)))

} else {
  cat("\n  No CP diagnosis data available. Skipping analysis.\n")
  cat("  CP variables (v816-v820) may need extraction from raw CPPVAR.\n")
}

# ── Comparison ────────────────────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Comparison with Nelson & Ellenberg (1986):\n")
cat(strrep("-", 70), "\n")
cat("  Original: ~189 CP cases among ~54,000 children\n")
cat("  Original: Low birth weight OR ~ 4-6, strongest single predictor\n")
cat("  Original: Birth asphyxia present in minority of CP cases\n")
cat("  Original: Most CP cases had no single identifiable perinatal cause\n")

# ── Save ──────────────────────────────────────────────────────────────
results <- list(data = d[, .(case_id, cp_any)])
if (exists("fit1")) results$logistic_birth <- fit1
if (exists("fit2")) results$logistic_full <- fit2
saveRDS(results, "results_replication_nelson.rds")
cat("\nResults saved to results_replication_nelson.rds\n")
