#!/usr/bin/env Rscript
# 15_replication_myrianthopoulos.R
# Replication: Myrianthopoulos & Keith (1976)
# Twin-singleton cognitive gap in the CPP
#
# Original finding: CPP twins scored lower than singletons on cognitive tests,
# with larger differences for Black than White children.

library(data.table)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")

cat("\n")
cat("--- REPLICATION: Myrianthopoulos & Keith (1976) Twin-Singleton Cognitive Gap ---
")

# ── Identify twins vs singletons ──────────────────────────────────────
# plurality: 1 = singleton, 2 = twin, 3+ = higher order
d[, is_twin := as.integer(plurality >= 2)]

cat("\nSample by plurality:\n")
print(d[, .N, by = plurality][order(plurality)])

cat(sprintf("\nSingletons: %d\n", d[is_twin == 0, .N]))
cat(sprintf("Twins:      %d\n", d[is_twin == 1, .N]))

# PART A: CLOSE REPLICATION — Stanford-Binet IQ at Age 4
# Myrianthopoulos & French (1968) and Keith et al. used SB IQ.
cat("\n")
cat("--- PART A: CLOSE REPLICATION — Stanford-Binet IQ at Age 4 ---
")

# Overall
sb_overall <- d[!is.na(sb_iq), .(
  mean_iq = mean(sb_iq),
  sd_iq = sd(sb_iq),
  n = .N
), by = is_twin]

cat("\nOverall:\n")
cat(sprintf("  %-12s  %8s  %8s  %8s\n", "Group", "Mean SB", "SD", "N"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nrow(sb_overall)) {
  lbl <- ifelse(sb_overall[i, is_twin] == 0, "Singletons", "Twins")
  cat(sprintf("  %-12s  %8.1f  %8.1f  %8d\n",
              lbl, sb_overall[i, mean_iq], sb_overall[i, sd_iq], sb_overall[i, n]))
}
if (nrow(sb_overall) == 2) {
  gap <- sb_overall[is_twin == 0, mean_iq] - sb_overall[is_twin == 1, mean_iq]
  cat(sprintf("  Gap (singleton - twin): %.1f points\n", gap))
}

# By race
sb_race <- d[!is.na(sb_iq), .(
  mean_iq = mean(sb_iq),
  sd_iq = sd(sb_iq),
  n = .N
), by = .(race, is_twin)]

cat("\nBy Race:\n")
cat(sprintf("  %-6s  %-12s  %8s  %8s  %5s\n", "Race", "Group", "Mean SB", "SD", "N"))
cat("  ", strrep("-", 45), "\n")

for (r in sort(unique(sb_race$race))) {
  for (tw in c(0, 1)) {
    row <- sb_race[race == r & is_twin == tw]
    if (nrow(row) > 0) {
      lbl <- ifelse(tw == 0, "Singletons", "Twins")
      cat(sprintf("  %-6s  %-12s  %8.1f  %8.1f  %5d\n",
                  r, lbl, row$mean_iq, row$sd_iq, row$n))
    }
  }
  # Gap within race
  s_mean <- sb_race[race == r & is_twin == 0, mean_iq]
  t_mean <- sb_race[race == r & is_twin == 1, mean_iq]
  if (length(s_mean) > 0 & length(t_mean) > 0) {
    cat(sprintf("  %-6s  %-12s  %8.1f\n", "", "Gap:", s_mean - t_mean))
  }
}

# ---- PART B: EXTENSION — WISC FSIQ at Age 7 + Regression Controls ----
cat("\n")
cat("--- PART B: EXTENSION — WISC FSIQ at Age 7 ---
")

# Overall
wisc_overall <- d[!is.na(wisc_fsiq), .(
  mean_iq = mean(wisc_fsiq),
  sd_iq = sd(wisc_fsiq),
  n = .N
), by = is_twin]

cat("\nOverall:\n")
cat(sprintf("  %-12s  %8s  %8s  %8s\n", "Group", "Mean IQ", "SD", "N"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nrow(wisc_overall)) {
  lbl <- ifelse(wisc_overall[i, is_twin] == 0, "Singletons", "Twins")
  cat(sprintf("  %-12s  %8.1f  %8.1f  %8d\n",
              lbl, wisc_overall[i, mean_iq], wisc_overall[i, sd_iq], wisc_overall[i, n]))
}
if (nrow(wisc_overall) == 2) {
  gap <- wisc_overall[is_twin == 0, mean_iq] - wisc_overall[is_twin == 1, mean_iq]
  cat(sprintf("  Gap (singleton - twin): %.1f points\n", gap))
}

# By race
wisc_race <- d[!is.na(wisc_fsiq), .(
  mean_iq = mean(wisc_fsiq),
  sd_iq = sd(wisc_fsiq),
  n = .N
), by = .(race, is_twin)]

cat("\nBy Race:\n")
cat(sprintf("  %-6s  %-12s  %8s  %8s  %5s\n", "Race", "Group", "Mean IQ", "SD", "N"))
cat("  ", strrep("-", 45), "\n")

for (r in sort(unique(wisc_race$race))) {
  for (tw in c(0, 1)) {
    row <- wisc_race[race == r & is_twin == tw]
    if (nrow(row) > 0) {
      lbl <- ifelse(tw == 0, "Singletons", "Twins")
      cat(sprintf("  %-6s  %-12s  %8.1f  %8.1f  %5d\n",
                  r, lbl, row$mean_iq, row$sd_iq, row$n))
    }
  }
  s_mean <- wisc_race[race == r & is_twin == 0, mean_iq]
  t_mean <- wisc_race[race == r & is_twin == 1, mean_iq]
  if (length(s_mean) > 0 & length(t_mean) > 0) {
    cat(sprintf("  %-6s  %-12s  %8.1f\n", "", "Gap:", s_mean - t_mean))
  }
}

# ── Regression with controls (Part B continued) ──────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Regression: IQ ~ Twin + Controls\n")
cat(strrep("-", 70), "\n")

# SB IQ
m1_sb <- lm(sb_iq ~ is_twin, data = d)
m2_sb <- lm(sb_iq ~ is_twin + race + sex + educ_yrs + sei_decimal + maternal_age +
              birth_wt_g + gest_age, data = d)

cat("\nStanford-Binet IQ:\n")
cat(sprintf("  Unadjusted:  b = %6.2f (SE = %.2f, p = %.4f), N = %d\n",
            coef(m1_sb)["is_twin"], summary(m1_sb)$coef["is_twin", 2],
            summary(m1_sb)$coef["is_twin", 4], nobs(m1_sb)))
cat(sprintf("  Adjusted:    b = %6.2f (SE = %.2f, p = %.4f), N = %d\n",
            coef(m2_sb)["is_twin"], summary(m2_sb)$coef["is_twin", 2],
            summary(m2_sb)$coef["is_twin", 4], nobs(m2_sb)))

# WISC FSIQ
m1_w <- lm(wisc_fsiq ~ is_twin, data = d)
m2_w <- lm(wisc_fsiq ~ is_twin + race + sex + educ_yrs + sei_decimal + maternal_age +
              birth_wt_g + gest_age, data = d)

cat("\nWISC FSIQ:\n")
cat(sprintf("  Unadjusted:  b = %6.2f (SE = %.2f, p = %.4f), N = %d\n",
            coef(m1_w)["is_twin"], summary(m1_w)$coef["is_twin", 2],
            summary(m1_w)$coef["is_twin", 4], nobs(m1_w)))
cat(sprintf("  Adjusted:    b = %6.2f (SE = %.2f, p = %.4f), N = %d\n",
            coef(m2_w)["is_twin"], summary(m2_w)$coef["is_twin", 2],
            summary(m2_w)$coef["is_twin", 4], nobs(m2_w)))

# Race interaction
m3_w <- lm(wisc_fsiq ~ is_twin * factor(race) + sex + educ_yrs + sei_decimal +
              maternal_age + birth_wt_g + gest_age, data = d)
cat("\nRace x Twin interaction (WISC):\n")
s3 <- summary(m3_w)$coefficients
for (nm in grep("is_twin", rownames(s3), value = TRUE)) {
  cat(sprintf("  %-35s  b = %6.2f (SE = %.2f, p = %.4f)\n",
              nm, s3[nm, 1], s3[nm, 2], s3[nm, 4]))
}

# ── Birth weight comparison (Part B continued) ───────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Birth Weight by Twin Status\n")
cat(strrep("-", 70), "\n")

bw_tab <- d[!is.na(birth_wt_g), .(
  mean_bw = mean(birth_wt_g),
  sd_bw = sd(birth_wt_g),
  n = .N
), by = is_twin]

cat(sprintf("  %-12s  %8s  %8s  %8s\n", "Group", "Mean BW", "SD", "N"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nrow(bw_tab)) {
  lbl <- ifelse(bw_tab[i, is_twin] == 0, "Singletons", "Twins")
  cat(sprintf("  %-12s  %8.0f  %8.0f  %8d\n",
              lbl, bw_tab[i, mean_bw], bw_tab[i, sd_bw], bw_tab[i, n]))
}

# ── Save ──────────────────────────────────────────────────────────────
results <- list(
  sb_overall = sb_overall,
  sb_race = sb_race,
  wisc_overall = wisc_overall,
  wisc_race = wisc_race,
  bw_table = bw_tab
)
saveRDS(results, "results_replication_myrianthopoulos.rds")
cat("\nResults saved to results_replication_myrianthopoulos.rds\n")
