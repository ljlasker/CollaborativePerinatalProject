#!/usr/bin/env Rscript
# fig_famsize_fertility.R — Family size gradient by fertility completion
# Shows that the family size–IQ gradient weakens among mothers with completed fertility

library(data.table)
library(fixest)

d <- readRDS("prepared_data.rds")

family_context <- d[, .(
  family_size = first(n_kids),
  max_mat_age = if (all(is.na(maternal_age))) NA_real_ else max(maternal_age, na.rm = TRUE)
), by = mother_id]

iq <- d[!is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
iq <- merge(iq, family_context, by = "mother_id", all.x = TRUE)
iq[family_size > 5, family_size := 5]  # cap at 5+ for display

# Use ASCII-only internal IDs. On Windows systems whose native locale cannot
# translate an en dash, using "30\u201334" as both a data value and a named-vector
# key can return NA styles. That made this group's line, points, error bars, and
# legend key invisible even though its legend text was still printed.
fert_groups <- c("age_lt30", "age_30_34", "age_35_plus")
fert_labels <- c(
  age_lt30 = "<30",
  age_30_34 = "30-34",
  age_35_plus = "35+"
)

iq[, fert_group := ifelse(max_mat_age >= 35, "age_35_plus",
                   ifelse(max_mat_age >= 30, "age_30_34", "age_lt30"))]
iq[, fert_group := factor(fert_group, levels = fert_groups)]

# Compute means by family size × fertility group
tab <- iq[, .(mean_iq = mean(wisc_fsiq),
              se_iq = sd(wisc_fsiq) / sqrt(.N),
              n = .N),
          by = .(family_size, fert_group)]
tab <- tab[order(fert_group, family_size)]

# All mothers (unstratified)
tab_all <- iq[, .(mean_iq = mean(wisc_fsiq),
                   se_iq = sd(wisc_fsiq) / sqrt(.N),
                   n = .N,
                   fert_group = factor("All", levels = "All")),
              by = family_size]

# Drop cells with < 15 observations
tab <- tab[n >= 15]
tab_all <- tab_all[n >= 15]
tab_all <- tab_all[order(family_size)]

cat("=== Data for figure ===\n")
print(tab)
cat("\n=== All mothers ===\n")
print(tab_all)

# Regression slopes
slopes <- list()
for (g in fert_groups) {
  m <- feols(wisc_fsiq ~ family_size + factor(sex) + factor(race),
             data = iq[fert_group == g], vcov = "hetero")
  slopes[[g]] <- coef(m)["family_size"]
}
m_all <- feols(wisc_fsiq ~ family_size + factor(sex) + factor(race),
               data = iq, vcov = "hetero")
slopes[["All"]] <- coef(m_all)["family_size"]

# ── Create figure ────────────────────────────────────────────────────
pdf("fig_famsize_fertility.pdf", width = 8, height = 6)

par(mar = c(5, 5, 4, 2), family = "serif")

style <- data.table(
  group = c("all", fert_groups),
  color = c("gray50", "#2C3E50", "#6C8EBF", "#8B1A1A"),
  pch = c(1, 16, 17, 15),
  lty = c(2, 1, 1, 1),
  offset = c(-0.18, -0.06, 0.06, 0.18)
)

# Fail loudly if a category or any visual style is missing. This guards the
# plotted series and legend against silent named-vector lookup failures.
stopifnot(
  identical(as.character(unique(tab$fert_group)), fert_groups),
  nrow(style) == length(fert_groups) + 1L,
  !anyDuplicated(style$group),
  !anyNA(style$color),
  !anyNA(style$pch),
  !anyNA(style$lty),
  !anyNA(style$offset)
)

# Y range
all_means <- c(tab$mean_iq, tab_all$mean_iq)
all_se <- c(tab$se_iq, tab_all$se_iq)
y_lo <- floor(min(all_means - 1.96 * all_se) / 2) * 2
y_hi <- ceiling(max(all_means + 1.96 * all_se) / 2) * 2
y_lo <- max(y_lo, 84)
y_hi <- min(y_hi, 100)

plot(NULL, xlim = c(0.7, 5.3), ylim = c(y_lo, y_hi),
     xaxt = "n", yaxt = "n", xlab = "", ylab = "", bty = "n")

# Gridlines
for (gy in seq(y_lo, y_hi, by = 2)) {
  segments(0.7, gy, 5.3, gy, col = "grey85", lwd = 0.5)
}

# Draw "All" first (behind the others)
sub_all <- tab_all
st <- style[group == "all"]
stopifnot(nrow(st) == 1L, nrow(sub_all) > 0L)
off <- st$offset
lines(sub_all$family_size + off, sub_all$mean_iq,
      col = st$color, lwd = 2, lty = st$lty)
arrows(sub_all$family_size + off, sub_all$mean_iq - 1.96 * sub_all$se_iq,
       sub_all$family_size + off, sub_all$mean_iq + 1.96 * sub_all$se_iq,
       code = 3, angle = 90, length = 0.03, col = st$color, lwd = 1.2)
points(sub_all$family_size + off, sub_all$mean_iq, pch = st$pch,
       col = st$color, cex = 1.5, lwd = 1.5)

# Stratified groups
for (g in fert_groups) {
  sub <- tab[fert_group == g]
  st <- style[group == g]
  stopifnot(nrow(st) == 1L, nrow(sub) > 0L)
  off <- st$offset

  lines(sub$family_size + off, sub$mean_iq,
        col = st$color, lwd = 2, lty = st$lty)
  arrows(sub$family_size + off, sub$mean_iq - 1.96 * sub$se_iq,
         sub$family_size + off, sub$mean_iq + 1.96 * sub$se_iq,
         code = 3, angle = 90, length = 0.03,
         col = st$color, lwd = 1.2)
  points(sub$family_size + off, sub$mean_iq,
         pch = st$pch, col = st$color, cex = 1.5)
}

# Axes
x_labels <- c("1", "2", "3", "4", "5+")
axis(1, at = 1:5, labels = x_labels, cex.axis = 0.95)
axis(2, at = seq(y_lo, y_hi, 2), las = 1, cex.axis = 0.9)
mtext("Number of children in family", side = 1, line = 2.5, cex = 1)
mtext("Mean WISC FSIQ", side = 2, line = 3, cex = 1)

# Title
mtext("Family Size and IQ by Fertility Completion", side = 3, line = 2.2,
      cex = 1.3, font = 2)
mtext("Stratified by maternal age at last observed CPP birth", side = 3, line = 0.9,
      cex = 0.95, col = "gray40")

# Use full (unfiltered) group counts for legend
n_all <- nrow(iq)
n_by_group <- setNames(
  vapply(fert_groups, function(g) nrow(iq[fert_group == g]), integer(1)),
  fert_groups
)

legend_text <- c(
  sprintf("All mothers (b = %.2f, n = %s)",
          slopes[["All"]], format(n_all, big.mark = ",")),
  vapply(fert_groups, function(g) {
    sprintf("%s at last birth (b = %.2f, n = %s)",
            fert_labels[[g]], slopes[[g]],
            format(n_by_group[[g]], big.mark = ","))
  }, character(1))
)

stopifnot(
  length(legend_text) == nrow(style),
  all(n_by_group > 0L),
  all(nzchar(legend_text))
)

legend("bottomleft",
       legend = legend_text,
       col = style$color,
       pch = style$pch,
       lty = style$lty, lwd = 2, pt.cex = 1.3,
       cex = 0.8, bty = "o", bg = "white", box.col = "gray80")

dev.off()
cat("\nFigure saved: fig_famsize_fertility.pdf\n")
