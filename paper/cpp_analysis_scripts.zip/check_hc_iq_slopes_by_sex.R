library(data.table)
library(fixest)

d <- as.data.table(readRDS("prepared_data.rds"))
growth <- as.data.table(readRDS("prepared_growth.rds"))

for (meas in c("head_circ_cm", "height_cm", "weight_g")) {
  g7 <- growth[measure == meas & age_months == 84,
               .(case_id = as.character(case_id), value)]
  short <- gsub("_cm$|_g$", "", meas)
  setnames(g7, "value", paste0(short, "_7yr"))
  d <- merge(d, g7, by = "case_id", all.x = TRUE)
}
d[, weight_7yr := weight_7yr / 1000]

hc <- d[race %in% c(1, 2) & !is.na(wisc_fsiq) & !is.na(head_circ_7yr)]
hc[, female := as.integer(sex == 2)]
hc[, race_label := ifelse(race == 1, "White", "Black")]

# ==== 1. HC-IQ slopes by sex ====
cat("=== HC-IQ SLOPES BY SEX ===\n\n")

# Pooled
m_pool <- feols(wisc_fsiq ~ head_circ_7yr, data = hc, vcov = "hetero")
cat(sprintf("Pooled:     b=%.3f (SE=%.3f)\n", coef(m_pool)["head_circ_7yr"], se(m_pool)["head_circ_7yr"]))

# By sex
for (s in c(1, 2)) {
  sl <- ifelse(s == 1, "Male", "Female")
  m <- feols(wisc_fsiq ~ head_circ_7yr, data = hc[sex == s], vcov = "hetero")
  cat(sprintf("%s:    b=%.3f (SE=%.3f)\n", sl, coef(m)["head_circ_7yr"], se(m)["head_circ_7yr"]))
}

# Interaction test
m_int <- feols(wisc_fsiq ~ head_circ_7yr * female, data = hc, vcov = "hetero")
cat(sprintf("Interaction: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_int)["head_circ_7yr:female"], se(m_int)["head_circ_7yr:female"],
            2*pnorm(-abs(coef(m_int)["head_circ_7yr:female"]/se(m_int)["head_circ_7yr:female"]))))

# With controls
cat("\n=== With race + height + weight controls ===\n")
hc_full <- hc[!is.na(height_7yr) & !is.na(weight_7yr)]
for (s in c(1, 2)) {
  sl <- ifelse(s == 1, "Male", "Female")
  m <- feols(wisc_fsiq ~ head_circ_7yr + factor(race) + height_7yr + weight_7yr,
             data = hc_full[sex == s], vcov = "hetero")
  cat(sprintf("%s:    b=%.3f (SE=%.3f)\n", sl, coef(m)["head_circ_7yr"], se(m)["head_circ_7yr"]))
}
m_int2 <- feols(wisc_fsiq ~ head_circ_7yr * female + factor(race) + height_7yr + weight_7yr,
                data = hc_full, vcov = "hetero")
cat(sprintf("Interaction: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_int2)["head_circ_7yr:female"], se(m_int2)["head_circ_7yr:female"],
            2*pnorm(-abs(coef(m_int2)["head_circ_7yr:female"]/se(m_int2)["head_circ_7yr:female"]))))

# ==== 2. HC-IQ slopes by race ====
cat("\n=== HC-IQ SLOPES BY RACE ===\n")
for (r in c(1, 2)) {
  rl <- ifelse(r == 1, "White", "Black")
  m <- feols(wisc_fsiq ~ head_circ_7yr, data = hc[race == r], vcov = "hetero")
  cat(sprintf("%s:    b=%.3f (SE=%.3f)\n", rl, coef(m)["head_circ_7yr"], se(m)["head_circ_7yr"]))
}
m_race_int <- feols(wisc_fsiq ~ head_circ_7yr * factor(race), data = hc, vcov = "hetero")
cat(sprintf("Race interaction: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_race_int)["head_circ_7yr:factor(race)2"],
            se(m_race_int)["head_circ_7yr:factor(race)2"],
            2*pnorm(-abs(coef(m_race_int)["head_circ_7yr:factor(race)2"]/
                         se(m_race_int)["head_circ_7yr:factor(race)2"]))))

# ==== 3. HC-IQ slopes by sex × race ====
cat("\n=== HC-IQ SLOPES BY SEX × RACE ===\n")
for (r in c(1, 2)) {
  for (s in c(1, 2)) {
    rl <- ifelse(r == 1, "White", "Black")
    sl <- ifelse(s == 1, "Male", "Female")
    sub <- hc[race == r & sex == s]
    m <- feols(wisc_fsiq ~ head_circ_7yr, data = sub, vcov = "hetero")
    cat(sprintf("%s %s:  b=%.3f (SE=%.3f), n=%d\n",
                rl, sl, coef(m)["head_circ_7yr"], se(m)["head_circ_7yr"], nrow(sub)))
  }
}

# ==== 4. Within-family HC-IQ by sex ====
cat("\n=== WITHIN-FAMILY HC-IQ BY SEX ===\n")
hc[, n_sibs := .N, by = mother_id]
hc_sib <- hc[n_sibs >= 2]

for (s in c(1, 2)) {
  sl <- ifelse(s == 1, "Male", "Female")
  # Same-sex sibships
  sub <- hc_sib[sex == s]
  sub[, n_same := .N, by = mother_id]
  sub2 <- sub[n_same >= 2]
  m <- feols(wisc_fsiq ~ head_circ_7yr | mother_id, data = sub2, vcov = ~mother_id)
  cat(sprintf("%s (same-sex sibs): b=%.3f (SE=%.3f), p=%.4f, n=%d, fam=%d\n",
              sl, coef(m)["head_circ_7yr"], se(m)["head_circ_7yr"],
              2*pnorm(-abs(coef(m)["head_circ_7yr"]/se(m)["head_circ_7yr"])),
              nrow(sub2), uniqueN(sub2$mother_id)))
}

# All sibs pooled (controlling for sex)
m_all <- feols(wisc_fsiq ~ head_circ_7yr + factor(sex) | mother_id,
               data = hc_sib, vcov = ~mother_id)
cat(sprintf("All sibs (sex ctrl): b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_all)["head_circ_7yr"], se(m_all)["head_circ_7yr"],
            2*pnorm(-abs(coef(m_all)["head_circ_7yr"]/se(m_all)["head_circ_7yr"]))))

# ==== 5. Within-family HC-IQ by race ====
cat("\n=== WITHIN-FAMILY HC-IQ BY RACE ===\n")
for (r in c(1, 2)) {
  rl <- ifelse(r == 1, "White", "Black")
  sub <- hc_sib[race == r]
  m <- feols(wisc_fsiq ~ head_circ_7yr + factor(sex) | mother_id,
             data = sub, vcov = ~mother_id)
  cat(sprintf("%s FE: b=%.3f (SE=%.3f), p=%.4f, n=%d\n",
              rl, coef(m)["head_circ_7yr"], se(m)["head_circ_7yr"],
              2*pnorm(-abs(coef(m)["head_circ_7yr"]/se(m)["head_circ_7yr"])),
              nrow(sub)))
}

# ==== 6. Test common regression: sex as intercept shift on HC-IQ line ====
cat("\n=== COMMON REGRESSION TEST: IQ ~ HC + sex ===\n")
m_common <- feols(wisc_fsiq ~ head_circ_7yr + female, data = hc, vcov = "hetero")
cat(sprintf("HC slope:     b=%.3f (SE=%.3f)\n", coef(m_common)["head_circ_7yr"], se(m_common)["head_circ_7yr"]))
cat(sprintf("Female shift: b=%.3f (SE=%.3f), p=%.1e\n",
            coef(m_common)["female"], se(m_common)["female"],
            2*pnorm(-abs(coef(m_common)["female"]/se(m_common)["female"]))))

# Same with all controls
m_common2 <- feols(wisc_fsiq ~ head_circ_7yr + female + factor(race) + height_7yr + weight_7yr,
                   data = hc_full, vcov = "hetero")
cat(sprintf("\nWith controls:\n"))
cat(sprintf("HC slope:     b=%.3f (SE=%.3f)\n", coef(m_common2)["head_circ_7yr"], se(m_common2)["head_circ_7yr"]))
cat(sprintf("Female shift: b=%.3f (SE=%.3f), p=%.1e\n",
            coef(m_common2)["female"], se(m_common2)["female"],
            2*pnorm(-abs(coef(m_common2)["female"]/se(m_common2)["female"]))))

# SB IQ
cat("\n=== SAME FOR SB IQ ===\n")
hc_sb <- hc[!is.na(sb_iq)]
for (s in c(1, 2)) {
  sl <- ifelse(s == 1, "Male", "Female")
  m <- feols(sb_iq ~ head_circ_7yr, data = hc_sb[sex == s], vcov = "hetero")
  cat(sprintf("%s:    b=%.3f (SE=%.3f)\n", sl, coef(m)["head_circ_7yr"], se(m)["head_circ_7yr"]))
}
m_sb_int <- feols(sb_iq ~ head_circ_7yr * female, data = hc_sb, vcov = "hetero")
cat(sprintf("Interaction: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_sb_int)["head_circ_7yr:female"], se(m_sb_int)["head_circ_7yr:female"],
            2*pnorm(-abs(coef(m_sb_int)["head_circ_7yr:female"]/se(m_sb_int)["head_circ_7yr:female"]))))

cat("\nDone.\n")
