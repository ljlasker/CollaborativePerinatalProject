#!/usr/bin/env Rscript
# 13_replication_turkheimer.R
# Replication: Turkheimer et al. (2003) — SES Moderation of IQ Heritability
#
# Original finding: In 319 CPP twin pairs (identified via Myrianthopoulos's
# blood-group classification), IQ heritability was near zero in impoverished
# families but substantial (~0.72) in affluent families. Shared environment
# accounted for ~58% of variance in low-SES families.
#
# Part A: Close replication using ONLY Myrianthopoulos-classified twins
# Part B: Extensions — sibling-only, multi-level with twin-specific effects
# Part C: g-loading x SES moderation analysis

library(data.table)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")

# Clean sentinel values in cognitive subtests
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}
if ("goodenough_standard" %in% names(d)) d[goodenough_standard == 888, goodenough_standard := NA]

twins <- fread(file.path("..", "clean", "cpp_twin_zygosity.csv"),
               colClasses = c(child1_id = "character", child2_id = "character",
                              mother_id = "character"))
links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

cat("\n")
cat("--- REPLICATION: Turkheimer et al. (2003) SES Moderation of IQ Heritability in Young Children ---
")

# PART A: CLOSE REPLICATION — Myrianthopoulos-Classified Twins Only
# Turkheimer used twins identified by Myrianthopoulos (1970/1975) via
# 9-system blood group panel + placental examination. We use ONLY pairs
# with myrianthop_zyg == 1 (MZ) or 2 (DZ), excluding our extended
# classification tiers (membrane, blood discordance, Bayesian model).
cat("\n")
cat("--- PART A: CLOSE REPLICATION — Myrianthopoulos Twins Only (Turkheimer et al. 2003, Psychological Science 14:623-628) ---
")

# ── Classification comparison ────────────────────────────────────────
cat("\nTwin zygosity classification sources:\n")
cat(sprintf("  Total twin pairs in file: %d\n", nrow(twins)))
cat(sprintf("  Myrianthopoulos classified (zyg=1 or 2): %d\n",
            twins[myrianthop_zyg %in% c(1, 2), .N]))
cat(sprintf("    MZ (myrianthop_zyg=1): %d\n", twins[myrianthop_zyg == 1, .N]))
cat(sprintf("    DZ (myrianthop_zyg=2): %d\n", twins[myrianthop_zyg == 2, .N]))
cat(sprintf("  Our extended classification (any MZ/DZ): %d\n",
            twins[grepl("^MZ|^DZ", zygosity_class), .N]))

# Use ONLY Myrianthopoulos classification for close replication
twins_myri <- twins[myrianthop_zyg %in% c(1, 2)]
twins_myri[, zyg := fifelse(myrianthop_zyg == 1, "MZ", "DZ")]

# ── Create twin-pair dataset ────────────────────────────────────────
d_slim <- d[, .(case_id, wisc_fsiq, sei_decimal, educ_yrs, income)]

tp_myri <- merge(twins_myri[, .(twin_pair_id, child1_id, child2_id, zyg)],
                 d_slim, by.x = "child1_id", by.y = "case_id")
setnames(tp_myri, c("wisc_fsiq", "sei_decimal", "educ_yrs", "income"),
         c("iq1", "sei1", "educ1", "income1"))
tp_myri <- merge(tp_myri, d_slim, by.x = "child2_id", by.y = "case_id")
setnames(tp_myri, c("wisc_fsiq", "sei_decimal", "educ_yrs", "income"),
         c("iq2", "sei2", "educ2", "income2"))

tp_myri[, sei := (sei1 + sei2) / 2]
tp_myri[, R := fifelse(zyg == "MZ", 1.0, 0.5)]

# Complete cases for WISC + SEI
tp <- tp_myri[!is.na(iq1) & !is.na(iq2) & !is.na(sei)]

cat(sprintf("\nMyrianthopoulos twin pairs with WISC FSIQ and SEI:\n"))
cat(sprintf("  MZ pairs: %d\n", tp[zyg == "MZ", .N]))
cat(sprintf("  DZ pairs: %d\n", tp[zyg == "DZ", .N]))
cat(sprintf("  Total:    %d\n", nrow(tp)))
cat(sprintf("\n  Turkheimer original: 319 pairs (114 MZ + 205 DZ)\n"))

# ── ICCs by zygosity and SES stratum ────────────────────────────────
tp[, iq1_z := as.numeric(scale(iq1))]
tp[, iq2_z := as.numeric(scale(iq2))]
tp[, sei_z := as.numeric(scale(sei))]

sei_med_tp <- median(tp$sei, na.rm = TRUE)
tp[, ses_grp := fifelse(sei <= sei_med_tp, "Low SES", "High SES")]

cat("\nIntraclass Correlations by Zygosity and SES:\n")
cat(sprintf("  %-5s  %12s  %12s\n", "Type", "Low SES", "High SES"))
cat("  ", strrep("-", 32), "\n")
for (z in c("MZ", "DZ")) {
  lo_r <- tp[zyg == z & ses_grp == "Low SES", cor(iq1, iq2, use = "complete.obs")]
  hi_r <- tp[zyg == z & ses_grp == "High SES", cor(iq1, iq2, use = "complete.obs")]
  lo_n <- tp[zyg == z & ses_grp == "Low SES", .N]
  hi_n <- tp[zyg == z & ses_grp == "High SES", .N]
  cat(sprintf("  %-5s  %.3f (%3d)  %.3f (%3d)\n", z, lo_r, lo_n, hi_r, hi_n))
}

# ── DeFries-Fulker regression ────────────────────────────────────────
# Double-enter: each twin serves as both proband and cotwin
tp_de <- rbind(
  tp[, .(iq_P = iq1_z, iq_C = iq2_z, R, sei = sei_z, zyg)],
  tp[, .(iq_P = iq2_z, iq_C = iq1_z, R, sei = sei_z, zyg)]
)

# Base DF model: C = b0 + b1*P + b2*R + b3*(P*R)
df_base <- lm(iq_C ~ iq_P + R + iq_P:R, data = tp_de)
sb <- summary(df_base)$coefficients

cat("\nBase DF Model (no moderation):\n")
cat(sprintf("  %-25s  %8s  %8s  %8s\n", "Term", "Estimate", "SE", "p"))
cat("  ", strrep("-", 55), "\n")
for (nm in rownames(sb)) {
  cat(sprintf("  %-25s  %8.3f  %8.3f  %8.4f\n", nm, sb[nm,1], sb[nm,2], sb[nm,4]))
}

b1 <- coef(df_base)["iq_P"]
b3 <- coef(df_base)["iq_P:R"]
cat(sprintf("\n  c^2 (shared env) = %.3f\n", b1))
cat(sprintf("  a^2 (genetic)    = %.3f\n", b3))
cat(sprintf("  e^2 (unique env) = %.3f\n", 1 - b1 - b3))

# Moderated DF model: add SES interactions
df_mod <- lm(iq_C ~ iq_P * R * sei, data = tp_de)
sm <- summary(df_mod)$coefficients

cat("\nModerated DF Model (SES interaction):\n")
cat(sprintf("  %-25s  %8s  %8s  %8s\n", "Term", "Estimate", "SE", "p"))
cat("  ", strrep("-", 55), "\n")
for (nm in rownames(sm)) {
  cat(sprintf("  %-25s  %8.3f  %8.3f  %8.4f\n", nm, sm[nm,1], sm[nm,2], sm[nm,4]))
}

# ACE at low (-1 SD) and high (+1 SD) SES
cf <- coef(df_mod)
ses_vals <- c("Low (-1SD)" = -1, "Mean (0)" = 0, "High (+1SD)" = 1)
cat("\nACE Components Across SES Levels:\n")
cat(sprintf("  %-15s  %8s  %8s  %8s\n", "SES Level", "a^2", "c^2", "e^2"))
cat("  ", strrep("-", 45), "\n")

for (i in seq_along(ses_vals)) {
  s <- ses_vals[i]
  c2 <- cf["iq_P"] + cf["iq_P:sei"] * s
  a2 <- cf["iq_P:R"] + cf["iq_P:R:sei"] * s
  e2 <- 1 - a2 - c2
  cat(sprintf("  %-15s  %8.3f  %8.3f  %8.3f\n", names(ses_vals)[i], a2, c2, e2))
}

cat("\n  Turkheimer original:\n")
cat("    h^2 ~ 0.00 at low SES, h^2 ~ 0.72 at high SES\n")
cat("    c^2 ~ 0.58 at low SES, c^2 ~ 0.00 at high SES\n")

# ── Scarr-Rowe at both ages: SB (age 4) vs WISC (age 7) ──────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Scarr-Rowe Interaction: Stanford-Binet (age 4) vs WISC (age 7)\n")
cat(strrep("-", 70), "\n")

# Twin-only DF for both measures
for (outcome in c("sb_iq", "wisc_fsiq")) {
  label <- if (outcome == "sb_iq") "Stanford-Binet (age 4)" else "WISC FSIQ (age 7)"

  d_slim_o <- d[, c("case_id", outcome, "sei_decimal"), with = FALSE]
  setnames(d_slim_o, outcome, "iq_score")

  tp_o <- merge(twins_myri[, .(twin_pair_id, child1_id, child2_id, zyg)],
                d_slim_o, by.x = "child1_id", by.y = "case_id")
  setnames(tp_o, c("iq_score", "sei_decimal"), c("iq1", "sei1"))
  tp_o <- merge(tp_o, d_slim_o, by.x = "child2_id", by.y = "case_id")
  setnames(tp_o, c("iq_score", "sei_decimal"), c("iq2", "sei2"))
  tp_o[, sei := (sei1 + sei2) / 2]
  tp_o[, R := fifelse(zyg == "MZ", 1.0, 0.5)]
  tp_o <- tp_o[!is.na(iq1) & !is.na(iq2) & !is.na(sei)]

  tp_o[, iq1_z := as.numeric(scale(iq1))]
  tp_o[, iq2_z := as.numeric(scale(iq2))]
  tp_o[, sei_z := as.numeric(scale(sei))]

  tp_de_o <- rbind(
    tp_o[, .(iq_P = iq1_z, iq_C = iq2_z, R, sei = sei_z)],
    tp_o[, .(iq_P = iq2_z, iq_C = iq1_z, R, sei = sei_z)]
  )

  df_mod_o <- lm(iq_C ~ iq_P * R * sei, data = tp_de_o)
  cf_o <- coef(df_mod_o)
  sm_o <- summary(df_mod_o)$coefficients
  p_3way_o <- sm_o["iq_P:R:sei", 4]

  a2_lo_o <- cf_o["iq_P:R"] + cf_o["iq_P:R:sei"] * (-1)
  a2_hi_o <- cf_o["iq_P:R"] + cf_o["iq_P:R:sei"] * (1)

  n_mz_o <- tp_o[zyg == "MZ", .N]
  n_dz_o <- tp_o[zyg == "DZ", .N]

  cat(sprintf("\n  %s (N = %d pairs: %d MZ, %d DZ):\n",
              label, nrow(tp_o), n_mz_o, n_dz_o))
  cat(sprintf("    a^2(lo) = %.3f, a^2(hi) = %.3f, delta = %.3f\n",
              a2_lo_o, a2_hi_o, a2_hi_o - a2_lo_o))
  cat(sprintf("    c^2(lo) = %.3f, c^2(hi) = %.3f\n",
              cf_o["iq_P"] + cf_o["iq_P:sei"] * (-1),
              cf_o["iq_P"] + cf_o["iq_P:sei"] * (1)))
  cat(sprintf("    3-way interaction p = %.4f%s\n",
              p_3way_o, ifelse(p_3way_o < 0.05, " *", "")))
}

# Multi-level DF (MZ+DZ+FS) for both measures
cat("\n  Multi-level DF (MZ+DZ+FS, no HS) by outcome:\n")
for (outcome in c("sb_iq", "wisc_fsiq")) {
  label <- if (outcome == "sb_iq") "SB (age 4)" else "WISC (age 7)"

  iq_data_o <- d[!is.na(get(outcome)), c("case_id", outcome, "sei_decimal"), with = FALSE]
  setnames(iq_data_o, outcome, "iq_score")

  pair_o <- merge(links, iq_data_o, by.x = "id_1", by.y = "case_id")
  setnames(pair_o, c("iq_score", "sei_decimal"), c("iq1", "sei1"))
  pair_o <- merge(pair_o, iq_data_o, by.x = "id_2", by.y = "case_id")
  setnames(pair_o, c("iq_score", "sei_decimal"), c("iq2", "sei2"))
  pair_o[, sei_mean := (sei1 + sei2) / 2]
  pair_o[, pair_class := fcase(
    pair_type == "MZ_twin", "MZ",
    pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
    pair_type == "full_sibling", "FS",
    default = NA_character_
  )]
  pair_o <- pair_o[!is.na(pair_class) & !is.na(sei_mean)]
  pair_o[, R := fifelse(pair_class == "MZ", 1.0, 0.5)]
  pair_o[, is_twin := as.integer(pair_class %in% c("MZ", "DZ"))]
  pair_o[, iq1_z := as.numeric(scale(iq1))]
  pair_o[, iq2_z := as.numeric(scale(iq2))]
  pair_o[, sei_z := as.numeric(scale(sei_mean))]

  pair_de_o <- rbind(
    pair_o[, .(iq_P = iq1_z, iq_C = iq2_z, R, sei = sei_z, is_twin)],
    pair_o[, .(iq_P = iq2_z, iq_C = iq1_z, R, sei = sei_z, is_twin)]
  )

  fit_ml_o <- lm(iq_C ~ iq_P * R * sei + iq_P:is_twin + iq_P:is_twin:sei,
                 data = pair_de_o)
  cf_ml <- coef(fit_ml_o)
  sm_ml <- summary(fit_ml_o)$coefficients
  p_3way_ml <- sm_ml["iq_P:R:sei", 4]

  a2_lo_ml <- cf_ml["iq_P:R"] + cf_ml["iq_P:R:sei"] * (-1)
  a2_hi_ml <- cf_ml["iq_P:R"] + cf_ml["iq_P:R:sei"] * (1)
  n_ml <- nrow(pair_o)

  cat(sprintf("    %s: a^2(lo)=%.3f, a^2(hi)=%.3f, delta=%.3f, p=%.4f%s (N=%d)\n",
              label, a2_lo_ml, a2_hi_ml, a2_hi_ml - a2_lo_ml,
              p_3way_ml, ifelse(p_3way_ml < 0.05, " *", ""), n_ml))
}

# ── Scarr-Rowe within racial groups ──────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Scarr-Rowe Interaction: Within-Race Analysis\n")
cat(strrep("-", 70), "\n")

# Build kinship pairs with IQ, SEI, and race for this analysis
iq_race <- d[!is.na(wisc_fsiq), .(case_id, wisc_fsiq, sei_decimal, race_label)]
pair_race <- merge(links, iq_race, by.x = "id_1", by.y = "case_id")
setnames(pair_race, c("wisc_fsiq", "sei_decimal", "race_label"),
         c("iq1", "sei1", "race1"))
pair_race <- merge(pair_race, iq_race, by.x = "id_2", by.y = "case_id")
setnames(pair_race, c("wisc_fsiq", "sei_decimal", "race_label"),
         c("iq2", "sei2", "race2"))
pair_race[, sei_mean := (sei1 + sei2) / 2]
pair_race[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair_race <- pair_race[!is.na(pair_class) & !is.na(sei_mean)]

# Keep only concordant-race pairs
pair_race <- pair_race[race1 == race2]
pair_race[, R := fcase(pair_class == "MZ", 1.0,
                        pair_class %in% c("DZ", "FS"), 0.5,
                        pair_class == "HS", 0.25)]
pair_race[, is_twin := as.integer(pair_class %in% c("MZ", "DZ"))]
pair_race[, iq1_z_r := as.numeric(scale(iq1))]
pair_race[, iq2_z_r := as.numeric(scale(iq2))]
pair_race[, sei_z_r := as.numeric(scale(sei_mean))]

# ── Baseline heritability by race ──────────────────────────────────
cat("\n  IQ correlations by pair type and race:\n")
cat(sprintf("  %-8s  %-5s  %8s  %6s\n", "Race", "Type", "r(IQ)", "N"))
cat("  ", strrep("-", 35), "\n")
for (rc in c("White", "Black")) {
  for (pc in c("MZ", "DZ", "FS", "HS")) {
    sub <- pair_race[race1 == rc & pair_class == pc]
    if (nrow(sub) >= 10) {
      r_val <- cor(sub$iq1, sub$iq2, use = "complete.obs")
      cat(sprintf("  %-8s  %-5s  %8.3f  %6d\n", rc, pc, r_val, nrow(sub)))
    } else {
      cat(sprintf("  %-8s  %-5s  %8s  %6d\n", rc, pc, "  --  ", nrow(sub)))
    }
  }
}

# Falconer ACE by race
cat("\n  Falconer ACE by race:\n")
cat(sprintf("  %-8s  %-15s  %6s  %6s  %6s  %12s  %12s\n",
            "Race", "Method", "a^2", "c^2", "e^2", "r(high)", "r(low)"))
cat("  ", strrep("-", 75), "\n")

for (rc in c("White", "Black")) {
  sub_rc <- pair_race[race1 == rc]

  # Get correlations by pair type
  r_mz_rc <- sub_rc[pair_class == "MZ" & .N >= 10, cor(iq1, iq2)]
  r_dz_rc <- sub_rc[pair_class == "DZ" & .N >= 10, cor(iq1, iq2)]
  r_fs_rc <- sub_rc[pair_class == "FS" & .N >= 10, cor(iq1, iq2)]
  r_hs_rc <- sub_rc[pair_class == "HS" & .N >= 10, cor(iq1, iq2)]

  # Classic twin: MZ vs DZ
  if (length(r_mz_rc) > 0 & length(r_dz_rc) > 0) {
    a2_td <- 2 * (r_mz_rc - r_dz_rc)
    c2_td <- 2 * r_dz_rc - r_mz_rc
    e2_td <- 1 - r_mz_rc
    cat(sprintf("  %-8s  %-15s  %6.3f  %6.3f  %6.3f  %12.3f  %12.3f\n",
                rc, "MZ vs DZ", a2_td, c2_td, e2_td, r_mz_rc, r_dz_rc))
  }

  # MZ vs FS (higher power at R=0.5)
  if (length(r_mz_rc) > 0 & length(r_fs_rc) > 0) {
    a2_mf <- 2 * (r_mz_rc - r_fs_rc)
    c2_mf <- 2 * r_fs_rc - r_mz_rc
    e2_mf <- 1 - r_mz_rc
    cat(sprintf("  %-8s  %-15s  %6.3f  %6.3f  %6.3f  %12.3f  %12.3f\n",
                rc, "MZ vs FS", a2_mf, c2_mf, e2_mf, r_mz_rc, r_fs_rc))
  }

  # FS vs HS (sibling-only)
  if (length(r_fs_rc) > 0 & length(r_hs_rc) > 0) {
    a2_fh <- (r_fs_rc - r_hs_rc) / 0.25
    c2_fh <- r_hs_rc - 0.25 * a2_fh
    e2_fh <- 1 - 0.5 * a2_fh - c2_fh
    cat(sprintf("  %-8s  %-15s  %6.3f  %6.3f  %6.3f  %12.3f  %12.3f\n",
                rc, "FS vs HS", a2_fh, c2_fh, e2_fh, r_fs_rc, r_hs_rc))
  }

  # Multi-level Falconer (WLS on all 4 pair types)
  cor_by_type <- sub_rc[, .(r = cor(iq1, iq2), n = .N), by = pair_class]
  cor_by_type[, R_val := fcase(pair_class == "MZ", 1.0,
                                pair_class %in% c("DZ", "FS"), 0.5,
                                pair_class == "HS", 0.25)]
  if (nrow(cor_by_type[n >= 10]) >= 3) {
    wls_fit <- lm(r ~ R_val, data = cor_by_type[n >= 10], weights = n)
    a2_wls <- coef(wls_fit)["R_val"]
    c2_wls <- coef(wls_fit)["(Intercept)"]
    e2_wls <- 1 - a2_wls - c2_wls
    cat(sprintf("  %-8s  %-15s  %6.3f  %6.3f  %6.3f  %12s  %12s\n",
                rc, "Multi-level WLS", a2_wls, c2_wls, e2_wls, "  --  ", "  --  "))
  }
}

# SES baselines by race
cat("\n  SES baselines by race (all kinship pairs):\n")
for (rc in c("White", "Black")) {
  sub <- pair_race[race1 == rc]
  cat(sprintf("    %s: N=%d, mean SEI=%.2f, SD=%.2f, median=%.2f\n",
              rc, nrow(sub), mean(sub$sei_mean), sd(sub$sei_mean), median(sub$sei_mean)))
}

# Drop HS for moderated DF (sparse at high SES, consistent with B4)
pair_race_nohs <- pair_race[pair_class %in% c("MZ", "DZ", "FS")]

cat("\n  Multi-level DF (MZ+DZ+FS) within racial groups:\n")
cat(sprintf("  %-8s  %6s  %8s  %8s  %8s  %10s\n",
            "Race", "N", "a2(lo)", "a2(hi)", "delta", "p(3-way)"))
cat("  ", strrep("-", 55), "\n")

for (rc in c("White", "Black", "Overall")) {
  if (rc == "Overall") {
    sub <- pair_race_nohs
  } else {
    sub <- pair_race_nohs[race1 == rc]
  }

  if (nrow(sub) < 100) next

  sub_de <- rbind(
    sub[, .(iq_P = iq1_z_r, iq_C = iq2_z_r, R, sei = sei_z_r, is_twin)],
    sub[, .(iq_P = iq2_z_r, iq_C = iq1_z_r, R, sei = sei_z_r, is_twin)]
  )

  fit_rc <- lm(iq_C ~ iq_P * R * sei + iq_P:is_twin + iq_P:is_twin:sei,
               data = sub_de)
  cf_rc <- coef(fit_rc)
  sm_rc <- summary(fit_rc)$coefficients

  p_3way_rc <- sm_rc["iq_P:R:sei", 4]
  a2_lo_rc <- cf_rc["iq_P:R"] + cf_rc["iq_P:R:sei"] * (-1)
  a2_hi_rc <- cf_rc["iq_P:R"] + cf_rc["iq_P:R:sei"] * (1)

  cat(sprintf("  %-8s  %6d  %8.3f  %8.3f  %8.3f  %10.4f%s\n",
              rc, nrow(sub), a2_lo_rc, a2_hi_rc,
              a2_hi_rc - a2_lo_rc, p_3way_rc,
              ifelse(p_3way_rc < 0.05, " *", ifelse(p_3way_rc < 0.10, " +", ""))))
}

# Also test with race as a covariate in the full model
pair_race_nohs[, is_black := as.integer(race1 == "Black")]
full_de <- rbind(
  pair_race_nohs[, .(iq_P = iq1_z_r, iq_C = iq2_z_r, R, sei = sei_z_r,
                is_twin, is_black)],
  pair_race_nohs[, .(iq_P = iq2_z_r, iq_C = iq1_z_r, R, sei = sei_z_r,
                is_twin, is_black)]
)

fit_race_ctrl <- lm(iq_C ~ iq_P * R * sei + iq_P:is_twin + iq_P:is_twin:sei +
                      is_black + iq_P:is_black + iq_P:R:is_black,
                    data = full_de)
sm_race_ctrl <- summary(fit_race_ctrl)$coefficients
p_3way_ctrl <- sm_race_ctrl["iq_P:R:sei", 4]
cf_ctrl <- coef(fit_race_ctrl)
a2_lo_ctrl <- cf_ctrl["iq_P:R"] + cf_ctrl["iq_P:R:sei"] * (-1)
a2_hi_ctrl <- cf_ctrl["iq_P:R"] + cf_ctrl["iq_P:R:sei"] * (1)

cat(sprintf("\n  Race-controlled model (with race main effect + interactions):\n"))
cat(sprintf("    a^2(lo) = %.3f, a^2(hi) = %.3f, delta = %.3f, p(3-way) = %.4f%s\n",
            a2_lo_ctrl, a2_hi_ctrl, a2_hi_ctrl - a2_lo_ctrl, p_3way_ctrl,
            ifelse(p_3way_ctrl < 0.05, " *", "")))

# ── Scarr-Rowe by cognitive measure (age 7 non-WISC tests) ──────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Scarr-Rowe Interaction: By Cognitive Measure (Multi-Level DF)\n")
cat(strrep("-", 70), "\n")

test_vars <- c("wisc_fsiq", "sb_iq", "wrat_read_raw",
               "bender_gestalt", "goodenough_raw",
               "wrat_spell_raw", "wrat_arith_raw")
test_labels <- c("WISC FSIQ (age 7)", "Stanford-Binet (age 4)",
                 "WRAT Reading (age 7)",
                 "Bender Gestalt (age 7)", "Goodenough (age 7)",
                 "WRAT Spelling (age 7)", "WRAT Arith (age 7)")

cat(sprintf("\n  %-25s  %6s  %8s  %8s  %8s  %10s\n",
            "Measure", "N", "a2(lo)", "a2(hi)", "delta", "p(3-way)"))
cat("  ", strrep("-", 65), "\n")

for (k in seq_along(test_vars)) {
  tv <- test_vars[k]
  tl <- test_labels[k]

  # Clean sentinels
  iq_t <- copy(d[, c("case_id", tv, "sei_decimal"), with = FALSE])
  setnames(iq_t, tv, "score")
  if (tv %in% c("wisc_picarr", "wisc_block", "wisc_coding")) {
    iq_t[score == 88, score := NA]
  }
  if (tv == "goodenough_standard") iq_t[score == 888, score := NA]
  if (tv == "goodenough_raw") iq_t[score > 70, score := NA]  # sanity check
  # bender_gestalt is already reversed (higher = better) in data prep
  iq_t <- iq_t[!is.na(score) & !is.na(sei_decimal)]

  pair_t <- merge(links, iq_t, by.x = "id_1", by.y = "case_id")
  setnames(pair_t, c("score", "sei_decimal"), c("s1", "sei1"))
  pair_t <- merge(pair_t, iq_t, by.x = "id_2", by.y = "case_id")
  setnames(pair_t, c("score", "sei_decimal"), c("s2", "sei2"))
  pair_t[, sei_mean := (sei1 + sei2) / 2]
  pair_t[, pc := fcase(
    pair_type == "MZ_twin", "MZ",
    pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
    pair_type == "full_sibling", "FS",
    default = NA_character_
  )]
  pair_t <- pair_t[!is.na(pc) & !is.na(sei_mean)]
  pair_t[, R := fifelse(pc == "MZ", 1.0, 0.5)]
  pair_t[, is_twin := as.integer(pc %in% c("MZ", "DZ"))]
  pair_t[, s1_z := as.numeric(scale(s1))]
  pair_t[, s2_z := as.numeric(scale(s2))]
  pair_t[, sei_z := as.numeric(scale(sei_mean))]

  pair_de_t <- rbind(
    pair_t[, .(iq_P = s1_z, iq_C = s2_z, R, sei = sei_z, is_twin)],
    pair_t[, .(iq_P = s2_z, iq_C = s1_z, R, sei = sei_z, is_twin)]
  )

  fit_t <- tryCatch(
    lm(iq_C ~ iq_P * R * sei + iq_P:is_twin + iq_P:is_twin:sei,
       data = pair_de_t),
    error = function(e) NULL
  )

  if (!is.null(fit_t)) {
    cf_t <- coef(fit_t)
    sm_t <- summary(fit_t)$coefficients
    p_t <- sm_t["iq_P:R:sei", 4]
    a2_lo_t <- cf_t["iq_P:R"] + cf_t["iq_P:R:sei"] * (-1)
    a2_hi_t <- cf_t["iq_P:R"] + cf_t["iq_P:R:sei"] * (1)
    cat(sprintf("  %-25s  %6d  %8.3f  %8.3f  %8.3f  %10.4f%s\n",
                tl, nrow(pair_t), a2_lo_t, a2_hi_t,
                a2_hi_t - a2_lo_t, p_t,
                ifelse(p_t < 0.05, " *", ifelse(p_t < 0.10, " +", ""))))
  }
}

# PART B: EXTENSIONS
# B1: Correlations by pair type x SES (each type separately)
# B2: Unmoderated heritability from all pairwise kinship contrasts
# B3: Falconer ACE by SES (multiple reference groups)
# B4: Multi-level DF (MZ + DZ + FS, dropping HS) with SES moderation
cat("\n")
cat("--- PART B: EXTENSIONS — Pair-Type-Specific and Multi-Level Analyses ---
")

# ── Merge IQ and SES onto all kinship pairs ──────────────────────────
iq_data <- d[!is.na(wisc_fsiq), .(case_id, wisc_fsiq, sei_decimal)]
pair_iq <- merge(links, iq_data, by.x = "id_1", by.y = "case_id")
setnames(pair_iq, c("wisc_fsiq", "sei_decimal"), c("iq1", "sei1"))
pair_iq <- merge(pair_iq, iq_data, by.x = "id_2", by.y = "case_id")
setnames(pair_iq, c("wisc_fsiq", "sei_decimal"), c("iq2", "sei2"))
pair_iq[, sei_mean := (sei1 + sei2) / 2]

pair_iq[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair_iq <- pair_iq[!is.na(pair_class) & !is.na(sei_mean)]

cat(sprintf("\nTotal kinship pairs with IQ and SEI: %d\n", nrow(pair_iq)))
cat(sprintf("  MZ: %d, DZ: %d, FS: %d, HS: %d\n",
            pair_iq[pair_class == "MZ", .N], pair_iq[pair_class == "DZ", .N],
            pair_iq[pair_class == "FS", .N], pair_iq[pair_class == "HS", .N]))

# ── Overall correlations by pair type ────────────────────────────────
cor_all <- pair_iq[, .(r = cor(iq1, iq2), n = .N), by = pair_class]
setorder(cor_all, pair_class)

# ── B1: Correlations by pair type x SES ──────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("B1: IQ Correlations by Pair Type and SES\n")
cat(strrep("-", 70), "\n")

# Median split
sei_med <- median(pair_iq$sei_mean, na.rm = TRUE)
pair_iq[, ses_group := fifelse(sei_mean <= sei_med, "Low SES", "High SES")]

cor_tab <- pair_iq[, .(r = cor(iq1, iq2), n = .N), by = .(ses_group, pair_class)]

cat("\n  Overall and median-split correlations:\n")
cat(sprintf("  %-5s  %12s  %12s  %12s\n", "Type", "Overall", "Low SES", "High SES"))
cat("  ", strrep("-", 48), "\n")

for (pc in c("MZ", "DZ", "FS", "HS")) {
  ov <- cor_all[pair_class == pc]
  lo <- cor_tab[pair_class == pc & ses_group == "Low SES"]
  hi <- cor_tab[pair_class == pc & ses_group == "High SES"]
  ov_str <- if (nrow(ov)) sprintf("%.3f (%4d)", ov$r, ov$n) else "   --   "
  lo_str <- if (nrow(lo)) sprintf("%.3f (%4d)", lo$r, lo$n) else "   --   "
  hi_str <- if (nrow(hi)) sprintf("%.3f (%4d)", hi$r, hi$n) else "   --   "
  cat(sprintf("  %-5s  %12s  %12s  %12s\n", pc, ov_str, lo_str, hi_str))
}

# ── B2: Unmoderated heritability from pairwise contrasts ─────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("B2: Heritability from Pairwise Kinship Contrasts (Unmoderated)\n")
cat(strrep("-", 70), "\n")
cat("  a^2 = (r_high - r_low) / (R_high - R_low)\n")
cat("  If the additive genetic model is correct, all contrasts should\n")
cat("  converge on similar a^2 estimates.\n\n")

# Define all pairwise contrasts with their R values
contrast_pairs <- list(
  list(hi = "MZ", lo = "DZ",  Rhi = 1.0,  Rlo = 0.5),
  list(hi = "MZ", lo = "FS",  Rhi = 1.0,  Rlo = 0.5),
  list(hi = "MZ", lo = "HS",  Rhi = 1.0,  Rlo = 0.25),
  list(hi = "DZ", lo = "HS",  Rhi = 0.5,  Rlo = 0.25),
  list(hi = "FS", lo = "HS",  Rhi = 0.5,  Rlo = 0.25)
)

cat(sprintf("  %-15s  %6s  %6s  %6s  %6s  %8s  %8s\n",
            "Contrast", "r(hi)", "r(lo)", "R(hi)", "R(lo)", "a^2", "c^2"))
cat("  ", strrep("-", 70), "\n")

for (cp in contrast_pairs) {
  r_hi <- cor_all[pair_class == cp$hi, r]
  r_lo <- cor_all[pair_class == cp$lo, r]
  n_hi <- cor_all[pair_class == cp$hi, n]
  n_lo <- cor_all[pair_class == cp$lo, n]

  if (length(r_hi) > 0 & length(r_lo) > 0) {
    a2 <- (r_hi - r_lo) / (cp$Rhi - cp$Rlo)
    # c^2 = r_lo - R_lo * a^2 (expected correlation at R_lo without c^2 = R_lo * a^2)
    c2 <- r_lo - cp$Rlo * a2
    label <- sprintf("%s vs %s", cp$hi, cp$lo)
    cat(sprintf("  %-15s  %6.3f  %6.3f  %6.2f  %6.2f  %8.3f  %8.3f\n",
                label, r_hi, r_lo, cp$Rhi, cp$Rlo, a2, c2))
  }
}

cat("\n  Interpretation:\n")
cat("  - MZ-vs-DZ (classic twin): standard twin-study estimate\n")
cat("  - MZ-vs-FS: leverages 6,800+ sibling pairs at R=0.5 (high power)\n")
cat("  - FS-vs-HS: purely sibling-based, no twins needed\n")
cat("  - Convergence across contrasts supports the additive genetic model\n")
cat("    and validates HS pairs as a useful fourth relatedness level.\n")
cat("  - The systematic increase in a^2 from MZ-DZ to FS-HS may reflect\n")
cat("    assortative mating (inflating true R) and/or non-additive effects.\n")

# ── B2a: Joint AM + Twin-Specific c² Model (Analytical Solution) ─────
cat("\n")
cat(strrep("-", 70), "\n")
cat("B2a: Joint Assortative Mating + Twin-Specific Shared Environment\n")
cat(strrep("-", 70), "\n")
cat("  With 4 observed correlations (MZ, DZ, FS, HS) we can exactly\n")
cat("  identify 4 parameters: a^2, c^2_fam, c^2_twin, and mu (spousal\n")
cat("  phenotypic IQ correlation) without assuming any value for mu.\n\n")
cat("  Model:\n")
cat("    r_MZ = a^2 + c^2_fam + c^2_twin\n")
cat("    r_DZ = a^2*(1+m)/2 + c^2_fam + c^2_twin   where m = mu*a^2\n")
cat("    r_FS = a^2*(1+m)/2 + c^2_fam\n")
cat("    r_HS = a^2*(1+m)/4 + c^2_fam\n\n")

# Load father education for spousal correlation (validation)
ses_det <- fread(file.path("..", "clean", "cpp_ses_detailed.csv"),
                 colClasses = c(case_id = "character"))
ses_det[father_education == 99, father_education := NA]
am_data <- merge(d[, .(case_id, educ_yrs)],
                 ses_det[, .(case_id, father_education)],
                 by = "case_id")
am_data <- am_data[!is.na(educ_yrs) & !is.na(father_education)]
r_edu <- cor(am_data$educ_yrs, am_data$father_education)
cat(sprintf("  Spousal education correlation: r = %.3f (N = %d)\n\n", r_edu, nrow(am_data)))

# Get overall correlations
r_mz <- cor_all[pair_class == "MZ", r]
r_dz <- cor_all[pair_class == "DZ", r]
r_fs <- cor_all[pair_class == "FS", r]
r_hs <- cor_all[pair_class == "HS", r]

cat(sprintf("  Observed correlations: MZ=%.3f, DZ=%.3f, FS=%.3f, HS=%.3f\n",
            r_mz, r_dz, r_fs, r_hs))

# ── Analytical solution ──
# c^2_twin = r_DZ - r_FS (both have same R, differ only in twin c^2)
c2_twin_est <- r_dz - r_fs

# Let A = r_MZ - r_DZ, B = r_FS - r_HS
# From the model:
#   A = a^2*(1-m)/2  ... MZ vs DZ difference
#   B = a^2*(1+m)/4  ... FS vs HS difference
# Solving: m = (2B - A) / (A + 2B)
A <- r_mz - r_dz
B <- r_fs - r_hs
m_est <- (2 * B - A) / (A + 2 * B)  # m = mu * a^2 (genetic spousal correlation)

# a^2 = 2A / (1 - m)
a2_est <- 2 * A / (1 - m_est)

# mu = m / a^2
mu_est <- m_est / a2_est

# c^2_fam = r_HS - a^2*(1+m)/4
c2_fam_est <- r_hs - a2_est * (1 + m_est) / 4

# e^2 = 1 - a^2 - c^2_fam - c^2_twin
e2_est <- 1 - a2_est - c2_fam_est - c2_twin_est

cat("\n  Analytical solution (exactly identified):\n")
cat(strrep("  ", 1), strrep("-", 45), "\n")
cat(sprintf("  a^2 (additive genetic)    = %.3f\n", a2_est))
cat(sprintf("  c^2_fam (family shared)   = %.3f\n", c2_fam_est))
cat(sprintf("  c^2_twin (twin-specific)  = %.3f\n", c2_twin_est))
cat(sprintf("  e^2 (non-shared env)      = %.3f\n", e2_est))
cat(sprintf("  mu (spousal IQ corr.)     = %.3f\n", mu_est))
cat(sprintf("  m = mu*a^2 (genetic AM)   = %.3f\n", m_est))
cat(strrep("  ", 1), strrep("-", 45), "\n")

# Verify: predicted correlations
pred_mz <- a2_est + c2_fam_est + c2_twin_est
pred_dz <- a2_est * (1 + m_est) / 2 + c2_fam_est + c2_twin_est
pred_fs <- a2_est * (1 + m_est) / 2 + c2_fam_est
pred_hs <- a2_est * (1 + m_est) / 4 + c2_fam_est

cat("\n  Verification (predicted vs observed):\n")
cat(sprintf("    MZ: pred=%.3f, obs=%.3f\n", pred_mz, r_mz))
cat(sprintf("    DZ: pred=%.3f, obs=%.3f\n", pred_dz, r_dz))
cat(sprintf("    FS: pred=%.3f, obs=%.3f\n", pred_fs, r_fs))
cat(sprintf("    HS: pred=%.3f, obs=%.3f\n", pred_hs, r_hs))

# AM-corrected R values
R_adj_DZ <- (1 + m_est) / 2
R_adj_HS <- (1 + m_est) / 4
cat(sprintf("\n  AM-corrected relatedness: R*_DZ = R*_FS = %.3f (nom 0.50), R*_HS = %.3f (nom 0.25)\n",
            R_adj_DZ, R_adj_HS))

# Now show corrected pairwise contrasts using the estimated mu
cat(sprintf("\n  Pairwise contrasts: uncorrected vs AM-corrected (mu = %.3f):\n", mu_est))
cat(sprintf("  %-15s  %10s  %10s\n", "Contrast", "Uncorr a^2", "AM-corr a^2"))
cat("  ", strrep("-", 40), "\n")

for (cp in contrast_pairs) {
  r_hi <- cor_all[pair_class == cp$hi, r]
  r_lo <- cor_all[pair_class == cp$lo, r]

  # Uncorrected
  a2_uncorr <- (r_hi - r_lo) / (cp$Rhi - cp$Rlo)

  # Corrected (use estimated m)
  R_hi_adj <- if (cp$Rhi == 1.0) 1.0 else if (cp$Rhi == 0.5) R_adj_DZ else R_adj_HS
  R_lo_adj <- if (cp$Rlo == 1.0) 1.0 else if (cp$Rlo == 0.5) R_adj_DZ else R_adj_HS
  denom_adj <- R_hi_adj - R_lo_adj
  a2_corr <- if (abs(denom_adj) > 0.001) (r_hi - r_lo) / denom_adj else NA

  label <- sprintf("%s vs %s", cp$hi, cp$lo)
  cat(sprintf("  %-15s  %10.3f  %10.3f\n", label, a2_uncorr,
              ifelse(is.na(a2_corr), NA, a2_corr)))
}

# ── Extended model: Dominance estimation with externally-fixed mu ──
cat(sprintf("\n  Extended model: Adding dominance (d^2) with mu fixed at %.3f\n", r_edu))
cat("  (from spousal education correlation as proxy for spousal IQ)\n")
cat("  Dominance shares: MZ=1, DZ=FS=1/4, HS=0\n")
cat("  c^2_twin = r_DZ - r_FS (still identified, same as before)\n")
cat("  Remaining 3 equations yield quadratic in a^2:\n")
cat("    5*mu*x^2 + x = 4*(3B - A)  where x = a^2\n\n")

mu_fixed <- r_edu  # Use spousal education correlation as proxy
# c²_twin still identified from DZ-FS difference
c2_twin_dom <- r_dz - r_fs

# A and B as before
# Quadratic: 5*mu*x^2 + x - 4*(3B - A) = 0
rhs <- 4 * (3 * B - A)
disc <- 1 + 20 * mu_fixed * rhs  # discriminant = 1 + 4*5*mu*rhs = 1 + 80*mu*(3B-A)

if (disc >= 0) {
  a2_dom <- (-1 + sqrt(disc)) / (10 * mu_fixed)
  m_dom <- mu_fixed * a2_dom
  d2_dom <- 4 * B - a2_dom * (1 + m_dom)
  c2_fam_dom <- r_hs - a2_dom * (1 + m_dom) / 4
  e2_dom <- 1 - a2_dom - d2_dom - c2_fam_dom - c2_twin_dom

  cat("  Extended solution (ADCE + twin c^2):\n")
  cat(strrep("  ", 1), strrep("-", 50), "\n")
  cat(sprintf("  a^2 (additive genetic)     = %.3f\n", a2_dom))
  cat(sprintf("  d^2 (dominance)            = %.3f\n", d2_dom))
  cat(sprintf("  c^2_fam (family shared)    = %.3f\n", c2_fam_dom))
  cat(sprintf("  c^2_twin (twin-specific)   = %.3f\n", c2_twin_dom))
  cat(sprintf("  e^2 (non-shared env)       = %.3f\n", e2_dom))
  cat(sprintf("  mu (fixed, from education) = %.3f\n", mu_fixed))
  cat(sprintf("  m = mu*a^2                 = %.3f\n", m_dom))
  cat(strrep("  ", 1), strrep("-", 50), "\n")

  # Verify
  pred_mz_d <- a2_dom + d2_dom + c2_fam_dom + c2_twin_dom
  pred_dz_d <- a2_dom * (1 + m_dom) / 2 + d2_dom / 4 + c2_fam_dom + c2_twin_dom
  pred_fs_d <- a2_dom * (1 + m_dom) / 2 + d2_dom / 4 + c2_fam_dom
  pred_hs_d <- a2_dom * (1 + m_dom) / 4 + c2_fam_dom
  cat("\n  Verification (predicted vs observed):\n")
  cat(sprintf("    MZ: pred=%.3f, obs=%.3f\n", pred_mz_d, r_mz))
  cat(sprintf("    DZ: pred=%.3f, obs=%.3f\n", pred_dz_d, r_dz))
  cat(sprintf("    FS: pred=%.3f, obs=%.3f\n", pred_fs_d, r_fs))
  cat(sprintf("    HS: pred=%.3f, obs=%.3f\n", pred_hs_d, r_hs))

  cat(sprintf("\n  Comparison: without dominance (mu estimated) vs with dominance (mu fixed):\n"))
  cat(sprintf("    %-20s  %12s  %12s\n", "Parameter", "ACE+twin", "ADCE+twin"))
  cat("    ", strrep("-", 48), "\n")
  cat(sprintf("    %-20s  %12.3f  %12.3f\n", "a^2", a2_est, a2_dom))
  cat(sprintf("    %-20s  %12s  %12.3f\n", "d^2", "    --    ", d2_dom))
  cat(sprintf("    %-20s  %12.3f  %12.3f\n", "c^2_fam", c2_fam_est, c2_fam_dom))
  cat(sprintf("    %-20s  %12.3f  %12.3f\n", "c^2_twin", c2_twin_est, c2_twin_dom))
  cat(sprintf("    %-20s  %12.3f  %12.3f\n", "e^2", e2_est, e2_dom))
  cat(sprintf("    %-20s  %12.3f  %12.3f\n", "mu", mu_est, mu_fixed))
  # Sensitivity: dominance across range of mu values
  cat("\n  Sensitivity: ADCE solution across mu values:\n")
  cat(sprintf("    %-10s  %8s  %8s  %8s  %8s  %8s\n",
              "mu", "a^2", "d^2", "c^2_fam", "c^2_tw", "e^2"))
  cat("    ", strrep("-", 55), "\n")
  for (mu_try in c(0.33, 0.40, 0.44, 0.50, 0.55, 0.607)) {
    rhs_t <- 4 * (3 * B - A)
    disc_t <- 1 + 20 * mu_try * rhs_t
    if (disc_t >= 0) {
      a2_t <- (-1 + sqrt(disc_t)) / (10 * mu_try)
      m_t <- mu_try * a2_t
      d2_t <- 4 * B - a2_t * (1 + m_t)
      c2_f_t <- r_hs - a2_t * (1 + m_t) / 4
      e2_t <- 1 - a2_t - d2_t - c2_f_t - c2_twin_dom
      cat(sprintf("    %-10.3f  %8.3f  %8.3f  %8.3f  %8.3f  %8.3f\n",
                  mu_try, a2_t, d2_t, c2_f_t, c2_twin_dom, e2_t))
    }
  }
  cat("    (mu=0.44: Horwitz et al. 2023 meta-analytic spousal IQ r)\n")
  cat("    (mu=0.607: CPP spousal education r, upper bound)\n")

} else {
  cat("  No real solution (discriminant < 0)\n")
}

# ── SES-stratified analytical solution ──
cat(sprintf("\n  SES-stratified analytical solution (full 4-equation system):\n\n"))

for (grp in c("Low SES", "High SES")) {
  r_mz_g <- cor_tab[pair_class == "MZ" & ses_group == grp, r]
  r_dz_g <- cor_tab[pair_class == "DZ" & ses_group == grp, r]
  r_fs_g <- cor_tab[pair_class == "FS" & ses_group == grp, r]
  r_hs_g <- cor_tab[pair_class == "HS" & ses_group == grp, r]
  n_mz_g <- cor_tab[pair_class == "MZ" & ses_group == grp, n]
  n_dz_g <- cor_tab[pair_class == "DZ" & ses_group == grp, n]
  n_fs_g <- cor_tab[pair_class == "FS" & ses_group == grp, n]
  n_hs_g <- cor_tab[pair_class == "HS" & ses_group == grp, n]

  if (length(r_mz_g) == 0 | length(r_fs_g) == 0 | length(r_hs_g) == 0) next

  # Same 4-equation system applied within stratum
  c2_tw_g <- if (length(r_dz_g) > 0) r_dz_g - r_fs_g else NA
  A_g <- r_mz_g - r_dz_g
  B_g <- r_fs_g - r_hs_g
  m_g <- (2 * B_g - A_g) / (A_g + 2 * B_g)
  a2_g <- 2 * A_g / (1 - m_g)
  mu_g <- m_g / a2_g
  c2_fam_g <- r_hs_g - a2_g * (1 + m_g) / 4
  e2_g <- 1 - a2_g - c2_fam_g - ifelse(is.na(c2_tw_g), 0, c2_tw_g)

  cat(sprintf("  %s:\n", grp))
  cat(sprintf("    r: MZ=%.3f(%d), DZ=%.3f(%d), FS=%.3f(%d), HS=%.3f(%d)\n",
              r_mz_g, n_mz_g, r_dz_g, n_dz_g, r_fs_g, n_fs_g, r_hs_g, n_hs_g))
  cat(sprintf("    a^2=%.3f, c^2_fam=%.3f, c^2_twin=%s, e^2=%.3f, mu=%.3f\n",
              a2_g, c2_fam_g,
              ifelse(is.na(c2_tw_g), "  NA", sprintf("%.3f", c2_tw_g)),
              e2_g, mu_g))
}
cat("\n  Note: SES-stratified estimates are noisy due to small twin and\n")
cat("  half-sibling Ns per stratum. See B4 for the preferred SES-moderated\n")
cat("  estimates using multi-level DF regression.\n")

# ── B2b: SES-Matched Pair Correlations ──────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("B2b: SES-Matched Pair Correlations\n")
cat(strrep("-", 70), "\n")
cat("  Half-siblings come from disrupted families (different fathers),\n")
cat("  typically lower SES. Matching on SES ensures the FS-HS comparison\n")
cat("  is not confounded by mean SES differences.\n")

# Show mean SES by pair type
cat("\n  Mean household SEI by pair type:\n")
cat(sprintf("  %-5s  %8s  %8s  %6s\n", "Type", "Mean SEI", "SD", "N"))
cat("  ", strrep("-", 35), "\n")
for (pc in c("MZ", "DZ", "FS", "HS")) {
  sub <- pair_iq[pair_class == pc]
  cat(sprintf("  %-5s  %8.2f  %8.2f  %6d\n",
              pc, mean(sub$sei_mean), sd(sub$sei_mean), nrow(sub)))
}

# Compute correlations within SES quintiles
pair_iq[, sei_quint := cut(sei_mean,
                           breaks = quantile(sei_mean, seq(0, 1, 0.2), na.rm = TRUE),
                           labels = paste0("Q", 1:5),
                           include.lowest = TRUE)]

cat("\n  IQ correlations by pair type within SES quintile:\n")
cat(sprintf("  %-5s", "Type"))
for (q in paste0("Q", 1:5)) cat(sprintf("  %12s", q))
cat("\n")
cat("  ", strrep("-", 5 + 5 * 14), "\n")

for (pc in c("MZ", "DZ", "FS", "HS")) {
  cat(sprintf("  %-5s", pc))
  for (q in paste0("Q", 1:5)) {
    sub <- pair_iq[pair_class == pc & sei_quint == q]
    if (nrow(sub) >= 10) {
      cat(sprintf("  %5.3f (%4d)", cor(sub$iq1, sub$iq2), nrow(sub)))
    } else if (nrow(sub) > 0) {
      cat(sprintf("   [N=%d]     ", nrow(sub)))
    } else {
      cat("    --       ")
    }
  }
  cat("\n")
}

# SES-matched FS-vs-HS comparison
cat("\n  SES-matched heritability (FS vs HS within same SEI quintile):\n")
cat(sprintf("  %-6s  %8s  %8s  %8s\n", "Quint", "r(FS)", "r(HS)", "a^2"))
cat("  ", strrep("-", 38), "\n")

for (q in paste0("Q", 1:5)) {
  fs_q <- pair_iq[pair_class == "FS" & sei_quint == q]
  hs_q <- pair_iq[pair_class == "HS" & sei_quint == q]
  if (nrow(fs_q) >= 20 & nrow(hs_q) >= 20) {
    r_fs_q <- cor(fs_q$iq1, fs_q$iq2)
    r_hs_q <- cor(hs_q$iq1, hs_q$iq2)
    a2_q <- (r_fs_q - r_hs_q) / (0.5 - 0.25)
    cat(sprintf("  %-6s  %8.3f  %8.3f  %8.3f  (FS N=%d, HS N=%d)\n",
                q, r_fs_q, r_hs_q, a2_q, nrow(fs_q), nrow(hs_q)))
  } else {
    cat(sprintf("  %-6s  %8s  %8s  %8s  (FS N=%d, HS N=%d)\n",
                q, "  --  ", "  --  ", "  --  ", nrow(fs_q), nrow(hs_q)))
  }
}

# ── B3: Falconer ACE by SES (multiple reference groups) ──────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("B3: Falconer ACE by SES (Multiple Reference Groups)\n")
cat(strrep("-", 70), "\n")

cat("\n  Classic twin (MZ vs DZ):\n")
cat(sprintf("  %-10s  %8s  %8s  %8s  %12s  %12s\n",
            "SES Group", "a^2", "c^2", "e^2", "r(MZ)", "r(DZ)"))
cat("  ", strrep("-", 65), "\n")
for (grp in c("Low SES", "High SES")) {
  r_mz <- cor_tab[pair_class == "MZ" & ses_group == grp, r]
  r_dz <- cor_tab[pair_class == "DZ" & ses_group == grp, r]
  if (length(r_mz) > 0 & length(r_dz) > 0) {
    a2 <- 2 * (r_mz - r_dz)
    c2 <- 2 * r_dz - r_mz
    e2 <- 1 - r_mz
    cat(sprintf("  %-10s  %8.3f  %8.3f  %8.3f  %12.3f  %12.3f\n",
                grp, a2, c2, e2, r_mz, r_dz))
  }
}

cat("\n  MZ vs Full Siblings (higher power at R=0.5):\n")
cat(sprintf("  %-10s  %8s  %8s  %8s  %12s  %12s\n",
            "SES Group", "a^2", "c^2", "e^2", "r(MZ)", "r(FS)"))
cat("  ", strrep("-", 65), "\n")
for (grp in c("Low SES", "High SES")) {
  r_mz <- cor_tab[pair_class == "MZ" & ses_group == grp, r]
  r_fs <- cor_tab[pair_class == "FS" & ses_group == grp, r]
  if (length(r_mz) > 0 & length(r_fs) > 0) {
    a2 <- 2 * (r_mz - r_fs)
    c2 <- 2 * r_fs - r_mz
    e2 <- 1 - r_mz
    cat(sprintf("  %-10s  %8.3f  %8.3f  %8.3f  %12.3f  %12.3f\n",
                grp, a2, c2, e2, r_mz, r_fs))
  }
}

cat("\n  FS vs HS (sibling-only, no twins):\n")
cat(sprintf("  %-10s  %8s  %8s  %8s  %12s  %12s\n",
            "SES Group", "a^2", "c^2", "e^2", "r(FS)", "r(HS)"))
cat("  ", strrep("-", 65), "\n")
for (grp in c("Low SES", "High SES")) {
  r_fs <- cor_tab[pair_class == "FS" & ses_group == grp, r]
  r_hs <- cor_tab[pair_class == "HS" & ses_group == grp, r]
  if (length(r_fs) > 0 & length(r_hs) > 0) {
    # a^2 = (r_fs - r_hs) / (0.5 - 0.25) = 4*(r_fs - r_hs)
    a2 <- (r_fs - r_hs) / (0.5 - 0.25)
    c2 <- r_hs - 0.25 * a2
    e2 <- 1 - 0.5 * a2 - c2   # evaluated at FS level
    n_hs <- cor_tab[pair_class == "HS" & ses_group == grp, n]
    cat(sprintf("  %-10s  %8.3f  %8.3f  %8.3f  %12.3f  %12.3f  (HS N=%d)\n",
                grp, a2, c2, e2, r_fs, r_hs, n_hs))
  }
}

# ── B4: Multi-Level DF (MZ + DZ + FS, dropping HS) ──────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("B4: Multi-Level DF — MZ + DZ + FS (Dropping Half-Siblings)\n")
cat(strrep("-", 70), "\n")
cat("  HS pairs are too sparse at high SES (N=28 in Q4) for stable\n")
cat("  moderation estimates. Dropping them yields a cleaner model.\n")
cat("  MZ (R=1.0) + DZ (R=0.5) + FS (R=0.5)\n")
cat("  is_twin distinguishes DZ from FS at R=0.5.\n\n")

# Use only MZ, DZ, FS (drop HS)
no_hs <- pair_iq[pair_class %in% c("MZ", "DZ", "FS")]
no_hs[, R := fifelse(pair_class == "MZ", 1.0, 0.5)]
no_hs[, is_twin := as.integer(pair_class %in% c("MZ", "DZ"))]
no_hs[, iq1_z := as.numeric(scale(iq1))]
no_hs[, iq2_z := as.numeric(scale(iq2))]
no_hs[, sei_z := as.numeric(scale(sei_mean))]

cat(sprintf("  Sample: MZ=%d, DZ=%d, FS=%d (total=%d pairs)\n",
            no_hs[pair_class == "MZ", .N], no_hs[pair_class == "DZ", .N],
            no_hs[pair_class == "FS", .N], nrow(no_hs)))

no_hs_de <- rbind(
  no_hs[, .(iq_P = iq1_z, iq_C = iq2_z, R, sei = sei_z, is_twin, pair_class)],
  no_hs[, .(iq_P = iq2_z, iq_C = iq1_z, R, sei = sei_z, is_twin, pair_class)]
)

# Base model
df_multi_base <- lm(iq_C ~ iq_P + R + iq_P:R + iq_P:is_twin, data = no_hs_de)
sm_multi <- summary(df_multi_base)$coefficients

cat(sprintf("\n  Base multi-level DF (no HS):\n"))
cat(sprintf("  %-25s  %8s  %8s  %8s\n", "Term", "Estimate", "SE", "p"))
cat("  ", strrep("-", 55), "\n")
for (nm in rownames(sm_multi)) {
  cat(sprintf("  %-25s  %8.3f  %8.3f  %8.4f\n",
              nm, sm_multi[nm,1], sm_multi[nm,2], sm_multi[nm,4]))
}

cf_mb <- coef(df_multi_base)
cat(sprintf("\n  a^2 (genetic)          = %.3f\n", cf_mb["iq_P:R"]))
cat(sprintf("  c^2_family (all pairs) = %.3f\n", cf_mb["iq_P"]))
cat(sprintf("  c^2_twin (twins extra) = %.3f\n", cf_mb["iq_P:is_twin"]))
cat(sprintf("  Total c^2 for twins    = %.3f\n", cf_mb["iq_P"] + cf_mb["iq_P:is_twin"]))
cat(sprintf("  e^2 (non-shared)       = %.3f\n",
            1 - cf_mb["iq_P:R"] - cf_mb["iq_P"] - cf_mb["iq_P:is_twin"]))

# Moderated: SES interactions
df_multi_mod <- lm(iq_C ~ iq_P * R * sei + iq_P:is_twin + iq_P:is_twin:sei,
                   data = no_hs_de)
cf_mm <- coef(df_multi_mod)
sm_mm <- summary(df_multi_mod)$coefficients

cat("\n  Moderated multi-level DF (no HS):\n")
cat(sprintf("  %-25s  %8s  %8s  %8s\n", "Term", "Estimate", "SE", "p"))
cat("  ", strrep("-", 55), "\n")
for (nm in rownames(sm_mm)) {
  cat(sprintf("  %-25s  %8.3f  %8.3f  %8.4f\n", nm, sm_mm[nm,1], sm_mm[nm,2], sm_mm[nm,4]))
}

cat("\n  ACE by SES (multi-level DF, no HS):\n")
cat(sprintf("  %-15s  %8s  %8s  %8s  %8s\n",
            "SES Level", "a^2", "c^2_fam", "c^2_twin", "e^2"))
cat("  ", strrep("-", 55), "\n")
for (i in seq_along(ses_vals)) {
  s <- ses_vals[i]
  a2 <- cf_mm["iq_P:R"] + cf_mm["iq_P:R:sei"] * s
  c2_fam <- cf_mm["iq_P"] + cf_mm["iq_P:sei"] * s
  c2_tw <- cf_mm["iq_P:is_twin"]
  if ("iq_P:is_twin:sei" %in% names(cf_mm)) c2_tw <- c2_tw + cf_mm["iq_P:is_twin:sei"] * s
  e2 <- 1 - a2 - c2_fam - c2_tw
  cat(sprintf("  %-15s  %8.3f  %8.3f  %8.3f  %8.3f\n",
              names(ses_vals)[i], a2, c2_fam, c2_tw, e2))
}

# ── B4b: AM-Corrected Multi-Level DF ──────────────────────────────────
cat("\n  --- Sensitivity: AM-corrected R values ---\n")
cat(sprintf("  Using R*_DZ = R*_FS = %.3f (from B2a, mu=%.3f)\n", R_adj_DZ, mu_est))
cat("  MZ R remains 1.0 (identical genomes).\n\n")

no_hs[, R_adj := fifelse(pair_class == "MZ", 1.0, R_adj_DZ)]

no_hs_de_adj <- rbind(
  no_hs[, .(iq_P = iq1_z, iq_C = iq2_z, R = R_adj, sei = sei_z, is_twin, pair_class)],
  no_hs[, .(iq_P = iq2_z, iq_C = iq1_z, R = R_adj, sei = sei_z, is_twin, pair_class)]
)

df_multi_base_adj <- lm(iq_C ~ iq_P + R + iq_P:R + iq_P:is_twin, data = no_hs_de_adj)
cf_mb_adj <- coef(df_multi_base_adj)
cat(sprintf("  AM-corrected base model:\n"))
cat(sprintf("    a^2 = %.3f, c^2_fam = %.3f, c^2_twin = %.3f, e^2 = %.3f\n",
            cf_mb_adj["iq_P:R"], cf_mb_adj["iq_P"],
            cf_mb_adj["iq_P:is_twin"],
            1 - cf_mb_adj["iq_P:R"] - cf_mb_adj["iq_P"] - cf_mb_adj["iq_P:is_twin"]))

df_multi_mod_adj <- lm(iq_C ~ iq_P * R * sei + iq_P:is_twin + iq_P:is_twin:sei,
                       data = no_hs_de_adj)
cf_mm_adj <- coef(df_multi_mod_adj)
sm_mm_adj <- summary(df_multi_mod_adj)$coefficients

cat("\n  AM-corrected moderated multi-level DF:\n")
cat(sprintf("  %-25s  %8s  %8s  %8s\n", "Term", "Estimate", "SE", "p"))
cat("  ", strrep("-", 55), "\n")
for (nm in rownames(sm_mm_adj)) {
  cat(sprintf("  %-25s  %8.3f  %8.3f  %8.4f\n",
              nm, sm_mm_adj[nm,1], sm_mm_adj[nm,2], sm_mm_adj[nm,4]))
}

cat("\n  ACE by SES (AM-corrected multi-level DF):\n")
cat(sprintf("  %-15s  %8s  %8s  %8s  %8s\n",
            "SES Level", "a^2", "c^2_fam", "c^2_twin", "e^2"))
cat("  ", strrep("-", 55), "\n")
for (i in seq_along(ses_vals)) {
  s <- ses_vals[i]
  a2 <- cf_mm_adj["iq_P:R"] + cf_mm_adj["iq_P:R:sei"] * s
  c2_fam <- cf_mm_adj["iq_P"] + cf_mm_adj["iq_P:sei"] * s
  c2_tw <- cf_mm_adj["iq_P:is_twin"]
  if ("iq_P:is_twin:sei" %in% names(cf_mm_adj)) c2_tw <- c2_tw + cf_mm_adj["iq_P:is_twin:sei"] * s
  e2 <- 1 - a2 - c2_fam - c2_tw
  cat(sprintf("  %-15s  %8.3f  %8.3f  %8.3f  %8.3f\n",
              names(ses_vals)[i], a2, c2_fam, c2_tw, e2))
}

# ── B5: Scarr-Rowe Robustness to AM Correction ────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("B5: Scarr-Rowe Interaction Robustness to Assortative Mating\n")
cat(strrep("-", 70), "\n")
cat("  Re-running moderated multi-level DF (MZ+DZ+FS) across a range\n")
cat("  of assumed spousal IQ correlations (mu), adjusting R* accordingly.\n")
cat("  mu=0.19: lower bound (edu-mediated only)\n")
cat("  mu=0.33: Bouchard & McGue (1981)\n")
cat("  mu=0.40: Plomin & Deary (2015) consensus\n")
cat("  mu=0.44: Horwitz et al. (2023) meta-analysis\n")
cat("  mu=0.55: data-estimated (4-equation ACE model)\n")
cat("  mu=0.61: CPP spousal education r (upper bound)\n\n")

mu_grid <- c(0.00, 0.19, 0.33, 0.40, 0.44, 0.50, 0.55, 0.607)

cat(sprintf("  %-6s  %6s  %8s  %8s  %8s  %10s\n",
            "mu", "R*", "a2(lo)", "a2(hi)", "delta", "p(3-way)"))
cat("  ", strrep("-", 55), "\n")

for (mu_try in mu_grid) {
  # Compute R* from ADCE quadratic (or use nominal for mu=0)
  if (mu_try == 0) {
    R_adj_try <- 0.5
  } else {
    rhs_t <- 4 * (3 * B - A)
    disc_t <- 1 + 20 * mu_try * rhs_t
    a2_t <- (-1 + sqrt(disc_t)) / (10 * mu_try)
    m_t <- mu_try * a2_t
    R_adj_try <- (1 + m_t) / 2
  }

  no_hs[, R_try := fifelse(pair_class == "MZ", 1.0, R_adj_try)]

  no_hs_de_try <- rbind(
    no_hs[, .(iq_P = iq1_z, iq_C = iq2_z, R = R_try, sei = sei_z, is_twin)],
    no_hs[, .(iq_P = iq2_z, iq_C = iq1_z, R = R_try, sei = sei_z, is_twin)]
  )

  fit_try <- lm(iq_C ~ iq_P * R * sei + iq_P:is_twin + iq_P:is_twin:sei,
                data = no_hs_de_try)
  cf_try <- coef(fit_try)
  sm_try <- summary(fit_try)$coefficients

  p_3way <- sm_try["iq_P:R:sei", 4]
  a2_lo <- cf_try["iq_P:R"] + cf_try["iq_P:R:sei"] * (-1)
  a2_hi <- cf_try["iq_P:R"] + cf_try["iq_P:R:sei"] * (1)
  delta <- a2_hi - a2_lo

  cat(sprintf("  %-6.2f  %6.3f  %8.3f  %8.3f  %8.3f  %10.4f%s\n",
              mu_try, R_adj_try, a2_lo, a2_hi, delta, p_3way,
              ifelse(p_3way < 0.05, " *", ifelse(p_3way < 0.10, " +", ""))))
}
cat("\n  * p < .05; + p < .10\n")
cat("  Interpretation: The Scarr-Rowe interaction (increasing heritability\n")
cat("  with SES) is robust to AM correction across the full range of\n")
cat("  plausible spousal IQ correlations.\n")

# PART C: g-LOADING × SES MODERATION ANALYSIS
# Uses Myrianthopoulos twins for consistency with Part A.
cat("\n")
cat("--- PART C: g-Loading x SES Moderation of Heritability ---
")

subtest_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
                  "wisc_picarr", "wisc_block", "wisc_coding",
                  "wrat_read_raw", "bender_gestalt",
                  "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
subtest_labels <- c("WISC Information", "WISC Comprehension", "WISC Vocabulary",
                    "WISC Digit Span", "WISC Picture Arrangement",
                    "WISC Block Design", "WISC Coding",
                    "WRAT Reading", "Bender Gestalt",
                    "WRAT Spelling", "WRAT Arithmetic", "Goodenough")

avail <- subtest_vars %in% names(d)
subtest_vars <- subtest_vars[avail]
subtest_labels <- subtest_labels[avail]

cat(sprintf("\nAvailable cognitive subtests: %d\n", length(subtest_vars)))
for (i in seq_along(subtest_vars)) {
  n <- d[!is.na(get(subtest_vars[i])), .N]
  cat(sprintf("  %-25s  N = %d\n", subtest_labels[i], n))
}

# ── Step 1: Compute g-loadings (correlation with main g factor) ─────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Step 1: g-Loadings (Pearson r with g factor from 12-test PCA)\n")
cat(strrep("-", 70), "\n")

# Use g_factor scores from data_prep (PCA PC1 on 12-test battery)
# g-loading = cor(subtest, g_factor) for consistency with main analysis
g_complete <- d[!is.na(g_factor)]
cat(sprintf("  Cases with g factor: %d\n", nrow(g_complete)))

g_loadings <- sapply(subtest_vars, function(sv) {
  cor(g_complete[[sv]], g_complete[["g_factor"]], use = "pairwise.complete.obs")
})

cat(sprintf("\n  %-25s  %10s\n", "Subtest", "g-loading"))
cat("  ", strrep("-", 38), "\n")
for (i in seq_along(subtest_vars)) {
  cat(sprintf("  %-25s  %10.3f\n", subtest_labels[i], g_loadings[subtest_vars[i]]))
}

# ── Step 2: Per-subtest DF model with SES moderator ──────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Step 2: Per-Subtest DF Model with SES Moderation\n")
cat("(Using Myrianthopoulos twins only)\n")
cat(strrep("-", 70), "\n")

gload_vec <- numeric(length(subtest_vars))
delta_h2_vec <- numeric(length(subtest_vars))
h2_lo_vec <- numeric(length(subtest_vars))
h2_hi_vec <- numeric(length(subtest_vars))
n_pairs_vec <- integer(length(subtest_vars))
names(gload_vec) <- subtest_vars
names(delta_h2_vec) <- subtest_vars

cat(sprintf("\n  %-25s  %8s  %8s  %8s  %8s  %5s\n",
            "Subtest", "g-load", "h2(lo)", "h2(hi)", "delta-h2", "Npair"))
cat("  ", strrep("-", 65), "\n")

for (k in seq_along(subtest_vars)) {
  sv <- subtest_vars[k]
  gload_vec[k] <- g_loadings[sv]

  d_sub <- d[, c("case_id", sv, "sei_decimal"), with = FALSE]
  setnames(d_sub, sv, "subtest_score")

  # Use Myrianthopoulos twins only
  tp_k <- merge(twins_myri[, .(twin_pair_id, child1_id, child2_id, zyg)],
                d_sub, by.x = "child1_id", by.y = "case_id")
  setnames(tp_k, c("subtest_score", "sei_decimal"), c("s1", "sei1"))
  tp_k <- merge(tp_k, d_sub, by.x = "child2_id", by.y = "case_id")
  setnames(tp_k, c("subtest_score", "sei_decimal"), c("s2", "sei2"))

  tp_k[, sei := (sei1 + sei2) / 2]
  tp_k[, R := fifelse(zyg == "MZ", 1.0, 0.5)]
  tp_k <- tp_k[!is.na(s1) & !is.na(s2) & !is.na(sei)]

  n_pairs_vec[k] <- nrow(tp_k)

  if (nrow(tp_k) < 30) {
    h2_lo_vec[k] <- NA; h2_hi_vec[k] <- NA; delta_h2_vec[k] <- NA
    cat(sprintf("  %-25s  %8.3f  %8s  %8s  %8s  %5d\n",
                subtest_labels[k], gload_vec[k], "  --  ", "  --  ", "  --  ", n_pairs_vec[k]))
    next
  }

  tp_k[, s1_z := as.numeric(scale(s1))]
  tp_k[, s2_z := as.numeric(scale(s2))]
  tp_k[, sei_z := as.numeric(scale(sei))]

  tp_de_k <- rbind(
    tp_k[, .(iq_P = s1_z, iq_C = s2_z, R, sei = sei_z)],
    tp_k[, .(iq_P = s2_z, iq_C = s1_z, R, sei = sei_z)]
  )

  fit_k <- tryCatch(lm(iq_C ~ iq_P * R * sei, data = tp_de_k), error = function(e) NULL)

  if (is.null(fit_k)) {
    h2_lo_vec[k] <- NA; h2_hi_vec[k] <- NA; delta_h2_vec[k] <- NA
    cat(sprintf("  %-25s  %8.3f  %8s  %8s  %8s  %5d\n",
                subtest_labels[k], gload_vec[k], " ERR  ", " ERR  ", " ERR  ", n_pairs_vec[k]))
    next
  }

  cf_k <- coef(fit_k)
  a2_lo <- cf_k["iq_P:R"] + cf_k["iq_P:R:sei"] * (-1)
  a2_hi <- cf_k["iq_P:R"] + cf_k["iq_P:R:sei"] * (1)

  h2_lo_vec[k] <- a2_lo
  h2_hi_vec[k] <- a2_hi
  delta_h2_vec[k] <- a2_hi - a2_lo

  cat(sprintf("  %-25s  %8.3f  %8.3f  %8.3f  %8.3f  %5d\n",
              subtest_labels[k], gload_vec[k], a2_lo, a2_hi,
              a2_hi - a2_lo, n_pairs_vec[k]))
}

# ── Step 3: Correlate g-loading with delta-h² ────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Step 3: Correlation Between g-Loading and SES Moderation of h²\n")
cat(strrep("-", 70), "\n")

valid <- !is.na(delta_h2_vec) & !is.na(gload_vec)
n_subtests <- sum(valid)

if (n_subtests >= 5) {
  r_test <- cor.test(gload_vec[valid], delta_h2_vec[valid])
  cat(sprintf("\n  N subtests: %d\n", n_subtests))
  cat(sprintf("  Pearson r(g-loading, delta-h²): %.3f\n", r_test$estimate))
  cat(sprintf("  95%% CI: [%.3f, %.3f]\n", r_test$conf.int[1], r_test$conf.int[2]))
  cat(sprintf("  p-value: %.4f\n", r_test$p.value))

  if (r_test$estimate < 0) {
    cat("\n  Interpretation: Negative — higher g-loaded subtests show\n")
    cat("  LESS SES moderation of heritability.\n")
  } else {
    cat("\n  Interpretation: Positive — higher g-loaded subtests show\n")
    cat("  MORE SES moderation of heritability.\n")
  }

  rho <- cor.test(gload_vec[valid], delta_h2_vec[valid], method = "spearman")
  cat(sprintf("\n  Spearman rho: %.3f (p = %.4f)\n", rho$estimate, rho$p.value))
} else {
  cat(sprintf("\n  Too few valid subtests (%d) for correlation.\n", n_subtests))
}

# ── Step 4: Multi-level per-subtest SES moderation — diagnostic ───────
# We run each subtest through multiple specifications to understand
# why the multi-level interaction differs from twin-only.
cat("\n")
cat(strrep("=", 70), "\n")
cat("Step 4: MULTI-LEVEL PER-SUBTEST SES MODERATION (DIAGNOSTIC)\n")
cat(strrep("=", 70), "\n")

# Helper: run DF model on double-entered data, return a2_lo, a2_hi, delta, p
run_df_mod <- function(tp, include_twin = FALSE) {
  tp[, s1_z := as.numeric(scale(s1))]
  tp[, s2_z := as.numeric(scale(s2))]
  tp[, sei_z := as.numeric(scale(sei))]
  de <- rbind(
    tp[, .(iq_P = s1_z, iq_C = s2_z, R, sei = sei_z, is_twin)],
    tp[, .(iq_P = s2_z, iq_C = s1_z, R, sei = sei_z, is_twin)]
  )
  if (include_twin) {
    fit <- tryCatch(
      lm(iq_C ~ iq_P * R * sei + iq_P:is_twin + iq_P:sei:is_twin, data = de),
      error = function(e) NULL)
  } else {
    fit <- tryCatch(lm(iq_C ~ iq_P * R * sei, data = de), error = function(e) NULL)
  }
  if (is.null(fit)) return(list(a2_lo = NA, a2_hi = NA, delta = NA, p = NA))
  cf <- coef(fit)
  a2_lo <- cf["iq_P:R"] + cf["iq_P:R:sei"] * (-1)
  a2_hi <- cf["iq_P:R"] + cf["iq_P:R:sei"] * (1)
  p3 <- summary(fit)$coef["iq_P:R:sei", 4]
  list(a2_lo = a2_lo, a2_hi = a2_hi, delta = a2_hi - a2_lo, p = p3)
}

# Helper: build subtest pair data from pair_iq
build_subtest_pairs <- function(sv, keep_classes = c("MZ", "DZ", "FS", "HS")) {
  sub_data <- d[!is.na(get(sv)), .(case_id, sub_score = get(sv), sei_decimal)]
  tp <- merge(pair_iq[pair_class %in% keep_classes, .(id_1, id_2, pair_class)],
              sub_data[, .(case_id, sub_score, sei_decimal)],
              by.x = "id_1", by.y = "case_id")
  setnames(tp, c("sub_score", "sei_decimal"), c("s1", "sei1"))
  tp <- merge(tp, sub_data[, .(case_id, sub_score, sei_decimal)],
              by.x = "id_2", by.y = "case_id")
  setnames(tp, c("sub_score", "sei_decimal"), c("s2", "sei2"))
  tp[, sei := (sei1 + sei2) / 2]
  tp[, R := fcase(pair_class == "MZ", 1.0,
                   pair_class %in% c("DZ", "FS"), 0.5,
                   pair_class == "HS", 0.25)]
  tp[, is_twin := as.integer(pair_class %in% c("MZ", "DZ"))]
  tp <- tp[!is.na(s1) & !is.na(s2) & !is.na(sei)]
  tp
}

# 4a. Diagnostic: SES distribution by pair type
cat("\n  4a. SES distribution by pair type (all pairs):\n")
cat(sprintf("  %-6s  %8s  %8s  %8s  %8s\n", "Type", "N", "mean_SEI", "SD", "median"))
for (pc in c("MZ", "DZ", "FS", "HS")) {
  sub <- pair_iq[pair_class == pc]
  cat(sprintf("  %-6s  %8d  %8.2f  %8.2f  %8.2f\n",
              pc, nrow(sub), mean(sub$sei_mean), sd(sub$sei_mean), median(sub$sei_mean)))
}

# 4b. Run five specifications per subtest
cat("\n  4b. Per-subtest SES moderation across specifications:\n")
cat("  Spec A: Twins only (Myrianthopoulos)\n")
cat("  Spec B: MZ+DZ+FS (no HS), basic DF\n")
cat("  Spec C: MZ+DZ+FS (no HS), with twin-specific c² and its SES interaction\n")
cat("  Spec D: MZ+DZ+FS+HS, basic DF\n")
cat("  Spec E: MZ+DZ+FS+HS, with twin-specific c² and its SES interaction\n")
cat("  Spec F: FS only (no twins, no HS)\n\n")

specs <- c("A:Twin", "B:noHS", "C:noHS+tw", "D:all", "E:all+tw", "F:FS-only")
n_specs <- length(specs)

# Store results: rows = subtests, cols = specs
delta_mat <- matrix(NA, nrow = length(subtest_vars), ncol = n_specs)
h2lo_mat <- matrix(NA, nrow = length(subtest_vars), ncol = n_specs)
h2hi_mat <- matrix(NA, nrow = length(subtest_vars), ncol = n_specs)
p_mat <- matrix(NA, nrow = length(subtest_vars), ncol = n_specs)
n_mat <- matrix(NA_integer_, nrow = length(subtest_vars), ncol = n_specs)
rownames(delta_mat) <- subtest_vars
colnames(delta_mat) <- specs

for (k in seq_along(subtest_vars)) {
  sv <- subtest_vars[k]

  # Spec A: twins only (already computed above)
  delta_mat[k, 1] <- delta_h2_vec[k]
  h2lo_mat[k, 1] <- h2_lo_vec[k]
  h2hi_mat[k, 1] <- h2_hi_vec[k]
  n_mat[k, 1] <- n_pairs_vec[k]

  # Build pair datasets
  tp_nohs <- build_subtest_pairs(sv, c("MZ", "DZ", "FS"))
  tp_all <- build_subtest_pairs(sv, c("MZ", "DZ", "FS", "HS"))
  tp_fs <- build_subtest_pairs(sv, c("FS"))

  # Spec B: MZ+DZ+FS, basic
  res_b <- run_df_mod(tp_nohs, include_twin = FALSE)
  delta_mat[k, 2] <- res_b$delta; h2lo_mat[k, 2] <- res_b$a2_lo
  h2hi_mat[k, 2] <- res_b$a2_hi; p_mat[k, 2] <- res_b$p; n_mat[k, 2] <- nrow(tp_nohs)

  # Spec C: MZ+DZ+FS, with twin-specific effects
  res_c <- run_df_mod(tp_nohs, include_twin = TRUE)
  delta_mat[k, 3] <- res_c$delta; h2lo_mat[k, 3] <- res_c$a2_lo
  h2hi_mat[k, 3] <- res_c$a2_hi; p_mat[k, 3] <- res_c$p; n_mat[k, 3] <- nrow(tp_nohs)

  # Spec D: all pairs, basic
  res_d <- run_df_mod(tp_all, include_twin = FALSE)
  delta_mat[k, 4] <- res_d$delta; h2lo_mat[k, 4] <- res_d$a2_lo
  h2hi_mat[k, 4] <- res_d$a2_hi; p_mat[k, 4] <- res_d$p; n_mat[k, 4] <- nrow(tp_all)

  # Spec E: all pairs, with twin-specific effects
  res_e <- run_df_mod(tp_all, include_twin = TRUE)
  delta_mat[k, 5] <- res_e$delta; h2lo_mat[k, 5] <- res_e$a2_lo
  h2hi_mat[k, 5] <- res_e$a2_hi; p_mat[k, 5] <- res_e$p; n_mat[k, 5] <- nrow(tp_all)

  # Spec F: FS only — use simple intraclass approach
  # FS all have R=0.5, so the basic DF model collapses; instead split by SES
  # and compare sibling correlations directly
  tp_fs[, sei_z := as.numeric(scale(sei))]
  tp_fs[, s1_z := as.numeric(scale(s1))]
  tp_fs[, s2_z := as.numeric(scale(s2))]
  sei_med_fs <- median(tp_fs$sei, na.rm = TRUE)
  r_lo_fs <- tp_fs[sei <= sei_med_fs, cor(s1_z, s2_z)]
  r_hi_fs <- tp_fs[sei > sei_med_fs, cor(s1_z, s2_z)]
  # delta_r = r_hi - r_lo; positive means higher correlation at high SES
  # (higher correlation = more shared factors = more c² or more a²)
  delta_mat[k, 6] <- r_hi_fs - r_lo_fs
  h2lo_mat[k, 6] <- r_lo_fs
  h2hi_mat[k, 6] <- r_hi_fs
  n_mat[k, 6] <- nrow(tp_fs)
}

# Print delta-h² comparison table
cat(sprintf("  %-20s  %6s", "Subtest", "g-ld"))
for (s in specs) cat(sprintf("  %9s", s))
cat("\n")
cat("  ", strrep("-", 20 + 8 + n_specs * 11), "\n")
for (k in seq_along(subtest_vars)) {
  cat(sprintf("  %-20s  %6.3f", subtest_labels[k], g_loadings[subtest_vars[k]]))
  for (j in 1:n_specs) {
    if (is.na(delta_mat[k, j])) {
      cat("       --  ")
    } else {
      cat(sprintf("  %9.3f", delta_mat[k, j]))
    }
  }
  cat("\n")
}

# Print h²(lo) table
cat("\n  h²(lo) across specifications:\n")
cat(sprintf("  %-20s  %6s", "Subtest", "g-ld"))
for (s in specs) cat(sprintf("  %9s", s))
cat("\n")
cat("  ", strrep("-", 20 + 8 + n_specs * 11), "\n")
for (k in seq_along(subtest_vars)) {
  cat(sprintf("  %-20s  %6.3f", subtest_labels[k], g_loadings[subtest_vars[k]]))
  for (j in 1:n_specs) {
    if (is.na(h2lo_mat[k, j])) cat("       --  ")
    else cat(sprintf("  %9.3f", h2lo_mat[k, j]))
  }
  cat("\n")
}

# Print h²(hi) table
cat("\n  h²(hi) across specifications:\n")
cat(sprintf("  %-20s  %6s", "Subtest", "g-ld"))
for (s in specs) cat(sprintf("  %9s", s))
cat("\n")
cat("  ", strrep("-", 20 + 8 + n_specs * 11), "\n")
for (k in seq_along(subtest_vars)) {
  cat(sprintf("  %-20s  %6.3f", subtest_labels[k], g_loadings[subtest_vars[k]]))
  for (j in 1:n_specs) {
    if (is.na(h2hi_mat[k, j])) cat("       --  ")
    else cat(sprintf("  %9.3f", h2hi_mat[k, j]))
  }
  cat("\n")
}

# Correlation of g-loading with delta-h² for each specification
cat("\n  r(g-loading, delta-h²) across specifications:\n")
cat(sprintf("  %-12s  %8s  %12s  %8s  %8s\n", "Spec", "r", "95% CI", "p", "N_pairs"))
cat("  ", strrep("-", 55), "\n")
gload_all <- g_loadings[subtest_vars]
for (j in 1:n_specs) {
  dh <- delta_mat[, j]
  valid_j <- !is.na(dh) & !is.na(gload_all)
  if (sum(valid_j) >= 5) {
    rt <- cor.test(gload_all[valid_j], dh[valid_j])
    cat(sprintf("  %-12s  %8.3f  [%5.3f,%5.3f]  %8.4f  %5d-%d\n",
                specs[j], rt$estimate, rt$conf.int[1], rt$conf.int[2],
                rt$p.value, min(n_mat[valid_j, j]), max(n_mat[valid_j, j])))
  }
}

# 4c. Diagnose: pair-type-specific sibling correlations by SES for each subtest
cat("\n  4c. Sibling r(IQ) by SES split, per subtest and pair type:\n")
cat("      (Median split on pair-mean SEI within each pair type)\n\n")
cat(sprintf("  %-20s  %6s  %6s  %6s  %6s  %6s  %6s  %6s  %6s\n",
            "Subtest", "FS_lo", "FS_hi", "d_FS", "HS_lo", "HS_hi", "d_HS", "N_FS", "N_HS"))
cat("  ", strrep("-", 80), "\n")

for (k in seq_along(subtest_vars)) {
  sv <- subtest_vars[k]
  tp_all <- build_subtest_pairs(sv, c("MZ", "DZ", "FS", "HS"))
  tp_all[, s1_z := as.numeric(scale(s1))]
  tp_all[, s2_z := as.numeric(scale(s2))]

  # FS split
  fs <- tp_all[pair_class == "FS"]
  fs_med <- median(fs$sei, na.rm = TRUE)
  r_fs_lo <- fs[sei <= fs_med, cor(s1_z, s2_z)]
  r_fs_hi <- fs[sei > fs_med, cor(s1_z, s2_z)]

  # HS split
  hs <- tp_all[pair_class == "HS"]
  hs_med <- median(hs$sei, na.rm = TRUE)
  r_hs_lo <- if (hs[sei <= hs_med, .N] >= 20) hs[sei <= hs_med, cor(s1_z, s2_z)] else NA
  r_hs_hi <- if (hs[sei > hs_med, .N] >= 20) hs[sei > hs_med, cor(s1_z, s2_z)] else NA

  cat(sprintf("  %-20s  %6.3f  %6.3f  %6.3f  %6s  %6s  %6s  %6d  %6d\n",
              subtest_labels[k], r_fs_lo, r_fs_hi, r_fs_hi - r_fs_lo,
              ifelse(is.na(r_hs_lo), "  -- ", sprintf("%.3f", r_hs_lo)),
              ifelse(is.na(r_hs_hi), "  -- ", sprintf("%.3f", r_hs_hi)),
              ifelse(is.na(r_hs_lo) | is.na(r_hs_hi), "  -- ",
                     sprintf("%.3f", r_hs_hi - r_hs_lo)),
              nrow(fs), nrow(hs)))
}

# 4d. Key question: Does the FS-only SES split show Scarr-Rowe?
cat("\n  4d. FS-only: does sibling r increase with SES? (Scarr-Rowe prediction)\n")
cat("      If Scarr-Rowe holds, r(hi) > r(lo) for FS pairs,\n")
cat("      because genetic variance is released at higher SES.\n")
cat("      But FS r = a²*(1+m)/2 + c²_fam, so higher r at high SES\n")
cat("      could reflect either higher a² OR higher c²_fam.\n\n")

# Use the stored Spec F results (r_hi - r_lo for FS)
fs_deltas <- delta_mat[, 6]
cat(sprintf("  Mean FS delta-r (hi - lo): %.4f\n", mean(fs_deltas, na.rm = TRUE)))
cat(sprintf("  Subtests with positive delta-r: %d/%d\n",
            sum(fs_deltas > 0, na.rm = TRUE), sum(!is.na(fs_deltas))))
r_fs_gload <- cor.test(gload_all, fs_deltas)
cat(sprintf("  r(g-loading, FS delta-r): %.3f (p = %.4f)\n",
            r_fs_gload$estimate, r_fs_gload$p.value))

# Store preferred multi-level results for paper (Spec C: MZ+DZ+FS with twin effects)
gload_ml <- gload_all
delta_h2_ml <- delta_mat[, 3]  # Spec C
h2_lo_ml <- h2lo_mat[, 3]
h2_hi_ml <- h2hi_mat[, 3]
n_pairs_ml <- n_mat[, 3]

valid_ml <- !is.na(delta_h2_ml) & !is.na(gload_ml)
n_subtests_ml <- sum(valid_ml)
r_test_ml <- if (n_subtests_ml >= 5) cor.test(gload_ml[valid_ml], delta_h2_ml[valid_ml]) else NULL

cat("\n")
cat(strrep("-", 70), "\n")
cat("SUMMARY: g-Loading x SES Moderation Across Specifications\n")
cat(strrep("-", 70), "\n")
if (!is.null(r_test_ml)) {
  cat(sprintf("  Twin-only (Myri):      r = %.3f (p = %.4f, N ~ %d-%d pairs)\n",
              r_test$estimate, r_test$p.value, min(n_pairs_vec), max(n_pairs_vec)))
  cat(sprintf("  Multi-level (preferred): r = %.3f (p = %.4f, N ~ %d-%d pairs)\n",
              r_test_ml$estimate, r_test_ml$p.value,
              min(n_pairs_ml[valid_ml]), max(n_pairs_ml[valid_ml])))
  cat(sprintf("  FS-only (delta-r):     r = %.3f (p = %.4f)\n",
              r_fs_gload$estimate, r_fs_gload$p.value))
}

# ── Save ──────────────────────────────────────────────────────────────
results <- list(
  df_base = df_base,
  df_moderated = df_mod,
  df_multi_base = df_multi_base,
  df_multi_mod = df_multi_mod,
  cor_table = cor_tab,
  cor_overall = cor_all,
  twin_pairs_myri = tp,
  kinship_pairs = pair_iq,
  g_loadings = g_loadings,
  h2_by_subtest = data.table(
    subtest = subtest_vars,
    label = subtest_labels,
    g_loading = gload_vec,
    h2_low_ses = h2_lo_vec,
    h2_high_ses = h2_hi_vec,
    delta_h2 = delta_h2_vec,
    n_pairs = n_pairs_vec
  ),
  g_delta_cor = if (n_subtests >= 5) r_test else NULL,
  h2_by_subtest_multilevel = data.table(
    subtest = subtest_vars,
    label = subtest_labels,
    g_loading = gload_ml,
    h2_low_ses = h2_lo_ml,
    h2_high_ses = h2_hi_ml,
    delta_h2 = delta_h2_ml,
    n_pairs = n_pairs_ml
  ),
  g_delta_cor_multilevel = if (n_subtests_ml >= 5) r_test_ml else NULL
)
saveRDS(results, "results_replication_turkheimer.rds")
cat("\nResults saved to results_replication_turkheimer.rds\n")
