library(data.table)
library(fixest)

d <- readRDS("prepared_data.rds")
growth <- as.data.table(readRDS("prepared_growth.rds"))
hc_results <- list()

# Merge HC at birth, 12mo, 84mo
for (age in c(0, 12, 84)) {
  hc_tmp <- growth[measure == "head_circ_cm" & age_months == age,
                   .(case_id = as.character(case_id), value)]
  setnames(hc_tmp, "value", paste0("hc_", age, "mo"))
  d <- merge(d, hc_tmp, by = "case_id", all.x = TRUE)
}

# Restrict to B/W siblings
sib <- d[race %in% c(1, 2) & !is.na(mother_id)]
sib[, n_sibs := .N, by = mother_id]
sib_fam <- sib[n_sibs >= 2]

# Standardize HC within sex
for (v in c("hc_0mo", "hc_12mo", "hc_84mo")) {
  sib_fam[, paste0(v, "_z") := as.numeric(scale(get(v))), by = sex]
}
sib_fam[, wisc_z := as.numeric(scale(wisc_fsiq))]
sib_fam[, sb_z := as.numeric(scale(sb_iq))]

cat("=== INDIVIDUAL HC AGES → WISC FSIQ (FE) ===\n\n")
for (hc_var in c("hc_0mo_z", "hc_12mo_z", "hc_84mo_z")) {
  sub <- sib_fam[!is.na(get(hc_var)) & !is.na(wisc_fsiq)]
  m <- feols(as.formula(paste("wisc_z ~", hc_var, "+ factor(sex) + birth_order | mother_id")),
             data = sub, vcov = ~mother_id)
  ct <- coeftable(m)[hc_var, ]
  hc_results[[length(hc_results) + 1L]] <- data.table(
    model = "Individual age -> WISC", term = hc_var,
    estimate = ct["Estimate"], std_error = ct["Std. Error"],
    p_value = ct["Pr(>|t|)"], n = nobs(m), families = uniqueN(sub$mother_id)
  )
  cat(sprintf("  %s → WISC: b = %.4f (SE = %.4f), p = %.4f, N = %d, fams = %d\n",
      hc_var, ct["Estimate"], ct["Std. Error"], ct["Pr(>|t|)"],
      nobs(m), uniqueN(sub$mother_id)))
}

cat("\n=== INDIVIDUAL HC AGES → SB IQ (FE) ===\n\n")
for (hc_var in c("hc_0mo_z", "hc_12mo_z", "hc_84mo_z")) {
  sub <- sib_fam[!is.na(get(hc_var)) & !is.na(sb_iq)]
  m <- feols(as.formula(paste("sb_z ~", hc_var, "+ factor(sex) + birth_order | mother_id")),
             data = sub, vcov = ~mother_id)
  ct <- coeftable(m)[hc_var, ]
  hc_results[[length(hc_results) + 1L]] <- data.table(
    model = "Individual age -> SB", term = hc_var,
    estimate = ct["Estimate"], std_error = ct["Std. Error"],
    p_value = ct["Pr(>|t|)"], n = nobs(m), families = uniqueN(sub$mother_id)
  )
  cat(sprintf("  %s → SB:   b = %.4f (SE = %.4f), p = %.4f, N = %d, fams = %d\n",
      hc_var, ct["Estimate"], ct["Std. Error"], ct["Pr(>|t|)"],
      nobs(m), uniqueN(sub$mother_id)))
}

cat("\n=== JOINT HC MODELS → WISC FSIQ (FE) ===\n\n")

# Birth + 7yr
sub2 <- sib_fam[!is.na(hc_0mo_z) & !is.na(hc_84mo_z) & !is.na(wisc_fsiq)]
m2 <- feols(wisc_z ~ hc_0mo_z + hc_84mo_z + factor(sex) + birth_order | mother_id,
            data = sub2, vcov = ~mother_id)
cat(sprintf("Birth + 7yr → WISC (N = %d, fams = %d):\n", nobs(m2), uniqueN(sub2$mother_id)))
ct2 <- coeftable(m2)
cat(sprintf("  hc_0mo:  b = %.4f (SE = %.4f), p = %.4f\n",
    ct2["hc_0mo_z", "Estimate"], ct2["hc_0mo_z", "Std. Error"], ct2["hc_0mo_z", "Pr(>|t|)"]))
cat(sprintf("  hc_84mo: b = %.4f (SE = %.4f), p = %.4f\n",
    ct2["hc_84mo_z", "Estimate"], ct2["hc_84mo_z", "Std. Error"], ct2["hc_84mo_z", "Pr(>|t|)"]))

# 12mo + 7yr
sub3 <- sib_fam[!is.na(hc_12mo_z) & !is.na(hc_84mo_z) & !is.na(wisc_fsiq)]
m3 <- feols(wisc_z ~ hc_12mo_z + hc_84mo_z + factor(sex) + birth_order | mother_id,
            data = sub3, vcov = ~mother_id)
cat(sprintf("\n12mo + 7yr → WISC (N = %d, fams = %d):\n", nobs(m3), uniqueN(sub3$mother_id)))
ct3 <- coeftable(m3)
cat(sprintf("  hc_12mo: b = %.4f (SE = %.4f), p = %.4f\n",
    ct3["hc_12mo_z", "Estimate"], ct3["hc_12mo_z", "Std. Error"], ct3["hc_12mo_z", "Pr(>|t|)"]))
cat(sprintf("  hc_84mo: b = %.4f (SE = %.4f), p = %.4f\n",
    ct3["hc_84mo_z", "Estimate"], ct3["hc_84mo_z", "Std. Error"], ct3["hc_84mo_z", "Pr(>|t|)"]))

# All three: birth + 12mo + 7yr
sub4 <- sib_fam[!is.na(hc_0mo_z) & !is.na(hc_12mo_z) & !is.na(hc_84mo_z) & !is.na(wisc_fsiq)]
m4 <- feols(wisc_z ~ hc_0mo_z + hc_12mo_z + hc_84mo_z + factor(sex) + birth_order | mother_id,
            data = sub4, vcov = ~mother_id)
cat(sprintf("\nBirth + 12mo + 7yr → WISC (N = %d, fams = %d):\n", nobs(m4), uniqueN(sub4$mother_id)))
ct4 <- coeftable(m4)
cat(sprintf("  hc_0mo:  b = %.4f (SE = %.4f), p = %.4f\n",
    ct4["hc_0mo_z", "Estimate"], ct4["hc_0mo_z", "Std. Error"], ct4["hc_0mo_z", "Pr(>|t|)"]))
cat(sprintf("  hc_12mo: b = %.4f (SE = %.4f), p = %.4f\n",
    ct4["hc_12mo_z", "Estimate"], ct4["hc_12mo_z", "Std. Error"], ct4["hc_12mo_z", "Pr(>|t|)"]))
cat(sprintf("  hc_84mo: b = %.4f (SE = %.4f), p = %.4f\n",
    ct4["hc_84mo_z", "Estimate"], ct4["hc_84mo_z", "Std. Error"], ct4["hc_84mo_z", "Pr(>|t|)"]))

cat("\n=== JOINT HC MODELS → SB IQ (FE) ===\n\n")

# All three: birth + 12mo + 7yr → SB
# Note: SB is at age 4, so 7yr HC is measured AFTER SB
# Only birth and 12mo HC precede SB
sub5 <- sib_fam[!is.na(hc_0mo_z) & !is.na(hc_12mo_z) & !is.na(sb_iq)]
m5 <- feols(sb_z ~ hc_0mo_z + hc_12mo_z + factor(sex) + birth_order | mother_id,
            data = sub5, vcov = ~mother_id)
cat(sprintf("Birth + 12mo → SB (N = %d, fams = %d):\n", nobs(m5), uniqueN(sub5$mother_id)))
ct5 <- coeftable(m5)
cat(sprintf("  hc_0mo:  b = %.4f (SE = %.4f), p = %.4f\n",
    ct5["hc_0mo_z", "Estimate"], ct5["hc_0mo_z", "Std. Error"], ct5["hc_0mo_z", "Pr(>|t|)"]))
cat(sprintf("  hc_12mo: b = %.4f (SE = %.4f), p = %.4f\n",
    ct5["hc_12mo_z", "Estimate"], ct5["hc_12mo_z", "Std. Error"], ct5["hc_12mo_z", "Pr(>|t|)"]))

# Correlation between HC measures within families (to see collinearity)
cat("\n=== WITHIN-FAMILY CORRELATIONS BETWEEN HC AGES ===\n\n")
sub_all <- sib_fam[!is.na(hc_0mo_z) & !is.na(hc_12mo_z) & !is.na(hc_84mo_z)]
cat(sprintf("r(hc_0mo, hc_12mo) = %.3f\n", cor(sub_all$hc_0mo_z, sub_all$hc_12mo_z)))
cat(sprintf("r(hc_0mo, hc_84mo) = %.3f\n", cor(sub_all$hc_0mo_z, sub_all$hc_84mo_z)))
cat(sprintf("r(hc_12mo, hc_84mo) = %.3f\n", cor(sub_all$hc_12mo_z, sub_all$hc_84mo_z)))

# Within-family (demeaned) correlations
sub_all[, hc0_dm := hc_0mo_z - mean(hc_0mo_z), by = mother_id]
sub_all[, hc12_dm := hc_12mo_z - mean(hc_12mo_z), by = mother_id]
sub_all[, hc84_dm := hc_84mo_z - mean(hc_84mo_z), by = mother_id]
cat(sprintf("\nWithin-family (demeaned):\n"))
cat(sprintf("r(hc_0mo, hc_12mo) = %.3f\n", cor(sub_all$hc0_dm, sub_all$hc12_dm)))
cat(sprintf("r(hc_0mo, hc_84mo) = %.3f\n", cor(sub_all$hc0_dm, sub_all$hc84_dm)))
cat(sprintf("r(hc_12mo, hc_84mo) = %.3f\n", cor(sub_all$hc12_dm, sub_all$hc84_dm)))

append_joint <- function(model, label, sub) {
  ct <- as.data.table(coeftable(model), keep.rownames = "term")
  ct <- ct[grepl("^hc_", term)]
  ct[, .(
    model = label,
    term,
    estimate = Estimate,
    std_error = `Std. Error`,
    p_value = `Pr(>|t|)`,
    n = nobs(model),
    families = uniqueN(sub$mother_id)
  )]
}

hc_results <- rbindlist(c(
  hc_results,
  list(
    append_joint(m2, "Birth + age 7 -> WISC", sub2),
    append_joint(m3, "Age 1 + age 7 -> WISC", sub3),
    append_joint(m4, "Birth + age 1 + age 7 -> WISC", sub4),
    append_joint(m5, "Birth + age 1 -> SB", sub5)
  )
), fill = TRUE)

fwrite(hc_results, "results_hc_iq_clustered.csv")
saveRDS(
  list(individual_and_joint = hc_results, wisc_birth_age7 = m2,
       wisc_age1_age7 = m3, wisc_all_ages = m4, sb_birth_age1 = m5),
  "results_hc_iq_clustered.rds"
)
cat("Wrote results_hc_iq_clustered.csv and results_hc_iq_clustered.rds.\n")
