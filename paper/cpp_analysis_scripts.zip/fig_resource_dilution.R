#!/usr/bin/env Rscript
# fig_resource_dilution.R — Resource dilution test results
# Panel A: Family size → IQ (between-family gradient)
# Panel B: Within-family tests

library(data.table)
library(fixest)

d <- readRDS("prepared_data.rds")

# ---- Panel A data: IQ by family size (between-family) ----
all_iq <- d[!is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
all_iq[, race_label := ifelse(race == 1, "White", "Black")]
all_iq[, family_size := n_kids]
all_iq[family_size > 6, family_size := 6]  # Cap at 6+

fs_desc <- all_iq[, .(mean_iq = mean(wisc_fsiq), se_iq = sd(wisc_fsiq) / sqrt(.N),
                        n = .N),
                   by = family_size][order(family_size)]

# ---- Panel B data: Within-family dilution tests ----
sib <- d[!is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
sib[, n_sibs := .N, by = mother_id]
sib_fam <- sib[n_sibs >= 2]

# 1. Birth order (WISC, FE)
m_bo <- feols(wisc_fsiq ~ birth_order + factor(sex) | mother_id,
              data = sib_fam[!is.na(birth_order)], vcov = ~mother_id)

# 2. Birth spacing (FE)
sib_fam <- sib_fam[order(mother_id, birth_order)]
sib_fam[, prev_mat_age := shift(maternal_age, 1), by = mother_id]
sib_fam[, spacing := maternal_age - prev_mat_age]
sib_fam[birth_order == 0 | spacing < 0.5 | spacing > 10, spacing := NA]
m_sp <- feols(wisc_fsiq ~ spacing + birth_order + factor(sex) | mother_id,
              data = sib_fam[!is.na(spacing)], vcov = ~mother_id)

# 3. Per-capita income (FE)
sib_fam[, inc_per_child := income / pmax(birth_order + 1, 1)]
m_pc <- feols(wisc_fsiq ~ inc_per_child + factor(sex) | mother_id,
              data = sib_fam[!is.na(inc_per_child)], vcov = ~mother_id)

# 4. IQ change from gaining siblings (birth to 7, FE + SB baseline)
# Need to reconstruct the gained siblings measure
both <- d[!is.na(sb_iq) & !is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
both[, iq_change := wisc_fsiq - sb_iq]
mother_kids <- d[!is.na(mother_id) & !is.na(birth_order) & !is.na(maternal_age),
                 .(case_id, mother_id, birth_order, maternal_age)]
sibs_all <- merge(
  both[, .(focal_id = case_id, mother_id, focal_mat_age = maternal_age)],
  mother_kids[, .(sib_id = case_id, mother_id, sib_mat_age = maternal_age)],
  by = "mother_id", allow.cartesian = TRUE)
sibs_all <- sibs_all[focal_id != sib_id]
sibs_all[, focal_age_when_sib_born := sib_mat_age - focal_mat_age]
sibs_wide <- sibs_all[focal_age_when_sib_born > 0 & focal_age_when_sib_born <= 7.5]
n_new <- sibs_wide[, .(n_new_sibs = .N), by = focal_id]
both <- merge(both, n_new, by.x = "case_id", by.y = "focal_id", all.x = TRUE)
both <- as.data.table(both)
both[is.na(n_new_sibs), n_new_sibs := 0]
both[, n_in_fam := .N, by = mother_id]
both_fe <- both[n_in_fam >= 2]
m_gain <- feols(iq_change ~ n_new_sibs + sb_iq + factor(sex) | mother_id,
                data = both_fe, vcov = ~mother_id)

# Scale all to "IQ points per 1 SD of the predictor" for comparability
# (except BO which is already interpretable)
sd_bo <- sd(sib_fam$birth_order, na.rm = TRUE)
sd_sp <- sd(sib_fam$spacing, na.rm = TRUE)
sd_pc <- sd(sib_fam$inc_per_child, na.rm = TRUE)
sd_gain <- sd(both_fe$n_new_sibs, na.rm = TRUE)

tests <- data.frame(
  label = c("Birth order\n(per parity)",
            "Birth spacing\n(per year)",
            "Income/child\n(per 10 units)",
            "Gained siblings\n(IQ change, per sib)"),
  b = c(coef(m_bo)["birth_order"],
        coef(m_sp)["spacing"],
        coef(m_pc)["inc_per_child"] * 10,  # scale to per 10 units
        coef(m_gain)["n_new_sibs"]),
  se = c(se(m_bo)["birth_order"],
         se(m_sp)["spacing"],
         se(m_pc)["inc_per_child"] * 10,
         se(m_gain)["n_new_sibs"]),
  stringsAsFactors = FALSE
)
tests$lo <- tests$b - 1.96 * tests$se
tests$hi <- tests$b + 1.96 * tests$se
tests$sig <- abs(tests$b / tests$se) > 1.96

# ---- Plot ----
pdf("fig_resource_dilution.pdf", width = 10, height = 5)
par(mfrow = c(1, 2), family = "serif")

col_bw <- "#2C3E50"
col_wf <- "#8B1A1A"
col_ns <- "#C46B6B"

# --- Panel A: Family size gradient (between-family) ---
par(mar = c(5, 5, 4, 1))

max_fs <- max(fs_desc$family_size)
y_lo <- floor(min(fs_desc$mean_iq) / 2) * 2  # round down to nearest even
y_hi <- ceiling(max(fs_desc$mean_iq) / 2) * 2  # round up to nearest even

plot(fs_desc$family_size, fs_desc$mean_iq,
     type = "n",
     xlim = c(0.5, max_fs + 0.5), ylim = c(y_lo, y_hi),
     xaxt = "n", yaxt = "n",
     xlab = "", ylab = "", bty = "n")

# Gridlines
for (gy in seq(y_lo, y_hi, by = 2)) {
  segments(0.5, gy, max_fs + 0.5, gy, col = "grey85", lwd = 0.5)
}

# Bars
for (i in 1:nrow(fs_desc)) {
  rect(fs_desc$family_size[i] - 0.35, y_lo,
       fs_desc$family_size[i] + 0.35, fs_desc$mean_iq[i],
       col = col_bw, border = NA)
  # Value label
  text(fs_desc$family_size[i], fs_desc$mean_iq[i] + 0.5,
       sprintf("%.1f", fs_desc$mean_iq[i]), cex = 0.7, font = 2, col = col_bw)
}

# Individual-level adjusted slope (retain uncapped family size)
m_fs <- lm(wisc_fsiq ~ n_kids + factor(sex) + factor(race), data = all_iq)
x_pred <- seq(1, max_fs, length.out = 100)
# Draw the adjusted slope through the observed centroid; bars remain descriptive means.
y_pred <- mean(all_iq$wisc_fsiq) + coef(m_fs)["n_kids"] *
  (x_pred - mean(all_iq$n_kids))
lines(x_pred, y_pred, col = col_wf, lwd = 2, lty = 2)

x_labels <- as.character(1:max_fs)
x_labels[max_fs] <- paste0(max_fs, "+")
axis(1, at = 1:max_fs, labels = x_labels, cex.axis = 0.9)
axis(2, at = seq(y_lo, y_hi, 2), las = 1, cex.axis = 0.85)
mtext("Number of children in family", side = 1, line = 2.5, cex = 0.9)
mtext("Mean WISC FSIQ", side = 2, line = 3, cex = 0.9)
mtext("A. Between-Family: Family Size and IQ", side = 3, line = 1.5,
      cex = 1.0, font = 2, adj = 0)
mtext(bquote(italic(b) * " = " * .(sprintf("%.2f", coef(m_fs)["n_kids"])) *
               " per child (sex/race adjusted)"), side = 3, line = 0.2,
      cex = 0.8, col = "grey30", adj = 0)

# --- Panel B: Within-family dilution tests ---
par(mar = c(5, 9, 4, 2))

n_tests <- nrow(tests)
y_pos <- n_tests:1

xlim <- c(min(tests$lo) - 0.3, max(tests$hi) + 0.3)
xlim <- c(-1.5, 1.5)

plot(NULL, xlim = xlim, ylim = c(0.3, n_tests + 0.7),
     xaxt = "n", yaxt = "n", xlab = "", ylab = "", bty = "n")

# Vertical gridlines
for (gx in seq(-1.5, 1.5, by = 0.5)) {
  segments(gx, 0.3, gx, n_tests + 0.7, col = "grey85", lwd = 0.5)
}

# Zero line
abline(v = 0, col = "grey40", lwd = 1.5)

# Points and CIs
for (i in 1:n_tests) {
  pt_col <- ifelse(tests$sig[i], col_wf, col_ns)
  # CI
  segments(tests$lo[i], y_pos[i], tests$hi[i], y_pos[i],
           col = pt_col, lwd = 2)
  # Point
  points(tests$b[i], y_pos[i], pch = 19, col = pt_col, cex = 1.5)
}

# Y axis labels
axis(2, at = y_pos, labels = tests$label, las = 1, tick = FALSE, cex.axis = 0.85)

# X axis
axis(1, at = seq(-1.5, 1.5, 0.5), cex.axis = 0.85)
mtext("IQ points (Mother FE)", side = 1, line = 2.5, cex = 0.9)

mtext("B. Within-Family: Resource Dilution Tests", side = 3, line = 1.5,
      cex = 1.0, font = 2, adj = 0)
mtext("All estimates from mother fixed effects", side = 3, line = 0.2,
      cex = 0.8, col = "grey30", adj = 0)

# Legend
legend("bottomright", legend = c("p < 0.05", "Not significant"),
       col = c(col_wf, col_ns), pch = 19, pt.cex = 1.3,
       bty = "n", cex = 0.8)

dev.off()
cat("Wrote fig_resource_dilution.pdf\n")
