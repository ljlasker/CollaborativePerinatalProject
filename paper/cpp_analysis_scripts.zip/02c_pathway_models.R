#!/usr/bin/env Rscript
# 02c_pathway_models.R
# Common Pathway (CP) vs Independent Pathway (IP) Models for WISC Subtests
#
# Tests whether genetic/environmental variance in cognitive subtests is
# mediated through a single latent g factor (CP) or operates through
# independent pathways (IP).
#
# Uses 4 relatedness groups: MZ twins, DZ twins, full siblings, half-siblings
# with 12 cognitive measures (7 WISC + 3 WRAT + Bender + Goodenough).

library(data.table)
library(OpenMx)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")

# Clean sentinel values
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}
if ("goodenough_standard" %in% names(d)) d[goodenough_standard == 888, goodenough_standard := NA]

links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

cat("\n")
cat("--- COMMON vs INDEPENDENT PATHWAY MODELS 12 Cognitive Measures, 4 Relatedness Groups ---
")

# ── Define subtests ────────────────────────────────────────────────────
sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Information", "Comprehension", "Vocabulary", "Digit Span",
                "Pic. Arrangement", "Block Design", "Coding",
                "WRAT Reading", "Bender",
                "WRAT Spelling", "WRAT Arithmetic", "Goodenough")
nv <- length(sub_vars)

# Factor groupings for HO/Bifactor models:
#   Verbal/Crystallized (indices 1-4, 8, 10-11): Info, Comp, Vocab, Digit, WRAT Read, Spell, Arith
#   Performance/Non-verbal (indices 5-7, 9, 12): PicArr, Block, Coding, Bender, Goodenough
v_idx <- c(1, 2, 3, 4, 8, 10, 11)
p_idx <- c(5, 6, 7, 9, 12)

# Approximate means for starting values (by subtest order)
start_means <- c(9.2, 8.7, 8.7, 9.6, 9.1, 9.4, 10.0, 33.8, -8.4,
                 23.7, 20.0, 19.7)

# ---- PART A: DATA PREPARATION ----
cat("\n")
cat("--- PART A: Data Preparation ---
")

# Extract subtests for each individual
d_sub <- d[, c("case_id", sub_vars), with = FALSE]

# Build pair-level wide-format data
pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
old_names <- sub_vars
new_names1 <- paste0(sub_vars, "_1")
setnames(pair, old_names, new_names1)

pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
new_names2 <- paste0(sub_vars, "_2")
setnames(pair, old_names, new_names2)

# Classify pair types
pair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair <- pair[!is.na(pair_class)]

# Check which pairs have at least one subtest for both members
has_any_1 <- rowSums(!is.na(pair[, ..new_names1])) > 0
has_any_2 <- rowSums(!is.na(pair[, ..new_names2])) > 0
pair <- pair[has_any_1 & has_any_2]

cat(sprintf("\nPairs with at least one subtest per member:\n"))
cat(sprintf("  MZ: %d, DZ: %d, FS: %d, HS: %d (total: %d)\n",
            pair[pair_class == "MZ", .N], pair[pair_class == "DZ", .N],
            pair[pair_class == "FS", .N], pair[pair_class == "HS", .N],
            nrow(pair)))

# Missingness per subtest per group
cat("\n  Completeness (% non-missing) by subtest and group:\n")
cat(sprintf("  %-15s", "Subtest"))
for (pc in c("MZ", "DZ", "FS", "HS")) cat(sprintf("  %6s", pc))
cat("\n")
cat("  ", strrep("-", 15 + 4*8), "\n")
for (i in seq_along(sub_vars)) {
  cat(sprintf("  %-15s", sub_labels[i]))
  for (pc in c("MZ", "DZ", "FS", "HS")) {
    sub <- pair[pair_class == pc]
    pct <- 100 * mean(!is.na(sub[[new_names1[i]]]) & !is.na(sub[[new_names2[i]]]))
    cat(sprintf("  %5.1f%%", pct))
  }
  cat("\n")
}

# Descriptive: means and SDs
cat("\n  Subtest means and SDs (pooled across all individuals in pairs):\n")
cat(sprintf("  %-15s  %8s  %8s  %8s\n", "Subtest", "Mean", "SD", "N"))
cat("  ", strrep("-", 45), "\n")
for (i in seq_along(sub_vars)) {
  all_vals <- c(pair[[new_names1[i]]], pair[[new_names2[i]]])
  all_vals <- all_vals[!is.na(all_vals)]
  cat(sprintf("  %-15s  %8.2f  %8.2f  %8d\n",
              sub_labels[i], mean(all_vals), sd(all_vals), length(all_vals)))
}

# Cross-pair correlations by group
cat("\n  Cross-pair correlations (same subtest) by group:\n")
cat(sprintf("  %-15s", "Subtest"))
for (pc in c("MZ", "DZ", "FS", "HS")) cat(sprintf("  %8s", pc))
cat("\n")
cat("  ", strrep("-", 15 + 4*10), "\n")
for (i in seq_along(sub_vars)) {
  cat(sprintf("  %-15s", sub_labels[i]))
  for (pc in c("MZ", "DZ", "FS", "HS")) {
    sub <- pair[pair_class == pc]
    cc <- sub[!is.na(get(new_names1[i])) & !is.na(get(new_names2[i]))]
    if (nrow(cc) >= 10) {
      r_val <- cor(cc[[new_names1[i]]], cc[[new_names2[i]]])
      cat(sprintf("  %8.3f", r_val))
    } else {
      cat(sprintf("  %8s", "--"))
    }
  }
  cat("\n")
}

# ---- PART B: 4-GROUP PATHWAY MODELS (MZ + DZ + FS + HS) ----
cat("\n")
cat("--- PART B: 4-Group Pathway Models (MZ + DZ + FS + HS) ---
")

# Prepare data for OpenMx
var_names <- c(new_names1, new_names2)  # 18 variables per pair

# Split into groups
mz_data <- as.data.frame(pair[pair_class == "MZ", ..var_names])
dz_data <- as.data.frame(pair[pair_class == "DZ", ..var_names])
fs_data <- as.data.frame(pair[pair_class == "FS", ..var_names])
hs_data <- as.data.frame(pair[pair_class == "HS", ..var_names])

cat(sprintf("\n  Group sizes: MZ=%d, DZ=%d, FS=%d, HS=%d\n",
            nrow(mz_data), nrow(dz_data), nrow(fs_data), nrow(hs_data)))

# ── Helper: build expected covariance for a group ─────────────────────
# Given A (nv x nv), C (nv x nv), E (nv x nv),
# the expected 2*nv x 2*nv covariance matrix is:
#   [   V    |  B(R) ]
#   [ B(R)'  |   V   ]
# where V = A + C + E
# and B(R) = R*A + C

# ── Model 1: Cholesky ACE(T) ──────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model 1: Cholesky ACE(T) Decomposition\n")
cat(strrep("-", 70), "\n")

# Use lower-triangular Cholesky factors
chol_model <- mxModel("Cholesky",

  # Free parameters (shared across groups)
  mxMatrix("Lower", nv, nv, free = TRUE, values = diag(1, nv),
           lbound = -.999, name = "aL"),
  mxMatrix("Lower", nv, nv, free = TRUE, values = diag(.5, nv),
           lbound = -.999, name = "cL"),
  mxMatrix("Lower", nv, nv, free = TRUE, values = diag(.5, nv),
           lbound = -.999, name = "eL"),

  # Means
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  # Covariance components
  mxAlgebra(aL %*% t(aL), name = "A"),
  mxAlgebra(cL %*% t(cL), name = "C"),
  mxAlgebra(eL %*% t(eL), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  # MZ group: R=1
  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(Cholesky.A + Cholesky.C, name = "B_MZ"),
    mxAlgebra(rbind(cbind(Cholesky.V, B_MZ),
                    cbind(B_MZ, Cholesky.V)), name = "expCov"),
    mxAlgebra(cbind(Cholesky.Mu, Cholesky.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # DZ group: R=0.5
  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * Cholesky.A + Cholesky.C, name = "B_DZ"),
    mxAlgebra(rbind(cbind(Cholesky.V, B_DZ),
                    cbind(B_DZ, Cholesky.V)), name = "expCov"),
    mxAlgebra(cbind(Cholesky.Mu, Cholesky.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # FS group: R=0.5, twin=0
  mxModel("FS",
    mxData(fs_data, type = "raw"),
    mxAlgebra(0.5 * Cholesky.A + Cholesky.C, name = "B_FS"),
    mxAlgebra(rbind(cbind(Cholesky.V, B_FS),
                    cbind(B_FS, Cholesky.V)), name = "expCov"),
    mxAlgebra(cbind(Cholesky.Mu, Cholesky.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # HS group: R=0.25, twin=0
  mxModel("HS",
    mxData(hs_data, type = "raw"),
    mxAlgebra(0.25 * Cholesky.A + Cholesky.C, name = "B_HS"),
    mxAlgebra(rbind(cbind(Cholesky.V, B_HS),
                    cbind(B_HS, Cholesky.V)), name = "expCov"),
    mxAlgebra(cbind(Cholesky.Mu, Cholesky.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
)

cat("  Fitting Cholesky model...\n")
chol_fit <- mxTryHard(chol_model, extraTries = 10, silent = TRUE)
chol_sum <- summary(chol_fit)
cat(sprintf("  Cholesky: -2LL = %.2f, df = %d, AIC = %.2f, status = %d\n",
            chol_sum$Minus2LogLikelihood, chol_sum$degreesOfFreedom,
            chol_sum$AIC.Mx, chol_fit$output$status$code))

# ── Model 2: Independent Pathway (IP) ──────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model 2: Independent Pathway (IP)\n")
cat(strrep("-", 70), "\n")
cat("  Common A, C, E factors with free loadings on each subtest\n")
cat("  + subtest-specific A, C, E residuals (diagonal)\n")
cat("  No twin-specific (T) component\n\n")

ip_model <- mxModel("IP",

  # Common factor loadings (one factor per variance component)
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.2, nv),
           lbound = -5, name = "ac"),  # common A loadings
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.8, nv),
           lbound = -5, name = "cc"),  # common C loadings
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.0, nv),
           lbound = -5, name = "ec"),  # common E loadings

  # Subtest-specific residual SDs (diagonal, squared for variances)
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.2, nv),
           lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
           lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.2, nv),
           lbound = 0.001, name = "es"),

  # Means
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  # Covariance components
  mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
  mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
  mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  # MZ: R=1
  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(IP.A + IP.C, name = "B_MZ"),
    mxAlgebra(rbind(cbind(IP.V, B_MZ), cbind(B_MZ, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # DZ: R=0.5
  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * IP.A + IP.C, name = "B_DZ"),
    mxAlgebra(rbind(cbind(IP.V, B_DZ), cbind(B_DZ, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # FS: R=0.5, twin=0
  mxModel("FS",
    mxData(fs_data, type = "raw"),
    mxAlgebra(0.5 * IP.A + IP.C, name = "B_FS"),
    mxAlgebra(rbind(cbind(IP.V, B_FS), cbind(B_FS, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # HS: R=0.25, twin=0
  mxModel("HS",
    mxData(hs_data, type = "raw"),
    mxAlgebra(0.25 * IP.A + IP.C, name = "B_HS"),
    mxAlgebra(rbind(cbind(IP.V, B_HS), cbind(B_HS, IP.V)), name = "expCov"),
    mxAlgebra(cbind(IP.Mu, IP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
)

cat("  Fitting IP model...\n")
ip_fit <- mxTryHard(ip_model, extraTries = 100, silent = TRUE)
ip_sum <- summary(ip_fit)
cat(sprintf("  IP: -2LL = %.2f, df = %d, AIC = %.2f, status = %d, infoDefinite = %s\n",
            ip_sum$Minus2LogLikelihood, ip_sum$degreesOfFreedom,
            ip_sum$AIC.Mx, ip_fit$output$status$code,
            ifelse(is.na(ip_sum$infoDefinite), "NA", as.character(ip_sum$infoDefinite))))

# ── Model 3: Common Pathway (CP) ──────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model 3: Common Pathway (CP)\n")
cat(strrep("-", 70), "\n")
cat("  One latent factor g with ACE decomposition (no T)\n")
cat("  + subtest-specific ACE residuals (diagonal)\n")
cat("  Factor variance fixed to 1 for identification\n\n")

cp_model <- mxModel("CP",

  # Factor loadings (9 free lambdas)
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.8, nv),
           lbound = 0.01, name = "lambda"),

  # Factor ACE path coefficients (factor variance = a_f^2 + c_f^2 + e_f^2 = 1)
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.65, lbound = 0.01,
           ubound = 0.99, name = "af"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.45, lbound = 0.01,
           ubound = 0.99, name = "cf"),

  # e_f = sqrt(1 - af^2 - cf^2)
  mxAlgebra(sqrt(1 - af*af - cf*cf), name = "ef"),

  # Constraint: af^2 + cf^2 < 1
  mxConstraint(af*af + cf*cf < 0.999, name = "factorVarConstraint"),

  # Subtest-specific residual SDs
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
           lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "es"),

  # Means
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  # Covariance components
  mxAlgebra(lambda %*% (af*af) %*% t(lambda) + as %*% t(as), name = "A"),
  mxAlgebra(lambda %*% (cf*cf) %*% t(lambda) + cs %*% t(cs), name = "C"),
  mxAlgebra(lambda %*% (ef*ef) %*% t(lambda) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  # MZ: R=1
  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(CP.A + CP.C, name = "B_MZ"),
    mxAlgebra(rbind(cbind(CP.V, B_MZ), cbind(B_MZ, CP.V)), name = "expCov"),
    mxAlgebra(cbind(CP.Mu, CP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # DZ: R=0.5
  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * CP.A + CP.C, name = "B_DZ"),
    mxAlgebra(rbind(cbind(CP.V, B_DZ), cbind(B_DZ, CP.V)), name = "expCov"),
    mxAlgebra(cbind(CP.Mu, CP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # FS: R=0.5, twin=0
  mxModel("FS",
    mxData(fs_data, type = "raw"),
    mxAlgebra(0.5 * CP.A + CP.C, name = "B_FS"),
    mxAlgebra(rbind(cbind(CP.V, B_FS), cbind(B_FS, CP.V)), name = "expCov"),
    mxAlgebra(cbind(CP.Mu, CP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  # HS: R=0.25, twin=0
  mxModel("HS",
    mxData(hs_data, type = "raw"),
    mxAlgebra(0.25 * CP.A + CP.C, name = "B_HS"),
    mxAlgebra(rbind(cbind(CP.V, B_HS), cbind(B_HS, CP.V)), name = "expCov"),
    mxAlgebra(cbind(CP.Mu, CP.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
)

cat("  Fitting CP model...\n")
cp_fit <- mxTryHard(cp_model, extraTries = 100, silent = TRUE)
cp_sum <- summary(cp_fit)
cat(sprintf("  CP: -2LL = %.2f, df = %d, AIC = %.2f, status = %d, infoDefinite = %s\n",
            cp_sum$Minus2LogLikelihood, cp_sum$degreesOfFreedom,
            cp_sum$AIC.Mx, cp_fit$output$status$code,
            ifelse(is.na(cp_sum$infoDefinite), "NA", as.character(cp_sum$infoDefinite))))
# Retry with SLSQP if Hessian is indefinite
if (!is.na(cp_sum$infoDefinite) && !cp_sum$infoDefinite) {
  cat("  CP Hessian indefinite — retrying with SLSQP optimizer...\n")
  cp_plan <- mxComputeSequence(list(
    mxComputeGradientDescent(engine = "SLSQP"),
    mxComputeNumericDeriv(), mxComputeStandardError(), mxComputeReportDeriv()))
  cp_fit2 <- mxTryHard(mxModel(cp_fit, cp_plan), extraTries = 100, silent = TRUE)
  cp_sum2 <- summary(cp_fit2)
  cat(sprintf("  CP [SLSQP]: -2LL = %.2f, infoDefinite = %s\n",
              cp_sum2$Minus2LogLikelihood,
              ifelse(is.na(cp_sum2$infoDefinite), "NA", as.character(cp_sum2$infoDefinite))))
  if ((!is.na(cp_sum2$infoDefinite) && cp_sum2$infoDefinite) ||
      cp_sum2$Minus2LogLikelihood < cp_sum$Minus2LogLikelihood) {
    cp_fit <- cp_fit2; cp_sum <- cp_sum2
  }
}

# ── Model 4: Higher-Order ────────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model 4: Higher-Order g (Verbal + Performance -> g)\n")
cat(strrep("-", 70), "\n")
cat("  Subtests -> V/P group factors -> second-order g\n")
cat("  ACE (no T) at g level, group-residual level, and specific level\n\n")

# Loading matrix Lambda (12x2):
#   V (col 1): indices 1-4,8,10-11; Info fixed to 1
#   P (col 2): indices 5-7,9,12; PicArr fixed to 1
ho_free <- matrix(FALSE, nv, 2)
ho_free[setdiff(v_idx, v_idx[1]), 1] <- TRUE   # All V except Info (marker)
ho_free[setdiff(p_idx, p_idx[1]), 2] <- TRUE   # All P except PicArr (marker)
ho_vals <- matrix(0, nv, 2)
ho_vals[v_idx[1], 1] <- 1          # Info fixed to 1
ho_vals[setdiff(v_idx, v_idx[1]), 1] <- c(0.8, 1.1, 0.9, 1.0, 0.9, 0.8)
ho_vals[p_idx[1], 2] <- 1          # PicArr fixed to 1
ho_vals[setdiff(p_idx, p_idx[1]), 2] <- c(0.8, 0.5, 0.7, 0.5)

ho_model <- mxModel("HO",

  # First-order loadings (9x2)
  mxMatrix("Full", nv, 2, free = ho_free, values = ho_vals, name = "Lambda"),

  # Higher-order loadings Gamma (2x1)
  mxMatrix("Full", 2, 1, free = TRUE, values = c(2.0, 2.0), name = "Gamma"),

  # g factor ACE proportions (variance = 1)
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.60, lbound = 0.01,
           ubound = 0.99, name = "ag"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.50, lbound = 0.01,
           ubound = 0.99, name = "cg"),
  mxAlgebra(sqrt(1 - ag*ag - cg*cg), name = "eg"),
  mxConstraint(ag*ag + cg*cg < 0.999, name = "gCon"),

  # Group residual paths (free, squared for variances)
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.5, lbound = 0, name = "arv"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.3, lbound = 0, name = "crv"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.5, lbound = 0, name = "erv"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.5, lbound = 0, name = "arp"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.3, lbound = 0, name = "crp"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.5, lbound = 0, name = "erp"),

  # Specific residual SDs (diagonal)
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
           lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "es"),

  # Means
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  # Helper: 2x2 diagonal matrices for group residuals
  mxAlgebra(rbind(cbind(arv*arv, 0), cbind(0, arp*arp)), name = "PsiA"),
  mxAlgebra(rbind(cbind(crv*crv, 0), cbind(0, crp*crp)), name = "PsiC"),
  mxAlgebra(rbind(cbind(erv*erv, 0), cbind(0, erp*erp)), name = "PsiE"),

  # Phi_x (2x2) = Gamma * x_g^2 * Gamma' + Psi_x
  mxAlgebra(Gamma %*% (ag*ag) %*% t(Gamma) + PsiA, name = "PhiA"),
  mxAlgebra(Gamma %*% (cg*cg) %*% t(Gamma) + PsiC, name = "PhiC"),
  mxAlgebra(Gamma %*% (eg*eg) %*% t(Gamma) + PsiE, name = "PhiE"),

  # Sigma_x (9x9) = Lambda * Phi_x * Lambda' + diag(x_si^2)
  mxAlgebra(Lambda %*% PhiA %*% t(Lambda) + as %*% t(as), name = "A"),
  mxAlgebra(Lambda %*% PhiC %*% t(Lambda) + cs %*% t(cs), name = "C"),
  mxAlgebra(Lambda %*% PhiE %*% t(Lambda) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  # MZ: R=1
  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(HO.A + HO.C, name = "B"),
    mxAlgebra(rbind(cbind(HO.V, B), cbind(B, HO.V)), name = "expCov"),
    mxAlgebra(cbind(HO.Mu, HO.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * HO.A + HO.C, name = "B"),
    mxAlgebra(rbind(cbind(HO.V, B), cbind(B, HO.V)), name = "expCov"),
    mxAlgebra(cbind(HO.Mu, HO.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("FS",
    mxData(fs_data, type = "raw"),
    mxAlgebra(0.5 * HO.A + HO.C, name = "B"),
    mxAlgebra(rbind(cbind(HO.V, B), cbind(B, HO.V)), name = "expCov"),
    mxAlgebra(cbind(HO.Mu, HO.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("HS",
    mxData(hs_data, type = "raw"),
    mxAlgebra(0.25 * HO.A + HO.C, name = "B"),
    mxAlgebra(rbind(cbind(HO.V, B), cbind(B, HO.V)), name = "expCov"),
    mxAlgebra(cbind(HO.Mu, HO.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
)

cat("  Fitting Higher-Order model...\n")
ho_fit <- mxTryHard(ho_model, extraTries = 100, silent = TRUE)
ho_sum <- summary(ho_fit)
cat(sprintf("  HO: -2LL = %.2f, df = %d, AIC = %.2f, status = %d, infoDefinite = %s\n",
            ho_sum$Minus2LogLikelihood, ho_sum$degreesOfFreedom,
            ho_sum$AIC.Mx, ho_fit$output$status$code,
            ifelse(is.na(ho_sum$infoDefinite), "NA", as.character(ho_sum$infoDefinite))))
# Retry with SLSQP if Hessian is indefinite
if (!is.na(ho_sum$infoDefinite) && !ho_sum$infoDefinite) {
  cat("  HO Hessian indefinite — retrying with SLSQP optimizer...\n")
  ho_plan <- mxComputeSequence(list(
    mxComputeGradientDescent(engine = "SLSQP"),
    mxComputeNumericDeriv(), mxComputeStandardError(), mxComputeReportDeriv()))
  ho_fit2 <- mxTryHard(mxModel(ho_fit, ho_plan), extraTries = 100, silent = TRUE)
  ho_sum2 <- summary(ho_fit2)
  cat(sprintf("  HO [SLSQP]: -2LL = %.2f, infoDefinite = %s\n",
              ho_sum2$Minus2LogLikelihood,
              ifelse(is.na(ho_sum2$infoDefinite), "NA", as.character(ho_sum2$infoDefinite))))
  if ((!is.na(ho_sum2$infoDefinite) && ho_sum2$infoDefinite) ||
      ho_sum2$Minus2LogLikelihood < ho_sum$Minus2LogLikelihood) {
    ho_fit <- ho_fit2; ho_sum <- ho_sum2
  }
}

# ── Model 5: Bifactor ────────────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model 5: Bifactor g (g + orthogonal V + orthogonal P)\n")
cat(strrep("-", 70), "\n")
cat("  g loads on all subtests; V on subtests 1-4,8; P on subtests 5-7,9\n")
cat("  All factors orthogonal, each with own ACE\n\n")

bf_model <- mxModel("BF",

  # g loadings (9x1, all free, positive)
  mxMatrix("Full", nv, 1, free = TRUE,
           values = rep(1.5, nv),
           lbound = 0.01, name = "lg"),

  # Verbal loadings (9x1, only V indices free)
  mxMatrix("Full", nv, 1,
           free = seq_len(nv) %in% v_idx,
           values = ifelse(seq_len(nv) %in% v_idx, 0.5, 0),
           name = "lv"),

  # Performance loadings (9x1, only P indices free)
  mxMatrix("Full", nv, 1,
           free = seq_len(nv) %in% p_idx,
           values = ifelse(seq_len(nv) %in% p_idx, 0.5, 0),
           name = "lp"),

  # Factor ACE for g
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.60, lbound = 0.01,
           ubound = 0.99, name = "ag"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.40, lbound = 0.01,
           ubound = 0.99, name = "cg"),
  mxAlgebra(sqrt(1 - ag*ag - cg*cg), name = "eg"),
  mxConstraint(ag*ag + cg*cg < 0.999, name = "gCon"),

  # Factor ACE for Verbal
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.50, lbound = 0.01,
           ubound = 0.99, name = "av"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.40, lbound = 0.01,
           ubound = 0.99, name = "cv"),
  mxAlgebra(sqrt(1 - av*av - cv*cv), name = "ev"),
  mxConstraint(av*av + cv*cv < 0.999, name = "vCon"),

  # Factor ACE for Performance
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.50, lbound = 0.01,
           ubound = 0.99, name = "ap"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.40, lbound = 0.01,
           ubound = 0.99, name = "cp_"),  # cp_ to avoid name clash
  mxAlgebra(sqrt(1 - ap*ap - cp_*cp_), name = "ep"),
  mxConstraint(ap*ap + cp_*cp_ < 0.999, name = "pCon"),

  # Specific residual SDs (diagonal)
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
           lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "es"),

  # Means
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  # Covariance components:
  # Sigma_x = lg * xg^2 * lg' + lv * xv^2 * lv' + lp * xp^2 * lp' + diag(xs^2)
  mxAlgebra(lg %*% (ag*ag) %*% t(lg) + lv %*% (av*av) %*% t(lv) +
            lp %*% (ap*ap) %*% t(lp) + as %*% t(as), name = "A"),
  mxAlgebra(lg %*% (cg*cg) %*% t(lg) + lv %*% (cv*cv) %*% t(lv) +
            lp %*% (cp_*cp_) %*% t(lp) + cs %*% t(cs), name = "C"),
  mxAlgebra(lg %*% (eg*eg) %*% t(lg) + lv %*% (ev*ev) %*% t(lv) +
            lp %*% (ep*ep) %*% t(lp) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  # MZ: R=1
  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(BF.A + BF.C, name = "B"),
    mxAlgebra(rbind(cbind(BF.V, B), cbind(B, BF.V)), name = "expCov"),
    mxAlgebra(cbind(BF.Mu, BF.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * BF.A + BF.C, name = "B"),
    mxAlgebra(rbind(cbind(BF.V, B), cbind(B, BF.V)), name = "expCov"),
    mxAlgebra(cbind(BF.Mu, BF.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("FS",
    mxData(fs_data, type = "raw"),
    mxAlgebra(0.5 * BF.A + BF.C, name = "B"),
    mxAlgebra(rbind(cbind(BF.V, B), cbind(B, BF.V)), name = "expCov"),
    mxAlgebra(cbind(BF.Mu, BF.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),
  mxModel("HS",
    mxData(hs_data, type = "raw"),
    mxAlgebra(0.25 * BF.A + BF.C, name = "B"),
    mxAlgebra(rbind(cbind(BF.V, B), cbind(B, BF.V)), name = "expCov"),
    mxAlgebra(cbind(BF.Mu, BF.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
)

cat("  Fitting Bifactor model...\n")
bf_fit <- mxTryHard(bf_model, extraTries = 100, silent = TRUE)
bf_sum <- summary(bf_fit)
cat(sprintf("  BF: -2LL = %.2f, df = %d, AIC = %.2f, status = %d, infoDefinite = %s\n",
            bf_sum$Minus2LogLikelihood, bf_sum$degreesOfFreedom,
            bf_sum$AIC.Mx, bf_fit$output$status$code,
            ifelse(is.na(bf_sum$infoDefinite), "NA", as.character(bf_sum$infoDefinite))))
# Retry with SLSQP if Hessian is indefinite
if (!is.na(bf_sum$infoDefinite) && !bf_sum$infoDefinite) {
  cat("  BF Hessian indefinite — retrying with SLSQP optimizer...\n")
  bf_plan <- mxComputeSequence(list(
    mxComputeGradientDescent(engine = "SLSQP"),
    mxComputeNumericDeriv(), mxComputeStandardError(), mxComputeReportDeriv()))
  bf_fit2 <- mxTryHard(mxModel(bf_fit, bf_plan), extraTries = 100, silent = TRUE)
  bf_sum2 <- summary(bf_fit2)
  cat(sprintf("  BF [SLSQP]: -2LL = %.2f, infoDefinite = %s\n",
              bf_sum2$Minus2LogLikelihood,
              ifelse(is.na(bf_sum2$infoDefinite), "NA", as.character(bf_sum2$infoDefinite))))
  if ((!is.na(bf_sum2$infoDefinite) && bf_sum2$infoDefinite) ||
      bf_sum2$Minus2LogLikelihood < bf_sum$Minus2LogLikelihood) {
    bf_fit <- bf_fit2; bf_sum <- bf_sum2
  }
}

# ── Model Comparison ──────────────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Model Comparison\n")
cat(strrep("-", 70), "\n")

# Count parameters
n_chol <- chol_sum$estimatedParameters
n_ip <- ip_sum$estimatedParameters
n_bf <- bf_sum$estimatedParameters
n_ho <- ho_sum$estimatedParameters
n_cp <- cp_sum$estimatedParameters

ll_chol <- chol_sum$Minus2LogLikelihood
ll_ip <- ip_sum$Minus2LogLikelihood
ll_bf <- bf_sum$Minus2LogLikelihood
ll_ho <- ho_sum$Minus2LogLikelihood
ll_cp <- cp_sum$Minus2LogLikelihood

aic_chol <- chol_sum$AIC.Mx
aic_ip <- ip_sum$AIC.Mx
aic_bf <- bf_sum$AIC.Mx
aic_ho <- ho_sum$AIC.Mx
aic_cp <- cp_sum$AIC.Mx

# BIC: -2LL + k*ln(N)
total_n <- nrow(mz_data) + nrow(dz_data) + nrow(fs_data) + nrow(hs_data)
bic_chol <- ll_chol + n_chol * log(total_n)
bic_ip <- ll_ip + n_ip * log(total_n)
bic_bf <- ll_bf + n_bf * log(total_n)
bic_ho <- ll_ho + n_ho * log(total_n)
bic_cp <- ll_cp + n_cp * log(total_n)

cat(sprintf("\n  %-14s  %5s  %12s  %12s  %12s  %6s\n",
            "Model", "k", "-2LL", "AIC", "BIC", "Status"))
cat("  ", strrep("-", 67), "\n")
cat(sprintf("  %-14s  %5d  %12.2f  %12.2f  %12.2f  %6d\n",
            "Cholesky", n_chol, ll_chol, aic_chol, bic_chol,
            chol_fit$output$status$code))
cat(sprintf("  %-14s  %5d  %12.2f  %12.2f  %12.2f  %6d\n",
            "IP", n_ip, ll_ip, aic_ip, bic_ip,
            ip_fit$output$status$code))
cat(sprintf("  %-14s  %5d  %12.2f  %12.2f  %12.2f  %6d\n",
            "Bifactor", n_bf, ll_bf, aic_bf, bic_bf,
            bf_fit$output$status$code))
cat(sprintf("  %-14s  %5d  %12.2f  %12.2f  %12.2f  %6d\n",
            "Higher-Order", n_ho, ll_ho, aic_ho, bic_ho,
            ho_fit$output$status$code))
cat(sprintf("  %-14s  %5d  %12.2f  %12.2f  %12.2f  %6d\n",
            "CP", n_cp, ll_cp, aic_cp, bic_cp,
            cp_fit$output$status$code))

# LRT: CP vs IP (nested)
chi2_cp_ip <- ll_cp - ll_ip
df_cp_ip <- n_ip - n_cp
p_cp_ip <- pchisq(chi2_cp_ip, df_cp_ip, lower.tail = FALSE)
cat(sprintf("\n  CP vs IP:       chi2 = %.2f, df = %d, p = %.4f%s\n",
            chi2_cp_ip, df_cp_ip, p_cp_ip,
            ifelse(p_cp_ip < 0.05, " (IP preferred)", " (CP adequate)")))

# LRT: CP vs Bifactor (nested: set group factor loadings to 0)
chi2_cp_bf <- ll_cp - ll_bf
df_cp_bf <- n_bf - n_cp
p_cp_bf <- pchisq(chi2_cp_bf, df_cp_bf, lower.tail = FALSE)
cat(sprintf("  CP vs BF:       chi2 = %.2f, df = %d, p = %.4f%s\n",
            chi2_cp_bf, df_cp_bf, p_cp_bf,
            ifelse(p_cp_bf < 0.05, " (BF preferred)", " (CP adequate)")))

# LRT: Higher-Order vs Bifactor (nested: proportionality constraint)
chi2_ho_bf <- ll_ho - ll_bf
df_ho_bf <- n_bf - n_ho
p_ho_bf <- pchisq(chi2_ho_bf, df_ho_bf, lower.tail = FALSE)
cat(sprintf("  HO vs BF:       chi2 = %.2f, df = %d, p = %.4f%s\n",
            chi2_ho_bf, df_ho_bf, p_ho_bf,
            ifelse(p_ho_bf < 0.05, " (BF preferred)", " (HO adequate)")))

# LRT: IP vs Cholesky
chi2_ip_chol <- ll_ip - ll_chol
df_ip_chol <- n_chol - n_ip
p_ip_chol <- pchisq(chi2_ip_chol, df_ip_chol, lower.tail = FALSE)
cat(sprintf("  IP vs Chol:     chi2 = %.2f, df = %d, p = %.4f\n",
            chi2_ip_chol, df_ip_chol, p_ip_chol))

# LRT: BF vs Cholesky
chi2_bf_chol <- ll_bf - ll_chol
df_bf_chol <- n_chol - n_bf
p_bf_chol <- pchisq(chi2_bf_chol, df_bf_chol, lower.tail = FALSE)
cat(sprintf("  BF vs Chol:     chi2 = %.2f, df = %d, p = %.4f\n",
            chi2_bf_chol, df_bf_chol, p_bf_chol))

# Best by AIC and BIC
all_aic <- c(Cholesky = aic_chol, IP = aic_ip, Bifactor = aic_bf,
             `Higher-Order` = aic_ho, CP = aic_cp)
all_bic <- c(Cholesky = bic_chol, IP = bic_ip, Bifactor = bic_bf,
             `Higher-Order` = bic_ho, CP = bic_cp)
cat(sprintf("\n  Best by AIC: %s (%.2f)\n", names(which.min(all_aic)), min(all_aic)))
cat(sprintf("  Best by BIC: %s (%.2f)\n", names(which.min(all_bic)), min(all_bic)))

# ── Parameter Estimates ───────────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("CP Model Parameter Estimates\n")
cat(strrep("-", 70), "\n")

lambda_est <- cp_fit$lambda$values[,1]
af_est <- cp_fit$af$values[1,1]
cf_est <- cp_fit$cf$values[1,1]
ef_est <- mxEval(ef, cp_fit)[1,1]

a2f <- af_est^2
c2f <- cf_est^2
e2f <- ef_est^2

cat(sprintf("\n  Factor-level ACE:\n"))
cat(sprintf("    a^2_g = %.3f (%.1f%%)\n", a2f, 100*a2f))
cat(sprintf("    c^2_g = %.3f (%.1f%%)\n", c2f, 100*c2f))
cat(sprintf("    e^2_g = %.3f (%.1f%%)\n", e2f, 100*e2f))

as_est <- diag(cp_fit$as$values)
cs_est <- diag(cp_fit$cs$values)
es_est <- diag(cp_fit$es$values)

cat(sprintf("\n  %-15s  %6s  %6s  %6s  %6s  %6s  %7s\n",
            "Subtest", "lambda", "a^2_s", "c^2_s", "e^2_s",
            "Var", "% via g"))
cat("  ", strrep("-", 60), "\n")

for (i in seq_along(sub_vars)) {
  lam <- lambda_est[i]
  a2s <- as_est[i]^2
  c2s <- cs_est[i]^2
  e2s <- es_est[i]^2
  total_var <- lam^2 + a2s + c2s + e2s
  pct_g <- 100 * lam^2 / total_var

  cat(sprintf("  %-15s  %6.3f  %6.3f  %6.3f  %6.3f  %6.2f  %6.1f%%\n",
              sub_labels[i], lam, a2s, c2s, e2s, total_var, pct_g))
}

# Standardized loadings (lambda / sqrt(total_var))
cat("\n  Standardized factor loadings:\n")
for (i in seq_along(sub_vars)) {
  lam <- lambda_est[i]
  a2s <- as_est[i]^2; c2s <- cs_est[i]^2; e2s <- es_est[i]^2
  total_var <- lam^2 + a2s + c2s + e2s
  std_lam <- lam / sqrt(total_var)
  cat(sprintf("    %-15s  %.3f\n", sub_labels[i], std_lam))
}

# IP Model Estimates
cat("\n")
cat(strrep("-", 70), "\n")
cat("IP Model Parameter Estimates\n")
cat(strrep("-", 70), "\n")

ac_est <- ip_fit$ac$values[,1]
cc_est <- ip_fit$cc$values[,1]
ec_est <- ip_fit$ec$values[,1]

cat(sprintf("\n  %-15s  %8s  %8s  %8s\n",
            "Subtest", "A_c load", "C_c load", "E_c load"))
cat("  ", strrep("-", 42), "\n")
for (i in seq_along(sub_vars)) {
  cat(sprintf("  %-15s  %8.3f  %8.3f  %8.3f\n",
              sub_labels[i], ac_est[i], cc_est[i], ec_est[i]))
}

# ── Proportion of genetic variance through common factor ──────────────
cat("\n  Proportion of genetic variance through common factor:\n")
cat(sprintf("  %-15s  %8s  %8s  %8s\n",
            "Subtest", "A_common", "A_specif", "% common"))
cat("  ", strrep("-", 45), "\n")

# From IP model
as_ip <- diag(ip_fit$as$values)
for (i in seq_along(sub_vars)) {
  a_common <- ac_est[i]^2
  a_specific <- as_ip[i]^2
  a_total <- a_common + a_specific
  pct_common <- if (a_total > 0) 100 * a_common / a_total else NA
  cat(sprintf("  %-15s  %8.3f  %8.3f  %7.1f%%\n",
              sub_labels[i], a_common, a_specific,
              ifelse(is.na(pct_common), NA, pct_common)))
}

# ── Higher-Order Model Parameter Estimates ────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Higher-Order Model Parameter Estimates\n")
cat(strrep("-", 70), "\n")

if (ho_fit$output$status$code == 0) {
  ho_ag <- ho_fit$ag$values[1,1]
  ho_cg <- ho_fit$cg$values[1,1]
  ho_eg <- mxEval(eg, ho_fit)[1,1]

  cat(sprintf("\n  g factor ACE (variance = 1):\n"))
  cat(sprintf("    a^2 = %.3f, c^2 = %.3f, e^2 = %.3f\n",
              ho_ag^2, ho_cg^2, ho_eg^2))

  cat(sprintf("\n  Higher-order loadings (Gamma):\n"))
  cat(sprintf("    Verbal -> g:      %.3f\n", ho_fit$Gamma$values[1,1]))
  cat(sprintf("    Performance -> g: %.3f\n", ho_fit$Gamma$values[2,1]))

  cat(sprintf("\n  First-order loadings (Lambda):\n"))
  ho_lam <- ho_fit$Lambda$values
  for (i in v_idx) {
    cat(sprintf("    %-15s -> V: %.3f%s\n", sub_labels[i], ho_lam[i,1],
                ifelse(i == 1, " (fixed)", "")))
  }
  for (i in p_idx) {
    cat(sprintf("    %-15s -> P: %.3f%s\n", sub_labels[i], ho_lam[i,2],
                ifelse(i == 5, " (fixed)", "")))
  }

  cat(sprintf("\n  Group factor residual variances (beyond g):\n"))
  ho_arv <- ho_fit$arv$values[1,1]; ho_crv <- ho_fit$crv$values[1,1]
  ho_erv <- ho_fit$erv$values[1,1]
  ho_arp <- ho_fit$arp$values[1,1]; ho_crp <- ho_fit$crp$values[1,1]
  ho_erp <- ho_fit$erp$values[1,1]
  v_resid <- ho_arv^2 + ho_crv^2 + ho_erv^2
  p_resid <- ho_arp^2 + ho_crp^2 + ho_erp^2
  cat(sprintf("    Verbal residual:  a=%.3f c=%.3f e=%.3f (total=%.3f)\n",
              ho_arv^2, ho_crv^2, ho_erv^2, v_resid))
  cat(sprintf("    Perf. residual:   a=%.3f c=%.3f e=%.3f (total=%.3f)\n",
              ho_arp^2, ho_crp^2, ho_erp^2, p_resid))
} else {
  cat("  Higher-Order model did not converge.\n")
}

# ── Bifactor Model Parameter Estimates ─────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Bifactor Model Parameter Estimates\n")
cat(strrep("-", 70), "\n")

if (bf_fit$output$status$code == 0) {
  bf_ag <- bf_fit$ag$values[1,1]
  bf_cg <- bf_fit$cg$values[1,1]
  bf_eg <- mxEval(eg, bf_fit)[1,1]

  bf_av <- bf_fit$av$values[1,1]
  bf_cv <- bf_fit$cv$values[1,1]
  bf_ev <- mxEval(ev, bf_fit)[1,1]

  bf_ap <- bf_fit$ap$values[1,1]
  bf_cp_ <- bf_fit$cp_$values[1,1]
  bf_ep <- mxEval(ep, bf_fit)[1,1]

  cat(sprintf("\n  Factor-level ACE:\n"))
  cat(sprintf("    g factor:      a^2=%.3f  c^2=%.3f  e^2=%.3f\n",
              bf_ag^2, bf_cg^2, bf_eg^2))
  cat(sprintf("    Verbal factor: a^2=%.3f  c^2=%.3f  e^2=%.3f\n",
              bf_av^2, bf_cv^2, bf_ev^2))
  cat(sprintf("    Perf. factor:  a^2=%.3f  c^2=%.3f  e^2=%.3f\n",
              bf_ap^2, bf_cp_^2, bf_ep^2))

  bf_lg <- bf_fit$lg$values[,1]
  bf_lv <- bf_fit$lv$values[,1]
  bf_lp <- bf_fit$lp$values[,1]

  cat(sprintf("\n  %-15s  %7s  %7s  %7s\n", "Subtest", "g load", "V load", "P load"))
  cat("  ", strrep("-", 40), "\n")
  for (i in seq_along(sub_vars)) {
    cat(sprintf("  %-15s  %7.3f  %7.3f  %7.3f\n",
                sub_labels[i], bf_lg[i], bf_lv[i], bf_lp[i]))
  }

  # Proportion of variance through g, V/P, and specific
  bf_as_est <- diag(bf_fit$as$values)
  bf_cs_est <- diag(bf_fit$cs$values)
  bf_es_est <- diag(bf_fit$es$values)

  cat(sprintf("\n  Variance decomposition by source:\n"))
  cat(sprintf("  %-15s  %6s  %6s  %6s  %7s\n",
              "Subtest", "% g", "% V/P", "% spec", "Total"))
  cat("  ", strrep("-", 48), "\n")
  for (i in seq_along(sub_vars)) {
    var_g <- bf_lg[i]^2  # factor variance is 1
    var_gf <- if (i %in% v_idx) bf_lv[i]^2 else bf_lp[i]^2
    var_spec <- bf_as_est[i]^2 + bf_cs_est[i]^2 + bf_es_est[i]^2
    total <- var_g + var_gf + var_spec
    cat(sprintf("  %-15s  %5.1f%%  %5.1f%%  %5.1f%%  %7.2f\n",
                sub_labels[i], 100*var_g/total, 100*var_gf/total,
                100*var_spec/total, total))
  }
} else {
  cat("  Bifactor model did not converge.\n")
}

# ---- PART C: TWIN-ONLY SENSITIVITY (MZ + DZ) ----
cat("\n")
cat("--- PART C: Twin-Only Sensitivity (MZ + DZ) ---
")
cat("  Standard twin design (no siblings). ACE model (no T).\n\n")

# CP twin-only
cp_twin <- mxModel("CP_twin",

  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.8, nv),
           lbound = 0.01, name = "lambda"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.65, lbound = 0.01,
           ubound = 0.99, name = "af"),
  mxMatrix("Full", 1, 1, free = TRUE, values = 0.50, lbound = 0.01,
           ubound = 0.99, name = "cf"),
  mxAlgebra(sqrt(1 - af*af - cf*cf), name = "ef"),
  mxConstraint(af*af + cf*cf < 0.999, name = "fvCon"),

  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.8, nv),
           lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "es"),
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  mxAlgebra(lambda %*% (af*af) %*% t(lambda) + as %*% t(as), name = "A"),
  mxAlgebra(lambda %*% (cf*cf) %*% t(lambda) + cs %*% t(cs), name = "C"),
  mxAlgebra(lambda %*% (ef*ef) %*% t(lambda) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(CP_twin.A + CP_twin.C, name = "B"),
    mxAlgebra(rbind(cbind(CP_twin.V, B), cbind(B, CP_twin.V)), name = "expCov"),
    mxAlgebra(cbind(CP_twin.Mu, CP_twin.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * CP_twin.A + CP_twin.C, name = "B"),
    mxAlgebra(rbind(cbind(CP_twin.V, B), cbind(B, CP_twin.V)), name = "expCov"),
    mxAlgebra(cbind(CP_twin.Mu, CP_twin.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxFitFunctionMultigroup(c("MZ", "DZ"))
)

cat("  Fitting twin-only CP...\n")
cp_twin_fit <- mxTryHard(cp_twin, extraTries = 100, silent = TRUE)
cp_twin_sum <- summary(cp_twin_fit)

# IP twin-only
ip_twin <- mxModel("IP_twin",

  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.5, nv),
           lbound = -5, name = "ac"),
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.8, nv),
           lbound = -5, name = "cc"),
  mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.0, nv),
           lbound = -5, name = "ec"),

  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "as"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
           lbound = 0.001, name = "cs"),
  mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
           lbound = 0.001, name = "es"),
  mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),

  mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
  mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
  mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
  mxAlgebra(A + C + E, name = "V"),

  mxModel("MZ",
    mxData(mz_data, type = "raw"),
    mxAlgebra(IP_twin.A + IP_twin.C, name = "B"),
    mxAlgebra(rbind(cbind(IP_twin.V, B), cbind(B, IP_twin.V)), name = "expCov"),
    mxAlgebra(cbind(IP_twin.Mu, IP_twin.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxModel("DZ",
    mxData(dz_data, type = "raw"),
    mxAlgebra(0.5 * IP_twin.A + IP_twin.C, name = "B"),
    mxAlgebra(rbind(cbind(IP_twin.V, B), cbind(B, IP_twin.V)), name = "expCov"),
    mxAlgebra(cbind(IP_twin.Mu, IP_twin.Mu), name = "expMean"),
    mxExpectationNormal(covariance = "expCov", means = "expMean",
                        dimnames = var_names),
    mxFitFunctionML()
  ),

  mxFitFunctionMultigroup(c("MZ", "DZ"))
)

cat("  Fitting twin-only IP...\n")
ip_twin_fit <- mxTryHard(ip_twin, extraTries = 100, silent = TRUE)
ip_twin_sum <- summary(ip_twin_fit)

cat(sprintf("\n  Twin-only CP: -2LL = %.2f, k = %d, AIC = %.2f, status = %d\n",
            cp_twin_sum$Minus2LogLikelihood, cp_twin_sum$estimatedParameters,
            cp_twin_sum$AIC.Mx, cp_twin_fit$output$status$code))
cat(sprintf("  Twin-only IP: -2LL = %.2f, k = %d, AIC = %.2f, status = %d\n",
            ip_twin_sum$Minus2LogLikelihood, ip_twin_sum$estimatedParameters,
            ip_twin_sum$AIC.Mx, ip_twin_fit$output$status$code))

chi2_twin <- cp_twin_sum$Minus2LogLikelihood - ip_twin_sum$Minus2LogLikelihood
df_twin <- ip_twin_sum$estimatedParameters - cp_twin_sum$estimatedParameters
p_twin <- pchisq(chi2_twin, df_twin, lower.tail = FALSE)
cat(sprintf("  CP vs IP: chi2 = %.2f, df = %d, p = %.4f%s\n",
            chi2_twin, df_twin, p_twin,
            ifelse(p_twin < 0.05, " (IP preferred)", " (CP adequate)")))

# Twin-only CP factor estimates
cat(sprintf("\n  Twin-only CP factor ACE:\n"))
af_tw <- cp_twin_fit$af$values[1,1]
cf_tw <- cp_twin_fit$cf$values[1,1]
ef_tw <- mxEval(ef, cp_twin_fit)[1,1]
cat(sprintf("    a^2_g = %.3f, c^2_g = %.3f, e^2_g = %.3f\n",
            af_tw^2, cf_tw^2, ef_tw^2))

# ---- PART D: COMPARE CP LOADINGS TO PCA g-LOADINGS ----
cat("\n")
cat("--- PART D: Congruence with Phenotypic g-Loadings ---
")

# Compute PCA g-loadings on the 9 cognitive measures
pca_data <- d[, ..sub_vars]
complete_idx <- complete.cases(pca_data)
pca_fit <- prcomp(pca_data[complete_idx], center = TRUE, scale. = TRUE)
eigenvalue_1 <- pca_fit$sdev[1]^2
pca_loadings <- pca_fit$rotation[, 1] * sqrt(eigenvalue_1)
if (mean(pca_loadings) < 0) pca_loadings <- -pca_loadings

# Standardized CP loadings
std_cp_loadings <- numeric(nv)
for (i in 1:nv) {
  lam <- lambda_est[i]
  total_var <- lam^2 + as_est[i]^2 + cs_est[i]^2 + es_est[i]^2
  std_cp_loadings[i] <- lam / sqrt(total_var)
}

cat(sprintf("\n  %-15s  %10s  %10s\n", "Subtest", "PCA g-load", "CP lambda*"))
cat("  ", strrep("-", 38), "\n")
for (i in seq_along(sub_vars)) {
  cat(sprintf("  %-15s  %10.3f  %10.3f\n",
              sub_labels[i], pca_loadings[sub_vars[i]], std_cp_loadings[i]))
}

r_congruence <- cor(pca_loadings[sub_vars], std_cp_loadings)
cat(sprintf("\n  Pearson r (PCA g-loading, CP std loading): %.3f\n", r_congruence))

# Tucker's congruence coefficient (phi)
phi <- sum(pca_loadings[sub_vars] * std_cp_loadings) /
  sqrt(sum(pca_loadings[sub_vars]^2) * sum(std_cp_loadings^2))
cat(sprintf("  Tucker's congruence coefficient (phi):     %.3f\n", phi))
cat("  (phi > 0.95 = essential equality; > 0.85 = fair similarity)\n")

# Also compare IP common A loadings to PCA
if (ip_fit$output$status$code == 0) {
  # Normalize IP A loadings
  ac_norm <- ac_est / sqrt(sum(ac_est^2))
  pca_norm <- pca_loadings[sub_vars] / sqrt(sum(pca_loadings[sub_vars]^2))
  phi_ip_a <- sum(ac_norm * pca_norm) / sqrt(sum(ac_norm^2) * sum(pca_norm^2))
  cat(sprintf("\n  IP genetic factor congruence with PCA: phi = %.3f\n", phi_ip_a))
}

# ── Save ──────────────────────────────────────────────────────────────
cat("\n")
cat("--- SUMMARY ---
")

best_4group_aic <- names(which.min(all_aic))
best_4group_bic <- names(which.min(all_bic))
best_twin <- if (p_twin >= 0.05) "CP" else "IP"

cat(sprintf("\n  4-group best by AIC: %s\n", best_4group_aic))
cat(sprintf("  4-group best by BIC: %s\n", best_4group_bic))
cat(sprintf("  Twin-only (MZ+DZ):   %s model preferred\n", best_twin))

cat(sprintf("\n  CP vs IP: %s (p = %.4f)\n",
            ifelse(p_cp_ip < 0.05, "IP preferred", "CP adequate"), p_cp_ip))
cat(sprintf("  CP vs BF: %s (p = %.4f)\n",
            ifelse(p_cp_bf < 0.05, "BF preferred", "CP adequate"), p_cp_bf))
cat(sprintf("  HO vs BF: %s (p = %.4f)\n",
            ifelse(p_ho_bf < 0.05, "BF preferred", "HO adequate"), p_ho_bf))

results <- list(
  chol_fit = chol_sum,
  ip_fit_sum = ip_sum,
  bf_fit_sum = bf_sum,
  ho_fit_sum = ho_sum,
  cp_fit_sum = cp_sum,
  cp_twin_sum = cp_twin_sum,
  ip_twin_sum = ip_twin_sum,
  model_comparison = data.frame(
    model = c("Cholesky", "IP", "Bifactor", "Higher-Order", "CP"),
    k = c(n_chol, n_ip, n_bf, n_ho, n_cp),
    minus2LL = c(ll_chol, ll_ip, ll_bf, ll_ho, ll_cp),
    AIC = c(aic_chol, aic_ip, aic_bf, aic_ho, aic_cp),
    BIC = c(bic_chol, bic_ip, bic_bf, bic_ho, bic_cp)
  ),
  cp_vs_ip = list(chi2 = chi2_cp_ip, df = df_cp_ip, p = p_cp_ip),
  cp_vs_bf = list(chi2 = chi2_cp_bf, df = df_cp_bf, p = p_cp_bf),
  ho_vs_bf = list(chi2 = chi2_ho_bf, df = df_ho_bf, p = p_ho_bf),
  cp_loadings = lambda_est,
  cp_std_loadings = std_cp_loadings,
  factor_ace = c(a2 = a2f, c2 = c2f, e2 = e2f),
  pca_loadings = pca_loadings[sub_vars],
  congruence_r = r_congruence,
  congruence_phi = phi
)

saveRDS(results, "results_pathway_models.rds")
cat("\nResults saved to results_pathway_models.rds\n")
