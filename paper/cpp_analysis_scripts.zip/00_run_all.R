#!/usr/bin/env Rscript
# 00_run_all.R — Master orchestrator for CPP analysis paper

cat("--- CPP Analysis Paper: Running All Analyses ---\n")

# Always resolve relative paths from this script's directory.
args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
if (length(file_arg) == 1L) {
  script_dir <- dirname(normalizePath(sub("^--file=", "", file_arg)))
  setwd(script_dir)
}

scripts <- c(
  # ---- Data preparation ----
  "01_data_prep.R",

  # ---- Behavior genetics ----
  "02_behavior_genetics.R",
  "02h_family_dependence_robustness.R", # Extended-family blocks / independent dyads
  "02b_bw_hc_heritability.R",
  "02c_pathway_models.R",          # IP, CP, Bifactor, Higher-Order
  "02c_ip_cp_diagnostic.R",        # IP/CP diagnostics (needs pathway results)
  "02c_congruence_benchmarks.R",   # CP-IP congruence, PCA/CFA g, WISC-only, bootstrap CIs
  "02i_independence_robust_pathway_models.R", # Independent-family IP/CP tests
  "02d_between_group.R",           # Dolan between-group decomposition
  "02e_between_group_expanded.R",  # Extended decomposition with specifics
  "02f_molenaar_gxe.R",            # Molenaar et al. G×E interaction test (IP factor scores)
  "diag_spearman_bifactor.R",      # Spearman's hypothesis via bifactor MI
  "diag_dmacs_effect_sizes.R",     # dMACS effect sizes for MI non-invariance

  # ---- Within-family analyses ----
  "03_birth_order.R",
  "03d_flynn_cohort.R",          # Reproducible cohort/Flynn sensitivity models
  "03e_flynn_cousin.R",          # Cousin-pair cohort sensitivity, family clustered
  "04_breastfeeding.R",
  "04b_breastfeeding_health.R",
  "05_birthweight.R",
  "06_maternal_age.R",

  # ---- Environmental gradients ----
  "07_ses_gradients.R",
  "07b_ses_within_family.R",          # Within-family SES-IQ (mother FE)
  "07c_ses_developmental.R",          # Developmental SES exposure (time-weighted)
  "07d_resource_dilution.R",           # Resource dilution, family size, birth spacing
  "08_smoking.R",

  # ---- Cousin/extended kinship correlations ----
  "cousin_correlations_adjusted.R",   # Extended kinship IQ correlations (Table 2)

  # ---- Descriptive & validity ----
  "09_family_structure.R",
  "10_growth_iq.R",
  "check_hc_iq_full.R",          # Clustered head-circumference sibling models
  "phase3k_gestational_diabetes.R", # Clustered GDM sibling models
  "11_attrition.R",
  "12_examiner_mi.R",
  "12b_examiner_mgcfa.R",
  "12c_examiner_crossval.R",          # Cross-validate examiner ratings vs written tests
  "12d_examiner_improved.R",          # Improved four-factor model + extended MI

  # ---- Replications ----
  "13_replication_turkheimer.R",
  "14_replication_willerman.R",
  "15_replication_myrianthopoulos.R",
  "15_replication_jensen.R",        # Jensen & Johnson (1994)
  "16_replication_broman.R",
  "17_replication_mcgrath.R",
  "18_replication_nelson.R",
  "19_replication_naeye.R",

  # ---- Sensitivity ----
  "supplement_weighted.R",           # Survey-weighted sensitivity analysis
  "supplement_molenaar_am.R",        # Molenaar G×E test AM sensitivity
  "supplement_am_dolan.R",           # AM sensitivity for between-group decomposition

  # ---- Additional analyses ----
  "hs_ip_sensitivity.R",             # HS SES confound sensitivity for IP model
  "remaining_items.R",               # Kelley's paradox, HC BF/WF, latent g matching
  "followup_queries.R",              # Twin-only decomposition, WF HC-IQ significance

  # ---- Sibling death dilution test ----
  "build_death_dilution.R",          # Dead vs surviving siblings + type decomposition

  # ---- Expanded MI analyses ----
  "03b_birth_order_mi_expanded.R",   # 7-subtest birth order MI
  "03c_birth_order_mi_with_only.R",  # 4-group with only children
  "12e_examiner_sex_variance.R",     # Examiner MI by child sex + variance test
  "sex_ho_mi_partial2.R",            # Higher-order MI across sexes (partial scalar)
  "check_sex_hc.R",                  # Sex differences in HC at matched IQ
  "check_hc_iq_slopes_by_sex.R",     # HC-IQ slope invariance across sex/race
  "check_sex_hc_measures.R",         # HC gap across all IQ measures
  "check_sex_iq_at_matched_hc.R",    # IQ gap at matched HC + selection check

  # ---- Figures ----
  "fig_forest_within_family.R",      # Forest plot: OLS vs Mother FE
  "fig_between_group.R",             # Between-group decomposition + IP loading profiles
  "fig_ip_heatmap.R",                # IP common-factor ACE heatmap + communality
  "fig_sibling_regression.R",        # Differential sibling regression to the mean
  "fig_famsize_fertility.R",         # Family size and fertility
  "fig_resource_dilution.R",         # Resource dilution
  "fig_ses_between_within.R"         # SES between vs within family
)

run_status <- data.frame(
  script = scripts,
  status = NA_character_,
  elapsed_seconds = NA_real_,
  stringsAsFactors = FALSE
)

for (i in seq_along(scripts)) {
  s <- scripts[i]
  cat(sprintf("\n>>> Running %s <<<\n", s))
  if (!file.exists(s)) {
    stop(sprintf("Required analysis script is missing: %s", s), call. = FALSE)
  }
  t0 <- Sys.time()
  tryCatch({
    source(s, local = new.env())
    run_status$status[i] <- "completed"
  }, error = function(e) {
    run_status$status[i] <- "failed"
    run_status$elapsed_seconds[i] <- as.numeric(
      difftime(Sys.time(), t0, units = "secs")
    )
    write.csv(run_status, "run_status.csv", row.names = FALSE, na = "")
    stop(sprintf("ERROR in %s: %s", s, conditionMessage(e)), call. = FALSE)
  })
  dt <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  run_status$elapsed_seconds[i] <- dt
  write.csv(run_status, "run_status.csv", row.names = FALSE, na = "")
  cat(sprintf(">>> %s completed in %.1f seconds <<<\n\n", s, dt))
}

cat("Done. All required scripts completed successfully.\n")
