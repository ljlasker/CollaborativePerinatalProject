#!/usr/bin/env Rscript
# Follow-up: twin-only total decomposition + HC WF significance

library(data.table)
library(OpenMx)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

d <- readRDS("prepared_data.rds")

# Load HC from growth data
growth <- as.data.table(readRDS("prepared_growth.rds"))
g7 <- growth[measure == "head_circ_cm" & age_months == 84,
             .(case_id = as.character(case_id), value)]
setnames(g7, "value", "head_circ_7yr")
d <- merge(d, g7, by = "case_id", all.x = TRUE)

links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

# ══════════════════════════════════════════════════════════════════════
# PART 1: Twin-only total decomposition
# ══════════════════════════════════════════════════════════════════════
cat("\n=== TWIN-ONLY: COMMON + TOTAL DECOMPOSITION ===\n\n")

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding")
sub_labels <- c("Info", "Comp", "Vocab", "DigSp", "PicArr", "Block", "Code")
nv <- length(sub_vars)

d_sub <- d[, c("case_id", "race", sub_vars), with = FALSE]

pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
setnames(pair, "race", "race_1")
rn1 <- paste0(sub_vars, "_1")
setnames(pair, sub_vars, rn1)

pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
setnames(pair, "race", "race_2")
rn2 <- paste0(sub_vars, "_2")
setnames(pair, sub_vars, rn2)

pair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  default = NA_character_
)]
pair <- pair[!is.na(pair_class)]
pair <- pair[race_1 == race_2 & race_1 %in% c(1, 2)]
pair[, race := ifelse(race_1 == 1, "White", "Black")]

has1 <- rowSums(!is.na(pair[, ..rn1])) > 0
has2 <- rowSums(!is.na(pair[, ..rn2])) > 0
pair <- pair[has1 & has2]

var_names <- c(rn1, rn2)

make_gd <- function(data, rv, pc) {
  as.data.frame(data[race == rv & pair_class == pc, ..var_names])
}

w_mz <- make_gd(pair, "White", "MZ")
w_dz <- make_gd(pair, "White", "DZ")
b_mz <- make_gd(pair, "Black", "MZ")
b_dz <- make_gd(pair, "Black", "DZ")

cat(sprintf("White: MZ=%d, DZ=%d; Black: MZ=%d, DZ=%d\n",
            nrow(w_mz), nrow(w_dz), nrow(b_mz), nrow(b_dz)))

# Refit the IP model (twin-only, no T)
build_ip <- function(model_name) {
  p <- model_name
  make_sub <- function(sub_name, data, R_coeff, use_white) {
    mu_ref <- if (use_white) paste0(p, ".MuW") else paste0(p, ".MuB")
    b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C")
    cov_str <- paste0("rbind(cbind(", p, ".V, B), cbind(B, ", p, ".V))")
    mean_str <- paste0("cbind(", mu_ref, ", ", mu_ref, ")")
    mxModel(sub_name, mxData(data, type = "raw"),
      mxAlgebraFromString(b_str, name = "B"),
      mxAlgebraFromString(cov_str, name = "expCov"),
      mxAlgebraFromString(mean_str, name = "expMean"),
      mxExpectationNormal("expCov", "expMean", dimnames = var_names),
      mxFitFunctionML())
  }

  mxModel(model_name,
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.5, nv), lbound = -5, name = "ac"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.8, nv), lbound = -5, name = "cc"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.0, nv), lbound = -5, name = "ec"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv), lbound = 0.001, name = "as"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv), lbound = 0.001, name = "cs"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv), lbound = 0.001, name = "es"),
    mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
    mxAlgebra(A + C + E, name = "V"),
    mxMatrix("Full", 1, nv, free = TRUE,
             values = c(8.5, 8.1, 7.5, 9.0, 8.3, 8.6, 9.8), name = "MuB"),
    mxMatrix("Full", 1, nv, free = TRUE,
             values = c(10.1, 9.5, 10.2, 10.4, 10.7, 10.6, 10.2), name = "MuW"),
    make_sub("W_MZ", w_mz, 1, TRUE),
    make_sub("W_DZ", w_dz, 0.5, TRUE),
    make_sub("B_MZ", b_mz, 1, FALSE),
    make_sub("B_DZ", b_dz, 0.5, FALSE),
    mxFitFunctionMultigroup(c("W_MZ", "W_DZ", "B_MZ", "B_DZ"))
  )
}

cat("Fitting twin-only IP (ACE, no T)...\n")
ip <- build_ip("IPtw")
ip_fit <- mxTryHard(ip, extraTries = 50, silent = TRUE)
ip_sum <- summary(ip_fit)
cat(sprintf("  -2LL=%.2f, k=%d, status=%d\n",
            ip_sum$Minus2LogLikelihood, ip_sum$estimatedParameters,
            ip_fit$output$status$code))

if (ip_fit$output$status$code <= 6) {
  ac_tw <- ip_fit$ac$values[, 1]
  cc_tw <- ip_fit$cc$values[, 1]
  as_tw <- diag(ip_fit$as$values)
  cs_tw <- diag(ip_fit$cs$values)
  muB_tw <- mxEval(MuB, ip_fit)[1, ]
  muW_tw <- mxEval(MuW, ip_fit)[1, ]

  delta <- muW_tw - muB_tw

  # Pooled SDs
  v1 <- as.matrix(pair[, ..rn1]); colnames(v1) <- sub_vars
  v2 <- as.matrix(pair[, ..rn2]); colnames(v2) <- sub_vars
  all_vals <- rbind(v1, v2)
  sds <- apply(all_vals, 2, sd, na.rm = TRUE)

  delta_z <- delta / sds
  ac_z <- ac_tw / sds
  cc_z <- cc_tw / sds
  as_z <- as_tw / sds
  cs_z <- cs_tw / sds

  # Common-variance decomposition
  X_com <- cbind(ac_z, cc_z)
  kappas_com <- solve(t(X_com) %*% X_com) %*% t(X_com) %*% delta_z
  pred_com <- X_com %*% kappas_com
  resid_com <- delta_z - pred_com
  R2_com <- 1 - sum(resid_com^2) / sum(delta_z^2)

  R2_a_com <- 1 - sum((delta_z - ac_z * sum(ac_z * delta_z) / sum(ac_z^2))^2) / sum(delta_z^2)
  R2_c_com <- 1 - sum((delta_z - cc_z * sum(cc_z * delta_z) / sum(cc_z^2))^2) / sum(delta_z^2)
  phi_A_com <- 0.5 * (R2_a_com + R2_com - R2_c_com)
  phi_C_com <- 0.5 * (R2_c_com + R2_com - R2_a_com)

  cat(sprintf("\nCommon-variance decomposition (twin-only):\n"))
  cat(sprintf("  R² = %.3f\n", R2_com))
  cat(sprintf("  Shapley: genetic = %.1f%%, environmental = %.1f%%\n",
              100 * phi_A_com / R2_com, 100 * phi_C_com / R2_com))

  # Total decomposition (4-way Shapley)
  X_tot <- cbind(ac_z, cc_z, as_z, cs_z)
  kappas_tot <- solve(t(X_tot) %*% X_tot) %*% t(X_tot) %*% delta_z
  pred_tot <- X_tot %*% kappas_tot
  resid_tot <- delta_z - pred_tot
  R2_tot <- 1 - sum(resid_tot^2) / sum(delta_z^2)

  # 4-way Shapley
  channels <- list(ac_z, cc_z, as_z, cs_z)
  n_ch <- 4
  shapley <- numeric(n_ch)
  for (i in 1:n_ch) {
    perms <- combn(n_ch, 1)  # Not needed for full Shapley
  }

  # Full 4-way Shapley via all subsets
  get_r2 <- function(idx) {
    if (length(idx) == 0) return(0)
    X_sub <- do.call(cbind, channels[idx])
    k_sub <- solve(t(X_sub) %*% X_sub) %*% t(X_sub) %*% delta_z
    p_sub <- X_sub %*% k_sub
    1 - sum((delta_z - p_sub)^2) / sum(delta_z^2)
  }

  shapley <- numeric(n_ch)
  for (i in 1:n_ch) {
    val <- 0
    others <- setdiff(1:n_ch, i)
    for (s_size in 0:(n_ch - 1)) {
      if (s_size == 0) {
        subsets <- list(integer(0))
      } else {
        subsets <- combn(others, s_size, simplify = FALSE)
      }
      for (S in subsets) {
        marginal <- get_r2(c(S, i)) - get_r2(S)
        weight <- factorial(s_size) * factorial(n_ch - s_size - 1) / factorial(n_ch)
        val <- val + weight * marginal
      }
    }
    shapley[i] <- val
  }

  gen_share <- (shapley[1] + shapley[3]) / sum(shapley)
  env_share <- (shapley[2] + shapley[4]) / sum(shapley)

  cat(sprintf("\nTotal decomposition (twin-only, 4-way Shapley):\n"))
  cat(sprintf("  R² = %.3f\n", R2_tot))
  cat(sprintf("  Shapley values: ac=%.3f, cc=%.3f, as=%.3f, cs=%.3f\n",
              shapley[1], shapley[2], shapley[3], shapley[4]))
  cat(sprintf("  Common genetic: %.1f%%\n", 100 * shapley[1] / sum(shapley)))
  cat(sprintf("  Common environ: %.1f%%\n", 100 * shapley[2] / sum(shapley)))
  cat(sprintf("  Specific genetic: %.1f%%\n", 100 * shapley[3] / sum(shapley)))
  cat(sprintf("  Specific environ: %.1f%%\n", 100 * shapley[4] / sum(shapley)))
  cat(sprintf("  TOTAL genetic: %.1f%%, TOTAL environ: %.1f%%\n",
              100 * gen_share, 100 * env_share))

  # Loading vectors
  cat(sprintf("\nLoading vectors:\n"))
  cat(sprintf("  %-8s  %8s  %8s  %8s  %8s\n", "Subtest", "ac", "cc", "as", "cs"))
  for (i in 1:nv) {
    cat(sprintf("  %-8s  %8.3f  %8.3f  %8.3f  %8.3f\n",
                sub_labels[i], ac_z[i], cc_z[i], as_z[i], cs_z[i]))
  }

  cat(sprintf("\n  Tucker(ac,cc) = %.3f\n",
              sum(ac_z * cc_z) / sqrt(sum(ac_z^2) * sum(cc_z^2))))
}


# ══════════════════════════════════════════════════════════════════════
# PART 2: Race-pooled WF HC-IQ significance across all kinship types
# ══════════════════════════════════════════════════════════════════════
cat("\n\n=== RACE-POOLED WF HC-IQ SIGNIFICANCE ===\n\n")

sub_vars_full <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
                   "wisc_picarr", "wisc_block", "wisc_coding",
                   "wrat_read_raw", "bender_gestalt",
                   "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")

d_hc <- d[!is.na(head_circ_7yr),
          c("case_id", "race", "sex", "head_circ_7yr", "wisc_fsiq"), with = FALSE]

pair_hc <- merge(links, d_hc, by.x = "id_1", by.y = "case_id")
setnames(pair_hc, c("race", "sex", "head_circ_7yr", "wisc_fsiq"),
         c("race_1", "sex_1", "hc_1", "iq_1"))
pair_hc <- merge(pair_hc, d_hc, by.x = "id_2", by.y = "case_id")
setnames(pair_hc, c("race", "sex", "head_circ_7yr", "wisc_fsiq"),
         c("race_2", "sex_2", "hc_2", "iq_2"))

pair_hc[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  pair_type == "ambiguous_sibling", "AMB",
  default = NA_character_
)]
pair_hc <- pair_hc[!is.na(pair_class)]

# Compute WF correlation with significance
wf_test <- function(hc1, hc2, iq1, iq2) {
  ok <- !is.na(hc1) & !is.na(hc2) & !is.na(iq1) & !is.na(iq2)
  if (sum(ok) < 20) return(list(N = sum(ok), BF = NA, WF = NA, WF_p = NA, BF_p = NA))
  hc_mean <- (hc1[ok] + hc2[ok]) / 2
  hc_diff <- hc1[ok] - hc2[ok]
  iq_mean <- (iq1[ok] + iq2[ok]) / 2
  iq_diff <- iq1[ok] - iq2[ok]
  bf_t <- cor.test(hc_mean, iq_mean)
  wf_t <- cor.test(hc_diff, iq_diff)
  list(N = sum(ok), BF = bf_t$estimate, BF_p = bf_t$p.value,
       WF = wf_t$estimate, WF_p = wf_t$p.value)
}

cat(sprintf("  %-10s  %5s  %8s  %12s  %8s  %12s\n",
            "Kinship", "N", "BF", "BF p", "WF", "WF p"))
cat("  ", strrep("-", 60), "\n")

for (pc in c("MZ", "DZ", "FS", "HS", "AMB")) {
  sub <- pair_hc[pair_class == pc]
  res <- wf_test(sub$hc_1, sub$hc_2, sub$iq_1, sub$iq_2)
  cat(sprintf("  %-10s  %5d  %8.3f  %12.2e  %8.3f  %12.2e\n",
              pc, res$N, res$BF, res$BF_p, res$WF, res$WF_p))
}

# All kinship combined
cat("\n")
res_all <- wf_test(pair_hc$hc_1, pair_hc$hc_2, pair_hc$iq_1, pair_hc$iq_2)
cat(sprintf("  %-10s  %5d  %8.3f  %12.2e  %8.3f  %12.2e\n",
            "ALL", res_all$N, res_all$BF, res_all$BF_p, res_all$WF, res_all$WF_p))

# Non-twin combined
nontwin <- pair_hc[pair_class %in% c("FS", "HS", "AMB")]
res_nt <- wf_test(nontwin$hc_1, nontwin$hc_2, nontwin$iq_1, nontwin$iq_2)
cat(sprintf("  %-10s  %5d  %8.3f  %12.2e  %8.3f  %12.2e\n",
            "FS+HS+AMB", res_nt$N, res_nt$BF, res_nt$BF_p, res_nt$WF, res_nt$WF_p))

# Also: regression of HC_diff on IQ_diff pooled across all pairs
cat("\n\nRegression: HC_diff ~ IQ_diff (all pairs pooled):\n")
pair_hc[, hc_diff := hc_1 - hc_2]
pair_hc[, iq_diff := iq_1 - iq_2]
m_wf <- lm(hc_diff ~ iq_diff, data = pair_hc)
cat(sprintf("  b = %.4f, SE = %.4f, t = %.2f, p = %.2e, N = %d\n",
            coef(m_wf)["iq_diff"], summary(m_wf)$coef["iq_diff", 2],
            summary(m_wf)$coef["iq_diff", 3], summary(m_wf)$coef["iq_diff", 4],
            nobs(m_wf)))

cat("\nDone.\n")
