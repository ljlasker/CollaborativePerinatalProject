#!/usr/bin/env Rscript
# 15_replication_jensen.R
# Replication of Jensen & Johnson (1994): Race and Sex Differences
# in Head Size and IQ, Intelligence, 18, 309-333.
#
# Key findings to replicate:
#  1. Within-subject HC-IQ correlations (raw and adjusted for height/weight)
#  2. Between-family (BF) vs within-family (WF) correlations:
#     HC shows both BF and WF correlation with IQ; height/weight show only BF
#  3. Extension to all kinship types (MZ, DZ, FS, HS) — Jensen used FS only
#  4. Race matching asymmetry (matching on IQ → no HC gap; matching on HC → IQ gap)
#  5. Effect sizes for siblings differing >= 1 SD

library(data.table)

cat("--- Jensen & Johnson (1994) Replication ---\n\n")

# ── Load data ──────────────────────────────────────────────────────────
d <- as.data.table(readRDS("prepared_data.rds"))
growth <- as.data.table(readRDS("prepared_growth.rds"))

# Merge anthropometrics at age 7 (84 months)
for (meas in c("head_circ_cm", "height_cm", "weight_g")) {
  g7 <- growth[measure == meas & age_months == 84,
               .(case_id = as.character(case_id), value)]
  short <- gsub("_cm$|_g$", "", meas)
  short <- paste0(short, "_7yr")
  setnames(g7, "value", short)
  d <- merge(d, g7, by = "case_id", all.x = TRUE)
}

# Convert weight to kg for interpretability
d[, weight_7yr := weight_7yr / 1000]

cat(sprintf("Individuals with HC at 7yr: %d\n", sum(!is.na(d$head_circ_7yr))))
cat(sprintf("Individuals with height at 7yr: %d\n", sum(!is.na(d$height_7yr))))
cat(sprintf("Individuals with weight at 7yr: %d\n", sum(!is.na(d$weight_7yr))))
cat(sprintf("Individuals with WISC FSIQ: %d\n", sum(!is.na(d$wisc_fsiq))))

# Restrict to Black and White with WISC + HC
dat <- d[race %in% c(1, 2) & !is.na(wisc_fsiq) & !is.na(head_circ_7yr)]
dat[, race_label := ifelse(race == 1, "White", "Black")]
dat[, female := as.integer(sex == 2)]

cat(sprintf("\nAnalytic sample: %d (White=%d, Black=%d)\n",
            nrow(dat), sum(dat$race == 1), sum(dat$race == 2)))

# ---- 1. Within-Subject Correlations (Jensen Table 7 analog) ----
cat("--- 1. WITHIN-SUBJECT CORRELATIONS OF ANTHROPOMETRICS WITH IQ ---\n")

# Raw correlations by race x sex
cat("\n  Raw correlations with WISC FSIQ:\n")
cat(sprintf("  %-12s %-10s %8s %8s %8s %6s\n",
            "Race", "Sex", "HC-IQ", "Ht-IQ", "Wt-IQ", "N"))
for (rv in c(1, 2)) {
  for (sv in c(1, 2)) {
    sub <- dat[race == rv & sex == sv]
    r_hc <- cor(sub$head_circ_7yr, sub$wisc_fsiq, use = "complete.obs")
    r_ht <- cor(sub$height_7yr, sub$wisc_fsiq, use = "complete.obs")
    r_wt <- cor(sub$weight_7yr, sub$wisc_fsiq, use = "complete.obs")
    rl <- ifelse(rv == 1, "White", "Black")
    sl <- ifelse(sv == 1, "Male", "Female")
    cat(sprintf("  %-12s %-10s %8.3f %8.3f %8.3f %6d\n",
                rl, sl, r_hc, r_ht, r_wt, nrow(sub)))
  }
}

# Adjusted correlations: partial out height and weight from HC
cat("\n  Adjusted correlations (HC adjusted for height & weight):\n")
cat(sprintf("  %-12s %-10s %8s %6s\n", "Race", "Sex", "HC-IQ", "N"))
for (rv in c(1, 2)) {
  for (sv in c(1, 2)) {
    sub <- dat[race == rv & sex == sv &
               !is.na(height_7yr) & !is.na(weight_7yr)]
    # Residualize HC on height and weight
    hc_resid <- residuals(lm(head_circ_7yr ~ height_7yr + weight_7yr, data = sub))
    r_adj <- cor(hc_resid, sub$wisc_fsiq, use = "complete.obs")
    rl <- ifelse(rv == 1, "White", "Black")
    sl <- ifelse(sv == 1, "Male", "Female")
    cat(sprintf("  %-12s %-10s %8.3f %6d\n", rl, sl, r_adj, nrow(sub)))
  }
}

# Pooled within-race (sex-adjusted z-scores)
cat("\n  Pooled within-race (sex-adjusted z-scores):\n")
dat[, iq_z := as.numeric(scale(wisc_fsiq)), by = sex]
dat[, hc_z := as.numeric(scale(head_circ_7yr)), by = sex]
dat[, ht_z := as.numeric(scale(height_7yr)), by = sex]
dat[, wt_z := as.numeric(scale(weight_7yr)), by = sex]

for (rv in c("White", "Black")) {
  sub <- dat[race_label == rv]
  r_hc <- cor(sub$hc_z, sub$iq_z, use = "complete.obs")
  r_ht <- cor(sub$ht_z, sub$iq_z, use = "complete.obs")
  r_wt <- cor(sub$wt_z, sub$iq_z, use = "complete.obs")
  cat(sprintf("  %s: r(HC,IQ)=%.3f  r(Ht,IQ)=%.3f  r(Wt,IQ)=%.3f  (n=%d)\n",
              rv, r_hc, r_ht, r_wt, sum(complete.cases(sub[, .(hc_z, iq_z)]))))
}

# ---- 2. Between-Family (BF) and Within-Family (WF) Correlations ----
cat("--- 2. BETWEEN-FAMILY vs WITHIN-FAMILY CORRELATIONS ---\n")

# Load kinship links
links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

# Classify pairs
links[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
links <- links[!is.na(pair_class)]

# Prepare individual-level data for merging
d_pair <- dat[, .(case_id, race, sex, wisc_fsiq,
                  head_circ_7yr, height_7yr, weight_7yr,
                  iq_z, hc_z, ht_z, wt_z)]

# Build pair dataset
pair <- merge(links[, .(id_1, id_2, pair_class)],
              d_pair, by.x = "id_1", by.y = "case_id")
setnames(pair, c("race", "sex", "wisc_fsiq",
                 "head_circ_7yr", "height_7yr", "weight_7yr",
                 "iq_z", "hc_z", "ht_z", "wt_z"),
         paste0(c("race", "sex", "iq",
                  "hc", "ht", "wt",
                  "iq_z", "hc_z", "ht_z", "wt_z"), "_1"))

pair <- merge(pair, d_pair, by.x = "id_2", by.y = "case_id")
setnames(pair, c("race", "sex", "wisc_fsiq",
                 "head_circ_7yr", "height_7yr", "weight_7yr",
                 "iq_z", "hc_z", "ht_z", "wt_z"),
         paste0(c("race", "sex", "iq",
                  "hc", "ht", "wt",
                  "iq_z", "hc_z", "ht_z", "wt_z"), "_2"))

# Keep same-race pairs (Black or White)
pair <- pair[race_1 == race_2 & race_1 %in% c(1, 2)]
pair[, race := ifelse(race_1 == 1, "White", "Black")]

cat(sprintf("\nPair counts:\n"))
print(pair[, .N, by = .(race, pair_class)][order(race, pair_class)])

# Compute BF and WF correlations
# BF: correlation of pair means
# WF: correlation of pair differences
cat("\n  BF = corr(pair means); WF = corr(pair differences)\n\n")

bf_wf_results <- list()

for (anthro in c("hc_z", "ht_z", "wt_z")) {
  anthro_label <- switch(anthro,
                         hc_z = "Head Circ",
                         ht_z = "Height",
                         wt_z = "Weight")
  v1 <- paste0(anthro, "_1")
  v2 <- paste0(anthro, "_2")

  cat(sprintf("  --- %s vs IQ ---\n", anthro_label))
  cat(sprintf("  %-10s %-6s %6s %8s %8s %8s\n",
              "Kinship", "Race", "N", "BF", "WF", "WF/BF"))

  for (kin in c("MZ", "DZ", "FS", "HS")) {
    for (rv in c("White", "Black")) {
      sub <- pair[pair_class == kin & race == rv &
                  !is.na(get(v1)) & !is.na(get(v2)) &
                  !is.na(iq_z_1) & !is.na(iq_z_2)]
      if (nrow(sub) < 10) {
        cat(sprintf("  %-10s %-6s %6d %8s %8s %8s\n",
                    kin, rv, nrow(sub), "---", "---", "---"))
        next
      }

      # Pair means and differences
      anthro_mean <- (sub[[v1]] + sub[[v2]]) / 2
      anthro_diff <- sub[[v1]] - sub[[v2]]
      iq_mean <- (sub$iq_z_1 + sub$iq_z_2) / 2
      iq_diff <- sub$iq_z_1 - sub$iq_z_2

      r_bf <- cor(anthro_mean, iq_mean, use = "complete.obs")
      r_wf <- cor(anthro_diff, iq_diff, use = "complete.obs")
      ratio <- if (abs(r_bf) > 0.01) r_wf / r_bf else NA

      cat(sprintf("  %-10s %-6s %6d %8.3f %8.3f %8.3f\n",
                  kin, rv, nrow(sub), r_bf, r_wf,
                  if (!is.na(ratio)) ratio else NaN))

      bf_wf_results[[paste(anthro_label, kin, rv, sep = "_")]] <-
        list(anthro = anthro_label, kin = kin, race = rv, n = nrow(sub),
             bf = r_bf, wf = r_wf, ratio = ratio)
    }
  }

  # Pooled across kinship and race
  for (rv in c("White", "Black", "All")) {
    if (rv == "All") {
      sub <- pair[!is.na(get(v1)) & !is.na(get(v2)) &
                  !is.na(iq_z_1) & !is.na(iq_z_2)]
    } else {
      sub <- pair[race == rv &
                  !is.na(get(v1)) & !is.na(get(v2)) &
                  !is.na(iq_z_1) & !is.na(iq_z_2)]
    }
    anthro_mean <- (sub[[v1]] + sub[[v2]]) / 2
    anthro_diff <- sub[[v1]] - sub[[v2]]
    iq_mean <- (sub$iq_z_1 + sub$iq_z_2) / 2
    iq_diff <- sub$iq_z_1 - sub$iq_z_2

    r_bf <- cor(anthro_mean, iq_mean, use = "complete.obs")
    r_wf <- cor(anthro_diff, iq_diff, use = "complete.obs")

    cat(sprintf("  %-10s %-6s %6d %8.3f %8.3f %8.3f\n",
                "Pooled", rv, nrow(sub), r_bf, r_wf, r_wf / r_bf))

    bf_wf_results[[paste(anthro_label, "Pooled", rv, sep = "_")]] <-
      list(anthro = anthro_label, kin = "Pooled", race = rv, n = nrow(sub),
           bf = r_bf, wf = r_wf, ratio = r_wf / r_bf)
  }
  cat("\n")
}

# ---- 3. Sibling Effect Sizes: Siblings Differing >= 1 SD ----
cat("--- 3. EFFECT SIZES FOR SIBLINGS DIFFERING >= 1 SD ---
")

# Use non-MZ pairs only (Jensen excluded twins)
# But we'll show all kinship types
cat("\n  Among sibling pairs differing >= 1 SD on one measure,\n")
cat("  what is the mean difference on the other?\n\n")

es_results <- list()

for (kin in c("DZ", "FS", "HS", "All_nonMZ")) {
  if (kin == "All_nonMZ") {
    sub <- pair[pair_class != "MZ" &
                !is.na(hc_z_1) & !is.na(hc_z_2) &
                !is.na(iq_z_1) & !is.na(iq_z_2)]
    kin_label <- "Non-MZ"
  } else {
    sub <- pair[pair_class == kin &
                !is.na(hc_z_1) & !is.na(hc_z_2) &
                !is.na(iq_z_1) & !is.na(iq_z_2)]
    kin_label <- kin
  }

  iq_diff <- sub$iq_z_1 - sub$iq_z_2
  hc_diff <- sub$hc_z_1 - sub$hc_z_2

  # Direction: higher-IQ sib minus lower-IQ sib
  # (so differences are always positive on the keyed variable)

  # 3a. Pairs differing >= 1 SD in IQ: how much do they differ in HC?
  big_iq <- abs(iq_diff) >= 1
  if (sum(big_iq) >= 10) {
    # Sign so higher IQ sib is first
    signed_hc <- ifelse(iq_diff > 0, hc_diff, -hc_diff)
    mean_hc_es <- mean(signed_hc[big_iq])
    se_hc <- sd(signed_hc[big_iq]) / sqrt(sum(big_iq))

    cat(sprintf("  %s: Sibs differing >= 1 SD in IQ (n=%d):\n",
                kin_label, sum(big_iq)))
    cat(sprintf("    Mean IQ diff = %.3f SD, Mean HC diff = %.3f SD (SE=%.3f)\n",
                mean(abs(iq_diff[big_iq])), mean_hc_es, se_hc))

    # Also for height and weight
    ht_diff <- sub$ht_z_1 - sub$ht_z_2
    wt_diff <- sub$wt_z_1 - sub$wt_z_2
    signed_ht <- ifelse(iq_diff > 0, ht_diff, -ht_diff)
    signed_wt <- ifelse(iq_diff > 0, wt_diff, -wt_diff)
    has_ht <- big_iq & !is.na(signed_ht)
    has_wt <- big_iq & !is.na(signed_wt)
    if (sum(has_ht) >= 10) {
      cat(sprintf("    Mean Ht diff = %.3f SD (SE=%.3f, n=%d)\n",
                  mean(signed_ht[has_ht]),
                  sd(signed_ht[has_ht]) / sqrt(sum(has_ht)), sum(has_ht)))
    }
    if (sum(has_wt) >= 10) {
      cat(sprintf("    Mean Wt diff = %.3f SD (SE=%.3f, n=%d)\n",
                  mean(signed_wt[has_wt]),
                  sd(signed_wt[has_wt]) / sqrt(sum(has_wt)), sum(has_wt)))
    }
  }

  # 3b. Pairs differing >= 1 SD in HC: how much do they differ in IQ?
  big_hc <- abs(hc_diff) >= 1
  if (sum(big_hc) >= 10) {
    signed_iq <- ifelse(hc_diff > 0, iq_diff, -iq_diff)
    mean_iq_es <- mean(signed_iq[big_hc])
    se_iq <- sd(signed_iq[big_hc]) / sqrt(sum(big_hc))

    cat(sprintf("  %s: Sibs differing >= 1 SD in HC (n=%d):\n",
                kin_label, sum(big_hc)))
    cat(sprintf("    Mean HC diff = %.3f SD, Mean IQ diff = %.3f SD (SE=%.3f)\n",
                mean(abs(hc_diff[big_hc])), mean_iq_es, se_iq))
  }
  cat("\n")

  es_results[[kin_label]] <- list(
    kin = kin_label,
    n_big_iq = sum(big_iq), n_big_hc = sum(big_hc),
    hc_es_given_iq = if (sum(big_iq) >= 10) mean_hc_es else NA,
    iq_es_given_hc = if (sum(big_hc) >= 10) mean_iq_es else NA
  )
}

# ---- 4. Matching Asymmetry ----
cat("--- 4. MATCHING ASYMMETRY (REGRESSION APPROACH) ---
")

dat[, black := as.integer(race == 2)]

# Raw gaps
m1 <- lm(iq_z ~ black + female, data = dat)
m3 <- lm(hc_z ~ black + female, data = dat)

# Controlling for each other
m2 <- lm(iq_z ~ black + female + hc_z, data = dat)
m4 <- lm(hc_z ~ black + female + iq_z, data = dat)

# Also adjusted for height and weight
dat_full <- dat[!is.na(ht_z) & !is.na(wt_z)]
m1f <- lm(iq_z ~ black + female, data = dat_full)
m2f <- lm(iq_z ~ black + female + hc_z + ht_z + wt_z, data = dat_full)
m3f <- lm(hc_z ~ black + female, data = dat_full)
m4f <- lm(hc_z ~ black + female + iq_z + ht_z + wt_z, data = dat_full)

raw_iq <- abs(coef(m1)["black"])
raw_hc <- abs(coef(m3)["black"])
adj_iq <- abs(coef(m2)["black"])
adj_hc <- coef(m4)["black"]  # keep sign (reverses)

cat(sprintf("\n  Raw IQ gap:                 %.3f SD\n", raw_iq))
cat(sprintf("  IQ gap | HC:                %.3f SD (%.1f%% remains)\n",
            adj_iq, 100 * adj_iq / raw_iq))
cat(sprintf("  Raw HC gap:                 %.3f SD\n", raw_hc))
cat(sprintf("  HC gap | IQ:                %.3f SD (sign reversed)\n", adj_hc))

cat(sprintf("\n  Full adjustment (+ height + weight), n=%d:\n", nrow(dat_full)))
cat(sprintf("  Raw IQ gap:                 %.3f SD\n", abs(coef(m1f)["black"])))
cat(sprintf("  IQ gap | HC+Ht+Wt:          %.3f SD (%.1f%% remains)\n",
            abs(coef(m2f)["black"]),
            100 * abs(coef(m2f)["black"]) / abs(coef(m1f)["black"])))
cat(sprintf("  Raw HC gap:                 %.3f SD\n", abs(coef(m3f)["black"])))
cat(sprintf("  HC gap | IQ+Ht+Wt:          %.3f SD\n", coef(m4f)["black"]))

# Binned matching
cat("\n  Binned matching (0.5 SD bins):\n")
dat[, iq_bin := round(iq_z * 2) / 2]
dat[, hc_bin := round(hc_z * 2) / 2]

iq_bins <- dat[, .(n_w = sum(race == 1), n_b = sum(race == 2),
                   hc_w = mean(hc_z[race == 1], na.rm = TRUE),
                   hc_b = mean(hc_z[race == 2], na.rm = TRUE)),
               by = iq_bin][n_w >= 10 & n_b >= 10][order(iq_bin)]
iq_bins[, hc_diff := hc_w - hc_b]

hc_bins <- dat[, .(n_w = sum(race == 1), n_b = sum(race == 2),
                   iq_w = mean(iq_z[race == 1], na.rm = TRUE),
                   iq_b = mean(iq_z[race == 2], na.rm = TRUE)),
               by = hc_bin][n_w >= 10 & n_b >= 10][order(hc_bin)]
hc_bins[, iq_diff := iq_w - iq_b]

cat(sprintf("  Matched on IQ:  mean HC diff = %.4f SD (Black > White)\n",
            weighted.mean(iq_bins$hc_diff, iq_bins$n_w + iq_bins$n_b)))
cat(sprintf("  Matched on HC:  mean IQ diff = %.4f SD (%.1f%% of raw)\n",
            weighted.mean(hc_bins$iq_diff, hc_bins$n_w + hc_bins$n_b),
            100 * weighted.mean(hc_bins$iq_diff, hc_bins$n_w + hc_bins$n_b) / raw_iq))

# ---- 5. Within-Family Matching ----
cat("--- 5. WITHIN-FAMILY REGRESSION OF HC ON IQ (AND VICE VERSA) ---\n")

# Using pair differences (non-MZ to avoid ceiling)
# For each kinship type: regress HC_diff on IQ_diff and vice versa
cat("\n  Regression of sibling differences:\n")
cat(sprintf("  %-10s %6s %8s %8s %8s %8s\n",
            "Kinship", "N", "b(HC~IQ)", "SE", "b(IQ~HC)", "SE"))

wf_reg_results <- list()

for (kin in c("DZ", "FS", "HS", "All_nonMZ")) {
  if (kin == "All_nonMZ") {
    sub <- pair[pair_class != "MZ" &
                !is.na(hc_z_1) & !is.na(hc_z_2) &
                !is.na(iq_z_1) & !is.na(iq_z_2)]
    kin_label <- "Non-MZ"
  } else {
    sub <- pair[pair_class == kin &
                !is.na(hc_z_1) & !is.na(hc_z_2) &
                !is.na(iq_z_1) & !is.na(iq_z_2)]
    kin_label <- kin
  }

  hc_d <- sub$hc_z_1 - sub$hc_z_2
  iq_d <- sub$iq_z_1 - sub$iq_z_2

  m_hc_on_iq <- lm(hc_d ~ iq_d - 1)  # no intercept for differences
  m_iq_on_hc <- lm(iq_d ~ hc_d - 1)

  b_hc <- coef(m_hc_on_iq)[1]
  se_hc <- summary(m_hc_on_iq)$coefficients[1, "Std. Error"]
  b_iq <- coef(m_iq_on_hc)[1]
  se_iq <- summary(m_iq_on_hc)$coefficients[1, "Std. Error"]

  cat(sprintf("  %-10s %6d %8.4f %8.4f %8.4f %8.4f\n",
              kin_label, nrow(sub), b_hc, se_hc, b_iq, se_iq))

  wf_reg_results[[kin_label]] <- list(
    kin = kin_label, n = nrow(sub),
    b_hc_on_iq = b_hc, se_hc_on_iq = se_hc,
    b_iq_on_hc = b_iq, se_iq_on_hc = se_iq
  )
}

# Same for height and weight (to show contrast)
cat("\n  Height diff ~ IQ diff (should be near zero WF):\n")
cat(sprintf("  %-10s %6s %8s %8s\n", "Kinship", "N", "b(Ht~IQ)", "SE"))
for (kin in c("DZ", "FS", "HS", "All_nonMZ")) {
  if (kin == "All_nonMZ") {
    sub <- pair[pair_class != "MZ" &
                !is.na(ht_z_1) & !is.na(ht_z_2) &
                !is.na(iq_z_1) & !is.na(iq_z_2)]
    kin_label <- "Non-MZ"
  } else {
    sub <- pair[pair_class == kin &
                !is.na(ht_z_1) & !is.na(ht_z_2) &
                !is.na(iq_z_1) & !is.na(iq_z_2)]
    kin_label <- kin
  }
  ht_d <- sub$ht_z_1 - sub$ht_z_2
  iq_d <- sub$iq_z_1 - sub$iq_z_2
  m <- lm(ht_d ~ iq_d - 1)
  cat(sprintf("  %-10s %6d %8.4f %8.4f\n",
              kin_label, nrow(sub), coef(m)[1],
              summary(m)$coefficients[1, "Std. Error"]))
}

cat("\n  Weight diff ~ IQ diff (should be near zero WF):\n")
cat(sprintf("  %-10s %6s %8s %8s\n", "Kinship", "N", "b(Wt~IQ)", "SE"))
for (kin in c("DZ", "FS", "HS", "All_nonMZ")) {
  if (kin == "All_nonMZ") {
    sub <- pair[pair_class != "MZ" &
                !is.na(wt_z_1) & !is.na(wt_z_2) &
                !is.na(iq_z_1) & !is.na(iq_z_2)]
    kin_label <- "Non-MZ"
  } else {
    sub <- pair[pair_class == kin &
                !is.na(wt_z_1) & !is.na(wt_z_2) &
                !is.na(iq_z_1) & !is.na(iq_z_2)]
    kin_label <- kin
  }
  wt_d <- sub$wt_z_1 - sub$wt_z_2
  iq_d <- sub$iq_z_1 - sub$iq_z_2
  m <- lm(wt_d ~ iq_d - 1)
  cat(sprintf("  %-10s %6d %8.4f %8.4f\n",
              kin_label, nrow(sub), coef(m)[1],
              summary(m)$coefficients[1, "Std. Error"]))
}

# ---- 6. Common Regression Line Test ----
cat("--- 6. COMMON REGRESSION LINE TEST (JENSEN'S KEY FINDING) ---\n")

m_common <- lm(hc_z ~ iq_z + female, data = dat)
m_race_int <- lm(hc_z ~ iq_z * black + female, data = dat)
f_test <- anova(m_common, m_race_int)

cat(sprintf("\n  Common line:  HC = %.4f + %.4f*IQ\n",
            coef(m_common)["(Intercept)"], coef(m_common)["iq_z"]))
cat(sprintf("  With race:    HC = %.4f + %.4f*IQ + %.4f*Black + %.4f*IQ:Black\n",
            coef(m_race_int)["(Intercept)"], coef(m_race_int)["iq_z"],
            coef(m_race_int)["black"], coef(m_race_int)["iq_z:black"]))
cat(sprintf("  F-test for race terms: F=%.2f, p=%.4f\n",
            f_test$F[2], f_test$`Pr(>F)`[2]))
cat("  (Jensen found B and W fall on the same regression line)\n")

# ---- 7. HC Associations with Subtests Residualized of g ----
cat("--- 7. HEAD CIRCUMFERENCE AND SUBTEST SPECIFICS (NET OF g) ---\n")
cat("  Does HC predict subtest-specific variance beyond g?\n")
cat("  Literature finds HC/brain size retains associations with spatial\n")
cat("  abilities after partialling out g.\n\n")

library(fixest)

# Define WISC subtests
wisc_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
               "wisc_picarr", "wisc_block", "wisc_coding")
wisc_labels <- c("Information", "Comprehension", "Vocabulary", "Digit Span",
                 "Pic. Arrangement", "Block Design", "Coding")

# Also include non-WISC measures if available
extra_vars <- c("wrat_read_raw", "bender_gestalt",
                "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
extra_labels <- c("WRAT Reading", "Bender-Gestalt",
                  "WRAT Spelling", "WRAT Arithmetic", "Goodenough")

# Check which exist
all_sub_vars <- c(wisc_vars, extra_vars)
all_sub_labels <- c(wisc_labels, extra_labels)
avail <- all_sub_vars %in% names(dat)
sub_vars_use <- all_sub_vars[avail]
sub_labs_use <- all_sub_labels[avail]

# Standardize subtests (sex-adjusted)
for (v in sub_vars_use) {
  vz <- paste0(v, "_z")
  dat[!is.na(get(v)), (vz) := as.numeric(scale(get(v))), by = sex]
}

# Extract g via ML factor analysis (single common factor)
# ML/EFA targets common variance only, unlike PCA which includes specific+error
sub_z_vars <- paste0(sub_vars_use, "_z")
sub_mat <- as.matrix(dat[, ..sub_z_vars])
cc <- complete.cases(sub_mat) & !is.na(dat$hc_z)
dat_g <- dat[cc]
sub_mat_cc <- sub_mat[cc, ]

fa_ml <- factanal(sub_mat_cc, factors = 1, scores = "regression")
dat_g[, g_ml := fa_ml$scores[, 1]]

cat(sprintf("  ML factor g extracted from %d subtests (N = %d)\n",
            length(sub_vars_use), nrow(dat_g)))
cat(sprintf("  ML factor loadings:\n"))
for (i in seq_along(sub_vars_use)) {
  cat(sprintf("    %-18s: %.3f\n", sub_labs_use[i], fa_ml$loadings[i, 1]))
}
cat(sprintf("  Proportion of variance explained: %.1f%%\n",
            100 * sum(fa_ml$loadings[, 1]^2) / ncol(sub_mat_cc)))

# 7a. Cross-sectional: HC correlations with subtests raw vs residualized of g
cat("\n  7a. Cross-sectional HC-subtest correlations (raw vs net-of-g):\n")
cat(sprintf("  %-18s  %8s  %8s  %8s  %8s\n",
            "Subtest", "r(HC,sub)", "r(HC,res)", "g-load", "Type"))
cat("  ", strrep("-", 60), "\n")

net_of_g_results <- data.table(
  subtest = character(), label = character(),
  r_raw = numeric(), r_net_g = numeric(), g_loading = numeric(),
  type = character()
)

for (i in seq_along(sub_vars_use)) {
  vz <- paste0(sub_vars_use[i], "_z")

  # Raw HC-subtest correlation
  r_raw <- cor(dat_g$hc_z, dat_g[[vz]], use = "complete.obs")

  # Residualize subtest of g
  resid_sub <- residuals(lm(as.formula(paste(vz, "~ g_ml")), data = dat_g))
  r_net <- cor(dat_g$hc_z, resid_sub, use = "complete.obs")

  # g-loading (correlation of subtest with ML factor g)
  g_load <- cor(dat_g[[vz]], dat_g$g_ml, use = "complete.obs")

  # Classify as verbal or performance/spatial
  verbal <- sub_vars_use[i] %in% c("wisc_info", "wisc_comp", "wisc_vocab",
                                    "wisc_digit", "wrat_read_raw",
                                    "wrat_spell_raw", "wrat_arith_raw")
  type <- ifelse(verbal, "Verbal", "Performance")

  cat(sprintf("  %-18s  %8.3f  %8.3f  %8.3f  %8s\n",
              sub_labs_use[i], r_raw, r_net, g_load, type))

  net_of_g_results <- rbind(net_of_g_results, data.table(
    subtest = sub_vars_use[i], label = sub_labs_use[i],
    r_raw = r_raw, r_net_g = r_net, g_loading = g_load, type = type
  ))
}

# Summary by type
cat("\n  Mean net-of-g HC correlation by type:\n")
for (tp in c("Verbal", "Performance")) {
  sub <- net_of_g_results[type == tp]
  cat(sprintf("    %-12s: mean r = %.4f (subtests: %s)\n",
              tp, mean(sub$r_net_g),
              paste(sub$label, collapse = ", ")))
}

# 7b. Within-family: HC predicting subtest residuals of g
cat("\n  7b. Within-family HC-subtest associations (net of g):\n")
cat("  Mother FE: subtest_resid ~ HC_z | mother_id\n")
cat(sprintf("  %-18s  %8s  %8s  %8s  %8s  %8s\n",
            "Subtest", "OLS_raw", "OLS_net", "FE_raw", "FE_net", "Type"))
cat("  ", strrep("-", 65), "\n")

# Need mother_id for FE
dat_g[, mother_id := as.character(mother_id)]

wf_net_g <- data.table(
  subtest = character(), label = character(),
  ols_raw = numeric(), ols_net = numeric(),
  fe_raw = numeric(), fe_net = numeric(),
  fe_net_se = numeric(), fe_net_p = numeric(),
  type = character()
)

for (i in seq_along(sub_vars_use)) {
  vz <- paste0(sub_vars_use[i], "_z")

  # Create g-residualized subtest
  dat_g[, sub_resid := residuals(lm(get(vz) ~ g_ml, data = .SD))]

  # OLS: raw and net-of-g
  ols_raw <- coef(lm(as.formula(paste(vz, "~ hc_z + female")),
                      data = dat_g))["hc_z"]
  ols_net <- coef(lm(sub_resid ~ hc_z + female, data = dat_g))["hc_z"]

  # FE: raw and net-of-g
  fe_raw_m <- tryCatch(
    feols(as.formula(paste(vz, "~ hc_z + female | mother_id")),
          data = dat_g, cluster = "mother_id"),
    error = function(e) NULL)
  fe_net_m <- tryCatch(
    feols(sub_resid ~ hc_z + female | mother_id,
          data = dat_g, cluster = "mother_id"),
    error = function(e) NULL)

  fe_raw_b <- if (!is.null(fe_raw_m)) coef(fe_raw_m)["hc_z"] else NA
  fe_net_b <- if (!is.null(fe_net_m)) coef(fe_net_m)["hc_z"] else NA
  fe_net_se_v <- if (!is.null(fe_net_m)) se(fe_net_m)["hc_z"] else NA
  fe_net_p_v <- if (!is.null(fe_net_m)) pvalue(fe_net_m)["hc_z"] else NA

  verbal <- sub_vars_use[i] %in% c("wisc_info", "wisc_comp", "wisc_vocab",
                                    "wisc_digit", "wrat_read_raw",
                                    "wrat_spell_raw", "wrat_arith_raw")
  type <- ifelse(verbal, "Verbal", "Performance")

  cat(sprintf("  %-18s  %8.4f  %8.4f  %8.4f  %8.4f  %8s\n",
              sub_labs_use[i], ols_raw, ols_net, fe_raw_b, fe_net_b, type))

  wf_net_g <- rbind(wf_net_g, data.table(
    subtest = sub_vars_use[i], label = sub_labs_use[i],
    ols_raw = ols_raw, ols_net = ols_net,
    fe_raw = fe_raw_b, fe_net = fe_net_b,
    fe_net_se = fe_net_se_v, fe_net_p = fe_net_p_v,
    type = type
  ))
}

# Summary by type
cat("\n  Mean within-family net-of-g HC coefficient by type:\n")
for (tp in c("Verbal", "Performance")) {
  sub <- wf_net_g[type == tp]
  cat(sprintf("    %-12s: mean FE_net = %.4f (subtests: %s)\n",
              tp, mean(sub$fe_net, na.rm = TRUE),
              paste(sub$label, collapse = ", ")))
}

# Also test: does HC predict performance g beyond verbal g?
# Extract separate V and P composites
v_vars <- paste0(c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit"), "_z")
p_vars <- paste0(c("wisc_picarr", "wisc_block", "wisc_coding"), "_z")

v_avail <- v_vars[v_vars %in% names(dat_g)]
p_avail <- p_vars[p_vars %in% names(dat_g)]

if (length(v_avail) >= 3 && length(p_avail) >= 2) {
  dat_g[, v_comp := rowMeans(.SD), .SDcols = v_avail]
  dat_g[, p_comp := rowMeans(.SD), .SDcols = p_avail]

  # HC predicting V and P composites, controlling for g
  cat("\n  7c. HC predicting V/P composites controlling for g:\n")

  m_v <- lm(v_comp ~ hc_z + g_ml + female, data = dat_g)
  m_p <- lm(p_comp ~ hc_z + g_ml + female, data = dat_g)
  cat(sprintf("    Verbal | g:       b = %.4f (SE = %.4f, p = %.4f)\n",
              coef(m_v)["hc_z"], summary(m_v)$coef["hc_z", 2],
              summary(m_v)$coef["hc_z", 4]))
  cat(sprintf("    Performance | g:  b = %.4f (SE = %.4f, p = %.4f)\n",
              coef(m_p)["hc_z"], summary(m_p)$coef["hc_z", 2],
              summary(m_p)$coef["hc_z", 4]))

  # Within-family
  fe_v <- tryCatch(
    feols(v_comp ~ hc_z + g_ml + female | mother_id,
          data = dat_g, cluster = "mother_id"),
    error = function(e) NULL)
  fe_p <- tryCatch(
    feols(p_comp ~ hc_z + g_ml + female | mother_id,
          data = dat_g, cluster = "mother_id"),
    error = function(e) NULL)

  if (!is.null(fe_v)) {
    cat(sprintf("    Verbal | g (FE):  b = %.4f (SE = %.4f, p = %.4f)\n",
                coef(fe_v)["hc_z"], se(fe_v)["hc_z"], pvalue(fe_v)["hc_z"]))
  }
  if (!is.null(fe_p)) {
    cat(sprintf("    Perf | g (FE):    b = %.4f (SE = %.4f, p = %.4f)\n",
                coef(fe_p)["hc_z"], se(fe_p)["hc_z"], pvalue(fe_p)["hc_z"]))
  }
}

# 7d. MIMIC SEM: Does HC predict subtests beyond g?
# Use the higher-order CFA structure from the MI analysis (4 group factors -> g)
# then add HC as a cause: HC -> g only vs HC -> g + group factors
cat("\n  7d. MIMIC SEM: HC predicting subtests through vs beyond g:\n")
library(lavaan)

# Higher-order structure matching the paper's MI analysis:
# Gc: Information, Comprehension, Vocabulary
# Gv: Picture Arrangement, Block Design, Goodenough
# Grw: WRAT Reading, Spelling, Arithmetic
# Gs: Digit Span, Bender-Gestalt, Coding (residual variance fixed to 0)
ho_base <- '
  Gc  =~ wisc_info_z + wisc_comp_z + wisc_vocab_z
  Gv  =~ wisc_picarr_z + wisc_block_z + goodenough_raw_z
  Grw =~ wrat_read_raw_z + wrat_spell_raw_z + wrat_arith_raw_z
  Gs  =~ wisc_digit_z + bender_gestalt_z + wisc_coding_z
  g   =~ Gc + Gv + Grw + Gs
  Gs ~~ 0*Gs
'

# Model 1: HC -> g only
m1_syntax <- paste0(ho_base, "\n  g ~ hc_z\n")
m1_fit <- sem(m1_syntax, data = dat_g, estimator = "MLR")

cat(sprintf("  Model 1 (HC -> g only):         chi2 = %.1f, df = %d, CFI = %.4f, RMSEA = %.4f\n",
            fitMeasures(m1_fit, "chisq.scaled"),
            fitMeasures(m1_fit, "df.scaled"),
            fitMeasures(m1_fit, "cfi.scaled"),
            fitMeasures(m1_fit, "rmsea.scaled")))

hc_g_est <- parameterEstimates(m1_fit, standardized = TRUE)
hc_g_row <- hc_g_est[hc_g_est$lhs == "g" & hc_g_est$rhs == "hc_z", ]
cat(sprintf("  HC -> g:  b = %.4f (SE = %.4f, p = %.6f, beta = %.4f)\n",
            hc_g_row$est, hc_g_row$se, hc_g_row$pvalue, hc_g_row$std.all))

# Model 2: HC -> g + HC -> all 4 group factors directly
m2_syntax <- paste0(ho_base, "\n  g ~ hc_z\n",
  "  Gc ~ hc_z\n  Gv ~ hc_z\n  Grw ~ hc_z\n  Gs ~ hc_z\n")
m2_fit <- sem(m2_syntax, data = dat_g, estimator = "MLR")

cat(sprintf("  Model 2 (HC -> g + all GF):     chi2 = %.1f, df = %d, CFI = %.4f, RMSEA = %.4f\n",
            fitMeasures(m2_fit, "chisq.scaled"),
            fitMeasures(m2_fit, "df.scaled"),
            fitMeasures(m2_fit, "cfi.scaled"),
            fitMeasures(m2_fit, "rmsea.scaled")))

# Print direct effects on group factors
m2_est <- parameterEstimates(m2_fit, standardized = TRUE)
for (gf in c("Gc", "Gv", "Grw", "Gs")) {
  row <- m2_est[m2_est$lhs == gf & m2_est$rhs == "hc_z", ]
  if (nrow(row) > 0)
    cat(sprintf("    HC -> %-4s: b = %7.4f (SE = %.4f, p = %.4f, beta = %.4f)\n",
                gf, row$est, row$se, row$pvalue, row$std.all))
}

d_test12 <- lavTestLRT(m1_fit, m2_fit)
cat(sprintf("  LRT M1 vs M2: Delta chi2 = %.1f, Delta df = %d, p = %.6f\n",
            d_test12[2, "Chisq diff"], d_test12[2, "Df diff"], d_test12[2, "Pr(>Chisq)"]))
dcfi12 <- fitMeasures(m2_fit, "cfi.scaled") - fitMeasures(m1_fit, "cfi.scaled")
cat(sprintf("  Delta CFI = %.4f (|DCFI| < .01 = direct effects negligible)\n", dcfi12))

# Model 3: HC -> g + HC -> Gv only (spatial specificity test)
m3_syntax <- paste0(ho_base, "\n  g ~ hc_z\n  Gv ~ hc_z\n")
m3_fit <- sem(m3_syntax, data = dat_g, estimator = "MLR")

cat(sprintf("\n  Model 3 (HC -> g + Gv only):    chi2 = %.1f, df = %d, CFI = %.4f, RMSEA = %.4f\n",
            fitMeasures(m3_fit, "chisq.scaled"),
            fitMeasures(m3_fit, "df.scaled"),
            fitMeasures(m3_fit, "cfi.scaled"),
            fitMeasures(m3_fit, "rmsea.scaled")))

m3_est <- parameterEstimates(m3_fit, standardized = TRUE)
gv_row <- m3_est[m3_est$lhs == "Gv" & m3_est$rhs == "hc_z", ]
cat(sprintf("    HC -> Gv:  b = %7.4f (SE = %.4f, p = %.4f, beta = %.4f)\n",
            gv_row$est, gv_row$se, gv_row$pvalue, gv_row$std.all))

d_test13 <- lavTestLRT(m1_fit, m3_fit)
cat(sprintf("  LRT M1 vs M3: Delta chi2 = %.1f, Delta df = %d, p = %.6f\n",
            d_test13[2, "Chisq diff"], d_test13[2, "Df diff"], d_test13[2, "Pr(>Chisq)"]))
dcfi13 <- fitMeasures(m3_fit, "cfi.scaled") - fitMeasures(m1_fit, "cfi.scaled")
cat(sprintf("  Delta CFI = %.4f\n", dcfi13))

# ---- 8. Summary Table ----
cat("\n--- 8. SUMMARY ---\n")

# Compile BF/WF table for all pooled results
bf_wf_dt <- rbindlist(lapply(bf_wf_results, as.data.table))
pooled <- bf_wf_dt[kin == "Pooled" & race == "All"]

cat("\n  Pooled BF/WF correlations with IQ (all kinship types):\n")
cat(sprintf("  %-12s %8s %8s %8s\n", "Measure", "BF", "WF", "WF/BF"))
for (i in 1:nrow(pooled)) {
  cat(sprintf("  %-12s %8.3f %8.3f %8.3f\n",
              pooled$anthro[i], pooled$bf[i], pooled$wf[i], pooled$ratio[i]))
}
cat("\n  Jensen's key finding: HC has both BF and WF correlation with IQ,\n")
cat("  while height and weight show primarily BF (and small/no WF).\n")
cat("  A non-zero WF correlation indicates a direct/pleiotropic\n")
cat("  relationship, not just shared familial confounds.\n")

# ---- Save Results ----
results <- list(
  n_individuals = nrow(dat),
  # Within-subject correlations (pooled, sex-adjusted)
  within_subject = list(
    white_hc_iq = cor(dat[race == 1]$hc_z, dat[race == 1]$iq_z, use = "complete.obs"),
    black_hc_iq = cor(dat[race == 2]$hc_z, dat[race == 2]$iq_z, use = "complete.obs"),
    white_ht_iq = cor(dat[race == 1]$ht_z, dat[race == 1]$iq_z, use = "complete.obs"),
    black_ht_iq = cor(dat[race == 2]$ht_z, dat[race == 2]$iq_z, use = "complete.obs"),
    white_wt_iq = cor(dat[race == 1]$wt_z, dat[race == 1]$iq_z, use = "complete.obs"),
    black_wt_iq = cor(dat[race == 2]$wt_z, dat[race == 2]$iq_z, use = "complete.obs")
  ),
  # BF/WF results
  bf_wf = bf_wf_results,
  bf_wf_dt = bf_wf_dt,
  # Sibling effect sizes
  effect_sizes = es_results,
  # WF regressions
  wf_regressions = wf_reg_results,
  # Matching asymmetry
  matching = list(
    raw_iq_gap = raw_iq, raw_hc_gap = raw_hc,
    iq_gap_after_hc = adj_iq,
    hc_gap_after_iq = adj_hc,
    binned_hc_diff_matched_iq = weighted.mean(iq_bins$hc_diff, iq_bins$n_w + iq_bins$n_b),
    binned_iq_diff_matched_hc = weighted.mean(hc_bins$iq_diff, hc_bins$n_w + hc_bins$n_b)
  ),
  # Common regression line
  regression_line = list(
    common_intercept = coef(m_common)["(Intercept)"],
    common_slope = coef(m_common)["iq_z"],
    race_intercept = coef(m_race_int)["black"],
    race_slope_diff = coef(m_race_int)["iq_z:black"],
    F_stat = f_test$F[2], p = f_test$`Pr(>F)`[2]
  ),
  iq_bins = as.data.frame(iq_bins),
  hc_bins = as.data.frame(hc_bins),
  # Net-of-g subtest associations
  net_of_g_cross = as.data.frame(net_of_g_results),
  net_of_g_wf = as.data.frame(wf_net_g)
)

saveRDS(results, "results_jensen_replication.rds")
cat("\nSaved to results_jensen_replication.rds\n")
