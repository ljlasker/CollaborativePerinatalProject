#!/usr/bin/env Rscript
# 06_maternal_age.R — Within-mother age effects on IQ

library(data.table)
library(fixest)

cat("--- Maternal Age and IQ ---\n")

d <- readRDS("prepared_data.rds")

# ---- 1. Descriptive ----
ma <- d[!is.na(wisc_fsiq) & !is.na(maternal_age)]
cat(sprintf("Children with WISC FSIQ and maternal age: %d\n", nrow(ma)))
cat(sprintf("Maternal age range: %d–%d, mean=%.1f\n",
            min(ma$maternal_age), max(ma$maternal_age), mean(ma$maternal_age)))

# IQ by maternal age bins
ma[, age_bin := cut(maternal_age, breaks = c(0, 17, 19, 24, 29, 34, 50),
                    labels = c("<18", "18-19", "20-24", "25-29", "30-34", "35+"))]
desc <- ma[, .(mean_iq = mean(wisc_fsiq), sd = sd(wisc_fsiq), n = .N), by = age_bin]
desc <- desc[order(age_bin)]
cat("\nIQ by maternal age:\n")
for (i in 1:nrow(desc)) {
  cat(sprintf("  %-8s: FSIQ=%.1f (SD=%.1f, n=%d)\n",
              desc$age_bin[i], desc$mean_iq[i], desc$sd[i], desc$n[i]))
}

# ---- 2. OLS ----
cat("\n--- OLS Regressions ---\n\n")

outcomes <- c("wisc_fsiq_z", "wisc_viq_z", "wisc_piq_z", "sb_iq_z", "g_factor_z")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

cat(sprintf("%-12s  %10s  %10s\n", "Outcome", "Linear", "Adjusted"))
cat(paste(rep("-", 38), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  m1 <- feols(as.formula(paste(y, "~ maternal_age")), data = ma, vcov = "hetero")
  m2 <- feols(as.formula(paste(y, "~ maternal_age + factor(sex) + factor(race) + educ_yrs + sei_decimal + birth_order")),
              data = ma, vcov = "hetero")
  cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)\n",
              outcome_labels[i],
              coef(m1)["maternal_age"], sprintf("%.4f", se(m1)["maternal_age"]),
              coef(m2)["maternal_age"], sprintf("%.4f", se(m2)["maternal_age"])))
}

# ---- 3. Mother Fixed Effects ----
cat("\n--- Mother Fixed Effects ---\n")
cat("Within-mother: IQ as function of maternal age at birth\n\n")

ma[, n_tested := .N, by = mother_id]
ma_fe <- ma[n_tested >= 2]
cat(sprintf("Children in families with 2+ tested: %d (in %d families)\n",
            nrow(ma_fe), uniqueN(ma_fe$mother_id)))

cat(sprintf("%-12s  %10s  %10s  %10s\n",
            "Outcome", "OLS", "FE_linear", "FE+parity"))
cat(paste(rep("-", 50), collapse=""), "\n")

ma_results <- list()
for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  ols <- feols(as.formula(paste(y, "~ maternal_age + factor(sex) + birth_order")),
               data = ma, vcov = "hetero")
  fe_lin <- feols(as.formula(paste(y, "~ maternal_age | mother_id")),
                  data = ma_fe, vcov = ~mother_id)
  fe_par <- feols(as.formula(paste(y, "~ maternal_age + birth_order | mother_id")),
                  data = ma_fe, vcov = ~mother_id)

  ma_results[[outcomes[i]]] <- list(ols = ols, fe_lin = fe_lin, fe_par = fe_par)

  cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)  %7.4f(%s)\n",
              outcome_labels[i],
              coef(ols)["maternal_age"], sprintf("%.4f", se(ols)["maternal_age"]),
              coef(fe_lin)["maternal_age"], sprintf("%.4f", se(fe_lin)["maternal_age"]),
              coef(fe_par)["maternal_age"], sprintf("%.4f", se(fe_par)["maternal_age"])))
}

# ---- 4. Quadratic specification ----
cat("\n--- Quadratic Maternal Age (Mother FE) ---\n\n")

for (i in 1:2) {
  y <- outcomes[i]
  fe_quad <- feols(as.formula(paste(y, "~ maternal_age + maternal_age_sq | mother_id")),
                   data = ma_fe, vcov = ~mother_id)
  cat(sprintf("  %s: age=%.4f (%.4f), age²=%.5f (%.5f)\n",
              outcome_labels[i],
              coef(fe_quad)["maternal_age"], se(fe_quad)["maternal_age"],
              coef(fe_quad)["maternal_age_sq"], se(fe_quad)["maternal_age_sq"]))
}

# ---- 5. Save ----
saveRDS(list(ma_results = ma_results, desc_table = desc),
        "results_maternal_age.rds")
cat("Done.\n")
