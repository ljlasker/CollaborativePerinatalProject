#!/usr/bin/env Rscript
# 07c_ses_developmental.R — Developmental SES Exposure and IQ
# Uses siblings' birth records to construct time-weighted SES trajectories
# For each child, estimates cumulative SES exposure from birth to WISC (age ~7)

library(data.table)
library(fixest)

cat("--- Developmental SES Exposure and IQ ---\n")

d <- readRDS("prepared_data.rds")

# ---- 1. Build family SES timelines ----
# Each pregnancy registration gives us an SES snapshot at a known date
# We need: mother_id, child birth date, SES at that birth

# Get birth date info — use gestational age or study_id ordering
# The CPP data has birth year/month in the raw data; use birth_order as time proxy
# More precisely: we need actual dates. Check what's available.

cat("Checking date variables...\n")
date_vars <- c("dob_year", "dob_month", "birth_year", "birth_month",
               "reg_year", "reg_month", "child_dob", "date_of_birth")
avail_dates <- date_vars[date_vars %in% names(d)]
cat(sprintf("  Available date vars: %s\n", paste(avail_dates, collapse = ", ")))

# Use study_id structure or birth_order + spacing to approximate timing
# Actually, let's use the pregnancy index within mother as our time variable
# and the SES recorded at each pregnancy

sib <- d[!is.na(mother_id) & race %in% c(1, 2)]

# Ensure birth_order is available and correct
sib[, n_sibs_total := .N, by = mother_id]

# Only families with 2+ children
sib_fam <- sib[n_sibs_total >= 2]

# Sort within family by birth_order
setorder(sib_fam, mother_id, birth_order)

cat(sprintf("\nTotal children in multi-child families: %d\n", nrow(sib_fam)))
cat(sprintf("Unique mothers: %d\n", uniqueN(sib_fam$mother_id)))

# ---- 2. Construct developmental SES index ----
# For each child i in family j:
#   - We know SES at each sibling's birth (including their own)
#   - Child i was born at birth_order k
#   - WISC administered at ~age 7
#   - Approximate that the SES recorded at each birth is the family's SES
#     from that birth until the next birth
#   - Compute time-weighted average SES across child i's developmental window
#
# With birth spacing ~2-3 years and WISC at age 7, a child's developmental
# window typically spans 2-4 sibling births, each updating the family SES.

ses_vars <- c("income", "sei_decimal", "housing_density")
ses_labels <- c("Family income", "SEI (decimal)", "Housing density")

# For each family, create the SES timeline
# We'll use birth_order spacing to approximate years between births
# Typical CPP inter-birth interval: ~2 years

# First, compute actual inter-birth intervals where possible
sib_fam[, bo_rank := rank(birth_order, ties.method = "first"), by = mother_id]

# For each child, compute developmental SES:
# All SES snapshots from their own birth through ~7 years later
# Weight by duration at each level

compute_dev_ses <- function(dt, ses_var) {
  # For each family, get the SES timeline (one value per birth)
  timeline <- dt[!is.na(get(ses_var)), .(case_id, mother_id, birth_order, bo_rank,
                                          ses_val = get(ses_var))]
  setorder(timeline, mother_id, birth_order)

  # For each child, compute:
  # 1. SES at own birth (contemporaneous)
  # 2. Average SES across all family births during child's developmental window
  # 3. Time-weighted SES (weight earlier observations less for later-born children)

  # Approach: for child with birth_order = k, the developmental window is
  # approximately from their birth to 7 years later.
  # Assume ~2 year inter-birth interval.
  # So births k through k+3 (roughly) fall in their developmental window.

  # Get all births per family
  fam_births <- timeline[, .(births = list(.SD)), by = mother_id]

  results <- list()

  for (fam_idx in seq_len(nrow(fam_births))) {
    mid <- fam_births$mother_id[fam_idx]
    births <- fam_births$births[[fam_idx]]
    n_births <- nrow(births)

    if (n_births < 2) next

    # Estimate inter-birth interval for this family
    # Use birth_order differences as proxy
    bo_vals <- births$birth_order
    bo_diffs <- diff(bo_vals)
    # Typical IBI in CPP is ~2 years; use birth_order diff as multiplier
    # (birth_order sometimes skips numbers for miscarriages)
    ibi <- 2.0  # approximate years between consecutive births

    for (i in seq_len(n_births)) {
      child_bo <- births$birth_order[i]
      child_id <- births$case_id[i]

      # Child's developmental window: birth to ~age 7
      # In birth_order units: child_bo to child_bo + 7/ibi = child_bo + 3.5

      # SES snapshots available during this window:
      # All family births from child's own birth onward, up to ~3-4 births later
      window_end_bo <- child_bo + 7 / ibi

      # All births in window (including before child's birth for prenatal environment)
      in_window <- births[birth_order >= child_bo & birth_order <= window_end_bo]

      if (nrow(in_window) == 0) {
        # Just use own birth SES
        dev_ses <- births$ses_val[i]
        n_updates <- 1
      } else {
        # Time-weight: each SES value applies from that birth to the next
        # Duration at each level proportional to gap to next birth
        ses_vals <- in_window$ses_val
        bo_in <- in_window$birth_order

        if (length(ses_vals) == 1) {
          dev_ses <- ses_vals[1]
          n_updates <- 1
        } else {
          # Durations: time from each birth to the next (or end of window)
          durations <- c(diff(bo_in) * ibi, 7 - (bo_in[length(bo_in)] - child_bo) * ibi)
          durations <- pmax(durations, 0)  # no negative durations
          # Cap last segment
          total_time <- sum(durations)
          if (total_time > 0) {
            dev_ses <- sum(ses_vals * durations) / total_time
          } else {
            dev_ses <- mean(ses_vals)
          }
          n_updates <- length(ses_vals)
        }
      }

      # Also compute: SES trajectory slope during developmental window
      # (is SES improving or declining?)
      all_before_and_during <- births[birth_order <= window_end_bo]
      if (nrow(all_before_and_during) >= 2) {
        ses_slope <- coef(lm(ses_val ~ birth_order, data = all_before_and_during))[2]
      } else {
        ses_slope <- 0
      }

      # Cumulative exposure: sum of SES * duration (not averaged)
      cum_ses <- dev_ses * 7  # total SES-years

      results[[length(results) + 1]] <- data.table(
        case_id = child_id,
        mother_id = mid,
        dev_ses = dev_ses,
        own_ses = births$ses_val[i],
        ses_slope = ses_slope,
        n_updates = n_updates
      )
    }
  }

  rbindlist(results)
}

# ---- 3. Compute developmental SES for each indicator ----
cat("\n--- Computing Developmental SES Indices ---\n")

dev_results <- list()
for (i in seq_along(ses_vars)) {
  v <- ses_vars[i]
  cat(sprintf("\n%s...\n", ses_labels[i]))

  dev <- compute_dev_ses(sib_fam, v)
  setnames(dev, c("dev_ses", "own_ses", "ses_slope"),
           paste0(c("dev_", "own_", "slope_"), v))
  dev_results[[v]] <- dev[, c("case_id", paste0(c("dev_", "own_", "slope_"), v), "n_updates"),
                           with = FALSE]

  cat(sprintf("  Children with developmental %s: %d\n", v, nrow(dev)))
  cat(sprintf("  Mean SES updates per child: %.1f\n", mean(dev$n_updates)))
  cat(sprintf("  Children with >1 update: %d (%.1f%%)\n",
              sum(dev$n_updates > 1), 100 * mean(dev$n_updates > 1)))
}

# Merge all developmental SES indices
dev_all <- Reduce(function(a, b) merge(a, b, by = "case_id", all = TRUE), dev_results)

# Merge back with main data
ana <- merge(sib_fam, dev_all, by = "case_id", all.x = TRUE)
ana <- ana[!is.na(wisc_fsiq)]

cat(sprintf("\nAnalysis sample: %d children with WISC + developmental SES\n", nrow(ana)))

# ---- 4. Key test: does developmental SES predict IQ beyond own-birth SES? ----
cat("\n--- Developmental SES vs Own-Birth SES ---\n\n")

for (i in seq_along(ses_vars)) {
  v <- ses_vars[i]
  dev_v <- paste0("dev_", v)
  own_v <- paste0("own_", v)
  slope_v <- paste0("slope_", v)

  sub <- ana[!is.na(get(dev_v)) & !is.na(get(own_v))]

  cat(sprintf("=== %s (n=%d, %d mothers) ===\n", ses_labels[i], nrow(sub), uniqueN(sub$mother_id)))

  # Correlation between own-birth and developmental SES
  r_own_dev <- cor(sub[[own_v]], sub[[dev_v]], use = "complete.obs")
  cat(sprintf("  r(own-birth, developmental) = %.3f\n", r_own_dev))

  # Within-family variation in developmental SES
  sub[, fam_mean_dev := mean(get(dev_v)), by = mother_id]
  sub[, wf_dev_ses := get(dev_v) - fam_mean_dev]
  wf_sd <- sd(sub$wf_dev_ses)
  cat(sprintf("  Within-family SD of developmental %s = %.2f\n", v, wf_sd))

  # Model 1: OLS with own-birth SES
  f1 <- as.formula(paste("wisc_fsiq ~", own_v, "+ factor(sex) + birth_order"))
  m1 <- feols(f1, data = sub, vcov = "hetero")

  # Model 2: OLS with developmental SES
  f2 <- as.formula(paste("wisc_fsiq ~", dev_v, "+ factor(sex) + birth_order"))
  m2 <- feols(f2, data = sub, vcov = "hetero")

  # Model 3: OLS with both
  f3 <- as.formula(paste("wisc_fsiq ~", own_v, "+", dev_v, "+ factor(sex) + birth_order"))
  m3 <- feols(f3, data = sub, vcov = "hetero")

  # Model 4: Mother FE with developmental SES
  f4 <- as.formula(paste("wisc_fsiq ~", dev_v, "+ factor(sex) + birth_order | mother_id"))
  m4 <- tryCatch(feols(f4, data = sub, vcov = ~mother_id), error = function(e) NULL)

  # Model 5: Mother FE with SES slope (trajectory direction)
  f5 <- as.formula(paste("wisc_fsiq ~", slope_v, "+ factor(sex) + birth_order | mother_id"))
  m5 <- tryCatch(feols(f5, data = sub, vcov = ~mother_id), error = function(e) NULL)

  # Model 6: Mother FE with both own-birth and developmental
  f6 <- as.formula(paste("wisc_fsiq ~", own_v, "+", dev_v, "+ factor(sex) + birth_order | mother_id"))
  m6 <- tryCatch(feols(f6, data = sub, vcov = ~mother_id), error = function(e) NULL)

  cat(sprintf("  OLS (own-birth):       b=%.3f (SE=%.3f)\n",
              coef(m1)[own_v], se(m1)[own_v]))
  cat(sprintf("  OLS (developmental):   b=%.3f (SE=%.3f)\n",
              coef(m2)[dev_v], se(m2)[dev_v]))
  cat(sprintf("  OLS (both):            own=%.3f (%.3f), dev=%.3f (%.3f)\n",
              coef(m3)[own_v], se(m3)[own_v], coef(m3)[dev_v], se(m3)[dev_v]))
  if (!is.null(m4)) {
    cat(sprintf("  Mother FE (dev):       b=%.3f (SE=%.3f)\n",
                coef(m4)[dev_v], se(m4)[dev_v]))
  }
  if (!is.null(m5)) {
    cat(sprintf("  Mother FE (slope):     b=%.3f (SE=%.3f)\n",
                coef(m5)[slope_v], se(m5)[slope_v]))
  }
  if (!is.null(m6)) {
    cat(sprintf("  Mother FE (own+dev):   own=%.3f (%.3f), dev=%.3f (%.3f)\n",
                coef(m6)[own_v], se(m6)[own_v], coef(m6)[dev_v], se(m6)[dev_v]))
  }
  cat("\n")

  sub[, fam_mean_dev := NULL]
  sub[, wf_dev_ses := NULL]
}

# ---- 5. Years at high vs low SES ----
cat("--- Proportion of Developmental Window at High vs Low SES ---\n\n")

# For income: classify each birth as above/below family median
# Then compute fraction of developmental window spent above median
for (i in seq_along(ses_vars)) {
  v <- ses_vars[i]
  dev_v <- paste0("dev_", v)
  own_v <- paste0("own_", v)

  sub <- ana[!is.na(get(dev_v)) & !is.na(wisc_fsiq)]

  # Within-family deviation of developmental SES
  sub[, fam_mean := mean(get(dev_v)), by = mother_id]
  sub[, dev_above := get(dev_v) > fam_mean]

  tab <- sub[, .(mean_iq = mean(wisc_fsiq), n = .N),
             by = .(race_label = ifelse(race == 1, "White", "Black"), dev_above)]

  cat(sprintf("%s — IQ by above/below family-mean developmental SES:\n", ses_labels[i]))
  print(tab[order(race_label, dev_above)])
  cat("\n")

  sub[, fam_mean := NULL]
  sub[, dev_above := NULL]
}

# ---- 6. By race with mother FE ----
cat("--- By Race: Mother FE with Developmental SES ---\n\n")

for (rv in c(1, 2)) {
  rl <- ifelse(rv == 1, "White", "Black")
  cat(sprintf("--- %s ---\n", rl))

  for (i in seq_along(ses_vars)) {
    v <- ses_vars[i]
    dev_v <- paste0("dev_", v)
    sub <- ana[race == rv & !is.na(get(dev_v))]

    f <- as.formula(paste("wisc_fsiq ~", dev_v, "+ factor(sex) + birth_order | mother_id"))
    m <- tryCatch(feols(f, data = sub, vcov = ~mother_id), error = function(e) NULL)

    if (!is.null(m)) {
      p <- 2 * pnorm(-abs(coef(m)[dev_v] / se(m)[dev_v]))
      cat(sprintf("  %s: b=%.3f (SE=%.3f), p=%.4f, n=%d\n",
                  ses_labels[i], coef(m)[dev_v], se(m)[dev_v], p, nrow(sub)))
    }
  }
  cat("\n")
}

# ---- 7. SES trajectory matters? Test rising vs falling SES ----
cat("--- Rising vs Falling SES Families ---\n\n")

for (i in seq_along(ses_vars)) {
  v <- ses_vars[i]
  slope_v <- paste0("slope_", v)

  sub <- ana[!is.na(get(slope_v)) & !is.na(wisc_fsiq)]

  # Classify families by SES trajectory
  fam_slopes <- sub[, .(mean_slope = mean(get(slope_v))), by = mother_id]
  fam_slopes[, trajectory := ifelse(mean_slope > 0.1, "Rising",
                              ifelse(mean_slope < -0.1, "Falling", "Stable"))]

  sub <- merge(sub, fam_slopes[, .(mother_id, trajectory)], by = "mother_id")

  tab <- sub[, .(mean_iq = mean(wisc_fsiq), n_kids = .N,
                  n_fams = uniqueN(mother_id)), by = trajectory]
  cat(sprintf("%s trajectories:\n", ses_labels[i]))
  print(tab[order(-mean_iq)])
  cat("\n")
}

# ---- 8. MDE for developmental SES ----
cat("--- Power: MDE for Developmental SES ---\n\n")

for (i in seq_along(ses_vars)) {
  v <- ses_vars[i]
  dev_v <- paste0("dev_", v)

  sub <- ana[!is.na(get(dev_v))]
  f <- as.formula(paste("wisc_fsiq ~", dev_v, "+ factor(sex) + birth_order | mother_id"))
  m <- tryCatch(feols(f, data = sub, vcov = ~mother_id), error = function(e) NULL)

  if (!is.null(m)) {
    se_fe <- se(m)[dev_v]
    sub[, fam_mean := mean(get(dev_v)), by = mother_id]
    sub[, wf_dev := get(dev_v) - fam_mean]
    wf_sd <- sd(sub$wf_dev)
    mde <- 2.8 * se_fe * wf_sd
    cat(sprintf("  %s: SE=%.4f, WF-SD=%.2f, MDE per 1-SD = %.2f IQ pts\n",
                ses_labels[i], se_fe, wf_sd, mde))
    sub[, fam_mean := NULL]
    sub[, wf_dev := NULL]
  }
}

cat("\nDone.\n")
