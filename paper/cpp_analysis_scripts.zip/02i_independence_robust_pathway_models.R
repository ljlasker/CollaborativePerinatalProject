#!/usr/bin/env Rscript
# Independence-robust sensitivity for the IP-versus-CP comparison.
#
# Two complementary procedures are used:
#   1. One random pair TOTAL per connected extended-family component. Ordinary
#      pair-level likelihood inference is then based on independent components.
#   2. A nonparametric component bootstrap retaining every pair contributed by
#      each sampled component. This supplies cluster-robust sampling variation
#      for the composite-likelihood point estimates and loading diagnostics.
#
# The number of repetitions can be overridden for smoke tests, e.g.
# CPP_PATHWAY_ROBUST_REPS=5 Rscript 02i_independence_robust_pathway_models.R

library(data.table)
library(OpenMx)

mxOption(NULL, "Number of Threads", max(1L, min(4L, parallel::detectCores() - 1L)))
set.seed(20260824)

repetitions <- as.integer(Sys.getenv("CPP_PATHWAY_ROBUST_REPS", "100"))
if (is.na(repetitions) || repetitions < 1L) {
  stop("CPP_PATHWAY_ROBUST_REPS must be a positive integer")
}
measure_set <- Sys.getenv("CPP_PATHWAY_MEASURE_SET", "wisc7")
run_independent_draws <- Sys.getenv("CPP_PATHWAY_INDEPENDENT_DRAWS", "1") != "0"
run_cluster_bootstrap <- Sys.getenv("CPP_PATHWAY_CLUSTER_BOOTSTRAP", "1") != "0"
if (!run_independent_draws && !run_cluster_bootstrap) {
  stop("At least one robustness procedure must be enabled")
}

full_sub_vars <- c(
  "wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
  "wisc_picarr", "wisc_block", "wisc_coding",
  "wrat_read_raw", "bender_gestalt",
  "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw"
)
if (measure_set == "wisc7") {
  sub_vars <- full_sub_vars[1:7]
  output_suffix <- "wisc7"
  start_result <- readRDS("results_congruence_benchmarks.rds")$wisc_only
  ip_summary <- start_result$ip_sum
  cp_summary <- start_result$cp_sum
  reference_chisq <- start_result$chi2
  reference_df <- start_result$df
} else if (measure_set == "full12") {
  sub_vars <- full_sub_vars
  output_suffix <- "full12"
  start_result <- readRDS("results_pathway_models.rds")
  ip_summary <- start_result$ip_fit_sum
  cp_summary <- start_result$cp_fit_sum
  reference_chisq <- start_result$cp_vs_ip$chi2
  reference_df <- start_result$cp_vs_ip$df
} else {
  stop("CPP_PATHWAY_MEASURE_SET must be 'wisc7' or 'full12'")
}
nv <- length(sub_vars)
name_1 <- paste0(sub_vars, "_1")
name_2 <- paste0(sub_vars, "_2")
var_names <- c(name_1, name_2)

family_result <- readRDS("results_family_dependence_robustness.rds")
component_map <- as.data.table(family_result$component_map)

d <- as.data.table(readRDS("prepared_data.rds"))
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}
if ("goodenough_standard" %in% names(d)) {
  d[goodenough_standard == 888, goodenough_standard := NA]
}

links <- fread(
  file.path("..", "clean", "cpp_kinship_links.csv"),
  colClasses = c(id_1 = "character", id_2 = "character", mother_id = "character")
)
d_sub <- d[, c("case_id", sub_vars), with = FALSE]
pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
setnames(pair, sub_vars, name_1)
pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
setnames(pair, sub_vars, name_2)
pair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %chin% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair <- pair[!is.na(pair_class)]
pair <- pair[
  rowSums(!is.na(pair[, ..name_1])) > 0 &
    rowSums(!is.na(pair[, ..name_2])) > 0
]
missing_mothers <- setdiff(unique(pair$mother_id), component_map$mother_id)
if (length(missing_mothers)) {
  # These mothers have usable subtests but no complete FSIQ pair and no edge in
  # the extended-kin file used to build the initial map. They are singleton
  # components under the observed genealogy.
  component_map <- rbind(
    component_map,
    data.table(mother_id = missing_mothers, component_id = missing_mothers)
  )
}
pair <- merge(pair, component_map, by = "mother_id", all.x = TRUE)
stopifnot(!anyNA(pair$component_id))
setorder(pair, component_id, pair_class, mother_id, id_1, id_2)

ip_parameters <- as.data.table(ip_summary$parameters)
cp_parameters <- as.data.table(cp_summary$parameters)
model_df <- ip_summary$estimatedParameters - cp_summary$estimatedParameters

matrix_estimates <- function(parameters, matrix_name) {
  parameters[matrix == matrix_name, Estimate]
}

ip_start <- list(
  ac = matrix_estimates(ip_parameters, "ac"),
  cc = matrix_estimates(ip_parameters, "cc"),
  ec = matrix_estimates(ip_parameters, "ec"),
  as = matrix_estimates(ip_parameters, "as"),
  cs = matrix_estimates(ip_parameters, "cs"),
  es = matrix_estimates(ip_parameters, "es"),
  Mu = matrix_estimates(ip_parameters, "Mu")
)
cp_start <- list(
  lambda = matrix_estimates(cp_parameters, "lambda"),
  af = matrix_estimates(cp_parameters, "af"),
  cf = matrix_estimates(cp_parameters, "cf"),
  as = matrix_estimates(cp_parameters, "as"),
  cs = matrix_estimates(cp_parameters, "cs"),
  es = matrix_estimates(cp_parameters, "es"),
  Mu = matrix_estimates(cp_parameters, "Mu")
)
stopifnot(
  lengths(ip_start) == c(nv, nv, nv, nv, nv, nv, nv),
  lengths(cp_start) == c(nv, 1L, 1L, nv, nv, nv, nv)
)

make_group <- function(group_name, relatedness, parent_name, observed) {
  mxModel(
    group_name,
    mxData(observed, type = "raw"),
    mxAlgebraFromString(
      sprintf("%.8f * %s.A + %s.C", relatedness, parent_name, parent_name),
      name = "B"
    ),
    mxAlgebraFromString(
      sprintf("rbind(cbind(%s.V, B), cbind(B, %s.V))", parent_name, parent_name),
      name = "expCov"
    ),
    mxAlgebraFromString(
      sprintf("cbind(%s.Mu, %s.Mu)", parent_name, parent_name),
      name = "expMean"
    ),
    mxExpectationNormal(
      covariance = "expCov", means = "expMean", dimnames = var_names
    ),
    mxFitFunctionML()
  )
}

split_groups <- function(sample) {
  list(
    MZ = as.data.frame(sample[pair_class == "MZ", ..var_names]),
    DZ = as.data.frame(sample[pair_class == "DZ", ..var_names]),
    FS = as.data.frame(sample[pair_class == "FS", ..var_names]),
    HS = as.data.frame(sample[pair_class == "HS", ..var_names])
  )
}

build_ip <- function(groups) {
  mxModel(
    "IP",
    mxMatrix("Full", nv, 1L, free = TRUE, values = ip_start$ac,
             lbound = -5, name = "ac"),
    mxMatrix("Full", nv, 1L, free = TRUE, values = ip_start$cc,
             lbound = -5, name = "cc"),
    mxMatrix("Full", nv, 1L, free = TRUE, values = ip_start$ec,
             lbound = -5, name = "ec"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = ip_start$as,
             lbound = 0.001, name = "as"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = ip_start$cs,
             lbound = 0.001, name = "cs"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = ip_start$es,
             lbound = 0.001, name = "es"),
    mxMatrix("Full", 1L, nv, free = TRUE, values = ip_start$Mu, name = "Mu"),
    mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
    mxAlgebra(A + C + E, name = "V"),
    make_group("MZ", 1.00, "IP", groups$MZ),
    make_group("DZ", 0.50, "IP", groups$DZ),
    make_group("FS", 0.50, "IP", groups$FS),
    make_group("HS", 0.25, "IP", groups$HS),
    mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
  )
}

build_cp <- function(groups) {
  mxModel(
    "CP",
    mxMatrix("Full", nv, 1L, free = TRUE, values = cp_start$lambda,
             lbound = 0.01, name = "lambda"),
    mxMatrix("Full", 1L, 1L, free = TRUE, values = cp_start$af,
             lbound = 0.01, ubound = 0.99, name = "af"),
    mxMatrix("Full", 1L, 1L, free = TRUE, values = cp_start$cf,
             lbound = 0.01, ubound = 0.99, name = "cf"),
    mxAlgebra(sqrt(1 - af * af - cf * cf), name = "ef"),
    mxConstraint(af * af + cf * cf < 0.999, name = "factor_variance"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = cp_start$as,
             lbound = 0.001, name = "as"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = cp_start$cs,
             lbound = 0.001, name = "cs"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = cp_start$es,
             lbound = 0.001, name = "es"),
    mxMatrix("Full", 1L, nv, free = TRUE, values = cp_start$Mu, name = "Mu"),
    mxAlgebra(lambda %*% (af * af) %*% t(lambda) + as %*% t(as), name = "A"),
    mxAlgebra(lambda %*% (cf * cf) %*% t(lambda) + cs %*% t(cs), name = "C"),
    mxAlgebra(lambda %*% (ef * ef) %*% t(lambda) + es %*% t(es), name = "E"),
    mxAlgebra(A + C + E, name = "V"),
    make_group("MZ", 1.00, "CP", groups$MZ),
    make_group("DZ", 0.50, "CP", groups$DZ),
    make_group("FS", 0.50, "CP", groups$FS),
    make_group("HS", 0.25, "CP", groups$HS),
    mxFitFunctionMultigroup(c("MZ", "DZ", "FS", "HS"))
  )
}

tucker <- function(x, y) sum(x * y) / sqrt(sum(x^2) * sum(y^2))

fit_sample <- function(sample, procedure, iteration) {
  counts <- sample[, .N, by = pair_class]
  if (!all(c("MZ", "DZ", "FS", "HS") %chin% counts$pair_class)) {
    return(data.table(
      procedure = procedure, iteration = iteration, converged = FALSE
    ))
  }
  groups <- split_groups(sample)
  run_checked <- function(model) {
    fit <- tryCatch(mxRun(model, silent = TRUE), error = function(e) NULL)
    if (!is.null(fit) && !fit$output$status$code %in% c(0L, 1L, 6L)) {
      fit <- tryCatch(
        mxTryHard(fit, extraTries = 3L, silent = TRUE),
        error = function(e) fit
      )
    }
    fit
  }
  ip_fit <- run_checked(build_ip(groups))
  cp_fit <- run_checked(build_cp(groups))
  if (is.null(ip_fit) || is.null(cp_fit)) {
    return(data.table(
      procedure = procedure, iteration = iteration, converged = FALSE
    ))
  }

  status_ip <- ip_fit$output$status$code
  status_cp <- cp_fit$output$status$code
  converged <- status_ip %in% c(0L, 1L, 6L) && status_cp %in% c(0L, 1L, 6L)
  ac <- ip_fit$ac$values[, 1L]
  cc <- ip_fit$cc$values[, 1L]
  ec <- ip_fit$ec$values[, 1L]
  singular_values <- svd(cbind(ac, cc, ec))$d
  delta <- as.numeric(cp_fit$output$fit - ip_fit$output$fit)

  data.table(
    procedure = procedure,
    iteration = iteration,
    converged = converged,
    pair_rows = nrow(sample),
    components = uniqueN(sample$component_id),
    n_mz = groups$MZ |> nrow(),
    n_dz = groups$DZ |> nrow(),
    n_fs = groups$FS |> nrow(),
    n_hs = groups$HS |> nrow(),
    status_ip = status_ip,
    status_cp = status_cp,
    minus2ll_ip = as.numeric(ip_fit$output$fit),
    minus2ll_cp = as.numeric(cp_fit$output$fit),
    delta_chisq = delta,
    df = model_df,
    log10_p = pchisq(max(delta, 0), df = model_df, lower.tail = FALSE, log.p = TRUE) /
      log(10),
    svd_rank1_share = singular_values[1L]^2 / sum(singular_values^2),
    tucker_ac_cc = tucker(ac, cc)
  )
}

components <- unique(pair$component_id)
independent_results <- vector("list", repetitions)
bootstrap_results <- vector("list", repetitions)

cat(sprintf(
  "Running %d %s repetition(s): %s%s...\n",
  repetitions, output_suffix,
  ifelse(run_independent_draws, "independent-pair draws", ""),
  ifelse(run_cluster_bootstrap,
         paste0(ifelse(run_independent_draws, " and ", ""),
                "extended-family bootstraps"), "")
))

for (b in seq_len(repetitions)) {
  set.seed(20260824L + b)
  if (run_independent_draws) {
    independent_sample <- pair[, .SD[sample.int(.N, 1L)], by = component_id]
    independent_results[[b]] <- fit_sample(
      independent_sample, "one_pair_per_extended_family", b
    )
  }

  if (run_cluster_bootstrap) {
    sampled_components <- sample(components, length(components), replace = TRUE)
    component_weights <- data.table(component_id = sampled_components)[
      , .(weight = .N), by = component_id
    ]
    bootstrap_sample <- merge(
      pair, component_weights, by = "component_id", all = FALSE
    )
    bootstrap_sample <- bootstrap_sample[rep(seq_len(.N), weight)]
    bootstrap_sample[, weight := NULL]
    bootstrap_results[[b]] <- fit_sample(
      bootstrap_sample, "extended_family_cluster_bootstrap", b
    )
  }

  if (b %% 5L == 0L || b == repetitions) {
    cat(sprintf("  completed %d/%d\n", b, repetitions))
    flush.console()
  }
}

model_results <- rbindlist(
  c(
    if (run_independent_draws) independent_results else list(),
    if (run_cluster_bootstrap) bootstrap_results else list()
  ),
  fill = TRUE
)
successful <- model_results[converged == TRUE]

model_summary <- successful[, .(
  requested_repetitions = repetitions,
  successful_fits = .N,
  pairs_median = median(pair_rows),
  pairs_min = min(pair_rows),
  pairs_max = max(pair_rows),
  delta_chisq_median = median(delta_chisq),
  delta_chisq_q025 = quantile(delta_chisq, 0.025),
  delta_chisq_q975 = quantile(delta_chisq, 0.975),
  delta_chisq_min = min(delta_chisq),
  maximum_log10_p = max(log10_p),
  svd_rank1_median = median(svd_rank1_share),
  svd_rank1_q025 = quantile(svd_rank1_share, 0.025),
  svd_rank1_q975 = quantile(svd_rank1_share, 0.975),
  tucker_ac_cc_median = median(tucker_ac_cc),
  tucker_ac_cc_q025 = quantile(tucker_ac_cc, 0.025),
  tucker_ac_cc_q975 = quantile(tucker_ac_cc, 0.975)
), by = procedure]

reference <- data.table(
  procedure = "all_pairs_conventional_reference",
  pair_rows = ip_summary$numObs,
  minus2ll_ip = ip_summary$Minus2LogLikelihood,
  minus2ll_cp = cp_summary$Minus2LogLikelihood,
  delta_chisq = reference_chisq,
  df = reference_df,
  log10_p = pchisq(
    reference_chisq,
    df = reference_df,
    lower.tail = FALSE,
    log.p = TRUE
  ) / log(10)
)

mode_suffix <- paste0(
  ifelse(run_independent_draws, "independent", ""),
  ifelse(run_independent_draws && run_cluster_bootstrap, "_and_", ""),
  ifelse(run_cluster_bootstrap, "cluster_bootstrap", "")
)
file_stub <- sprintf("%s_%s", output_suffix, mode_suffix)
fwrite(model_results, sprintf("results_independence_robust_pathway_draws_%s.csv", file_stub))
fwrite(model_summary, sprintf("results_independence_robust_pathway_summary_%s.csv", file_stub))
fwrite(reference, sprintf("results_independence_robust_pathway_reference_%s.csv", file_stub))
saveRDS(
  list(
    reference = reference,
    draws = model_results,
    summary = model_summary,
    component_count = length(components)
  ),
  sprintf("results_independence_robust_pathway_models_%s.rds", file_stub)
)

cat("--- Independence-robust pathway-model summary ---\n")
print(reference)
print(model_summary)
