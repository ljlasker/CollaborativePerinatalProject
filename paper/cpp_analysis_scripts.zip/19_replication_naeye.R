#!/usr/bin/env Rscript
# 19_replication_naeye.R
# Replication: Naeye (1979)
# "Weight gain and the outcome of pregnancy" (AJOG)
#
# Original finding: Optimal maternal weight gain depended on pre-pregnancy
# weight; thin women needed more gain, obese women less. Excessive weight gain
# in obese women was associated with adverse outcomes.
#
# Our approach: Use weight_gain and weight_predelivery (available in clean
# data) to examine birth weight outcomes by maternal weight gain category,
# stratified by pre-delivery weight tertiles (as proxy for body habitus).

library(data.table)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")

cat("\n")
cat("--- REPLICATION: Naeye (1979) Maternal Weight Gain and Birth Outcomes ---
")

# ── Check available weight variables ──────────────────────────────────
wt_cols <- grep("weight|wt|bmi", names(d), ignore.case = TRUE, value = TRUE)
cat("\nWeight-related columns in data:\n")
for (v in wt_cols) {
  n_valid <- d[!is.na(get(v)), .N]
  m <- d[, mean(get(v), na.rm = TRUE)]
  cat(sprintf("  %-25s  N = %6d  Mean = %8.1f\n", v, n_valid, m))
}

# ── Variables ─────────────────────────────────────────────────────────
# weight_gain: maternal weight gain during pregnancy (lbs)
# weight_predelivery: maternal weight at delivery (lbs)
# birth_wt_g: infant birth weight (grams)

cat(sprintf("\nweight_gain: N = %d, Mean = %.1f lbs, SD = %.1f\n",
            d[!is.na(weight_gain), .N],
            d[, mean(weight_gain, na.rm = TRUE)],
            d[, sd(weight_gain, na.rm = TRUE)]))
cat(sprintf("weight_predelivery: N = %d, Mean = %.1f lbs, SD = %.1f\n",
            d[!is.na(weight_predelivery), .N],
            d[, mean(weight_predelivery, na.rm = TRUE)],
            d[, sd(weight_predelivery, na.rm = TRUE)]))

# Clean: exclude extreme values
d[weight_gain < -10 | weight_gain > 80, weight_gain := NA]
d[weight_predelivery < 80 | weight_predelivery > 350, weight_predelivery := NA]

# Compute pre-pregnancy weight = pre-delivery weight - weight gain
d[, pre_preg_wt := weight_predelivery - weight_gain]
d[pre_preg_wt < 70 | pre_preg_wt > 300, pre_preg_wt := NA]

cat(sprintf("\npre_preg_wt (computed): N = %d, Mean = %.1f lbs, SD = %.1f\n",
            d[!is.na(pre_preg_wt), .N],
            d[, mean(pre_preg_wt, na.rm = TRUE)],
            d[, sd(pre_preg_wt, na.rm = TRUE)]))

# PART A: CLOSE REPLICATION — Naeye (1979)
# Naeye used pre-pregnancy weight categories (<110, 110-129, 130-149,
# 150+ lbs) and examined birth weight by weight gain within each stratum.
# We restrict to singletons as Naeye did.
cat("\n")
cat("--- PART A: CLOSE REPLICATION — Naeye (1979) Sample: singletons only, using computed pre-pregnancy weight ---
")

# Restrict to singletons
d_close <- d[plurality == 0]
cat(sprintf("\n  Full sample: %d\n", nrow(d)))
cat(sprintf("  Singletons: %d\n", nrow(d_close)))
cat(sprintf("  With pre-pregnancy wt + weight gain + birth wt: %d\n",
            d_close[!is.na(pre_preg_wt) & !is.na(weight_gain) & !is.na(birth_wt_g), .N]))

# Naeye's pre-pregnancy weight categories
d_close[, ppw_cat := fcase(
  pre_preg_wt < 110, "<110 lbs",
  pre_preg_wt < 130, "110-129 lbs",
  pre_preg_wt < 150, "130-149 lbs",
  pre_preg_wt >= 150, "150+ lbs",
  default = NA_character_
)]

# Coarser gain categories
d_close[, wt_gain_broad := fcase(
  weight_gain < 16,  "<16 lbs",
  weight_gain < 26,  "16-25 lbs",
  weight_gain < 36,  "26-35 lbs",
  weight_gain >= 36, "36+ lbs",
  default = NA_character_
)]

cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE A1: Birth Weight by Weight Gain, Stratified by Pre-Pregnancy Weight\n")
cat("(Matching Naeye's weight categories)\n")
cat(strrep("-", 70), "\n")

naeye_tab <- d_close[!is.na(ppw_cat) & !is.na(wt_gain_broad) & !is.na(birth_wt_g), .(
  mean_bw = mean(birth_wt_g),
  pct_lbw = mean(birth_wt_g < 2500) * 100,
  n = .N
), by = .(ppw_cat, wt_gain_broad)]

naeye_tab[, ppw_cat := factor(ppw_cat,
  levels = c("<110 lbs", "110-129 lbs", "130-149 lbs", "150+ lbs"))]
naeye_tab[, wt_gain_broad := factor(wt_gain_broad,
  levels = c("<16 lbs", "16-25 lbs", "26-35 lbs", "36+ lbs"))]
naeye_tab <- naeye_tab[order(ppw_cat, wt_gain_broad)]

for (ppw in levels(naeye_tab$ppw_cat)) {
  cat(sprintf("\n  Pre-pregnancy weight: %s\n", ppw))
  cat(sprintf("  %-12s  %8s  %7s  %5s\n", "Wt Gain", "BW (g)", "% LBW", "N"))
  cat("  ", strrep("-", 35), "\n")
  sub <- naeye_tab[ppw_cat == ppw]
  for (j in 1:nrow(sub)) {
    cat(sprintf("  %-12s  %8.0f  %6.1f%%  %5d\n",
                as.character(sub[j, wt_gain_broad]),
                sub[j, mean_bw], sub[j, pct_lbw], sub[j, n]))
  }
}

# Gradient by pre-pregnancy weight category (g per lb gained)
cat("\n  Weight gain gradient (g birth weight per lb gained) by pre-preg weight:\n")
for (ppw in levels(naeye_tab$ppw_cat)) {
  sub <- d_close[ppw_cat == ppw & !is.na(weight_gain) & !is.na(birth_wt_g)]
  if (nrow(sub) > 50) {
    m <- lm(birth_wt_g ~ weight_gain, data = sub)
    cat(sprintf("    %-15s  b = %.1f g/lb (N = %d)\n",
                ppw, coef(m)["weight_gain"], nobs(m)))
  }
}

cat("\n  Naeye original: Thin women (<110 lbs) benefit most from weight gain;\n")
cat("  heavy women (150+ lbs) show diminishing returns.\n")

# ---- PART B: EXTENSION — Full Sample Analysis ----
cat("\n")
cat("--- PART B: EXTENSION — Full Sample Analysis ---
")

cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE B1: Birth Weight by Maternal Weight Gain Category\n")
cat(strrep("-", 70), "\n")

d[, wt_gain_cat := fcase(
  weight_gain < 10,  "<10 lbs",
  weight_gain < 16,  "10-15 lbs",
  weight_gain < 21,  "16-20 lbs",
  weight_gain < 26,  "21-25 lbs",
  weight_gain < 31,  "26-30 lbs",
  weight_gain < 36,  "31-35 lbs",
  weight_gain < 41,  "36-40 lbs",
  weight_gain >= 41, "41+ lbs",
  default = NA_character_
)]

wg_tab <- d[!is.na(wt_gain_cat) & !is.na(birth_wt_g), .(
  mean_bw = mean(birth_wt_g),
  sd_bw = sd(birth_wt_g),
  pct_lbw = mean(birth_wt_g < 2500) * 100,
  mean_gest = mean(gest_age, na.rm = TRUE),
  n = .N
), by = wt_gain_cat]

wg_tab[, wt_gain_cat := factor(wt_gain_cat,
  levels = c("<10 lbs", "10-15 lbs", "16-20 lbs", "21-25 lbs",
             "26-30 lbs", "31-35 lbs", "36-40 lbs", "41+ lbs"))]
wg_tab <- wg_tab[order(wt_gain_cat)]

cat(sprintf("\n  %-12s  %8s  %8s  %8s  %8s  %5s\n",
            "Wt Gain", "BW (g)", "SD", "% LBW", "Gest Age", "N"))
cat("  ", strrep("-", 55), "\n")
for (i in 1:nrow(wg_tab)) {
  cat(sprintf("  %-12s  %8.0f  %8.0f  %7.1f%%  %8.1f  %5d\n",
              as.character(wg_tab[i, wt_gain_cat]),
              wg_tab[i, mean_bw], wg_tab[i, sd_bw],
              wg_tab[i, pct_lbw], wg_tab[i, mean_gest], wg_tab[i, n]))
}

cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE B2: Birth Weight by Weight Gain, Stratified by Pre-Delivery Weight\n")
cat("(Pre-delivery weight tertiles — alternative stratification)\n")
cat(strrep("-", 70), "\n")

# Create weight tertiles
d[!is.na(weight_predelivery), wt_tertile := cut(weight_predelivery,
    breaks = quantile(weight_predelivery, probs = c(0, 1/3, 2/3, 1), na.rm = TRUE),
    labels = c("Light", "Medium", "Heavy"),
    include.lowest = TRUE)]

# Tertile cutpoints
cat("\nPre-delivery weight tertile cutpoints:\n")
qs <- d[!is.na(weight_predelivery),
        quantile(weight_predelivery, probs = c(0, 1/3, 2/3, 1))]
cat(sprintf("  Light:  <= %.0f lbs\n", qs[2]))
cat(sprintf("  Medium: %.0f - %.0f lbs\n", qs[2], qs[3]))
cat(sprintf("  Heavy:  > %.0f lbs\n", qs[3]))

# Coarser gain categories for stratified table
d[, wt_gain_broad := fcase(
  weight_gain < 16,  "<16 lbs",
  weight_gain < 26,  "16-25 lbs",
  weight_gain < 36,  "26-35 lbs",
  weight_gain >= 36, "36+ lbs",
  default = NA_character_
)]

strat_tab <- d[!is.na(wt_tertile) & !is.na(wt_gain_broad) & !is.na(birth_wt_g), .(
  mean_bw = mean(birth_wt_g),
  pct_lbw = mean(birth_wt_g < 2500) * 100,
  n = .N
), by = .(wt_tertile, wt_gain_broad)]

strat_tab[, wt_gain_broad := factor(wt_gain_broad,
  levels = c("<16 lbs", "16-25 lbs", "26-35 lbs", "36+ lbs"))]
strat_tab <- strat_tab[order(wt_tertile, wt_gain_broad)]

for (tert in c("Light", "Medium", "Heavy")) {
  cat(sprintf("\n  %s mothers (pre-delivery weight tertile):\n", tert))
  cat(sprintf("  %-12s  %8s  %7s  %5s\n", "Wt Gain", "BW (g)", "% LBW", "N"))
  cat("  ", strrep("-", 35), "\n")
  sub <- strat_tab[wt_tertile == tert]
  for (j in 1:nrow(sub)) {
    cat(sprintf("  %-12s  %8.0f  %6.1f%%  %5d\n",
                as.character(sub[j, wt_gain_broad]),
                sub[j, mean_bw], sub[j, pct_lbw], sub[j, n]))
  }
}

cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE B3: OLS Regression — Birth Weight on Weight Gain\n")
cat(strrep("-", 70), "\n")

m1 <- lm(birth_wt_g ~ weight_gain, data = d)
m2 <- lm(birth_wt_g ~ weight_gain + race + sex + maternal_age + educ_yrs +
           gest_age + parity + smoker, data = d)
m3 <- lm(birth_wt_g ~ weight_gain * wt_tertile + race + sex + maternal_age +
           educ_yrs + gest_age + parity + smoker, data = d)

cat(sprintf("\n  %-50s  %8s  %8s  %8s  %5s\n",
            "Model", "b(wt_gain)", "SE", "p", "N"))
cat("  ", strrep("-", 80), "\n")

cat(sprintf("  %-50s  %8.2f  %8.2f  %8.4f  %5d\n",
            "Unadjusted",
            coef(m1)["weight_gain"], summary(m1)$coef["weight_gain", 2],
            summary(m1)$coef["weight_gain", 4], nobs(m1)))
cat(sprintf("  %-50s  %8.2f  %8.2f  %8.4f  %5d\n",
            "Adjusted (race, sex, mat age, educ, GA, parity)",
            coef(m2)["weight_gain"], summary(m2)$coef["weight_gain", 2],
            summary(m2)$coef["weight_gain", 4], nobs(m2)))

# Interaction model coefficients
cat("\n  Interaction model (weight gain x maternal weight tertile):\n")
s3 <- summary(m3)$coefficients
wg_terms <- grep("weight_gain", rownames(s3), value = TRUE)
for (nm in wg_terms) {
  cat(sprintf("    %-45s  %8.2f  %8.2f  %8.4f\n",
              nm, s3[nm, 1], s3[nm, 2], s3[nm, 4]))
}

# TABLE B4: Low Birth Weight Risk by Weight Gain
cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE 4: Logistic Regression — LBW on Weight Gain\n")
cat(strrep("-", 70), "\n")

d[, lbw := as.integer(birth_wt_g < 2500)]
lg1 <- glm(lbw ~ weight_gain, data = d, family = binomial)
lg2 <- glm(lbw ~ weight_gain + race + sex + maternal_age + gest_age +
              parity + smoker, data = d, family = binomial)

cat(sprintf("\n  %-45s  %8s  %8s  %8s\n", "Model", "OR", "95% CI", "p"))
cat("  ", strrep("-", 75), "\n")

or1 <- exp(coef(lg1)["weight_gain"])
ci1 <- exp(confint.default(lg1)["weight_gain", ])
cat(sprintf("  %-45s  %8.3f  [%.3f-%.3f]  %8.4f\n",
            "Unadjusted (per 1-lb gain)", or1, ci1[1], ci1[2],
            summary(lg1)$coef["weight_gain", 4]))

or2 <- exp(coef(lg2)["weight_gain"])
ci2 <- exp(confint.default(lg2)["weight_gain", ])
cat(sprintf("  %-45s  %8.3f  [%.3f-%.3f]  %8.4f\n",
            "Adjusted", or2, ci2[1], ci2[2],
            summary(lg2)$coef["weight_gain", 4]))

# Per 10-lb gain
cat(sprintf("\n  Per 10-lb gain (adjusted): OR = %.3f [%.3f-%.3f]\n",
            or2^10, ci2[1]^10, ci2[2]^10))

# TABLE B5: By Race
cat("\n")
cat(strrep("-", 70), "\n")
cat("TABLE 5: Weight Gain-Birth Weight Gradient by Race\n")
cat(strrep("-", 70), "\n")

for (r in sort(unique(d[race %in% c(1, 2), race]))) {
  rlbl <- ifelse(r == 1, "White", "Black")
  sub <- d[race == r & !is.na(weight_gain) & !is.na(birth_wt_g)]
  m <- lm(birth_wt_g ~ weight_gain, data = sub)
  cat(sprintf("\n  %s (N = %d): b = %.2f g per lb gained (SE = %.2f, p = %.4f)\n",
              rlbl, nobs(m), coef(m)["weight_gain"],
              summary(m)$coef["weight_gain", 2],
              summary(m)$coef["weight_gain", 4]))
}

# ── Comparison ────────────────────────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Comparison with Naeye (1979):\n")
cat(strrep("-", 70), "\n")
cat("  Original: Weight gain-birth weight relationship depends on\n")
cat("  pre-pregnancy body habitus. Thin women benefit most from weight\n")
cat("  gain; heavy women show diminishing returns. Excessive gain in\n")
cat("  heavy women associated with adverse perinatal outcomes.\n")
cat("  Our analysis uses pre-delivery weight tertiles as proxy for\n")
cat("  body habitus (pre-pregnancy weight not reliably available).\n")

# ── Save ──────────────────────────────────────────────────────────────
results <- list(
  overall_table = wg_tab,
  stratified_table = strat_tab,
  ols_models = list(m1 = m1, m2 = m2, m3 = m3),
  logistic_models = list(lg1 = lg1, lg2 = lg2)
)
saveRDS(results, "results_replication_naeye.rds")
cat("\nResults saved to results_replication_naeye.rds\n")
