# ============================================================================
# Phase 3k: Gestational Diabetes -> IQ and Head Circumference
# Between-family (OLS) and within-family (mother FE) analyses
# ============================================================================

library(data.table)
library(fixest)
source("case_id_helpers.R")

cat("====================================================================\n")
cat("  Phase 3k: Gestational Diabetes Effects on IQ & Head Circumference\n")
cat("====================================================================\n\n")

# ── 1. Load prepared data ─────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")
cat("Prepared data loaded:", nrow(d), "rows,", ncol(d), "columns\n")

# ── 2. Load diabetes variables from raw CPP data ────────────────────────────
csv <- fread("../clean/cppvar_all_columns.csv",
             select = c("case_id",
                         "v156_diabetes_mellitus_diabetes_mellitus",
                         "v163_glucose_tolerance_test_abnormal",
                         "v1159_head_circumference_neonatal_cms",
                         "v811_head_circumference_yr_cms"),
             colClasses = list(character = "case_id"),
             strip.white = FALSE)

# Right-complete blank child digits; numeric left-padding would shift the ID.
csv[, case_id := canonicalize_cpp_case_id(case_id, strict = TRUE)]

cat("Raw CSV loaded:", nrow(csv), "rows\n\n")

# ── 3. Create gestational diabetes indicator ────────────────────────────────
# v156 codes: 0=none, 1-7=various trimester/type codes, 9=unknown/NA
# v163 codes: 0=none, 1-7=various codes, 9=unknown/NA
# We treat 9 as missing/unknown, and 1-7 as positive

csv[, v156 := v156_diabetes_mellitus_diabetes_mellitus]
csv[, v163 := v163_glucose_tolerance_test_abnormal]

# Binary: 1 if any positive diabetes or abnormal GTT (codes 1-7)
csv[, gestational_diabetes := as.integer(
  (v156 %in% 1:7) | (v163 %in% 1:7)
)]
# Set to NA if both variables are NA or both are 9 (unknown) with no positive
csv[is.na(v156) & is.na(v163), gestational_diabetes := NA_integer_]
# If one is 9 and other is NA, and neither is in 1:7, set to NA
csv[!(v156 %in% 1:7) & !(v163 %in% 1:7) & (v156 == 9 | v163 == 9),
    gestational_diabetes := NA_integer_]

cat("Gestational diabetes variable created:\n")
print(table(csv$gestational_diabetes, useNA = "ifany"))
cat("\n")

# ── 4. Clean head circumference variables ────────────────────────────────────
# 99 is a missing code
csv[v1159_head_circumference_neonatal_cms == 99,
    v1159_head_circumference_neonatal_cms := NA_real_]
csv[v811_head_circumference_yr_cms == 99,
    v811_head_circumference_yr_cms := NA_real_]

setnames(csv,
         c("v1159_head_circumference_neonatal_cms",
           "v811_head_circumference_yr_cms"),
         c("hc_neonatal", "hc_1yr"))

cat("Head circumference (neonatal) summary:\n")
print(summary(csv$hc_neonatal))
cat("\nHead circumference (1 year) summary:\n")
print(summary(csv$hc_1yr))
cat("\n")

# ── 5. Merge into prepared data ─────────────────────────────────────────────
d <- merge(d, csv[, .(case_id, gestational_diabetes, hc_neonatal, hc_1yr)],
           by = "case_id", all.x = TRUE)

cat("After merge:", nrow(d), "rows\n")
cat("Gestational diabetes in merged data:\n")
print(table(d$gestational_diabetes, useNA = "ifany"))
cat("\n")

# ── 6. Prevalence by race ───────────────────────────────────────────────────
cat("====================================================================\n")
cat("  Prevalence of Gestational Diabetes\n")
cat("====================================================================\n\n")

# Overall
overall_prev <- d[!is.na(gestational_diabetes),
                  .(n_total = .N,
                    n_diabetes = sum(gestational_diabetes == 1),
                    prevalence = mean(gestational_diabetes == 1) * 100)]
cat("Overall:\n")
print(overall_prev)
cat("\n")

# By race
race_prev <- d[!is.na(gestational_diabetes) & !is.na(race_label),
               .(n_total = .N,
                 n_diabetes = sum(gestational_diabetes == 1),
                 prevalence = round(mean(gestational_diabetes == 1) * 100, 2)),
               by = race_label]
cat("By race:\n")
print(race_prev)
cat("\n")

# ── 7. Identify available IQ outcomes ────────────────────────────────────────
cat("====================================================================\n")
cat("  Available Outcome Variables\n")
cat("====================================================================\n\n")

cat("Stanford-Binet IQ (age 4): n =", sum(!is.na(d$sb_iq)), "\n")
cat("WISC Full-Scale IQ (age 7): n =", sum(!is.na(d$wisc_fsiq)), "\n")
cat("Head circ neonatal: n =", sum(!is.na(d$hc_neonatal)), "\n")
cat("Head circ 1yr: n =", sum(!is.na(d$hc_1yr)), "\n\n")

# ── 8. Within-family variation check ─────────────────────────────────────────
cat("====================================================================\n")
cat("  Within-Family Variation in Gestational Diabetes\n")
cat("====================================================================\n\n")

# Mothers with >1 child who have non-missing diabetes info
multi_child <- d[!is.na(gestational_diabetes),
                 .(n_kids = .N,
                   n_diab = sum(gestational_diabetes),
                   any_variation = (min(gestational_diabetes) != max(gestational_diabetes))),
                 by = mother_id]

multi_child <- multi_child[n_kids >= 2]
cat("Mothers with 2+ children (non-missing diabetes):", nrow(multi_child), "\n")
cat("Mothers with within-family variation in diabetes:",
    sum(multi_child$any_variation), "\n")

# Children in varying families
varying_moms <- multi_child[any_variation == TRUE, mother_id]
n_kids_varying <- d[mother_id %in% varying_moms & !is.na(gestational_diabetes), .N]
cat("Children from mothers with variation:", n_kids_varying, "\n\n")

# Show the distribution of diabetes among varying mothers
cat("Among mothers with variation:\n")
vary_detail <- d[mother_id %in% varying_moms & !is.na(gestational_diabetes),
                 .(n = .N, pct_diab = round(mean(gestational_diabetes)*100, 1)),
                 by = mother_id]
cat("  Number of mothers:", nrow(vary_detail), "\n")
cat("  Total children:", sum(vary_detail$n), "\n\n")

# Also check for IQ-specific samples
for (outcome in c("sb_iq", "wisc_fsiq")) {
  mc <- d[!is.na(gestational_diabetes) & !is.na(get(outcome)),
          .(n_kids = .N,
            any_var = (min(gestational_diabetes) != max(gestational_diabetes))),
          by = mother_id]
  mc <- mc[n_kids >= 2]
  cat(sprintf("For %s: %d mothers with 2+ kids, %d with diabetes variation\n",
              outcome, nrow(mc), sum(mc$any_var)))
}

for (outcome in c("hc_neonatal", "hc_1yr")) {
  mc <- d[!is.na(gestational_diabetes) & !is.na(get(outcome)),
          .(n_kids = .N,
            any_var = (min(gestational_diabetes) != max(gestational_diabetes))),
          by = mother_id]
  mc <- mc[n_kids >= 2]
  cat(sprintf("For %s: %d mothers with 2+ kids, %d with diabetes variation\n",
              outcome, nrow(mc), sum(mc$any_var)))
}
cat("\n")

# ── 9. Run regression models ────────────────────────────────────────────────
cat("====================================================================\n")
cat("  Regression Models\n")
cat("====================================================================\n\n")

# Standardize outcomes for easier interpretation
d[, sb_iq_std := (sb_iq - mean(sb_iq, na.rm = TRUE)) / sd(sb_iq, na.rm = TRUE)]
d[, wisc_fsiq_std := (wisc_fsiq - mean(wisc_fsiq, na.rm = TRUE)) / sd(wisc_fsiq, na.rm = TRUE)]
d[, hc_neo_std := (hc_neonatal - mean(hc_neonatal, na.rm = TRUE)) / sd(hc_neonatal, na.rm = TRUE)]
d[, hc_1yr_std := (hc_1yr - mean(hc_1yr, na.rm = TRUE)) / sd(hc_1yr, na.rm = TRUE)]

# Controls
# race as factor, sex, maternal_age, sei (socioeconomic index), gest_age,
# and observed live-birth order.  Use birth_order (prior live births), not the
# obstetric parity count, so the script matches the manuscript specification.
d[, race_f := factor(race)]
d[, sex_f := factor(sex)]

results_list <- list()

outcomes <- c("sb_iq", "wisc_fsiq", "hc_neonatal", "hc_1yr",
              "sb_iq_std", "wisc_fsiq_std", "hc_neo_std", "hc_1yr_std")

for (outvar in outcomes) {
  cat("--------------------------------------------------------------\n")
  cat("  Outcome:", outvar, "\n")
  cat("--------------------------------------------------------------\n\n")

  # Build formula strings
  controls <- "gestational_diabetes + sex_f + maternal_age + sei + gest_age + birth_order"

  # --- OLS (between-family, with race) ---
  f_ols <- as.formula(paste(outvar, "~", controls, "+ race_f"))

  tryCatch({
    m_ols <- feols(f_ols, data = d, vcov = "hetero")
    cat("OLS (between-family):\n")
    cat(sprintf("  N = %d\n", m_ols$nobs))
    coef_ols <- coeftable(m_ols)["gestational_diabetes", ]
    cat(sprintf("  gestational_diabetes: b = %.4f, SE = %.4f, t = %.2f, p = %.4f\n",
                coef_ols["Estimate"], coef_ols["Std. Error"],
                coef_ols["t value"], coef_ols["Pr(>|t|)"]))
    cat("\n")

    results_list[[paste0(outvar, "_ols")]] <- list(
      outcome = outvar,
      model = "OLS",
      n = m_ols$nobs,
      coef = coef_ols["Estimate"],
      se = coef_ols["Std. Error"],
      t = coef_ols["t value"],
      p = coef_ols["Pr(>|t|)"],
      full_model = summary(m_ols)
    )
  }, error = function(e) {
    cat("  OLS failed:", e$message, "\n\n")
  })

  # --- Mother FE (within-family) ---
  f_fe <- as.formula(paste(outvar, "~", controls, "| mother_id"))

  tryCatch({
    m_fe <- feols(f_fe, data = d, vcov = ~mother_id)
    cat("Mother FE (within-family):\n")
    cat(sprintf("  N = %d\n", m_fe$nobs))
    coef_fe <- coeftable(m_fe)["gestational_diabetes", ]
    cat(sprintf("  gestational_diabetes: b = %.4f, SE = %.4f, t = %.2f, p = %.4f\n",
                coef_fe["Estimate"], coef_fe["Std. Error"],
                coef_fe["t value"], coef_fe["Pr(>|t|)"]))
    cat("\n")

    results_list[[paste0(outvar, "_fe")]] <- list(
      outcome = outvar,
      model = "Mother_FE",
      n = m_fe$nobs,
      coef = coef_fe["Estimate"],
      se = coef_fe["Std. Error"],
      t = coef_fe["t value"],
      p = coef_fe["Pr(>|t|)"],
      full_model = summary(m_fe)
    )
  }, error = function(e) {
    cat("  Mother FE failed:", e$message, "\n\n")
  })
}

# ── 10. Summary table ───────────────────────────────────────────────────────
cat("\n====================================================================\n")
cat("  Summary Table: Gestational Diabetes Coefficients\n")
cat("====================================================================\n\n")

summary_rows <- list()
for (nm in names(results_list)) {
  r <- results_list[[nm]]
  summary_rows[[length(summary_rows) + 1]] <- data.table(
    outcome = r$outcome,
    model = r$model,
    n = r$n,
    coef = round(r$coef, 4),
    se = round(r$se, 4),
    t = round(r$t, 2),
    p = round(r$p, 4)
  )
}

summary_dt <- rbindlist(summary_rows)
print(summary_dt, row.names = FALSE)

# ── 11. Print full model summaries for raw-score outcomes ────────────────────
cat("\n====================================================================\n")
cat("  Full Model Summaries (Raw Scores)\n")
cat("====================================================================\n\n")

for (nm in c("sb_iq_ols", "sb_iq_fe", "wisc_fsiq_ols", "wisc_fsiq_fe",
             "hc_neonatal_ols", "hc_neonatal_fe", "hc_1yr_ols", "hc_1yr_fe")) {
  if (!is.null(results_list[[nm]])) {
    cat("--------------------------------------------------------------\n")
    cat(" ", nm, "\n")
    cat("--------------------------------------------------------------\n")
    print(results_list[[nm]]$full_model)
    cat("\n")
  }
}

# ── 12. Save results ────────────────────────────────────────────────────────
saveRDS(results_list, "results_gestational_diabetes.rds")
cat("\nResults saved to results_gestational_diabetes.rds\n")
cat("Done.\n")
