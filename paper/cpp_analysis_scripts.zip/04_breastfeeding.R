#!/usr/bin/env Rscript
# 04_breastfeeding.R — Breastfeeding-IQ association (OLS + mother FE)

library(data.table)
library(fixest)

cat("--- Breastfeeding and IQ ---\n")

d <- readRDS("prepared_data.rds")

# ---- 1. Sample description ----
bf <- d[!is.na(wisc_fsiq) & !is.na(bf_any)]
cat(sprintf("Children with WISC FSIQ and BF data: %d\n", nrow(bf)))
cat(sprintf("  Breastfed: %d (%.1f%%)\n", sum(bf$bf_any==1), 100*mean(bf$bf_any==1)))
cat(sprintf("  Not breastfed: %d (%.1f%%)\n", sum(bf$bf_any==0), 100*mean(bf$bf_any==0)))
cat(sprintf("  Mean IQ (BF): %.1f, Mean IQ (no BF): %.1f, diff = %.1f\n",
            mean(bf[bf_any==1]$wisc_fsiq), mean(bf[bf_any==0]$wisc_fsiq),
            mean(bf[bf_any==1]$wisc_fsiq) - mean(bf[bf_any==0]$wisc_fsiq)))

# Caveat about BF measurement
cat("\nNote: CPP breastfeeding is nursery feeding (0-8 days postpartum).\n")
cat("This is NOT long-term breastfeeding duration.\n\n")

# ---- 2. OLS specifications ----
cat("--- OLS Regressions ---\n\n")

covariates_base <- "bf_any"
covariates_demo <- "bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal"
covariates_full <- "bf_any + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_wt_g + gest_age + smoker + birth_order"

outcomes <- c("wisc_fsiq_z", "wisc_viq_z", "wisc_piq_z", "sb_iq_z", "g_factor_z")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

cat(sprintf("%-12s  %10s  %10s  %10s\n",
            "Outcome", "Bivar_b", "Demo_b", "Full_b"))
cat(paste(rep("-", 50), collapse=""), "\n")

for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  m1 <- feols(as.formula(paste(y, "~", covariates_base)), data = bf, vcov = "hetero")
  m2 <- feols(as.formula(paste(y, "~", covariates_demo)), data = bf, vcov = "hetero")
  m3 <- feols(as.formula(paste(y, "~", covariates_full)), data = bf, vcov = "hetero")

  cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)  %7.4f(%s)\n",
              outcome_labels[i],
              coef(m1)["bf_any"], sprintf("%.4f", se(m1)["bf_any"]),
              coef(m2)["bf_any"], sprintf("%.4f", se(m2)["bf_any"]),
              coef(m3)["bf_any"], sprintf("%.4f", se(m3)["bf_any"])))
}

# ---- 3. Mother Fixed Effects ----
cat("\n--- Mother Fixed Effects ---\n\n")

# Need families with variation in BF
bf[, n_tested := .N, by = mother_id]
bf_fe <- bf[n_tested >= 2]
bf_fe[, bf_var := sd(bf_any, na.rm=TRUE), by = mother_id]
bf_disc <- bf_fe[bf_var > 0]

cat(sprintf("Children in families with 2+ tested: %d\n", nrow(bf_fe)))
cat(sprintf("Children in discordant families (BF varies): %d (in %d families)\n",
            nrow(bf_disc), uniqueN(bf_disc$mother_id)))

cat(sprintf("\n%-12s  %10s  %10s  %10s\n",
            "Outcome", "OLS_b", "FE_all_b", "FE_disc_b"))
cat(paste(rep("-", 50), collapse=""), "\n")

bf_results <- list()
for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  ols <- feols(as.formula(paste(y, "~ bf_any + factor(sex) + birth_order")),
               data = bf, vcov = "hetero")
  fe_all <- tryCatch(
    feols(as.formula(paste(y, "~ bf_any + factor(sex) + birth_order | mother_id")),
          data = bf_fe, vcov = ~mother_id),
    error = function(e) NULL
  )
  fe_disc <- tryCatch(
    feols(as.formula(paste(y, "~ bf_any + factor(sex) + birth_order | mother_id")),
          data = bf_disc, vcov = ~mother_id),
    error = function(e) NULL
  )

  bf_results[[outcomes[i]]] <- list(ols = ols, fe_all = fe_all, fe_disc = fe_disc)

  cat(sprintf("%-12s  %7.4f(%s)",
              outcome_labels[i],
              coef(ols)["bf_any"], sprintf("%.4f", se(ols)["bf_any"])))
  if (!is.null(fe_all)) {
    cat(sprintf("  %7.4f(%s)", coef(fe_all)["bf_any"], sprintf("%.4f", se(fe_all)["bf_any"])))
  } else cat("        --    ")
  if (!is.null(fe_disc)) {
    cat(sprintf("  %7.4f(%s)", coef(fe_disc)["bf_any"], sprintf("%.4f", se(fe_disc)["bf_any"])))
  } else cat("        --    ")
  cat("\n")
}

# ---- 4. BF by race ----
cat("\n--- Breastfeeding-IQ by Race ---\n\n")
for (race_val in c(1, 2)) {
  race_lab <- ifelse(race_val == 1, "White", "Black")
  sub <- bf[race == race_val]
  cat(sprintf("  %s: BF rate = %.1f%%, n = %d\n",
              race_lab, 100*mean(sub$bf_any==1), nrow(sub)))
  m <- feols(wisc_fsiq_z ~ bf_any + factor(sex) + maternal_age + educ_yrs + birth_order,
             data = sub, vcov = "hetero")
  cat(sprintf("    OLS b(BF) = %.4f (se=%.4f)\n", coef(m)["bf_any"], se(m)["bf_any"]))
}

# ---- 5. Historical context ----
cat("\n--- Historical Context ---\n")
cat("In the 1960s CPP, breastfeeding was NEGATIVELY associated with SES:\n")
bf_by_educ <- bf[, .(bf_rate = mean(bf_any==1, na.rm=TRUE), n = .N),
                 by = .(educ_group = cut(educ_yrs, c(0, 8, 11, 12, 16, 25)))]
bf_by_educ <- bf_by_educ[order(educ_group)]
for (i in 1:nrow(bf_by_educ)) {
  cat(sprintf("  Educ %s: BF rate = %.1f%% (n=%d)\n",
              bf_by_educ$educ_group[i], 100*bf_by_educ$bf_rate[i], bf_by_educ$n[i]))
}

# ---- 6. Save ----
saveRDS(list(bf_results = bf_results), "results_breastfeeding.rds")
cat("Done.\n")
