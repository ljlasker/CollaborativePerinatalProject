#!/usr/bin/env Rscript
# 02f_molenaar_gxe.R
# Molenaar, Boomsma, & Dolan (1993) Fourth-Order Moment Test for
# Gene-Environment Interactions in ACE Factor Scores
#
# Applies the Molenaar et al. test to common A, C, E factor scores from
# the multivariate Independent Pathway (IP) model (12 cognitive subtests).
# Unlike univariate ACE models where A/C/E factor scores are all linear
# functions of a single observed variable, the IP model identifies each
# common factor through 12 indicators, providing genuine separation.
#
# The test examines fourth-order moments (kurtosis, cross-kurtosis) of
# standardized factor scores. Under a pure linear ACE model:
#   E[X^4] = 3 (mesokurtic)        E[X^2 Y^2] = 1 (independent)
# Under full multiplicative interaction:
#   E[X^4] = 9                     E[X^2 Y^2] = 3
#
# Interactivity percentage = (observed - pure) / (interactive - pure) * 100
#
# Requires: results_pathway_models.rds (IP model parameter estimates)

library(data.table)

cat("\n")
cat("--- MOLENAAR ET AL. (1993) FOURTH-ORDER MOMENT TEST FOR G x E Applied to Multivariate IP Model Common Factor Scores ---
")

# ---- 1. RECONSTRUCT IP MODEL PARAMETERS ----

r <- readRDS("results_pathway_models.rds")
p <- r$ip_fit_sum$parameters
nv <- 12

# Extract parameter vectors
get_vec <- function(mat_name) {
  rows <- p[p$matrix == mat_name, ]
  rows <- rows[order(rows$row), ]
  rows$Estimate
}
get_diag <- function(mat_name, n) {
  rows <- p[p$matrix == mat_name, ]
  rows <- rows[order(rows$row), ]
  diag(rows$Estimate, n)
}

ac <- matrix(get_vec("ac"), nv, 1)    # common A loadings (nv x 1)
cc <- matrix(get_vec("cc"), nv, 1)    # common C loadings
ec <- matrix(get_vec("ec"), nv, 1)    # common E loadings
as_mat <- get_diag("as", nv)          # specific A (diagonal nv x nv)
cs_mat <- get_diag("cs", nv)          # specific C
es_mat <- get_diag("es", nv)          # specific E

mu_rows <- p[p$matrix == "Mu", ]
mu_rows <- mu_rows[order(mu_rows$col), ]
Mu <- mu_rows$Estimate

# Reconstruct covariance components
A <- ac %*% t(ac) + as_mat %*% t(as_mat)
C <- cc %*% t(cc) + cs_mat %*% t(cs_mat)
E <- ec %*% t(ec) + es_mat %*% t(es_mat)
V <- A + C + E

cat("IP model parameters reconstructed from saved estimates.\n")
cat(sprintf("  Variance (trace): A=%.1f (%.1f%%), C=%.1f (%.1f%%), E=%.1f (%.1f%%)\n\n",
            sum(diag(A)), 100*sum(diag(A))/sum(diag(V)),
            sum(diag(C)), 100*sum(diag(C))/sum(diag(V)),
            sum(diag(E)), 100*sum(diag(E))/sum(diag(V))))


# ---- 2. DATA PREPARATION ----

d <- readRDS("prepared_data.rds")
for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}
links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")

d_sub <- d[, c("case_id", sub_vars), with = FALSE]
pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
new_names1 <- paste0(sub_vars, "_1")
setnames(pair, sub_vars, new_names1)
pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
new_names2 <- paste0(sub_vars, "_2")
setnames(pair, sub_vars, new_names2)

pair[, kin_group := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair <- pair[!is.na(kin_group)]

mat1 <- as.matrix(pair[, ..new_names1])
mat2 <- as.matrix(pair[, ..new_names2])

cat("Pair counts:\n")
for (g in c("MZ", "DZ", "FS", "HS")) {
  idx <- pair$kin_group == g
  comp <- rowSums(is.na(mat1[idx,])) == 0 & rowSums(is.na(mat2[idx,])) == 0
  cat(sprintf("  %s: %d total, %d complete (%.0f%%)\n",
              g, sum(idx), sum(comp), 100 * sum(comp) / sum(idx)))
}


# ---- 3. FACTOR SCORE EXTRACTION (regression method) ----
#
# For a pair (y1, y2) with genetic relatedness R:
#   Sigma_pair = [[V, R*A+C], [R*A+C, V]]
#
# Regression factor scores for common factors:
#   Cov(Ac1, [y1;y2]) = [ac, R*ac]     (genetic: cross-pair cov = R)
#   Cov(Cc1, [y1;y2]) = [cc, cc]       (shared env: cross-pair cov = 1)
#   Cov(Ec1, [y1;y2]) = [ec, 0]        (unique env: cross-pair cov = 0)
#
#   f_hat = Cov(f, y) * Sigma^{-1} * (y - mu)

cat("\n")
cat(strrep("-", 70), "\n")
cat("Extracting common A, C, E factor scores (complete cases only)\n")
cat(strrep("-", 70), "\n\n")

R_map <- c(MZ = 1.0, DZ = 0.5, FS = 0.5, HS = 0.25)

extract_factor_scores <- function(y1_mat, y2_mat, R_val) {
  N <- nrow(y1_mat)
  B <- R_val * A + C
  Sigma_pair <- rbind(cbind(V, B), cbind(B, V))
  Sigma_inv <- solve(Sigma_pair)
  zero_v <- rep(0, nv)

  # Regression weights (1 x 2nv) for each common factor
  w_Ac1 <- t(c(ac, R_val * ac)) %*% Sigma_inv
  w_Cc1 <- t(c(cc, cc)) %*% Sigma_inv
  w_Ec1 <- t(c(ec, zero_v)) %*% Sigma_inv
  w_Ac2 <- t(c(R_val * ac, ac)) %*% Sigma_inv
  w_Cc2 <- t(c(cc, cc)) %*% Sigma_inv
  w_Ec2 <- t(c(zero_v, ec)) %*% Sigma_inv

  # Center data and compute scores
  y_centered <- cbind(sweep(y1_mat, 2, Mu), sweep(y2_mat, 2, Mu))

  cbind(Ac1 = as.vector(y_centered %*% t(w_Ac1)),
        Cc1 = as.vector(y_centered %*% t(w_Cc1)),
        Ec1 = as.vector(y_centered %*% t(w_Ec1)),
        Ac2 = as.vector(y_centered %*% t(w_Ac2)),
        Cc2 = as.vector(y_centered %*% t(w_Cc2)),
        Ec2 = as.vector(y_centered %*% t(w_Ec2)))
}


# ---- 4. COMPUTE FOURTH-ORDER MOMENTS ----

compute_moments <- function(fs) {
  fs <- scale(fs)
  n <- nrow(fs)
  if (n < 20) return(NULL)

  # Diagonal: E[X^4] — average across both pair members
  G4 <- (mean(fs[,"Ac1"]^4) + mean(fs[,"Ac2"]^4)) / 2
  C4 <- (mean(fs[,"Cc1"]^4) + mean(fs[,"Cc2"]^4)) / 2
  E4 <- (mean(fs[,"Ec1"]^4) + mean(fs[,"Ec2"]^4)) / 2

  # Cross-moments: E[X^2 Y^2] — average across pair members
  AC <- (mean(fs[,"Ac1"]^2 * fs[,"Cc1"]^2) + mean(fs[,"Ac2"]^2 * fs[,"Cc2"]^2)) / 2
  EA <- (mean(fs[,"Ec1"]^2 * fs[,"Ac1"]^2) + mean(fs[,"Ec2"]^2 * fs[,"Ac2"]^2)) / 2
  EC <- (mean(fs[,"Ec1"]^2 * fs[,"Cc1"]^2) + mean(fs[,"Ec2"]^2 * fs[,"Cc2"]^2)) / 2

  c(E_A4 = G4, E_C4 = C4, E_E4 = E4,
    E_A2C2 = AC, E_E2A2 = EA, E_E2C2 = EC, n = n)
}


# ---- 5. MAIN ANALYSIS ----

results <- list()

for (g in c("MZ", "DZ", "FS", "HS")) {
  R_val <- R_map[g]
  idx <- pair$kin_group == g

  y1 <- mat1[idx, , drop = FALSE]
  y2 <- mat2[idx, , drop = FALSE]

  # Complete cases only
  comp <- rowSums(is.na(y1)) == 0 & rowSums(is.na(y2)) == 0
  y1c <- y1[comp, , drop = FALSE]
  y2c <- y2[comp, , drop = FALSE]

  cat(sprintf("%s (R=%.2f): %d complete pairs\n", g, R_val, nrow(y1c)))

  if (nrow(y1c) < 20) {
    cat("  SKIPPED: insufficient complete pairs\n")
    next
  }

  fs <- extract_factor_scores(y1c, y2c, R_val)

  # Factor score diagnostics
  cor_ac_cc <- cor(fs[,"Ac1"], fs[,"Cc1"])
  cor_ac_ec <- cor(fs[,"Ac1"], fs[,"Ec1"])
  cor_cc_ec <- cor(fs[,"Cc1"], fs[,"Ec1"])
  cat(sprintf("  Factor score correlations: Ac-Cc=%.3f, Ac-Ec=%.3f, Cc-Ec=%.3f\n",
              cor_ac_cc, cor_ac_ec, cor_cc_ec))

  m <- compute_moments(fs)
  results[[g]] <- m

  if (!is.null(m)) {
    cat(sprintf("  E[A^4]=%.3f  E[C^4]=%.3f  E[E^4]=%.3f\n",
                m["E_A4"], m["E_C4"], m["E_E4"]))
    cat(sprintf("  E[A^2C^2]=%.3f  E[E^2A^2]=%.3f  E[E^2C^2]=%.3f\n",
                m["E_A2C2"], m["E_E2A2"], m["E_E2C2"]))
  }
  cat("\n")
}


# ---- 6. SUMMARY TABLES ----
cat("--- RESULTS: Molenaar et al. (1993) Fourth-Order Moment Test Applied to IP Model Common Factor Scores (12 Subtests) ---
")

cat("Table: Fourth-Order Moments of Common A, C, E Factor Scores\n")
cat("  Benchmarks: E[X^4] = 3 (pure factor), 9 (fully interactive)\n")
cat("              E[X^2Y^2] = 1 (independent), 3 (fully interactive)\n\n")

cat(sprintf("%-4s  %5s | %7s %7s %7s | %7s %7s %7s\n",
            "Kin", "N", "E[A^4]", "E[C^4]", "E[E^4]",
            "A^2C^2", "E^2A^2", "E^2C^2"))
cat(strrep("-", 68), "\n")
for (g in c("MZ", "DZ", "FS", "HS")) {
  m <- results[[g]]
  if (is.null(m)) next
  cat(sprintf("%-4s  %5.0f | %7.3f %7.3f %7.3f | %7.3f %7.3f %7.3f\n",
              g, m["n"], m["E_A4"], m["E_C4"], m["E_E4"],
              m["E_A2C2"], m["E_E2A2"], m["E_E2C2"]))
}

# Interactivity percentages
cat("\n\nTable: Interactivity Percentages\n")
cat("  0% = pure/independent factor; 100% = fully interactive\n\n")

cat(sprintf("%-4s  %5s | %6s %6s %6s | %6s %6s %6s\n",
            "Kin", "N", "A%", "C%", "E%", "AxC%", "ExA%", "ExC%"))
cat(strrep("-", 62), "\n")
for (g in c("MZ", "DZ", "FS", "HS")) {
  m <- results[[g]]
  if (is.null(m)) next
  int_A <- (m["E_A4"] - 3) / 6 * 100
  int_C <- (m["E_C4"] - 3) / 6 * 100
  int_E <- (m["E_E4"] - 3) / 6 * 100
  int_AC <- (m["E_A2C2"] - 1) / 2 * 100
  int_EA <- (m["E_E2A2"] - 1) / 2 * 100
  int_EC <- (m["E_E2C2"] - 1) / 2 * 100
  cat(sprintf("%-4s  %5.0f | %5.1f%% %5.1f%% %5.1f%% | %5.1f%% %5.1f%% %5.1f%%\n",
              g, m["n"], int_A, int_C, int_E, int_AC, int_EA, int_EC))
}


# ── Statistical significance (FS and HS have adequate N) ────────────
cat("\n\nStatistical Significance (z-test vs. pure-factor benchmark):\n\n")

for (g in c("FS", "HS")) {
  m <- results[[g]]
  if (is.null(m)) next
  n <- m["n"]
  se_k <- sqrt(24 / n)  # SE for excess kurtosis
  se_c <- sqrt(2 / n)   # SE for cross-moment

  sig <- function(z) {
    ifelse(abs(z) > 3.291, "***",
           ifelse(abs(z) > 2.576, "**",
                  ifelse(abs(z) > 1.960, "*", "ns")))
  }

  z_A  <- (m["E_A4"]   - 3) / se_k
  z_C  <- (m["E_C4"]   - 3) / se_k
  z_E  <- (m["E_E4"]   - 3) / se_k
  z_AC <- (m["E_A2C2"] - 1) / se_c
  z_EA <- (m["E_E2A2"] - 1) / se_c
  z_EC <- (m["E_E2C2"] - 1) / se_c

  cat(sprintf("  %s (N = %d):\n", g, as.integer(n)))
  cat(sprintf("    E[A^4]:   z = %6.2f %s\n", z_A, sig(z_A)))
  cat(sprintf("    E[C^4]:   z = %6.2f %s\n", z_C, sig(z_C)))
  cat(sprintf("    E[E^4]:   z = %6.2f %s\n", z_E, sig(z_E)))
  cat(sprintf("    E[A^2C^2]: z = %6.2f %s\n", z_AC, sig(z_AC)))
  cat(sprintf("    E[E^2A^2]: z = %6.2f %s  (G x E)\n", z_EA, sig(z_EA)))
  cat(sprintf("    E[E^2C^2]: z = %6.2f %s\n", z_EC, sig(z_EC)))
  cat("\n")
}


# ── Weighted average across informative groups ──────────────────────
cat("Weighted-Average Interactivity (DZ + FS + HS):\n\n")

groups_inf <- c("DZ", "FS", "HS")
ns <- setNames(numeric(3), groups_inf)
for (g in groups_inf) {
  m <- results[[g]]
  ns[g] <- if (is.null(m)) 0 else unname(m["n"])
}
total_n <- sum(ns)

nms <- c("E_A4", "E_C4", "E_E4", "E_A2C2", "E_E2A2", "E_E2C2")
labels <- c("E[A^4]", "E[C^4]", "E[E^4]", "E[A^2C^2]", "E[E^2A^2]", "E[E^2C^2]")
benchmarks <- c(3, 3, 3, 1, 1, 1)
ranges <- c(6, 6, 6, 2, 2, 2)
descriptions <- c("Genetic factor kurtosis",
                   "Shared-env factor kurtosis",
                   "Unique-env factor kurtosis",
                   "A x C cross-moment",
                   "E x A cross-moment (G x E)",
                   "E x C cross-moment")

for (i in seq_along(nms)) {
  w_avg <- 0
  for (g in groups_inf) {
    m <- results[[g]]
    if (!is.null(m) && ns[g] > 0) {
      w_avg <- w_avg + ns[g] / total_n * unname(m[nms[i]])
    }
  }
  pct <- (w_avg - benchmarks[i]) / ranges[i] * 100
  cat(sprintf("  %-10s = %5.3f  (%5.1f%% interactive)  — %s\n",
              labels[i], w_avg, pct, descriptions[i]))
}


# ---- 7. SIMULATION-CALIBRATED INTERACTIVITY ----
#
# Regression factor scores from an orthogonal model are not themselves
# orthogonal. Under the null (normal, non-interactive) model, cross-moments
# exceed 1.0 due to factor score correlations, and kurtosis may differ
# from 3.0 due to regression shrinkage. We simulate from the fitted
# normal model to establish proper null baselines, then measure departures
# relative to those baselines.

cat("\n\n")
cat("--- SIMULATION-CALIBRATED INTERACTIVITY ---
")
cat(strrep("-", 70), "\n")
cat("Null baselines from 50,000 simulated pairs per group (normal model).\n")
cat("Adjusted % = (observed - null) / (interactive - null) * 100\n\n")

set.seed(42)
N_sim <- 50000
sim_baselines <- list()

for (g in c("MZ", "DZ", "FS", "HS")) {
  R_val <- R_map[g]
  B <- R_val * A + C
  Sigma_pair <- rbind(cbind(V, B), cbind(B, V))

  L <- chol(Sigma_pair)
  z <- matrix(rnorm(N_sim * 2 * nv), N_sim, 2 * nv)
  y_sim <- z %*% L

  Sigma_inv <- solve(Sigma_pair)
  zero_v <- rep(0, nv)
  w_Ac1 <- t(c(ac, R_val * ac)) %*% Sigma_inv
  w_Cc1 <- t(c(cc, cc)) %*% Sigma_inv
  w_Ec1 <- t(c(ec, zero_v)) %*% Sigma_inv
  w_Ac2 <- t(c(R_val * ac, ac)) %*% Sigma_inv
  w_Cc2 <- t(c(cc, cc)) %*% Sigma_inv
  w_Ec2 <- t(c(zero_v, ec)) %*% Sigma_inv

  fs_sim <- scale(cbind(
    Ac1 = as.vector(y_sim %*% t(w_Ac1)),
    Cc1 = as.vector(y_sim %*% t(w_Cc1)),
    Ec1 = as.vector(y_sim %*% t(w_Ec1)),
    Ac2 = as.vector(y_sim %*% t(w_Ac2)),
    Cc2 = as.vector(y_sim %*% t(w_Cc2)),
    Ec2 = as.vector(y_sim %*% t(w_Ec2))
  ))

  sim_baselines[[g]] <- c(
    E_A4   = (mean(fs_sim[,"Ac1"]^4) + mean(fs_sim[,"Ac2"]^4)) / 2,
    E_C4   = (mean(fs_sim[,"Cc1"]^4) + mean(fs_sim[,"Cc2"]^4)) / 2,
    E_E4   = (mean(fs_sim[,"Ec1"]^4) + mean(fs_sim[,"Ec2"]^4)) / 2,
    E_A2C2 = (mean(fs_sim[,"Ac1"]^2 * fs_sim[,"Cc1"]^2) + mean(fs_sim[,"Ac2"]^2 * fs_sim[,"Cc2"]^2)) / 2,
    E_E2A2 = (mean(fs_sim[,"Ec1"]^2 * fs_sim[,"Ac1"]^2) + mean(fs_sim[,"Ec2"]^2 * fs_sim[,"Ac2"]^2)) / 2,
    E_E2C2 = (mean(fs_sim[,"Ec1"]^2 * fs_sim[,"Cc1"]^2) + mean(fs_sim[,"Ec2"]^2 * fs_sim[,"Cc2"]^2)) / 2
  )
}

# Print calibrated table
nms <- c("E_A4", "E_C4", "E_E4", "E_A2C2", "E_E2A2", "E_E2C2")
max_vals <- c(9, 9, 9, 3, 3, 3)
mom_labels <- c("E[A^4]", "E[C^4]", "E[E^4]", "A^2C^2", "E^2A^2 (GxE)", "E^2C^2")

for (g in c("FS", "HS")) {
  m <- results[[g]]
  s <- sim_baselines[[g]]
  if (is.null(m)) next

  cat(sprintf("  %s (N = %d):\n", g, as.integer(m["n"])))
  cat(sprintf("    %-14s  %8s  %8s  %8s\n", "Moment", "Null", "Observed", "Adj. %"))
  cat(sprintf("    %s\n", strrep("-", 46)))
  for (i in seq_along(nms)) {
    null_val <- s[nms[i]]
    obs_val <- m[nms[i]]
    adj_pct <- (obs_val - null_val) / (max_vals[i] - null_val) * 100
    cat(sprintf("    %-14s  %8.3f  %8.3f  %7.1f%%\n",
                mom_labels[i], null_val, obs_val, adj_pct))
  }
  cat("\n")
}

# Ranking with calibrated values (FS group)
cat("Ranking (FS group, simulation-calibrated):\n")
m <- results[["FS"]]
s <- sim_baselines[["FS"]]
if (!is.null(m)) {
  diag_nms <- c("E_A4", "E_C4", "E_E4")
  diag_labs <- c("A (genetic)", "C (shared env)", "E (unique env)")
  diag_adj <- sapply(diag_nms, function(nm) (m[nm] - s[nm]) / (9 - s[nm]) * 100)
  diag_ord <- order(diag_adj, decreasing = TRUE)
  cat("  Diagonal (kurtosis):\n")
  for (j in diag_ord) {
    cat(sprintf("    %s: %.1f%%\n", diag_labs[j], diag_adj[j]))
  }

  cross_nms <- c("E_A2C2", "E_E2A2", "E_E2C2")
  cross_labs <- c("A x C", "E x A (G x E)", "E x C")
  cross_adj <- sapply(cross_nms, function(nm) (m[nm] - s[nm]) / (3 - s[nm]) * 100)
  cross_ord <- order(cross_adj, decreasing = TRUE)
  cat("  Cross-moments:\n")
  for (j in cross_ord) {
    cat(sprintf("    %s: %.1f%%\n", cross_labs[j], cross_adj[j]))
  }
}


# ---- 8. INTERPRETATION AND LIMITATIONS ----
cat("--- INTERPRETATION ---\n")
cat(strrep("-", 70), "\n\n")

cat("After calibrating against the simulated null (normal model with\n")
cat("factor score regression artifacts removed), the key findings are:\n\n")

cat("  - Diagonal kurtosis: The genetic factor (A) is the most 'pure' at\n")
cat("    ~10% calibrated interactivity in the FS group. The shared-\n")
cat("    environment factor (C) shows the largest departure at ~16%,\n")
cat("    with unique-environment (E) at ~13%. These are modest departures\n")
cat("    consistent with mild non-normality in the observed cognitive data.\n\n")

cat("  - Cross-moments: After calibration, the canonical G x E interaction\n")
cat("    (E^2 A^2) shows only ~3% interactivity in the FS group, making\n")
cat("    it the weakest of the three cross-moment signals. The strongest\n")
cat("    is E x C at ~10%. Much of the raw cross-moment departure (before\n")
cat("    calibration) is attributable to inherent correlations among\n")
cat("    regression factor scores rather than genuine interactions.\n\n")

cat("  - AM robustness: A supplementary analysis (supplement_molenaar_am.R)\n")
cat("    re-fits the IP model under four levels of assortative mating\n")
cat("    (spousal correlation mu = 0, 0.20, 0.35, 0.55; h2 = 0.71),\n")
cat("    which adjust the sibling genetic correlations upward\n")
cat("    (R_DZ = R_FS from 0.50 to 0.70; R_HS from 0.25 to 0.35).\n")
cat("    Results are robust: calibrated G x E interactivity remains\n")
cat("    at 1-4% across all AM levels. The genetic factor becomes\n")
cat("    progressively more pure (10% -> 4%) as AM increases, because\n")
cat("    higher sibling A-correlations provide more information to\n")
cat("    separate A from C/E. The environmental factors show stable\n")
cat("    departures (~16-18% for C, ~13-17% for E).\n\n")

cat("  - These results provide no evidence for substantial gene-environment\n")
cat("    interaction at the common factor level. The ACE factors are\n")
cat("    approximately 'pure' (additive, non-interactive), and this\n")
cat("    conclusion holds across a wide range of AM assumptions.\n\n")

cat(strrep("-", 70), "\n")
cat("LIMITATIONS\n")
cat(strrep("-", 70), "\n\n")

cat("1. Factor score indeterminacy: Regression factor scores are estimates,\n")
cat("   not the true latent factors. Regression shrinkage attenuates\n")
cat("   kurtosis toward normality, biasing against detecting interactions.\n")
cat("   The simulation calibration partially addresses this by establishing\n")
cat("   the expected kurtosis of factor scores under the null, but it\n")
cat("   cannot recover true factor-level moments.\n\n")

cat("2. Complete-case analysis: Only pairs with all 12 subtests observed\n")
cat("   for both members are used (47% of pairs). If missingness is\n")
cat("   related to cognitive ability, this may bias the sample.\n\n")

cat("3. Single common factor per component: The IP model posits one\n")
cat("   common A, C, E factor each. If the true genetic architecture\n")
cat("   involves multiple genetic factors (e.g., verbal vs. performance),\n")
cat("   the single-factor score is a weighted composite that may mask\n")
cat("   factor-specific interactions.\n\n")

cat("4. Model dependence: Factor scores are conditional on the IP model\n")
cat("   being correctly specified. Misspecification of the IP structure\n")
cat("   propagates into factor scores and their higher-order moments.\n")

# Save results
saveRDS(list(moments = results,
             sim_baselines = sim_baselines,
             ip_params = list(ac = ac, cc = cc, ec = ec,
                              as_mat = as_mat, cs_mat = cs_mat, es_mat = es_mat,
                              Mu = Mu, A = A, C = C, E = E, V = V)),
        "results_molenaar_gxe.rds")
cat("\nResults saved to results_molenaar_gxe.rds\n")
cat("Done.\n")
