#!/usr/bin/env Rscript
# 14_replication_willerman.R
# Replication: Willerman, Naylor, & Myrianthopoulos (1970)
# "Intellectual development of children from interracial matings" (Science)
#
# Original finding: Among 129 children of Black-White interracial matings in
# CPP, children with White mothers scored ~9 IQ points higher at age 4 than
# children with Black mothers (regardless of child's assigned race).
#
# Extension: We also test at age 7 (WISC FSIQ) and add SES controls.

library(data.table)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")
ses <- fread(file.path("..", "clean", "cpp_ses_detailed.csv"),
             colClasses = c(case_id = "character", mother_id = "character"))

cat("\n")
cat("--- REPLICATION: Willerman, Naylor, & Myrianthopoulos (1970) Intellectual Development of Children from Interracial Matings ---
")

# ── Merge father's race ───────────────────────────────────────────────
d <- merge(d, ses[, .(case_id, father_race, father_age, father_education)],
           by = "case_id", all.x = TRUE)

# Race codes: 1 = White, 2 = Black (check actual coding)
cat("\nMother race distribution:\n")
print(d[, .N, by = race][order(race)])
cat("\nFather race distribution:\n")
print(d[!is.na(father_race), .N, by = father_race][order(father_race)])

# ── Identify interracial Black x White matings ─────────────────────────
# Convention: race = 1 (White), race = 2 (Black)
d[, interracial := FALSE]
d[race == 1 & father_race == 2, interracial := TRUE]  # White mother, Black father
d[race == 2 & father_race == 1, interracial := TRUE]  # Black mother, White father

d[, mating_type := fcase(
  race == 1 & father_race == 2, "White_M x Black_F",
  race == 2 & father_race == 1, "Black_M x White_F",
  default = NA_character_
)]

ir <- d[interracial == TRUE]
cat(sprintf("\nInterracial Black x White matings: %d children\n", nrow(ir)))
cat(sprintf("  White mother, Black father: %d\n", ir[mating_type == "White_M x Black_F", .N]))
cat(sprintf("  Black mother, White father: %d\n", ir[mating_type == "Black_M x White_F", .N]))
cat(sprintf("  Willerman original: 129 children\n"))

# PART A: CLOSE REPLICATION — Stanford-Binet IQ at Age 4
# Willerman et al. used SB IQ only, N = 129 interracial children.
cat("\n")
cat("--- PART A: CLOSE REPLICATION — Stanford-Binet IQ at Age 4 (Willerman et al. 1970, Science 168:1329-1331) ---
")

sb_tab <- ir[!is.na(sb_iq), .(
  mean_sb = mean(sb_iq),
  sd_sb = sd(sb_iq),
  n = .N
), by = mating_type]

cat("\n")
cat(sprintf("  %-25s  %8s  %8s  %5s\n", "Mating Type", "Mean SB", "SD", "N"))
cat("  ", strrep("-", 50), "\n")
for (i in 1:nrow(sb_tab)) {
  cat(sprintf("  %-25s  %8.1f  %8.1f  %5d\n",
              sb_tab[i, mating_type], sb_tab[i, mean_sb],
              sb_tab[i, sd_sb], sb_tab[i, n]))
}

if (nrow(sb_tab) == 2) {
  gap <- sb_tab[mating_type == "White_M x Black_F", mean_sb] -
         sb_tab[mating_type == "Black_M x White_F", mean_sb]
  cat(sprintf("\n  White-mother advantage: %.1f points\n", gap))
  cat("  Willerman original: ~9 points\n")

  # t-test
  tt <- t.test(sb_iq ~ mating_type, data = ir[!is.na(sb_iq)])
  cat(sprintf("  t-test: t = %.2f, p = %.4f\n", tt$statistic, tt$p.value))
}

# PART B: EXTENSION — WISC FSIQ at Age 7 + SES Controls
# Not in original (Willerman used SB only). Extends to age 7.
cat("\n")
cat("--- PART B: EXTENSION — WISC FSIQ at Age 7 (Not in original — extends to age 7 measure) ---
")

wisc_tab <- ir[!is.na(wisc_fsiq), .(
  mean_iq = mean(wisc_fsiq),
  sd_iq = sd(wisc_fsiq),
  n = .N
), by = mating_type]

cat("\n")
cat(sprintf("  %-25s  %8s  %8s  %5s\n", "Mating Type", "Mean IQ", "SD", "N"))
cat("  ", strrep("-", 50), "\n")
for (i in 1:nrow(wisc_tab)) {
  cat(sprintf("  %-25s  %8.1f  %8.1f  %5d\n",
              wisc_tab[i, mating_type], wisc_tab[i, mean_iq],
              wisc_tab[i, sd_iq], wisc_tab[i, n]))
}

if (nrow(wisc_tab) == 2) {
  gap <- wisc_tab[mating_type == "White_M x Black_F", mean_iq] -
         wisc_tab[mating_type == "Black_M x White_F", mean_iq]
  cat(sprintf("\n  White-mother advantage: %.1f points\n", gap))

  tt <- t.test(wisc_fsiq ~ mating_type, data = ir[!is.na(wisc_fsiq)])
  cat(sprintf("  t-test: t = %.2f, p = %.4f\n", tt$statistic, tt$p.value))
}

# ── SES comparison between groups (Part B continued) ─────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("SES Characteristics by Mating Type\n")
cat(strrep("-", 70), "\n")

ses_tab <- ir[, .(
  mean_educ = mean(educ_yrs, na.rm = TRUE),
  mean_sei = mean(sei_decimal, na.rm = TRUE),
  mean_mat_age = mean(maternal_age, na.rm = TRUE),
  n = .N
), by = mating_type]

cat("\n")
cat(sprintf("  %-25s  %8s  %8s  %8s  %5s\n",
            "Mating Type", "Educ", "SEI", "Mat Age", "N"))
cat("  ", strrep("-", 55), "\n")
for (i in 1:nrow(ses_tab)) {
  cat(sprintf("  %-25s  %8.1f  %8.1f  %8.1f  %5d\n",
              ses_tab[i, mating_type], ses_tab[i, mean_educ],
              ses_tab[i, mean_sei], ses_tab[i, mean_mat_age], ses_tab[i, n]))
}

# ── Regression with SES controls (Part B continued) ──────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Regression: IQ ~ White Mother + Controls\n")
cat(strrep("-", 70), "\n")

ir[, white_mother := as.integer(mating_type == "White_M x Black_F")]

# SB IQ
if (ir[!is.na(sb_iq) & !is.na(educ_yrs) & !is.na(sei_decimal), .N] > 10) {
  cat("\nStanford-Binet IQ:\n")

  m1 <- lm(sb_iq ~ white_mother, data = ir)
  m2 <- lm(sb_iq ~ white_mother + educ_yrs + sei_decimal + sex + maternal_age,
            data = ir)

  cat(sprintf("  Unadjusted:  b = %6.2f (SE = %.2f, p = %.4f), N = %d\n",
              coef(m1)["white_mother"], summary(m1)$coef["white_mother", 2],
              summary(m1)$coef["white_mother", 4], nobs(m1)))
  cat(sprintf("  Adjusted:    b = %6.2f (SE = %.2f, p = %.4f), N = %d\n",
              coef(m2)["white_mother"], summary(m2)$coef["white_mother", 2],
              summary(m2)$coef["white_mother", 4], nobs(m2)))
}

# WISC FSIQ
if (ir[!is.na(wisc_fsiq) & !is.na(educ_yrs) & !is.na(sei_decimal), .N] > 10) {
  cat("\nWISC FSIQ:\n")

  m3 <- lm(wisc_fsiq ~ white_mother, data = ir)
  m4 <- lm(wisc_fsiq ~ white_mother + educ_yrs + sei_decimal + sex + maternal_age,
            data = ir)

  cat(sprintf("  Unadjusted:  b = %6.2f (SE = %.2f, p = %.4f), N = %d\n",
              coef(m3)["white_mother"], summary(m3)$coef["white_mother", 2],
              summary(m3)$coef["white_mother", 4], nobs(m3)))
  cat(sprintf("  Adjusted:    b = %6.2f (SE = %.2f, p = %.4f), N = %d\n",
              coef(m4)["white_mother"], summary(m4)$coef["white_mother", 2],
              summary(m4)$coef["white_mother", 4], nobs(m4)))
}

# ── Comparison with mono-racial matings ───────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Context: Mean IQ by Race (All Matings)\n")
cat(strrep("-", 70), "\n")

context <- d[!is.na(wisc_fsiq), .(
  mean_iq = mean(wisc_fsiq),
  sd_iq = sd(wisc_fsiq),
  n = .N
), by = race]

cat("\n")
cat(sprintf("  %-6s  %8s  %8s  %8s\n", "Race", "Mean IQ", "SD", "N"))
cat("  ", strrep("-", 35), "\n")
for (i in 1:nrow(context)) {
  cat(sprintf("  %-6s  %8.1f  %8.1f  %8d\n",
              context[i, race], context[i, mean_iq],
              context[i, sd_iq], context[i, n]))
}

# ── Save ──────────────────────────────────────────────────────────────
results <- list(
  sb_table = sb_tab,
  wisc_table = wisc_tab,
  ses_table = ses_tab,
  interracial_data = ir
)
saveRDS(results, "results_replication_willerman.rds")
cat("\nResults saved to results_replication_willerman.rds\n")
