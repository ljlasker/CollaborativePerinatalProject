#!/usr/bin/env Rscript
# diag_spearman_bifactor.R — Spearman's Hypothesis via Bifactor and HO models
# Uses lavaan (WLSMV for ordinal, MLR for continuous).
# Hierarchical partial MI search at every level where needed.

library(data.table)
library(lavaan)

d <- readRDS("prepared_data.rds")
d <- as.data.table(d)

# Clean sentinel values
for (v in c("wisc_picarr", "wisc_block", "wisc_coding"))
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "Digit", "PicArr",
                "Block", "Coding", "WRAT Read", "Bender",
                "WRAT Spell", "WRAT Arith", "Goodenough")
nv <- length(sub_vars)
v_idx <- c(1, 2, 3, 4, 8, 10, 11)
p_idx <- c(5, 6, 7, 9, 12)

ord_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding")

# Prepare data
d[, race_grp := factor(race, levels = c(1, 2), labels = c("White", "Black"))]
dat <- as.data.frame(d[!is.na(race_grp), c(..sub_vars, "mother_id", "race_grp")])
dat <- dat[complete.cases(dat[, sub_vars]), ]

cat(sprintf("N = %d (White = %d, Black = %d) [complete cases]\n",
            nrow(dat), sum(dat$race_grp == "White"), sum(dat$race_grp == "Black")))
cat(sprintf("Unique mothers = %d\n\n", length(unique(dat$mother_id))))

# Collapse empty categories for ordered variables
cat("Checking for empty categories in ordered variables...\n")
for (v in ord_vars) {
  repeat {
    changed <- FALSE
    vals <- sort(unique(dat[[v]][!is.na(dat[[v]])]))
    for (val in vals) {
      nw <- sum(dat[[v]][dat$race_grp == "White"] == val, na.rm = TRUE)
      nb <- sum(dat[[v]][dat$race_grp == "Black"] == val, na.rm = TRUE)
      if (nw == 0 || nb == 0) {
        others <- vals[vals != val]
        if (length(others) == 0) break
        nearest <- others[which.min(abs(others - val))]
        cat(sprintf("  %s: collapsing %.0f -> %.0f (W=%d, B=%d)\n",
                    v, val, nearest, nw, nb))
        dat[[v]][dat[[v]] == val & !is.na(dat[[v]])] <- nearest
        changed <- TRUE
        break
      }
    }
    if (!changed) break
  }
}

# Pooled SDs and gaps for MCV
pool_sds <- c(); gaps_d <- c()
for (i in 1:nv) {
  xw <- dat[[sub_vars[i]]][dat$race_grp == "White"]
  xb <- dat[[sub_vars[i]]][dat$race_grp == "Black"]
  sdp <- sqrt((var(xw, na.rm = T) * (sum(!is.na(xw)) - 1) +
               var(xb, na.rm = T) * (sum(!is.na(xb)) - 1)) /
              (sum(!is.na(xw)) + sum(!is.na(xb)) - 2))
  gap <- (mean(xw, na.rm = T) - mean(xb, na.rm = T)) / sdp
  pool_sds <- c(pool_sds, sdp)
  gaps_d <- c(gaps_d, gap)
}

# ---- Utility Functions ----

fit_wlsmv <- function(model, group_eq = NULL, gp = NULL, label = "") {
  cat(sprintf("Fitting %s (WLSMV)...\n", label))
  t0 <- Sys.time()
  fit <- tryCatch(
    suppressWarnings(
      cfa(model, data = dat, group = "race_grp", estimator = "WLSMV",
          ordered = ord_vars, group.equal = group_eq, group.partial = gp)
    ),
    error = function(e) { cat(sprintf("  ERROR: %s\n", e$message)); NULL }
  )
  dt <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  if (!is.null(fit)) {
    conv <- lavInspect(fit, "converged")
    cat(sprintf("  Converged: %s (%.1f sec)\n", conv, dt))
  }
  fit
}

fit_mlr <- function(model, group_eq = NULL, gp = NULL, label = "") {
  cat(sprintf("Fitting %s (MLR)...\n", label))
  t0 <- Sys.time()
  fit <- tryCatch(
    suppressWarnings(
      cfa(model, data = dat, group = "race_grp", estimator = "MLR",
          group.equal = group_eq, group.partial = gp)
    ),
    error = function(e) { cat(sprintf("  ERROR: %s\n", e$message)); NULL }
  )
  dt <- as.numeric(difftime(Sys.time(), t0, units = "secs"))
  if (!is.null(fit)) {
    conv <- lavInspect(fit, "converged")
    cat(sprintf("  Converged: %s (%.1f sec)\n", conv, dt))
  }
  fit
}

get_cfi <- function(fit, prefer = "scaled") {
  if (is.null(fit)) return(NA)
  if (prefer == "scaled") {
    cfi <- tryCatch(fitMeasures(fit, "cfi.scaled"), error = function(e) NA)
    if (is.na(cfi)) cfi <- tryCatch(fitMeasures(fit, "cfi.robust"), error = function(e) NA)
    if (is.na(cfi)) cfi <- tryCatch(fitMeasures(fit, "cfi"), error = function(e) NA)
  } else if (prefer == "robust") {
    cfi <- tryCatch(fitMeasures(fit, "cfi.robust"), error = function(e) NA)
    if (is.na(cfi)) cfi <- tryCatch(fitMeasures(fit, "cfi.scaled"), error = function(e) NA)
    if (is.na(cfi)) cfi <- tryCatch(fitMeasures(fit, "cfi"), error = function(e) NA)
  } else {
    cfi <- tryCatch(fitMeasures(fit, "cfi"), error = function(e) NA)
  }
  cfi
}

safe_lrt <- function(fit0, fit1, label) {
  dcfi <- NA
  cfi0 <- get_cfi(fit0); cfi1 <- get_cfi(fit1)
  if (!is.na(cfi0) && !is.na(cfi1)) dcfi <- cfi0 - cfi1
  lrt <- tryCatch(lavTestLRT(fit0, fit1), error = function(e) NULL)
  if (is.null(lrt)) {
    cat(sprintf("%-40s  %8s  %5s  %12s  %8s\n", label, "ERROR", "", "", ""))
    return(invisible(NULL))
  }
  dchi <- lrt[["Chisq diff"]][2]
  ddf  <- lrt[["Df diff"]][2]
  pval <- lrt[["Pr(>Chisq)"]][2]
  pstr <- if (is.na(pval)) "NA" else if (pval < 2e-16) "< 2e-16" else sprintf("%.2e", pval)
  cat(sprintf("%-40s  %8.1f  %5.0f  %12s  %8.5f\n", label, dchi, ddf, pstr, dcfi))
  invisible(data.frame(label = label, dchi2 = dchi, ddf = ddf, p = pval, dcfi = dcfi))
}

safe_means <- function(fit, label) {
  if (is.null(fit)) return()
  lm <- tryCatch(lavInspect(fit, "mean.lv"), error = function(e) NULL)
  if (is.null(lm)) return()
  vals <- lm$Black
  parts <- c()
  for (nm in names(vals)) parts <- c(parts, sprintf("%s = %.3f", nm, vals[nm]))
  cat(sprintf("  %s: %s\n", label, paste(parts, collapse = ", ")))
}

# Build group.partial strings for freed parameters
build_gp <- function(freed_loadings, freed_scalar, freed_strict,
                     loading_params, ord_vars) {
  gp <- character(0)
  # Freed loadings: variable-name -> list of "factor =~ variable" strings
  for (v in freed_loadings) {
    if (v %in% names(loading_params)) gp <- c(gp, loading_params[[v]])
  }
  # Freed thresholds/intercepts
  for (v in freed_scalar) {
    if (v %in% ord_vars) gp <- c(gp, paste0(v, "|t", 1:25))
    else gp <- c(gp, paste0(v, " ~ 1"))
  }
  # Freed residuals
  for (v in freed_strict) {
    gp <- c(gp, paste0(v, " ~~ ", v))
  }
  gp
}

# General partial MI search at one level
# search_what: "loadings", "scalar" (thresholds+intercepts), or "residuals"
# estimator: "WLSMV" or "MLR"
# cfi_prefer: passed to get_cfi for consistent CFI type
partial_search <- function(model_syntax, baseline_fit, group_equal,
                           existing_gp, search_what, candidates,
                           loading_params, ord_vars, threshold = 0.010,
                           estimator = "WLSMV", cfi_prefer = "scaled") {

  cfi_baseline <- get_cfi(baseline_fit, prefer = cfi_prefer)
  freed <- character(0)
  current_fit <- NULL
  log_df <- data.frame()

  # First try the full constraint
  if (estimator == "WLSMV") {
    full_fit <- tryCatch(suppressWarnings(
      cfa(model_syntax, data = dat, group = "race_grp", estimator = "WLSMV",
          ordered = ord_vars, group.equal = group_equal, group.partial = existing_gp)
    ), error = function(e) NULL)
  } else {
    full_fit <- tryCatch(suppressWarnings(
      cfa(model_syntax, data = dat, group = "race_grp", estimator = estimator,
          group.equal = group_equal, group.partial = existing_gp)
    ), error = function(e) NULL)
  }

  if (is.null(full_fit) || !lavInspect(full_fit, "converged")) {
    cat("  Full model did not converge.\n")
    return(list(fit = baseline_fit, freed = character(0), log = log_df, gp = existing_gp))
  }

  cfi_full <- get_cfi(full_fit, prefer = cfi_prefer)
  dcfi_full <- if (!is.na(cfi_baseline) && !is.na(cfi_full)) cfi_baseline - cfi_full else NA
  cat(sprintf("  Baseline CFI = %s, Full %s CFI = %s, ΔCFI = %s\n",
              ifelse(is.na(cfi_baseline), "NA", sprintf("%.4f", cfi_baseline)),
              search_what,
              ifelse(is.na(cfi_full), "NA", sprintf("%.4f", cfi_full)),
              ifelse(is.na(dcfi_full), "NA", sprintf("%.4f", dcfi_full))))

  if (is.na(dcfi_full)) {
    cat("  WARNING: Cannot compute ΔCFI (baseline or full CFI is NA). Returning full model.\n")
    return(list(fit = full_fit, freed = character(0), log = log_df, gp = existing_gp))
  }

  if (dcfi_full <= threshold) {
    cat(sprintf("  Full %s holds (ΔCFI ≤ %.3f). No partial search needed.\n",
                search_what, threshold))
    return(list(fit = full_fit, freed = character(0), log = log_df, gp = existing_gp))
  }

  cat(sprintf("  Full %s fails. Beginning partial search...\n\n", search_what))
  current_fit <- full_fit

  for (iter in 1:length(candidates)) {
    cfi_current <- get_cfi(current_fit, prefer = cfi_prefer)
    dcfi_now <- cfi_baseline - cfi_current
    if (dcfi_now <= threshold) {
      cat(sprintf("\n  Partial %s achieved (ΔCFI = %.4f) after freeing %d variables.\n",
                  search_what, dcfi_now, length(freed)))
      break
    }

    remaining <- setdiff(candidates, freed)
    if (length(remaining) == 0) break

    best_cfi <- -Inf; best_var <- NULL; best_fit <- NULL
    cat(sprintf("  Step %d: Testing %d candidates for %s...\n",
                iter, length(remaining), search_what))

    for (v in remaining) {
      # Build group.partial for this candidate
      test_freed <- c(freed, v)
      gp_test <- existing_gp

      if (search_what == "loadings") {
        for (fv in test_freed) {
          if (fv %in% names(loading_params)) gp_test <- c(gp_test, loading_params[[fv]])
        }
      } else if (search_what == "scalar") {
        for (fv in test_freed) {
          if (estimator == "WLSMV" && fv %in% ord_vars) {
            gp_test <- c(gp_test, paste0(fv, "|t", 1:25))
          } else {
            gp_test <- c(gp_test, paste0(fv, " ~ 1"))
          }
        }
      } else if (search_what == "residuals") {
        for (fv in test_freed) gp_test <- c(gp_test, paste0(fv, " ~~ ", fv))
      }

      if (estimator == "WLSMV") {
        test_fit <- tryCatch(suppressWarnings(
          cfa(model_syntax, data = dat, group = "race_grp", estimator = "WLSMV",
              ordered = ord_vars, group.equal = group_equal, group.partial = gp_test)
        ), error = function(e) NULL)
      } else {
        test_fit <- tryCatch(suppressWarnings(
          cfa(model_syntax, data = dat, group = "race_grp", estimator = estimator,
              group.equal = group_equal, group.partial = gp_test)
        ), error = function(e) NULL)
      }

      if (!is.null(test_fit) && lavInspect(test_fit, "converged")) {
        cfi_test <- get_cfi(test_fit, prefer = cfi_prefer)
        if (cfi_test > best_cfi) {
          best_cfi <- cfi_test; best_var <- v; best_fit <- test_fit
        }
      }
    }

    if (is.null(best_var)) { cat("  No improvement. Stopping.\n"); break }

    freed <- c(freed, best_var)
    current_fit <- best_fit
    dcfi_step <- cfi_baseline - best_cfi
    cat(sprintf("    → Freed %s: CFI = %.4f, ΔCFI from baseline = %.4f\n",
                best_var, best_cfi, dcfi_step))
    log_df <- rbind(log_df,
      data.frame(step = iter, freed = best_var, cfi = best_cfi,
                 dcfi = dcfi_step, stringsAsFactors = FALSE))
  }

  # Build final gp
  final_gp <- existing_gp
  if (search_what == "loadings") {
    for (fv in freed) {
      if (fv %in% names(loading_params)) final_gp <- c(final_gp, loading_params[[fv]])
    }
  } else if (search_what == "scalar") {
    for (fv in freed) {
      if (estimator == "WLSMV" && fv %in% ord_vars) {
        final_gp <- c(final_gp, paste0(fv, "|t", 1:25))
      } else {
        final_gp <- c(final_gp, paste0(fv, " ~ 1"))
      }
    }
  } else if (search_what == "residuals") {
    for (fv in freed) final_gp <- c(final_gp, paste0(fv, " ~~ ", fv))
  }

  cat(sprintf("  Freed for %s: {%s}\n", search_what, paste(freed, collapse = ", ")))
  list(fit = current_fit, freed = freed, log = log_df, gp = final_gp)
}


# ---- PART 1: Bifactor Model (g + V) ----

cat("--- PART 1: BIFACTOR MODEL (g + V) ---\n")

# Bifactor: g loads on all 12; V loads on verbal indicators only.
# P factor removed — collapsed under strict MI (negative variance).

bf_base <- '
  g =~ NA*wisc_info + wisc_comp + wisc_vocab + wisc_digit +
       wisc_picarr + wisc_block + wisc_coding +
       wrat_read_raw + bender_gestalt +
       wrat_spell_raw + wrat_arith_raw + goodenough_raw
  V =~ NA*wisc_info + wisc_comp + wisc_vocab + wisc_digit +
       wrat_read_raw + wrat_spell_raw + wrat_arith_raw
  g ~~ 1*g; V ~~ 1*V
  g ~~ 0*V
'

bf_means <- paste0(bf_base, '
  g ~ c(0, NA)*1; V ~ c(0, NA)*1
')
bf_gonly <- paste0(bf_base, '
  g ~ c(0, NA)*1; V ~ c(0, 0)*1
')
bf_nodiff <- paste0(bf_base, '
  g ~ c(0, 0)*1; V ~ c(0, 0)*1
')
bf_freevar <- '
  g =~ NA*wisc_info + wisc_comp + wisc_vocab + wisc_digit +
       wisc_picarr + wisc_block + wisc_coding +
       wrat_read_raw + bender_gestalt +
       wrat_spell_raw + wrat_arith_raw + goodenough_raw
  V =~ NA*wisc_info + wisc_comp + wisc_vocab + wisc_digit +
       wrat_read_raw + wrat_spell_raw + wrat_arith_raw
  g ~~ c(1, NA)*g; V ~~ c(1, NA)*V
  g ~~ 0*V
  g ~ c(0, NA)*1; V ~ c(0, NA)*1
'

# Loading parameter names for each variable (bifactor)
bf_loading_params <- list()
for (v in sub_vars) {
  params <- paste0("g =~ ", v)
  if (v %in% sub_vars[v_idx]) params <- c(params, paste0("V =~ ", v))
  bf_loading_params[[v]] <- params
}

wlsmv_metric_eq <- "loadings"
wlsmv_scalar_eq <- c("loadings", "thresholds", "intercepts")
wlsmv_strict_eq <- c("loadings", "thresholds", "intercepts", "residuals")

# ── Step 1: Configural ──
bf_m1 <- fit_wlsmv(bf_base, NULL, NULL, "BF Configural")

# ── Step 2: Metric (with partial search if needed) ──
cat("\n--- Metric invariance ---\n")
bf_metric_res <- partial_search(bf_base, bf_m1, "loadings",
                                 NULL, "loadings", sub_vars,
                                 bf_loading_params, ord_vars)
bf_m2 <- bf_metric_res$fit
bf_freed_loadings <- bf_metric_res$freed
bf_gp_metric <- bf_metric_res$gp

# ── Step 3: Scalar (with partial search if needed) ──
cat("\n--- Scalar invariance ---\n")
bf_scalar_res <- partial_search(bf_means, bf_m2, wlsmv_scalar_eq,
                                 bf_gp_metric, "scalar", sub_vars,
                                 bf_loading_params, ord_vars)
bf_m3 <- bf_scalar_res$fit
bf_freed_scalar <- bf_scalar_res$freed
bf_gp_scalar <- bf_scalar_res$gp

# ── Step 4: Strict (with partial search if needed) ──
cat("\n--- Strict invariance ---\n")
bf_strict_res <- partial_search(bf_means, bf_m3, wlsmv_strict_eq,
                                 bf_gp_scalar, "residuals", sub_vars,
                                 bf_loading_params, ord_vars)
bf_m3s <- bf_strict_res$fit
bf_freed_strict <- bf_strict_res$freed
bf_gp_strict <- bf_strict_res$gp

# ── Strict + free factor variances ──
cat("\n--- Strict + free factor variances ---\n")
bf_m3sv <- fit_wlsmv(bf_freevar, wlsmv_strict_eq, bf_gp_strict,
                      "BF Strict+FreeVar")

# ── Fit table ──
cat("\n")
cat("--- BIFACTOR FIT INDICES (partial MI where applicable) ---
")

bf_fits <- list(bf_m1, bf_m2, bf_m3, bf_m3s, bf_m3sv)
bf_labs <- c("Configural",
             paste0("Metric", if (length(bf_freed_loadings) > 0)
               paste0(" (freed: ", paste(bf_freed_loadings, collapse=","), ")") else ""),
             paste0("Scalar", if (length(bf_freed_scalar) > 0)
               paste0(" (freed: ", paste(bf_freed_scalar, collapse=","), ")") else ""),
             paste0("Strict", if (length(bf_freed_strict) > 0)
               paste0(" (freed: ", paste(bf_freed_strict, collapse=","), ")") else ""),
             "Strict+FreeVar")

cat(sprintf("%-50s  %5s  %10s  %6s  %8s  %8s\n",
            "Model", "k", "chi2.sc", "df", "CFI.sc", "RMSEA"))
cat(strrep("-", 90), "\n")

bf_tab <- data.frame(label = bf_labs, k = NA_real_, chi2 = NA_real_, df = NA_real_,
                     cfi = NA_real_, rmsea = NA_real_)

for (i in seq_along(bf_fits)) {
  if (is.null(bf_fits[[i]])) next
  fm <- tryCatch(
    fitMeasures(bf_fits[[i]], c("npar", "chisq.scaled", "df.scaled",
                                 "cfi.scaled", "rmsea.scaled")),
    error = function(e) NULL)
  if (is.null(fm)) next
  bf_tab$k[i]     <- fm["npar"]
  bf_tab$chi2[i]  <- fm["chisq.scaled"]
  bf_tab$df[i]    <- fm["df.scaled"]
  bf_tab$cfi[i]   <- fm["cfi.scaled"]
  bf_tab$rmsea[i] <- fm["rmsea.scaled"]
  cat(sprintf("%-50s  %5.0f  %10.1f  %6.0f  %8.4f  %8.5f\n",
              bf_labs[i], fm["npar"], fm["chisq.scaled"], fm["df.scaled"],
              fm["cfi.scaled"], fm["rmsea.scaled"]))
}

# ── Latent means ──
cat("\n\nBIFACTOR LATENT MEANS (Black - White, factor SD units):\n")
safe_means(bf_m3, "Scalar")
safe_means(bf_m3s, "Strict")

# ── Factor variances ──
if (!is.null(bf_m3sv)) {
  cat("\nFACTOR VARIANCES (strict + free var):\n")
  fv <- tryCatch(lavInspect(bf_m3sv, "cov.lv"), error = function(e) NULL)
  if (!is.null(fv)) {
    cat(sprintf("  White: g=%.3f, V=%.3f (fixed to 1)\n",
                fv$White["g","g"], fv$White["V","V"]))
    cat(sprintf("  Black: g=%.3f, V=%.3f (free)\n",
                fv$Black["g","g"], fv$Black["V","V"]))
  }
}

# ── Spearman hypothesis tests ──
cat("\n\nSPEARMAN HYPOTHESIS TESTS (nested within scalar):\n")
cat(sprintf("%-40s  %8s  %5s  %12s  %8s\n", "Comparison", "dChi2", "ddf", "p", "dCFI"))
cat(strrep("-", 85), "\n")

bf_m4b <- fit_wlsmv(bf_gonly, wlsmv_scalar_eq, bf_gp_scalar, "BF g-only (Spearman)")
bf_m5  <- fit_wlsmv(bf_nodiff, wlsmv_scalar_eq, bf_gp_scalar, "BF No diff")

bf_lrt <- list()
bf_lrt[[1]] <- safe_lrt(bf_m3, bf_m4b, "Scalar -> V=0 (Spearman)")
bf_lrt[[2]] <- safe_lrt(bf_m4b, bf_m5, "g-only -> No diff (g=0)")

safe_means(bf_m4b, "g-only (Spearman)")

# ── MCV ──
mcv_r <- NA
if (!is.null(bf_m3)) {
  std_sol <- tryCatch(standardizedSolution(bf_m3), error = function(e) NULL)
  if (!is.null(std_sol)) {
    g_loads <- std_sol$est.std[std_sol$op == "=~" & std_sol$lhs == "g" &
                                std_sol$group == 1]
    mcv_r <- cor(g_loads, gaps_d)
    cat(sprintf("\nMETHOD OF CORRELATED VECTORS: r = %.3f\n", mcv_r))
  }
}


# ---- PART 2: Higher-Order Model (Gc + Gv + Grw + Gs -> g) ----

cat("--- PART 2: HIGHER-ORDER MODEL (Gc + Gv + Grw + Gs → g, Gs~~0) ---\n")

# 4-factor HO: Gc (Verbal), Gv (Spatial/Visual-Motor), Grw (Reading/Writing),
# Gs (Processing Speed). Gs residual variance fixed to 0 because Digit, Bender,
# and Coding share no group-factor variance beyond g (confirmed by EFA and
# negative Gs variance in unconstrained model).
ho_base <- '
  Gc =~ NA*wisc_info + wisc_comp + wisc_vocab
  Gv =~ NA*wisc_picarr + wisc_block + goodenough_raw
  Grw =~ NA*wrat_read_raw + wrat_spell_raw + wrat_arith_raw
  Gs =~ NA*wisc_digit + bender_gestalt + wisc_coding
  g =~ NA*Gc + Gv + Grw + Gs
  g ~~ 1*g
  Gs ~~ 0*Gs
'

ho_means <- paste0(ho_base, '
  Gc ~ c(0, NA)*1; Gv ~ c(0, NA)*1; Grw ~ c(0, NA)*1; Gs ~ c(0, NA)*1
')
ho_freevar <- '
  Gc =~ NA*wisc_info + wisc_comp + wisc_vocab
  Gv =~ NA*wisc_picarr + wisc_block + goodenough_raw
  Grw =~ NA*wrat_read_raw + wrat_spell_raw + wrat_arith_raw
  Gs =~ NA*wisc_digit + bender_gestalt + wisc_coding
  g =~ NA*Gc + Gv + Grw + Gs
  g ~~ c(1, NA)*g
  Gs ~~ 0*Gs
  Gc ~ c(0, NA)*1; Gv ~ c(0, NA)*1; Grw ~ c(0, NA)*1; Gs ~ c(0, NA)*1
'

# HO factor indices
ho_gc_idx  <- c(1, 2, 3)        # Info, Comp, Vocab
ho_gv_idx  <- c(5, 6, 12)       # PicArr, Block, Goodenough
ho_grw_idx <- c(8, 10, 11)      # WRAT Read, WRAT Spell, WRAT Arith
ho_gs_idx  <- c(4, 9, 7)        # Digit, Bender, Coding

# HO loading params (first-order only)
ho_loading_params <- list()
for (v in sub_vars[ho_gc_idx])  ho_loading_params[[v]] <- paste0("Gc =~ ", v)
for (v in sub_vars[ho_gv_idx])  ho_loading_params[[v]] <- paste0("Gv =~ ", v)
for (v in sub_vars[ho_grw_idx]) ho_loading_params[[v]] <- paste0("Grw =~ ", v)
for (v in sub_vars[ho_gs_idx])  ho_loading_params[[v]] <- paste0("Gs =~ ", v)

# Note: HO model uses MLR (robust ML, treating all variables as continuous).
# WLSMV does not produce scaled fit statistics for the HO configural model,
# making ΔCFI comparisons across MI levels impossible. The WISC subtests
# (integer-valued 0-20 range) are treated as continuous under MLR.

# MLR group.equal for MI hierarchy (no thresholds for continuous data)
mlr_metric_eq <- "loadings"
mlr_scalar_eq <- c("loadings", "intercepts")
mlr_strict_eq <- c("loadings", "intercepts", "residuals")

# Second-order loadings are structural, always freed in MI tests
ho_2nd_order_gp <- c("g =~ Gc", "g =~ Gv", "g =~ Grw", "g =~ Gs")

# ── Step 1: Configural ──
ho_m1 <- fit_mlr(ho_base, NULL, NULL, "HO Configural")

# ── Step 2: Metric ──
# Always free 2nd-order loadings (structural); test 1st-order loading invariance
cat("\n--- HO Metric invariance ---\n")
ho_metric_res <- partial_search(ho_base, ho_m1, mlr_metric_eq,
                                 ho_2nd_order_gp, "loadings", sub_vars,
                                 ho_loading_params, ord_vars,
                                 estimator = "MLR", cfi_prefer = "robust")
ho_m2 <- ho_metric_res$fit
ho_freed_loadings <- ho_metric_res$freed
ho_gp_metric <- ho_metric_res$gp

# ── Step 3: Scalar ──
cat("\n--- HO Scalar invariance ---\n")
ho_scalar_res <- partial_search(ho_means, ho_m2, mlr_scalar_eq,
                                 ho_gp_metric, "scalar", sub_vars,
                                 ho_loading_params, ord_vars,
                                 estimator = "MLR", cfi_prefer = "robust")
ho_m3 <- ho_scalar_res$fit
ho_freed_scalar <- ho_scalar_res$freed
ho_gp_scalar <- ho_scalar_res$gp

# ── Step 4: Strict ──
cat("\n--- HO Strict invariance ---\n")
ho_strict_res <- partial_search(ho_means, ho_m3, mlr_strict_eq,
                                 ho_gp_scalar, "residuals", sub_vars,
                                 ho_loading_params, ord_vars,
                                 estimator = "MLR", cfi_prefer = "robust")
ho_m3s <- ho_strict_res$fit
ho_freed_strict <- ho_strict_res$freed
ho_gp_strict <- ho_strict_res$gp

# ── Strict + free variances ──
cat("\n--- HO Strict + free factor variances ---\n")
ho_m3sv <- fit_mlr(ho_freevar, mlr_strict_eq, ho_gp_strict,
                    "HO Strict+FreeVar")

# ── HO fit table ──
cat("\n")
cat("--- HIGHER-ORDER FIT INDICES (partial MI where applicable) ---
")

ho_fits <- list(ho_m1, ho_m2, ho_m3, ho_m3s, ho_m3sv)
ho_labs <- c("HO Configural",
             paste0("HO Metric", if (length(ho_freed_loadings) > 0)
               paste0(" (freed: ", paste(ho_freed_loadings, collapse=","), ")") else ""),
             paste0("HO Scalar", if (length(ho_freed_scalar) > 0)
               paste0(" (freed: ", paste(ho_freed_scalar, collapse=","), ")") else ""),
             paste0("HO Strict", if (length(ho_freed_strict) > 0)
               paste0(" (freed: ", paste(ho_freed_strict, collapse=","), ")") else ""),
             "HO Strict+FreeVar")

cat(sprintf("%-50s  %5s  %10s  %6s  %8s  %8s\n",
            "Model", "k", "chi2.sc", "df", "CFI.sc", "RMSEA"))
cat(strrep("-", 90), "\n")

ho_tab <- data.frame(label = ho_labs, k = NA_real_, chi2 = NA_real_, df = NA_real_,
                     cfi = NA_real_, rmsea = NA_real_)

for (i in seq_along(ho_fits)) {
  if (is.null(ho_fits[[i]])) next
  # MLR uses .robust suffix for fit measures
  fm <- tryCatch(
    fitMeasures(ho_fits[[i]], c("npar", "chisq.scaled", "df.scaled",
                                 "cfi.robust", "rmsea.robust")),
    error = function(e) NULL)
  if (is.null(fm)) next
  ho_tab$k[i]     <- fm["npar"]
  ho_tab$chi2[i]  <- fm["chisq.scaled"]
  ho_tab$df[i]    <- fm["df.scaled"]
  ho_tab$cfi[i]   <- fm["cfi.robust"]
  ho_tab$rmsea[i] <- fm["rmsea.robust"]
  cat(sprintf("%-50s  %5.0f  %10.1f  %6.0f  %8.4f  %8.5f\n",
              ho_labs[i], fm["npar"], fm["chisq.scaled"], fm["df.scaled"],
              fm["cfi.robust"], fm["rmsea.robust"]))
}

# ── HO Latent means ──
cat("\n\nHO LATENT MEANS (Black - White):\n")
safe_means(ho_m3, "HO Scalar")
safe_means(ho_m3s, "HO Strict")

# ── HO Factor variances ──
if (!is.null(ho_m3sv)) {
  cat("\nHO FACTOR VARIANCES (strict + free var):\n")
  fv_ho <- tryCatch(lavInspect(ho_m3sv, "cov.lv"), error = function(e) NULL)
  if (!is.null(fv_ho)) {
    cat(sprintf("  White: g=%.3f (fixed)\n", fv_ho$White["g","g"]))
    cat(sprintf("  Black: g=%.3f (free)\n", fv_ho$Black["g","g"]))
  }
}

# ── HO Comprehensive Constraint Configurations ──
cat("\n\nHO LATENT MEAN CONSTRAINT CONFIGURATIONS:\n")
cat("Testing all combinations of constraining {g, Gc, Gv, Grw} means to 0\n")
cat("(Gs mean is determined by g since Gs ~~ 0)\n\n")

ho_constraint_tab <- data.frame(
  config = character(), g_free = logical(), Gc_free = logical(),
  Gv_free = logical(), Grw_free = logical(),
  CFI = numeric(), stringsAsFactors = FALSE
)

for (mask in 0:15) {
  g_free   <- !(mask %% 2)
  Gc_free  <- !((mask %/% 2) %% 2)
  Gv_free  <- !((mask %/% 4) %% 2)
  Grw_free <- !((mask %/% 8) %% 2)

  constraints <- ""
  label_parts <- c(); free_parts <- c()
  if (!g_free)   { constraints <- paste0(constraints, "\n  g ~ c(0,0)*1");   label_parts <- c(label_parts, "g=0") }   else { free_parts <- c(free_parts, "g") }
  if (!Gc_free)  { constraints <- paste0(constraints, "\n  Gc ~ c(0,0)*1");  label_parts <- c(label_parts, "Gc=0") }  else { free_parts <- c(free_parts, "Gc") }
  if (!Gv_free)  { constraints <- paste0(constraints, "\n  Gv ~ c(0,0)*1");  label_parts <- c(label_parts, "Gv=0") }  else { free_parts <- c(free_parts, "Gv") }
  if (!Grw_free) { constraints <- paste0(constraints, "\n  Grw ~ c(0,0)*1"); label_parts <- c(label_parts, "Grw=0") } else { free_parts <- c(free_parts, "Grw") }

  if (length(label_parts) == 0) label <- "All free"
  else if (length(free_parts) == 0) label <- "All = 0"
  else label <- paste0("Free: ", paste(free_parts, collapse="+"),
                       " | Fix: ", paste(label_parts, collapse=","))

  syntax <- paste0(ho_base, constraints)

  fit_try <- tryCatch(suppressWarnings(
    cfa(syntax, data = dat, group = "race_grp", estimator = "MLR",
        group.equal = mlr_scalar_eq, group.partial = ho_gp_scalar)
  ), error = function(e) NULL)

  if (!is.null(fit_try) && lavInspect(fit_try, "converged")) {
    cfi_val <- as.numeric(fitMeasures(fit_try, "cfi.robust"))
    # Get means for free factors
    pe <- parameterEstimates(fit_try)
    mean_str <- ""
    for (f in c("g", "Gc", "Gv", "Grw")) {
      is_free <- switch(f, g=g_free, Gc=Gc_free, Gv=Gv_free, Grw=Grw_free)
      if (is_free) {
        m <- pe[pe$op == "~1" & pe$group == 2 & pe$lhs == f, "est"]
        if (length(m) > 0) mean_str <- paste0(mean_str, sprintf(" %s=%.3f", f, m))
      }
    }
    cat(sprintf("%-55s CFI=%.4f%s\n", label, cfi_val, mean_str))
  } else {
    cfi_val <- NA
    cat(sprintf("%-55s FAILED\n", label))
  }

  ho_constraint_tab <- rbind(ho_constraint_tab, data.frame(
    config=label, g_free=g_free, Gc_free=Gc_free, Gv_free=Gv_free, Grw_free=Grw_free,
    CFI=cfi_val, stringsAsFactors=FALSE))
}

# Sort and display summary
ref_cfi <- ho_constraint_tab$CFI[ho_constraint_tab$config == "All free"]
ho_constraint_tab$dCFI <- ref_cfi - ho_constraint_tab$CFI

cat("\n\nSorted by ΔCFI from baseline:\n")
ho_ct_sorted <- ho_constraint_tab[order(ho_constraint_tab$dCFI),]
for (i in 1:nrow(ho_ct_sorted)) {
  cat(sprintf("%-55s CFI=%.4f  dCFI=%.4f\n",
      ho_ct_sorted$config[i], ho_ct_sorted$CFI[i], ho_ct_sorted$dCFI[i]))
}

# ---- Save All Results ----

bf_lrt_df <- do.call(rbind, bf_lrt[!sapply(bf_lrt, is.null)])

results <- list(
  # Sample
  N = nrow(dat), N_white = sum(dat$race_grp == "White"),
  N_black = sum(dat$race_grp == "Black"),
  gaps_d = gaps_d, pool_sds = pool_sds,

  # --- Bifactor ---
  bf_tab = bf_tab, bf_lrt = bf_lrt_df, bf_mcv = mcv_r,
  bf_freed_loadings = bf_freed_loadings,
  bf_freed_scalar = bf_freed_scalar,
  bf_freed_strict = bf_freed_strict,
  bf_metric_log = bf_metric_res$log,
  bf_scalar_log = bf_scalar_res$log,
  bf_strict_log = bf_strict_res$log,

  # --- Higher-Order ---
  ho_tab = ho_tab,
  ho_freed_loadings = ho_freed_loadings,
  ho_freed_scalar = ho_freed_scalar,
  ho_freed_strict = ho_freed_strict,
  ho_metric_log = ho_metric_res$log,
  ho_scalar_log = ho_scalar_res$log,
  ho_strict_log = ho_strict_res$log,
  ho_constraint_tab = ho_constraint_tab
)

# Bifactor latent means
if (!is.null(bf_m3)) {
  lm3 <- lavInspect(bf_m3, "mean.lv")
  results$bf_delta_g <- lm3$Black["g"]
  results$bf_delta_V <- lm3$Black["V"]
}
if (!is.null(bf_m3s)) {
  lm3s <- lavInspect(bf_m3s, "mean.lv")
  results$bf_delta_g_strict <- lm3s$Black["g"]
  results$bf_delta_V_strict <- lm3s$Black["V"]
}
if (!is.null(bf_m4b)) {
  results$bf_delta_g_gonly <- lavInspect(bf_m4b, "mean.lv")$Black["g"]
}
if (!is.null(bf_m3sv)) {
  fv <- lavInspect(bf_m3sv, "cov.lv")
  results$bf_fvar_black <- c(g = fv$Black["g","g"], V = fv$Black["V","V"])
}

# HO latent means
if (!is.null(ho_m3)) {
  lm_ho <- lavInspect(ho_m3, "mean.lv")
  results$ho_delta_Gc  <- lm_ho$Black["Gc"]
  results$ho_delta_Gv  <- lm_ho$Black["Gv"]
  results$ho_delta_Grw <- lm_ho$Black["Grw"]
  results$ho_delta_Gs  <- lm_ho$Black["Gs"]
  results$ho_delta_g   <- lm_ho$Black["g"]
}
if (!is.null(ho_m3sv)) {
  fv_ho <- lavInspect(ho_m3sv, "cov.lv")
  results$ho_fvar_black_g <- fv_ho$Black["g","g"]
}

saveRDS(results, "results_spearman_bifactor.rds")
cat("\nSaved to results_spearman_bifactor.rds\n")
