#!/usr/bin/env Rscript
# 07d_resource_dilution.R — Resource Dilution, Parenting Experience, and Returns to Scale
#
# Tests whether:
# 1. Family size depresses IQ (resource dilution) or raises it (parenting experience/returns to scale)
# 2. Birth order × SES interactions (does dilution bite harder in poorer families?)
# 3. Per-capita income (income / n_children) vs raw income under mother FE
# 4. Family size × birth order interactions within families
# 5. SES change between births interacts with birth spacing or family size

library(data.table)
library(fixest)

cat("--- Resource Dilution, Parenting Experience, and Returns to Scale ---\n\n")

d <- readRDS("prepared_data.rds")

# ---- 1. Setup: sibling families with IQ ----
sib <- d[!is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
sib[, race_label := ifelse(race == 1, "White", "Black")]
sib[, n_sibs := .N, by = mother_id]
sib_fam <- sib[n_sibs >= 2]

# Number of live-birth records captured for each mother in the full prepared
# cohort, rather than only children with an observed WISC score.
sib_fam[, completed_family_size := first(n_kids), by = mother_id]

# Also use the actual number of tested siblings as a measure
sib_fam[, n_tested := .N, by = mother_id]

cat(sprintf("Sibling sample: %d children, %d mothers\n", nrow(sib_fam), uniqueN(sib_fam$mother_id)))
cat(sprintf("Family size distribution (completed, based on max parity):\n"))
fs_tab <- sib_fam[, .(n_moms = uniqueN(mother_id), n_kids = .N,
                        mean_iq = mean(wisc_fsiq)), by = completed_family_size]
setorder(fs_tab, completed_family_size)
cat(sprintf("  %-6s  %6s  %6s  %8s\n", "Size", "Moms", "Kids", "Mean IQ"))
for (i in 1:min(nrow(fs_tab), 10)) {
  cat(sprintf("  %-6.0f  %6d  %6d  %8.1f\n",
              fs_tab$completed_family_size[i], fs_tab$n_moms[i],
              fs_tab$n_kids[i], fs_tab$mean_iq[i]))
}

# ---- 2. Between-family: Family size and IQ ----
cat("\n--- Between-Family: Family Size and IQ ---\n\n")

# OLS: Family size predicting IQ (all children with IQ, not just siblings)
all_iq <- d[!is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
all_iq[, family_size_obs := n_kids]

m_fs_ols <- feols(wisc_fsiq ~ family_size_obs + factor(sex) + factor(race),
                  data = all_iq, vcov = "hetero")
cat(sprintf("OLS: Family size -> IQ: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_fs_ols)["family_size_obs"], se(m_fs_ols)["family_size_obs"],
            2 * pnorm(-abs(coef(m_fs_ols)["family_size_obs"] / se(m_fs_ols)["family_size_obs"]))))

# Controlling for SES
if ("income" %in% names(all_iq)) {
  m_fs_ses <- feols(wisc_fsiq ~ family_size_obs + income + sei_decimal + factor(sex) + factor(race),
                    data = all_iq, vcov = "hetero")
  cat(sprintf("OLS + SES: Family size -> IQ: b=%.3f (SE=%.3f), p=%.4f\n",
              coef(m_fs_ses)["family_size_obs"], se(m_fs_ses)["family_size_obs"],
              2 * pnorm(-abs(coef(m_fs_ses)["family_size_obs"] / se(m_fs_ses)["family_size_obs"]))))
}

# By race
for (rv in c(1, 2)) {
  rl <- ifelse(rv == 1, "White", "Black")
  sub <- all_iq[race == rv]
  m <- feols(wisc_fsiq ~ family_size_obs + factor(sex), data = sub, vcov = "hetero")
  cat(sprintf("  %s OLS: b=%.3f (SE=%.3f)\n", rl,
              coef(m)["family_size_obs"], se(m)["family_size_obs"]))
}

# ---- 3. Within-family: Birth order controlling for family size ----
cat("\n--- Within-Family: Birth Order Controlling for Family Size ---\n\n")

# Mother FE already absorbs family size (it's constant within family)
# So the existing birth_order FE result IS the within-family effect
# But we can test whether the birth order effect VARIES by family size

# First, replicate the basic birth order FE
m_bo_fe <- feols(wisc_fsiq ~ birth_order + factor(sex) | mother_id,
                 data = sib_fam, vcov = ~mother_id)
cat(sprintf("Birth order (Mother FE): b=%.4f (SE=%.4f)\n",
            coef(m_bo_fe)["birth_order"], se(m_bo_fe)["birth_order"]))

# Birth order × family size interaction (within family, family size is absorbed by FE,
# but we can still interact birth_order with it because the interaction varies within family
# for larger families)
sib_fam[, bo_x_fs := birth_order * completed_family_size]
m_bo_fs <- feols(wisc_fsiq ~ birth_order + bo_x_fs + factor(sex) | mother_id,
                 data = sib_fam, vcov = ~mother_id)
cat(sprintf("Birth order × family size (Mother FE):\n"))
cat(sprintf("  birth_order: b=%.4f (SE=%.4f)\n",
            coef(m_bo_fs)["birth_order"], se(m_bo_fs)["birth_order"]))
cat(sprintf("  birth_order × family_size: b=%.4f (SE=%.4f), p=%.4f\n",
            coef(m_bo_fs)["bo_x_fs"], se(m_bo_fs)["bo_x_fs"],
            2 * pnorm(-abs(coef(m_bo_fs)["bo_x_fs"] / se(m_bo_fs)["bo_x_fs"]))))

# ---- 4. Resource dilution test: Birth order × SES interaction ----
cat("\n--- Birth Order × SES Interaction (Mother FE) ---\n")
cat("Does the birth order effect depend on family income?\n\n")

if ("income" %in% names(sib_fam)) {
  # Within-family: birth order × income deviation
  sib_fam[, fam_mean_inc := mean(income, na.rm = TRUE), by = mother_id]
  sib_fam[, inc_dev := income - fam_mean_inc]
  sib_fam[, bo_x_inc := birth_order * income]

  # FE: birth_order + income + birth_order × income
  m_boi <- feols(wisc_fsiq ~ birth_order + income + birth_order:income + factor(sex) | mother_id,
                 data = sib_fam[!is.na(income)], vcov = ~mother_id)
  cat("Birth order × income (Mother FE):\n")
  for (v in names(coef(m_boi))) {
    if (v == "factor(sex)2") next
    cat(sprintf("  %-30s: b=%8.5f (SE=%.5f), p=%.4f\n",
                v, coef(m_boi)[v], se(m_boi)[v],
                2 * pnorm(-abs(coef(m_boi)[v] / se(m_boi)[v]))))
  }
}

# ---- 5. Per-capita income vs raw income ----
cat("\n--- Per-Capita Income vs Raw Income ---\n")
cat("Does income-per-child predict IQ better than raw income?\n\n")

if ("income" %in% names(sib_fam)) {
  # Compute per-capita income (income / number of prior livebirths + 1)
  sib_fam[, inc_per_child := income / pmax(birth_order + 1, 1)]

  # OLS comparison
  sub <- sib_fam[!is.na(income) & !is.na(wisc_fsiq)]
  m_raw_ols <- feols(wisc_fsiq ~ income + factor(sex) + factor(race), data = sub, vcov = "hetero")
  m_pc_ols  <- feols(wisc_fsiq ~ inc_per_child + factor(sex) + factor(race), data = sub, vcov = "hetero")

  cat(sprintf("OLS raw income:       b=%.4f (SE=%.4f), R2=%.4f\n",
              coef(m_raw_ols)["income"], se(m_raw_ols)["income"],
              fitstat(m_raw_ols, "r2")$r2))
  cat(sprintf("OLS income/child:     b=%.4f (SE=%.4f), R2=%.4f\n",
              coef(m_pc_ols)["inc_per_child"], se(m_pc_ols)["inc_per_child"],
              fitstat(m_pc_ols, "r2")$r2))

  # Mother FE comparison
  m_raw_fe <- feols(wisc_fsiq ~ income + factor(sex) | mother_id, data = sub, vcov = ~mother_id)
  m_pc_fe  <- feols(wisc_fsiq ~ inc_per_child + factor(sex) | mother_id, data = sub, vcov = ~mother_id)

  cat(sprintf("FE raw income:        b=%.4f (SE=%.4f)\n",
              coef(m_raw_fe)["income"], se(m_raw_fe)["income"]))
  cat(sprintf("FE income/child:      b=%.4f (SE=%.4f)\n",
              coef(m_pc_fe)["inc_per_child"], se(m_pc_fe)["inc_per_child"]))
}

# ---- 6. Birth spacing and IQ ----
cat("\n--- Birth Spacing and IQ ---\n")
cat("Does longer spacing between siblings predict higher IQ?\n\n")

# Compute inter-birth interval using child's birth date info
# birth_order is available; we need actual dates or can use maternal age difference
sib_fam <- sib_fam[order(mother_id, birth_order)]
sib_fam[, prev_maternal_age := shift(maternal_age, 1), by = mother_id]
sib_fam[, birth_spacing_yrs := maternal_age - prev_maternal_age]
sib_fam[birth_order == 0, birth_spacing_yrs := NA]  # No spacing for firstborns

# Clean extreme values
sib_fam[birth_spacing_yrs < 0.5 | birth_spacing_yrs > 10, birth_spacing_yrs := NA]

cat(sprintf("Children with valid birth spacing: %d\n",
            sum(!is.na(sib_fam$birth_spacing_yrs))))
cat(sprintf("Mean spacing: %.1f years (SD=%.1f)\n",
            mean(sib_fam$birth_spacing_yrs, na.rm = TRUE),
            sd(sib_fam$birth_spacing_yrs, na.rm = TRUE)))

# OLS and FE
sub_sp <- sib_fam[!is.na(birth_spacing_yrs) & !is.na(wisc_fsiq)]
m_sp_ols <- feols(wisc_fsiq ~ birth_spacing_yrs + birth_order + factor(sex) + factor(race),
                  data = sub_sp, vcov = "hetero")
m_sp_fe  <- feols(wisc_fsiq ~ birth_spacing_yrs + birth_order + factor(sex) | mother_id,
                  data = sub_sp, vcov = ~mother_id)

cat(sprintf("OLS spacing -> IQ: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_sp_ols)["birth_spacing_yrs"], se(m_sp_ols)["birth_spacing_yrs"],
            2 * pnorm(-abs(coef(m_sp_ols)["birth_spacing_yrs"] / se(m_sp_ols)["birth_spacing_yrs"]))))
cat(sprintf("FE  spacing -> IQ: b=%.3f (SE=%.3f), p=%.4f\n",
            coef(m_sp_fe)["birth_spacing_yrs"], se(m_sp_fe)["birth_spacing_yrs"],
            2 * pnorm(-abs(coef(m_sp_fe)["birth_spacing_yrs"] / se(m_sp_fe)["birth_spacing_yrs"]))))

# By race
for (rv in c(1, 2)) {
  rl <- ifelse(rv == 1, "White", "Black")
  sub_r <- sub_sp[race == rv]
  m_r <- feols(wisc_fsiq ~ birth_spacing_yrs + birth_order + factor(sex) | mother_id,
               data = sub_r, vcov = ~mother_id)
  cat(sprintf("  %s FE: b=%.3f (SE=%.3f), p=%.4f\n", rl,
              coef(m_r)["birth_spacing_yrs"], se(m_r)["birth_spacing_yrs"],
              2 * pnorm(-abs(coef(m_r)["birth_spacing_yrs"] / se(m_r)["birth_spacing_yrs"]))))
}

# ---- 7. Resource dilution: family size × SES between families ----
cat("\n--- Family Size × SES Between Families ---\n")
cat("Does family size hurt more in low-SES families?\n\n")

if ("income" %in% names(all_iq)) {
  # Median split SES
  all_iq[, inc_median := median(income, na.rm = TRUE)]
  all_iq[, low_ses := as.integer(income < inc_median)]

  # Family size × low_ses interaction
  m_fsi <- feols(wisc_fsiq ~ family_size_obs * low_ses + factor(sex) + factor(race),
                 data = all_iq[!is.na(income)], vcov = "hetero")
  cat("Family size × low SES (OLS):\n")
  for (v in c("family_size_obs", "low_ses", "family_size_obs:low_ses")) {
    if (v %in% names(coef(m_fsi))) {
      cat(sprintf("  %-30s: b=%8.3f (SE=%.3f), p=%.4f\n",
                  v, coef(m_fsi)[v], se(m_fsi)[v],
                  2 * pnorm(-abs(coef(m_fsi)[v] / se(m_fsi)[v]))))
    }
  }

  # Continuous interaction
  m_fsi2 <- feols(wisc_fsiq ~ family_size_obs * income + factor(sex) + factor(race),
                  data = all_iq[!is.na(income)], vcov = "hetero")
  cat("\nFamily size × income (OLS, continuous):\n")
  for (v in c("family_size_obs", "income", "family_size_obs:income")) {
    cat(sprintf("  %-30s: b=%8.5f (SE=%.5f), p=%.4f\n",
                v, coef(m_fsi2)[v], se(m_fsi2)[v],
                2 * pnorm(-abs(coef(m_fsi2)[v] / se(m_fsi2)[v]))))
  }
}

# ---- 8. Decomposing the birth order effect: dilution vs experience ----
cat("\n--- Decomposing Birth Order: Dilution vs Experience ---\n\n")

# The key insight: if resource dilution dominates, the birth order FE effect should be
# negative (later-born = fewer resources per child = lower IQ).
# If parenting experience dominates, it should be positive (later-born = more experienced parents).
# The CPP shows +0.034 SD per parity, suggesting experience > dilution.

# Test whether this effect varies by income (resource constraint)
# If dilution is real, the positive birth order effect should be SMALLER in poor families
# (where there's less slack) and LARGER in rich families

if ("income" %in% names(sib_fam)) {
  sib_fam[, fam_mean_inc_q := cut(fam_mean_inc,
                                    breaks = quantile(fam_mean_inc, c(0, 0.25, 0.5, 0.75, 1), na.rm = TRUE),
                                    labels = c("Q1 (poorest)", "Q2", "Q3", "Q4 (richest)"),
                                    include.lowest = TRUE)]

  cat("Birth order FE effect by family income quartile:\n")
  for (q in levels(sib_fam$fam_mean_inc_q)) {
    sub_q <- sib_fam[fam_mean_inc_q == q]
    if (uniqueN(sub_q$mother_id) > 100) {
      m_q <- feols(wisc_fsiq ~ birth_order + factor(sex) | mother_id,
                   data = sub_q, vcov = ~mother_id)
      cat(sprintf("  %-18s: b=%.4f (SE=%.4f), n=%d kids, %d moms\n",
                  q, coef(m_q)["birth_order"], se(m_q)["birth_order"],
                  nrow(sub_q), uniqueN(sub_q$mother_id)))
    }
  }
}

# ---- 9. Family size effects on IQ, controlling for birth order (between-family) ----
cat("\n--- Family Size Effect on IQ (Controlling for Birth Order, Between-Family) ---\n\n")

# Between-family: compare same-birth-order children across different family sizes
# e.g., firstborns in 2-child families vs firstborns in 5-child families
cat("IQ by family size, for firstborns only:\n")
firstborns <- all_iq[birth_order == 0]
fb_tab <- firstborns[, .(mean_iq = mean(wisc_fsiq), n = .N),
                      by = family_size_obs][order(family_size_obs)]
cat(sprintf("  %-6s  %8s  %6s\n", "Size", "Mean IQ", "N"))
for (i in 1:min(nrow(fb_tab), 8)) {
  cat(sprintf("  %-6d  %8.1f  %6d\n",
              fb_tab$family_size_obs[i], fb_tab$mean_iq[i], fb_tab$n[i]))
}

# Same for secondborns
cat("\nIQ by family size, for secondborns only:\n")
secondborns <- all_iq[birth_order == 1]
sb_tab <- secondborns[, .(mean_iq = mean(wisc_fsiq), n = .N),
                       by = family_size_obs][order(family_size_obs)]
cat(sprintf("  %-6s  %8s  %6s\n", "Size", "Mean IQ", "N"))
for (i in 1:min(nrow(sb_tab), 8)) {
  cat(sprintf("  %-6d  %8.1f  %6d\n",
              sb_tab$family_size_obs[i], sb_tab$mean_iq[i], sb_tab$n[i]))
}

# Regression: IQ ~ family_size + birth_order + SES + race + sex
m_fs_bo <- feols(wisc_fsiq ~ family_size_obs + birth_order + factor(sex) + factor(race),
                 data = all_iq, vcov = "hetero")
cat(sprintf("\nOLS: family_size | birth_order: b=%.3f (SE=%.3f)\n",
            coef(m_fs_bo)["family_size_obs"], se(m_fs_bo)["family_size_obs"]))

if ("income" %in% names(all_iq)) {
  m_fs_bo_ses <- feols(wisc_fsiq ~ family_size_obs + birth_order + income + sei_decimal +
                         factor(sex) + factor(race),
                       data = all_iq, vcov = "hetero")
  cat(sprintf("OLS + SES: family_size | birth_order: b=%.3f (SE=%.3f)\n",
              coef(m_fs_bo_ses)["family_size_obs"], se(m_fs_bo_ses)["family_size_obs"]))
}

# ---- 10. Power analysis ----
cat("\n--- Power Analysis ---\n\n")

# MDE for birth spacing
se_sp <- se(m_sp_fe)["birth_spacing_yrs"]
sd_sp <- sd(sib_fam$birth_spacing_yrs, na.rm = TRUE)
mde_sp <- 2.8 * se_sp
cat(sprintf("Birth spacing MDE: %.2f IQ pts per year (SE=%.3f)\n", mde_sp, se_sp))
cat(sprintf("  Per 1 SD (%.1f yrs): %.2f IQ pts\n", sd_sp, mde_sp * sd_sp))

# MDE for birth order × income interaction
if ("income" %in% names(sib_fam) && "birth_order:income" %in% names(coef(m_boi))) {
  se_boi <- se(m_boi)["birth_order:income"]
  mde_boi <- 2.8 * se_boi
  cat(sprintf("Birth order × income MDE: %.5f per unit (SE=%.5f)\n", mde_boi, se_boi))
}

cat("\nDone.\n")
