#!/usr/bin/env Rscript
# hs_ip_sensitivity.R
# Assess whether HS SES confound biases the IP model and between-group decomposition
#
# Strategy:
# 1. Compute cross-sibling covariance matrices by kinship type
# 2. Estimate A and C matrices from different kinship combinations
# 3. Extract common-factor (PC1) loadings and compare profiles
# 4. Re-fit IP model without HS and compare to full model
# 5. Re-fit between-group decomposition without HS

library(data.table)
library(OpenMx)
mxOption(NULL, "Number of Threads", parallel::detectCores() - 1)

# ── Load data ──────────────────────────────────────────────────────────
d <- readRDS("prepared_data.rds")
ses <- fread(file.path("..", "clean", "cpp_ses_detailed.csv"),
             colClasses = c(case_id = "character", mother_id = "character"))

for (v in c("wisc_picarr", "wisc_block", "wisc_coding")) {
  if (v %in% names(d)) d[get(v) == 88, (v) := NA]
}

links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

cat("\n")
cat("=== HS SENSITIVITY: IP MODEL AND BETWEEN-GROUP DECOMPOSITION ===\n\n")

# ── Define subtests ────────────────────────────────────────────────────
sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "DigSp", "PicArr", "Block",
                "Code", "WRATrd", "Bend", "WRATsp", "WRATar", "Good")
nv <- length(sub_vars)

# ── Build pair data ──────────────────────────────────────────────────
d_sub <- d[, c("case_id", sub_vars), with = FALSE]

pair <- merge(links, d_sub, by.x = "id_1", by.y = "case_id")
old_names <- sub_vars
new_names1 <- paste0(sub_vars, "_1")
setnames(pair, old_names, new_names1)

pair <- merge(pair, d_sub, by.x = "id_2", by.y = "case_id")
new_names2 <- paste0(sub_vars, "_2")
setnames(pair, old_names, new_names2)

pair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
pair <- pair[!is.na(pair_class)]

has_any_1 <- rowSums(!is.na(pair[, ..new_names1])) > 0
has_any_2 <- rowSums(!is.na(pair[, ..new_names2])) > 0
pair <- pair[has_any_1 & has_any_2]

cat(sprintf("Pairs: MZ=%d, DZ=%d, FS=%d, HS=%d\n",
            pair[pair_class == "MZ", .N], pair[pair_class == "DZ", .N],
            pair[pair_class == "FS", .N], pair[pair_class == "HS", .N]))

# ── Merge SES for diagnostic ────────────────────────────────────────
d_ses <- merge(d[, .(case_id, sei_decimal)], ses[, .(case_id)], by = "case_id", all.x = TRUE)
pair_ses <- merge(pair, d[, .(case_id, sei_decimal)], by.x = "id_1", by.y = "case_id", all.x = TRUE)
setnames(pair_ses, "sei_decimal", "sei_1")
pair_ses <- merge(pair_ses, d[, .(case_id, sei_decimal)], by.x = "id_2", by.y = "case_id", all.x = TRUE)
setnames(pair_ses, "sei_decimal", "sei_2")
pair_ses[, mean_sei := (sei_1 + sei_2) / 2]

cat("\nMean SEI by pair type:\n")
for (pc in c("MZ", "DZ", "FS", "HS")) {
  m <- pair_ses[pair_class == pc, mean(mean_sei, na.rm = TRUE)]
  s <- pair_ses[pair_class == pc, sd(mean_sei, na.rm = TRUE)]
  cat(sprintf("  %s: %.2f (SD = %.2f)\n", pc, m, s))
}

# ══════════════════════════════════════════════════════════════════════
# PART 1: Cross-Sibling Covariance Analysis
# ══════════════════════════════════════════════════════════════════════
cat("\n")
cat(strrep("=", 70), "\n")
cat("PART 1: Cross-Sibling Covariance Matrices\n")
cat(strrep("=", 70), "\n")

# Compute cross-sibling covariance: cov(sib1_vars, sib2_vars)
cross_cov <- list()
for (pc in c("MZ", "DZ", "FS", "HS")) {
  sub <- pair[pair_class == pc]
  m1 <- as.matrix(sub[, ..new_names1])
  m2 <- as.matrix(sub[, ..new_names2])
  # Pairwise complete covariance between sib1 and sib2 variables
  cc <- matrix(NA, nv, nv)
  for (i in 1:nv) {
    for (j in 1:nv) {
      ok <- !is.na(m1[, i]) & !is.na(m2[, j])
      if (sum(ok) >= 20) {
        cc[i, j] <- cov(m1[ok, i], m2[ok, j])
      }
    }
  }
  rownames(cc) <- colnames(cc) <- sub_labels
  cross_cov[[pc]] <- cc
}

# Under ACE model: cross_cov = R*A + C (+ T for twins)
# For non-twins: cross_cov(FS) = 0.5*A + C; cross_cov(HS) = 0.25*A + C
# So A = 4*(cross_cov(FS) - cross_cov(HS)), C = cross_cov(HS) - 0.25*A
# For MZ-FS: A = 2*(cross_cov(MZ) - cross_cov(FS) - T)
# Simplification ignoring T: A_mzfs ≈ 2*(cross_cov(MZ) - cross_cov(FS))

cat("\nDiagonal of cross-sibling covariance (same-variable cross-pair r*var):\n")
cat(sprintf("  %-8s  %8s  %8s  %8s  %8s\n", "Subtest", "MZ", "DZ", "FS", "HS"))
cat("  ", strrep("-", 45), "\n")
for (i in 1:nv) {
  cat(sprintf("  %-8s  %8.2f  %8.2f  %8.2f  %8.2f\n",
              sub_labels[i],
              cross_cov[["MZ"]][i,i], cross_cov[["DZ"]][i,i],
              cross_cov[["FS"]][i,i], cross_cov[["HS"]][i,i]))
}

# Estimate A from different contrasts
# Method 1: FS - HS (no twin confound)
A_fshs <- 4 * (cross_cov[["FS"]] - cross_cov[["HS"]])
C_fshs <- cross_cov[["HS"]] - 0.25 * A_fshs

# Method 2: MZ - FS (ignoring twin-specific env)
A_mzfs <- 2 * (cross_cov[["MZ"]] - cross_cov[["FS"]])
C_mzfs <- cross_cov[["FS"]] - 0.5 * A_mzfs

# Method 3: MZ - DZ (classic twin, includes twin-specific env in both)
A_mzdz <- 2 * (cross_cov[["MZ"]] - cross_cov[["DZ"]])
C_mzdz <- cross_cov[["DZ"]] - 0.5 * A_mzdz

cat("\nDiagonal of estimated A matrix (genetic variance per subtest):\n")
cat(sprintf("  %-8s  %8s  %8s  %8s\n", "Subtest", "MZ-DZ", "MZ-FS", "FS-HS"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nv) {
  cat(sprintf("  %-8s  %8.2f  %8.2f  %8.2f\n",
              sub_labels[i],
              A_mzdz[i,i], A_mzfs[i,i], A_fshs[i,i]))
}

cat("\nDiagonal of estimated C matrix (shared-env variance per subtest):\n")
cat(sprintf("  %-8s  %8s  %8s  %8s\n", "Subtest", "MZ-DZ", "MZ-FS", "FS-HS"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nv) {
  cat(sprintf("  %-8s  %8.2f  %8.2f  %8.2f\n",
              sub_labels[i],
              C_mzdz[i,i], C_mzfs[i,i], C_fshs[i,i]))
}

# ── Compare A loadings (PC1 of A) across methods ──────────────────────
# Symmetrize A matrices and extract PC1
extract_pc1 <- function(mat, label) {
  mat_sym <- (mat + t(mat)) / 2  # ensure symmetric
  # Clip negative eigenvalues (non-PD matrix)
  eig <- eigen(mat_sym, symmetric = TRUE)
  # First eigenvector, sign-corrected so majority of loadings positive
  v1 <- eig$vectors[, 1]
  if (sum(v1 < 0) > sum(v1 > 0)) v1 <- -v1
  pct <- 100 * eig$values[1] / sum(pmax(eig$values, 0))
  cat(sprintf("  %s: PC1 explains %.1f%% of positive variance\n", label, pct))
  return(v1)
}

cat("\nPC1 loadings of estimated A matrices:\n")
pc1_mzdz <- extract_pc1(A_mzdz, "A(MZ-DZ)")
pc1_mzfs <- extract_pc1(A_mzfs, "A(MZ-FS)")
pc1_fshs <- extract_pc1(A_fshs, "A(FS-HS)")

cat(sprintf("\n  %-8s  %8s  %8s  %8s\n", "Subtest", "MZ-DZ", "MZ-FS", "FS-HS"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nv) {
  cat(sprintf("  %-8s  %8.3f  %8.3f  %8.3f\n",
              sub_labels[i], pc1_mzdz[i], pc1_mzfs[i], pc1_fshs[i]))
}

cat(sprintf("\n  Congruence coefficients:\n"))
congr <- function(a, b) sum(a * b) / sqrt(sum(a^2) * sum(b^2))
cat(sprintf("    MZ-DZ vs MZ-FS: %.4f\n", congr(pc1_mzdz, pc1_mzfs)))
cat(sprintf("    MZ-DZ vs FS-HS: %.4f\n", congr(pc1_mzdz, pc1_fshs)))
cat(sprintf("    MZ-FS vs FS-HS: %.4f\n", congr(pc1_mzfs, pc1_fshs)))

# ── Predicted vs observed HS cross-covariance ──────────────────────────
# Under the model using MZ-FS estimates:
# Predicted HS = 0.25*A_mzfs + C_mzfs
hs_pred <- 0.25 * A_mzfs + C_mzfs
hs_obs <- cross_cov[["HS"]]

cat("\nPredicted vs Observed HS cross-covariance (diagonal):\n")
cat(sprintf("  %-8s  %8s  %8s  %8s\n", "Subtest", "Observed", "Predicted", "Diff"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nv) {
  cat(sprintf("  %-8s  %8.2f  %8.2f  %8.2f\n",
              sub_labels[i], hs_obs[i,i], hs_pred[i,i],
              hs_obs[i,i] - hs_pred[i,i]))
}
cat(sprintf("\n  Mean diagonal: Obs=%.2f, Pred=%.2f, Diff=%.2f\n",
            mean(diag(hs_obs), na.rm = TRUE),
            mean(diag(hs_pred), na.rm = TRUE),
            mean(diag(hs_obs) - diag(hs_pred), na.rm = TRUE)))

# Direction of bias: if HS cross-cov is inflated (due to extra C at low SES),
# then FS-HS contrast underestimates A and overestimates C.
# But we actually want to know about the full IP model fit.

# ══════════════════════════════════════════════════════════════════════
# PART 2: Re-fit IP Model Without HS
# ══════════════════════════════════════════════════════════════════════
cat("\n")
cat(strrep("=", 70), "\n")
cat("PART 2: IP Model — With vs Without HS\n")
cat(strrep("=", 70), "\n")

var_names <- c(new_names1, new_names2)
mz_data <- as.data.frame(pair[pair_class == "MZ", ..var_names])
dz_data <- as.data.frame(pair[pair_class == "DZ", ..var_names])
fs_data <- as.data.frame(pair[pair_class == "FS", ..var_names])
hs_data <- as.data.frame(pair[pair_class == "HS", ..var_names])

start_means <- c(9.2, 8.7, 8.7, 9.6, 9.1, 9.4, 10.0, 33.8, -8.4,
                 23.7, 20.0, 19.7)

# Build IP model helper
build_ip <- function(model_name, groups, group_data, R_coeffs, has_twin) {
  make_group_sub <- function(sub_name, data, R_coeff, twin) {
    p <- model_name
    if (twin) {
      b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C + ", p, ".Tt")
    } else {
      b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C")
    }
    cov_str <- paste0("rbind(cbind(", p, ".V, B), cbind(B, ", p, ".V))")
    mean_str <- paste0("cbind(", p, ".Mu, ", p, ".Mu)")
    mxModel(sub_name, mxData(data, type = "raw"),
      mxAlgebraFromString(b_str, name = "B"),
      mxAlgebraFromString(cov_str, name = "expCov"),
      mxAlgebraFromString(mean_str, name = "expMean"),
      mxExpectationNormal("expCov", "expMean", dimnames = var_names),
      mxFitFunctionML())
  }

  group_models <- mapply(make_group_sub, groups, group_data, R_coeffs, has_twin,
                         SIMPLIFY = FALSE)

  do.call(mxModel, c(list(model_name,
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.5, nv),
             lbound = -5, name = "ac"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.8, nv),
             lbound = -5, name = "cc"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(0.3, nv),
             lbound = -5, name = "tc"),
    mxMatrix("Full", nv, 1, free = TRUE, values = rep(1.0, nv),
             lbound = -5, name = "ec"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
             lbound = 0.001, name = "as"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.5, nv),
             lbound = 0.001, name = "cs"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(0.3, nv),
             lbound = 0.001, name = "ts"),
    mxMatrix("Diag", nv, nv, free = TRUE, values = rep(1.5, nv),
             lbound = 0.001, name = "es"),
    mxAlgebra(ac %*% t(ac) + as %*% t(as), name = "A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name = "C"),
    mxAlgebra(tc %*% t(tc) + ts %*% t(ts), name = "Tt"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name = "E"),
    mxAlgebra(A + C + Tt + E, name = "V"),
    mxMatrix("Full", 1, nv, free = TRUE, values = start_means, name = "Mu"),
    mxFitFunctionMultigroup(groups)),
    group_models))
}

# Full model: MZ + DZ + FS + HS
cat("\n  Fitting IP model with all 4 groups (MZ+DZ+FS+HS)...\n")
ip_full <- build_ip("IPfull",
  c("MZ", "DZ", "FS", "HS"),
  list(mz_data, dz_data, fs_data, hs_data),
  c("1", "0.5", "0.5", "0.25"),
  c(TRUE, TRUE, FALSE, FALSE))
ip_full_fit <- mxTryHard(ip_full, extraTries = 30, silent = TRUE)
ip_full_sum <- summary(ip_full_fit)
cat(sprintf("  Full IP: -2LL=%.2f, k=%d, status=%d\n",
            ip_full_sum$Minus2LogLikelihood, ip_full_sum$estimatedParameters,
            ip_full_fit$output$status$code))

# No-HS model: MZ + DZ + FS
cat("  Fitting IP model without HS (MZ+DZ+FS)...\n")
ip_nohs <- build_ip("IPnohs",
  c("MZ", "DZ", "FS"),
  list(mz_data, dz_data, fs_data),
  c("1", "0.5", "0.5"),
  c(TRUE, TRUE, FALSE))
ip_nohs_fit <- mxTryHard(ip_nohs, extraTries = 30, silent = TRUE)
ip_nohs_sum <- summary(ip_nohs_fit)
cat(sprintf("  No-HS IP: -2LL=%.2f, k=%d, status=%d\n",
            ip_nohs_sum$Minus2LogLikelihood, ip_nohs_sum$estimatedParameters,
            ip_nohs_fit$output$status$code))

# ── Compare loadings ──────────────────────────────────────────────────
ac_full <- ip_full_fit$ac$values[,1]
cc_full <- ip_full_fit$cc$values[,1]
ac_nohs <- ip_nohs_fit$ac$values[,1]
cc_nohs <- ip_nohs_fit$cc$values[,1]

cat("\nIP Model A-common loadings (ac):\n")
cat(sprintf("  %-8s  %8s  %8s  %8s\n", "Subtest", "Full", "No-HS", "Diff"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nv) {
  cat(sprintf("  %-8s  %8.3f  %8.3f  %8.3f\n",
              sub_labels[i], ac_full[i], ac_nohs[i], ac_nohs[i] - ac_full[i]))
}

cat("\nIP Model C-common loadings (cc):\n")
cat(sprintf("  %-8s  %8s  %8s  %8s\n", "Subtest", "Full", "No-HS", "Diff"))
cat("  ", strrep("-", 40), "\n")
for (i in 1:nv) {
  cat(sprintf("  %-8s  %8.3f  %8.3f  %8.3f\n",
              sub_labels[i], cc_full[i], cc_nohs[i], cc_nohs[i] - cc_full[i]))
}

# Congruence of loading profiles
cat(sprintf("\nCongruence of A-common loadings (full vs no-HS): %.4f\n",
            congr(ac_full, ac_nohs)))
cat(sprintf("Congruence of C-common loadings (full vs no-HS): %.4f\n",
            congr(cc_full, cc_nohs)))

# Variance explained by common A vs common C
A_full <- mxEval(A, ip_full_fit)
C_full <- mxEval(C, ip_full_fit)
V_full <- mxEval(V, ip_full_fit)
A_nohs <- mxEval(A, ip_nohs_fit)
C_nohs <- mxEval(C, ip_nohs_fit)
V_nohs <- mxEval(V, ip_nohs_fit)

cat("\nTotal variance partitioning (trace proportions):\n")
cat(sprintf("  %-20s  %8s  %8s\n", "", "Full", "No-HS"))
cat("  ", strrep("-", 40), "\n")
cat(sprintf("  %-20s  %8.3f  %8.3f\n", "A / V (heritability)",
            sum(diag(A_full)) / sum(diag(V_full)),
            sum(diag(A_nohs)) / sum(diag(V_nohs))))
cat(sprintf("  %-20s  %8.3f  %8.3f\n", "C / V (shared env)",
            sum(diag(C_full)) / sum(diag(V_full)),
            sum(diag(C_nohs)) / sum(diag(V_nohs))))

# Common factor A proportion
ac2_full <- ac_full^2
ac2_nohs <- ac_nohs^2
cc2_full <- cc_full^2
cc2_nohs <- cc_nohs^2

cat("\nCommon-factor variance (ac^2) sum:\n")
cat(sprintf("  Full:  %.3f\n", sum(ac2_full)))
cat(sprintf("  No-HS: %.3f\n", sum(ac2_nohs)))
cat(sprintf("  Ratio: %.3f\n", sum(ac2_nohs) / sum(ac2_full)))

cat("\nCommon-factor C (cc^2) sum:\n")
cat(sprintf("  Full:  %.3f\n", sum(cc2_full)))
cat(sprintf("  No-HS: %.3f\n", sum(cc2_nohs)))
cat(sprintf("  Ratio: %.3f\n", sum(cc2_nohs) / sum(cc2_full)))

# Proportion of common variance that is genetic
pct_a_full <- sum(ac2_full) / (sum(ac2_full) + sum(cc2_full))
pct_a_nohs <- sum(ac2_nohs) / (sum(ac2_nohs) + sum(cc2_nohs))
cat(sprintf("\nProportion of common-factor variance that is genetic:\n"))
cat(sprintf("  Full:  %.3f\n", pct_a_full))
cat(sprintf("  No-HS: %.3f\n", pct_a_nohs))

# ══════════════════════════════════════════════════════════════════════
# PART 3: Between-Group Decomposition Without HS
# ══════════════════════════════════════════════════════════════════════
cat("\n")
cat(strrep("=", 70), "\n")
cat("PART 3: Between-Group Decomposition — With vs Without HS\n")
cat(strrep("=", 70), "\n")

# Build pair data with race
sub_vars7 <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
               "wisc_picarr", "wisc_block", "wisc_coding")
sub_labels7 <- c("Info", "Comp", "Vocab", "DigSp", "PicArr", "Block", "Code")
nv7 <- length(sub_vars7)

d_sub7 <- d[, c("case_id", "race", sub_vars7), with = FALSE]

rpair <- merge(links, d_sub7, by.x = "id_1", by.y = "case_id")
setnames(rpair, "race", "race_1")
rn1 <- paste0(sub_vars7, "_1")
setnames(rpair, sub_vars7, rn1)

rpair <- merge(rpair, d_sub7, by.x = "id_2", by.y = "case_id")
setnames(rpair, "race", "race_2")
rn2 <- paste0(sub_vars7, "_2")
setnames(rpair, sub_vars7, rn2)

rpair[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  default = NA_character_
)]
rpair <- rpair[!is.na(pair_class)]
rpair <- rpair[race_1 == race_2 & race_1 %in% c(1, 2)]
rpair[, race := ifelse(race_1 == 1, "White", "Black")]

has_any_1r <- rowSums(!is.na(rpair[, ..rn1])) > 0
has_any_2r <- rowSums(!is.na(rpair[, ..rn2])) > 0
rpair <- rpair[has_any_1r & has_any_2r]

rvar_names <- c(rn1, rn2)

make_rgroup <- function(data, race_val, pc) {
  as.data.frame(data[race == race_val & pair_class == pc, ..rvar_names])
}

w_mz <- make_rgroup(rpair, "White", "MZ")
w_dz <- make_rgroup(rpair, "White", "DZ")
w_fs <- make_rgroup(rpair, "White", "FS")
w_hs <- make_rgroup(rpair, "White", "HS")
b_mz <- make_rgroup(rpair, "Black", "MZ")
b_dz <- make_rgroup(rpair, "Black", "DZ")
b_fs <- make_rgroup(rpair, "Black", "FS")
b_hs <- make_rgroup(rpair, "Black", "HS")

cat(sprintf("\nWhite: MZ=%d, DZ=%d, FS=%d, HS=%d\n",
            nrow(w_mz), nrow(w_dz), nrow(w_fs), nrow(w_hs)))
cat(sprintf("Black: MZ=%d, DZ=%d, FS=%d, HS=%d\n",
            nrow(b_mz), nrow(b_dz), nrow(b_fs), nrow(b_hs)))

# Build decomposition model helper (adapted from 02d)
build_decomp_flex <- function(model_name, kA_free, kC_free,
                              kA_val = 0.5, kC_val = 0.5,
                              include_hs = TRUE) {
  p <- model_name
  make_sub <- function(sub_name, data, R_coeff, has_twin, use_white) {
    mu_ref <- if (use_white) paste0(p, ".MuW") else paste0(p, ".MuB")
    if (has_twin) {
      b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C + ", p, ".Tt")
    } else {
      b_str <- paste0(R_coeff, "*", p, ".A + ", p, ".C")
    }
    cov_str <- paste0("rbind(cbind(", p, ".V, B), cbind(B, ", p, ".V))")
    mean_str <- paste0("cbind(", mu_ref, ", ", mu_ref, ")")
    mxModel(sub_name, mxData(data, type = "raw"),
      mxAlgebraFromString(b_str, name = "B"),
      mxAlgebraFromString(cov_str, name = "expCov"),
      mxAlgebraFromString(mean_str, name = "expMean"),
      mxExpectationNormal("expCov", "expMean", dimnames = rvar_names),
      mxFitFunctionML())
  }

  group_list <- list(
    make_sub("W_MZ", w_mz, 1,    TRUE,  TRUE),
    make_sub("W_DZ", w_dz, 0.5,  TRUE,  TRUE),
    make_sub("W_FS", w_fs, 0.5,  FALSE, TRUE),
    make_sub("B_MZ", b_mz, 1,    TRUE,  FALSE),
    make_sub("B_DZ", b_dz, 0.5,  TRUE,  FALSE),
    make_sub("B_FS", b_fs, 0.5,  FALSE, FALSE)
  )
  group_names <- c("W_MZ", "W_DZ", "W_FS", "B_MZ", "B_DZ", "B_FS")

  if (include_hs) {
    group_list <- c(group_list, list(
      make_sub("W_HS", w_hs, 0.25, FALSE, TRUE),
      make_sub("B_HS", b_hs, 0.25, FALSE, FALSE)
    ))
    group_names <- c(group_names, "W_HS", "B_HS")
  }

  do.call(mxModel, c(list(model_name,
    mxMatrix("Full", nv7, 1, free=TRUE, values=rep(1.5, nv7), lbound=-5, name="ac"),
    mxMatrix("Full", nv7, 1, free=TRUE, values=rep(0.8, nv7), lbound=-5, name="cc"),
    mxMatrix("Full", nv7, 1, free=TRUE, values=rep(0.3, nv7), lbound=-5, name="tc"),
    mxMatrix("Full", nv7, 1, free=TRUE, values=rep(1.0, nv7), lbound=-5, name="ec"),
    mxMatrix("Diag", nv7, nv7, free=TRUE, values=rep(1.5, nv7), lbound=0.001, name="as"),
    mxMatrix("Diag", nv7, nv7, free=TRUE, values=rep(0.5, nv7), lbound=0.001, name="cs"),
    mxMatrix("Diag", nv7, nv7, free=TRUE, values=rep(0.3, nv7), lbound=0.001, name="ts"),
    mxMatrix("Diag", nv7, nv7, free=TRUE, values=rep(1.5, nv7), lbound=0.001, name="es"),
    mxAlgebra(ac %*% t(ac) + as %*% t(as), name="A"),
    mxAlgebra(cc %*% t(cc) + cs %*% t(cs), name="C"),
    mxAlgebra(tc %*% t(tc) + ts %*% t(ts), name="Tt"),
    mxAlgebra(ec %*% t(ec) + es %*% t(es), name="E"),
    mxAlgebra(A + C + Tt + E, name="V"),
    mxMatrix("Full", 1, nv7, free=TRUE,
             values=c(8.5, 8.1, 7.5, 9.0, 8.3, 8.6, 9.8), name="MuB"),
    mxMatrix("Full", 1, 1, free=kA_free, values=kA_val, name="kA"),
    mxMatrix("Full", 1, 1, free=kC_free, values=kC_val, name="kC"),
    mxAlgebra(MuB + t(ac)*kA + t(cc)*kC, name="MuW"),
    mxFitFunctionMultigroup(group_names)),
    group_list))
}

# Fit M2 (A+C decomposition) WITH HS
cat("\n  Fitting M2 (A+C decomposition) WITH HS...\n")
m2_full <- build_decomp_flex("M2full", TRUE, TRUE, include_hs = TRUE)
m2_full_fit <- mxTryHard(m2_full, extraTries = 30, silent = TRUE)
cat(sprintf("  M2 (with HS): -2LL=%.2f, status=%d\n",
            summary(m2_full_fit)$Minus2LogLikelihood,
            m2_full_fit$output$status$code))

# Fit M2 WITHOUT HS
cat("  Fitting M2 (A+C decomposition) WITHOUT HS...\n")
m2_nohs <- build_decomp_flex("M2nohs", TRUE, TRUE, include_hs = FALSE)
m2_nohs_fit <- mxTryHard(m2_nohs, extraTries = 30, silent = TRUE)
cat(sprintf("  M2 (no HS): -2LL=%.2f, status=%d\n",
            summary(m2_nohs_fit)$Minus2LogLikelihood,
            m2_nohs_fit$output$status$code))

# Fit M3 (genetic only) WITH HS
cat("  Fitting M3 (genetic only) WITH HS...\n")
m3_full <- build_decomp_flex("M3full", TRUE, FALSE, kC_val = 0, include_hs = TRUE)
m3_full_fit <- mxTryHard(m3_full, extraTries = 30, silent = TRUE)
cat(sprintf("  M3 (with HS): -2LL=%.2f, status=%d\n",
            summary(m3_full_fit)$Minus2LogLikelihood,
            m3_full_fit$output$status$code))

# Fit M3 WITHOUT HS
cat("  Fitting M3 (genetic only) WITHOUT HS...\n")
m3_nohs <- build_decomp_flex("M3nohs", TRUE, FALSE, kC_val = 0, include_hs = FALSE)
m3_nohs_fit <- mxTryHard(m3_nohs, extraTries = 30, silent = TRUE)
cat(sprintf("  M3 (no HS): -2LL=%.2f, status=%d\n",
            summary(m3_nohs_fit)$Minus2LogLikelihood,
            m3_nohs_fit$output$status$code))

# Fit M4 (environmental only) WITH HS
cat("  Fitting M4 (environmental only) WITH HS...\n")
m4_full <- build_decomp_flex("M4full", FALSE, TRUE, kA_val = 0, include_hs = TRUE)
m4_full_fit <- mxTryHard(m4_full, extraTries = 30, silent = TRUE)
cat(sprintf("  M4 (with HS): -2LL=%.2f, status=%d\n",
            summary(m4_full_fit)$Minus2LogLikelihood,
            m4_full_fit$output$status$code))

# Fit M4 WITHOUT HS
cat("  Fitting M4 (environmental only) WITHOUT HS...\n")
m4_nohs <- build_decomp_flex("M4nohs", FALSE, TRUE, kA_val = 0, include_hs = FALSE)
m4_nohs_fit <- mxTryHard(m4_nohs, extraTries = 30, silent = TRUE)
cat(sprintf("  M4 (no HS): -2LL=%.2f, status=%d\n",
            summary(m4_nohs_fit)$Minus2LogLikelihood,
            m4_nohs_fit$output$status$code))

# ── Compare decomposition results ─────────────────────────────────────
cat("\n")
cat(strrep("-", 70), "\n")
cat("Between-Group Decomposition Comparison: With vs Without HS\n")
cat(strrep("-", 70), "\n")

if (m2_full_fit$output$status$code == 0) {
  kA_f <- m2_full_fit$kA$values[1,1]
  kC_f <- m2_full_fit$kC$values[1,1]
  ac_f <- m2_full_fit$ac$values[,1]
  cc_f <- m2_full_fit$cc$values[,1]
  da_f <- ac_f * kA_f
  dc_f <- cc_f * kC_f
  dt_f <- da_f + dc_f
  pct_a_f <- ifelse(abs(dt_f) > 0.001, 100 * da_f / dt_f, NA)
  cat(sprintf("\n  With HS: kA=%.4f, kC=%.4f\n", kA_f, kC_f))
}

if (m2_nohs_fit$output$status$code == 0) {
  kA_n <- m2_nohs_fit$kA$values[1,1]
  kC_n <- m2_nohs_fit$kC$values[1,1]
  ac_n <- m2_nohs_fit$ac$values[,1]
  cc_n <- m2_nohs_fit$cc$values[,1]
  da_n <- ac_n * kA_n
  dc_n <- cc_n * kC_n
  dt_n <- da_n + dc_n
  pct_a_n <- ifelse(abs(dt_n) > 0.001, 100 * da_n / dt_n, NA)
  cat(sprintf("  No HS:   kA=%.4f, kC=%.4f\n", kA_n, kC_n))
}

cat(sprintf("\n  %-8s  %12s  %12s  %12s  %12s\n",
            "Subtest", "%A(full)", "%A(no-HS)", "Gap(full)", "Gap(no-HS)"))
cat("  ", strrep("-", 60), "\n")
for (i in 1:nv7) {
  cat(sprintf("  %-8s  %12.1f  %12.1f  %12.3f  %12.3f\n",
              sub_labels7[i],
              ifelse(is.na(pct_a_f[i]), NA, pct_a_f[i]),
              ifelse(is.na(pct_a_n[i]), NA, pct_a_n[i]),
              dt_f[i], dt_n[i]))
}

# Overall genetic share
cat(sprintf("\n  Overall genetic share of predicted gap:\n"))
cat(sprintf("    With HS: %.1f%%\n", 100 * sum(da_f) / sum(dt_f)))
cat(sprintf("    No HS:   %.1f%%\n", 100 * sum(da_n) / sum(dt_n)))

# LRT comparison: M3 vs M2
cat("\n  LRT: M3 (genetic only) vs M2 (A+C):\n")
chi2_f <- summary(m3_full_fit)$Minus2LogLikelihood - summary(m2_full_fit)$Minus2LogLikelihood
chi2_n <- summary(m3_nohs_fit)$Minus2LogLikelihood - summary(m2_nohs_fit)$Minus2LogLikelihood
p_f <- pchisq(chi2_f, 1, lower.tail = FALSE)
p_n <- pchisq(chi2_n, 1, lower.tail = FALSE)
cat(sprintf("    With HS: chi2=%.2f, p=%.4f — env component %s\n",
            chi2_f, p_f, ifelse(p_f < 0.05, "NEEDED", "not needed")))
cat(sprintf("    No HS:   chi2=%.2f, p=%.4f — env component %s\n",
            chi2_n, p_n, ifelse(p_n < 0.05, "NEEDED", "not needed")))

# M4 vs M2
cat("\n  LRT: M4 (env only) vs M2 (A+C):\n")
chi2_f4 <- summary(m4_full_fit)$Minus2LogLikelihood - summary(m2_full_fit)$Minus2LogLikelihood
chi2_n4 <- summary(m4_nohs_fit)$Minus2LogLikelihood - summary(m2_nohs_fit)$Minus2LogLikelihood
p_f4 <- pchisq(chi2_f4, 1, lower.tail = FALSE)
p_n4 <- pchisq(chi2_n4, 1, lower.tail = FALSE)
cat(sprintf("    With HS: chi2=%.2f, p=%.4f — genetic component %s\n",
            chi2_f4, p_f4, ifelse(p_f4 < 0.05, "NEEDED", "not needed")))
cat(sprintf("    No HS:   chi2=%.2f, p=%.4f — genetic component %s\n",
            chi2_n4, p_n4, ifelse(p_n4 < 0.05, "NEEDED", "not needed")))

# ── Save results ──────────────────────────────────────────────────────
results <- list(
  cross_cov = cross_cov,
  A_estimates = list(mzdz = A_mzdz, mzfs = A_mzfs, fshs = A_fshs),
  C_estimates = list(mzdz = C_mzdz, mzfs = C_mzfs, fshs = C_fshs),
  ip_full = list(ac = ac_full, cc = cc_full,
                 A = A_full, C = C_full, V = V_full,
                 status = ip_full_fit$output$status$code),
  ip_nohs = list(ac = ac_nohs, cc = cc_nohs,
                 A = A_nohs, C = C_nohs, V = V_nohs,
                 status = ip_nohs_fit$output$status$code),
  decomp_full = if (m2_full_fit$output$status$code == 0)
    list(kA = kA_f, kC = kC_f, ac = ac_f, cc = cc_f, pct_a = pct_a_f),
  decomp_nohs = if (m2_nohs_fit$output$status$code == 0)
    list(kA = kA_n, kC = kC_n, ac = ac_n, cc = cc_n, pct_a = pct_a_n),
  lrt_full = list(m3v2 = c(chi2 = chi2_f, p = p_f),
                  m4v2 = c(chi2 = chi2_f4, p = p_f4)),
  lrt_nohs = list(m3v2 = c(chi2 = chi2_n, p = p_n),
                  m4v2 = c(chi2 = chi2_n4, p = p_n4))
)
saveRDS(results, "results_hs_ip_sensitivity.rds")
cat("\nResults saved to results_hs_ip_sensitivity.rds\n")
