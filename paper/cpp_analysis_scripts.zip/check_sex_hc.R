library(data.table)
library(fixest)

d <- as.data.table(readRDS("prepared_data.rds"))
growth <- as.data.table(readRDS("prepared_growth.rds"))

# Merge anthropometrics at age 7
for (meas in c("head_circ_cm", "height_cm", "weight_g")) {
  g7 <- growth[measure == meas & age_months == 84,
               .(case_id = as.character(case_id), value)]
  short <- gsub("_cm$|_g$", "", meas)
  setnames(g7, "value", paste0(short, "_7yr"))
  d <- merge(d, g7, by = "case_id", all.x = TRUE)
}
d[, weight_7yr := weight_7yr / 1000]

hc <- d[race %in% c(1, 2) & !is.na(wisc_fsiq) & !is.na(head_circ_7yr)]
cat(sprintf("Sample: %d (Male=%d, Female=%d)\n",
            nrow(hc), sum(hc$sex == 1), sum(hc$sex == 2)))

# Raw means
cat("\nRaw means:\n")
for (s in c(1, 2)) {
  sl <- ifelse(s == 1, "Male", "Female")
  sub <- hc[sex == s]
  cat(sprintf("  %s: HC=%.2f (SD=%.2f), IQ=%.1f (SD=%.1f), Ht=%.1f, Wt=%.1f\n",
              sl, mean(sub$head_circ_7yr), sd(sub$head_circ_7yr),
              mean(sub$wisc_fsiq), sd(sub$wisc_fsiq),
              mean(sub$height_7yr, na.rm=TRUE), mean(sub$weight_7yr, na.rm=TRUE)))
}

# Models
cat("\n=== OLS Models ===\n")
m1 <- feols(head_circ_7yr ~ factor(sex), data = hc, vcov = "hetero")
cat(sprintf("1. Raw gap:                      b=%.3f cm (SE=%.3f), p=%.1e\n",
            coef(m1)["factor(sex)2"], se(m1)["factor(sex)2"],
            2*pnorm(-abs(coef(m1)["factor(sex)2"]/se(m1)["factor(sex)2"]))))

m2 <- feols(head_circ_7yr ~ factor(sex) + wisc_fsiq, data = hc, vcov = "hetero")
cat(sprintf("2. | IQ:                         b=%.3f cm (SE=%.3f), p=%.1e\n",
            coef(m2)["factor(sex)2"], se(m2)["factor(sex)2"],
            2*pnorm(-abs(coef(m2)["factor(sex)2"]/se(m2)["factor(sex)2"]))))

m3 <- feols(head_circ_7yr ~ factor(sex) + wisc_fsiq + factor(race),
            data = hc, vcov = "hetero")
cat(sprintf("3. | IQ + race:                  b=%.3f cm (SE=%.3f), p=%.1e\n",
            coef(m3)["factor(sex)2"], se(m3)["factor(sex)2"],
            2*pnorm(-abs(coef(m3)["factor(sex)2"]/se(m3)["factor(sex)2"]))))

hc_full <- hc[!is.na(height_7yr) & !is.na(weight_7yr)]
m4 <- feols(head_circ_7yr ~ factor(sex) + wisc_fsiq + factor(race) + height_7yr + weight_7yr,
            data = hc_full, vcov = "hetero")
cat(sprintf("4. | IQ + race + ht + wt:        b=%.3f cm (SE=%.3f), p=%.1e\n",
            coef(m4)["factor(sex)2"], se(m4)["factor(sex)2"],
            2*pnorm(-abs(coef(m4)["factor(sex)2"]/se(m4)["factor(sex)2"]))))

# Within family
cat("\n=== Within-Family (Mother FE) ===\n")
hc[, n_sibs := .N, by = mother_id]
hc_sib <- hc[n_sibs >= 2]
hc_sib[, n_male := sum(sex == 1), by = mother_id]
hc_sib[, n_female := sum(sex == 2), by = mother_id]
hc_mixed <- hc_sib[n_male >= 1 & n_female >= 1]
cat(sprintf("Mixed-sex sibships: %d children, %d families\n",
            nrow(hc_mixed), uniqueN(hc_mixed$mother_id)))

m5 <- feols(head_circ_7yr ~ factor(sex) + wisc_fsiq | mother_id,
            data = hc_mixed, vcov = ~mother_id)
cat(sprintf("5. FE | IQ:                      b=%.3f cm (SE=%.3f), p=%.4f\n",
            coef(m5)["factor(sex)2"], se(m5)["factor(sex)2"],
            2*pnorm(-abs(coef(m5)["factor(sex)2"]/se(m5)["factor(sex)2"]))))

hc_mixed_full <- hc_mixed[!is.na(height_7yr) & !is.na(weight_7yr)]
m6 <- feols(head_circ_7yr ~ factor(sex) + wisc_fsiq + height_7yr + weight_7yr | mother_id,
            data = hc_mixed_full, vcov = ~mother_id)
cat(sprintf("6. FE | IQ + ht + wt:            b=%.3f cm (SE=%.3f), p=%.4f\n",
            coef(m6)["factor(sex)2"], se(m6)["factor(sex)2"],
            2*pnorm(-abs(coef(m6)["factor(sex)2"]/se(m6)["factor(sex)2"]))))

# IQ-matched bins
cat("\n=== HC by Sex at Matched IQ Bins ===\n")
hc[, iq_bin := cut(wisc_fsiq, breaks = seq(60, 140, 10))]
tab <- hc[!is.na(iq_bin), .(hc_m = mean(head_circ_7yr[sex == 1]),
                              hc_f = mean(head_circ_7yr[sex == 2]),
                              n_m = sum(sex == 1),
                              n_f = sum(sex == 2)),
           by = iq_bin][order(iq_bin)]
tab[, gap := hc_m - hc_f]
cat(sprintf("%-15s  %6s  %6s  %6s  %5s  %5s\n", "IQ bin", "HC_M", "HC_F", "Gap", "n_M", "n_F"))
for (i in 1:nrow(tab)) {
  if (tab$n_m[i] >= 10 & tab$n_f[i] >= 10)
    cat(sprintf("%-15s  %6.2f  %6.2f  %6.2f  %5d  %5d\n",
                as.character(tab$iq_bin[i]),
                tab$hc_m[i], tab$hc_f[i], tab$gap[i], tab$n_m[i], tab$n_f[i]))
}

# Express gap in SD units
pooled_hc_sd <- sd(hc$head_circ_7yr)
cat(sprintf("\nPooled HC SD: %.2f cm\n", pooled_hc_sd))
cat(sprintf("Raw sex gap: %.2f cm = %.2f SD\n",
            mean(hc[sex==1]$head_circ_7yr) - mean(hc[sex==2]$head_circ_7yr),
            (mean(hc[sex==1]$head_circ_7yr) - mean(hc[sex==2]$head_circ_7yr)) / pooled_hc_sd))

cat("\nDone.\n")
