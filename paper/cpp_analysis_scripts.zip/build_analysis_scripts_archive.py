"""Build the public CPP analysis-code archive.

The builder refuses to overwrite an existing archive and records SHA-256 hashes for
every included file in an internal manifest.  Raw data and fitted-model binaries are
intentionally excluded; the public release provides the analysis inputs separately.
"""

from __future__ import annotations

import csv
import hashlib
import io
from pathlib import Path
import re
import zipfile


ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT / "cpp_analysis_scripts.zip"
SCRIPT_INDEX_FILES = {"00_run_all.R"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def selected_files() -> list[Path]:
    # Include the declared production pipeline, not exploratory one-off
    # diagnostics left in the working directory.
    script_names = set(SCRIPT_INDEX_FILES)
    for index_name in SCRIPT_INDEX_FILES:
        text = (ROOT / index_name).read_text(encoding="utf-8")
        script_names.update(re.findall(r'"([^"\r\n]+\.R)"', text))
    script_names.add("case_id_helpers.R")
    files = [ROOT / name for name in sorted(script_names)]
    files.extend(
        [
            ROOT / "cpp_analysis_paper.tex",
            ROOT / "build_analysis_scripts_archive.py",
        ]
    )
    missing = [str(path.name) for path in files if not path.is_file()]
    if missing:
        raise FileNotFoundError(f"Required archive inputs are missing: {missing}")
    return sorted(set(files), key=lambda path: path.name.lower())


def build() -> None:
    if OUTPUT.exists():
        raise FileExistsError(f"Refusing to overwrite existing archive: {OUTPUT}")

    inputs = selected_files()
    manifest_rows: list[tuple[str, int, str]] = []

    with zipfile.ZipFile(OUTPUT, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in inputs:
            data = path.read_bytes()
            archive.writestr(path.name, data)
            manifest_rows.append((path.name, len(data), sha256(data)))

        buffer = io.StringIO(newline="")
        writer = csv.writer(buffer)
        writer.writerow(["file", "bytes", "sha256"])
        writer.writerows(manifest_rows)
        archive.writestr("MANIFEST.csv", buffer.getvalue().encode("utf-8"))

    with zipfile.ZipFile(OUTPUT) as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"ZIP CRC validation failed for {bad}")

    print(f"Created {OUTPUT}")
    print(f"Included {len(inputs)} files plus MANIFEST.csv")
    print(f"SHA256 {sha256(OUTPUT.read_bytes())}")


if __name__ == "__main__":
    build()
