#!/usr/bin/env Rscript
# 08_smoking.R — Prenatal smoking effects on BW and IQ (OLS + sibling FE)

library(data.table)
library(fixest)

cat("--- Prenatal Smoking, Birth Weight, and IQ ---\n")
cat("NOTE: Smoking variables were recorded at prenatal registration.\n")
cat("'Cigarettes Per Day Now' reflects active smoking during pregnancy.\n\n")

d <- readRDS("prepared_data.rds")

# ---- 1. Descriptive ----
sm <- d[!is.na(smoker)]
cat(sprintf("Children with smoking data: %d\n", nrow(sm)))
cat(sprintf("  Smokers: %d (%.1f%%)\n", sum(sm$smoker==1), 100*mean(sm$smoker==1)))
cat(sprintf("  Mean cigs/day (smokers): %.1f\n", mean(sm[smoker==1]$cigs_day, na.rm=TRUE)))
cat(sprintf("  Mean years smoked (smokers): %.1f\n", mean(sm[smoker==1]$years_smoked, na.rm=TRUE)))

# Smoking by demographics
cat("\nSmoking rate by race:\n")
sm[, .(pct_smoke = 100*mean(smoker==1), N = .N), by = race_label][order(-pct_smoke)]  |> print()
cat("\nSmoking rate by education:\n")
sm[!is.na(educ_yrs), .(pct_smoke = 100*mean(smoker==1), N = .N),
   by = .(educ = ifelse(educ_yrs < 12, "<12yr", ifelse(educ_yrs == 12, "12yr", ">12yr")))][order(-pct_smoke)] |> print()

# BW by smoking
cat("\nBirth weight by smoking status:\n")
cat(sprintf("  Non-smokers: %.0f g (SD=%.0f, n=%d)\n",
            mean(sm[smoker==0]$birth_wt_g, na.rm=TRUE),
            sd(sm[smoker==0]$birth_wt_g, na.rm=TRUE),
            sum(!is.na(sm[smoker==0]$birth_wt_g))))
cat(sprintf("  Smokers:     %.0f g (SD=%.0f, n=%d)\n",
            mean(sm[smoker==1]$birth_wt_g, na.rm=TRUE),
            sd(sm[smoker==1]$birth_wt_g, na.rm=TRUE),
            sum(!is.na(sm[smoker==1]$birth_wt_g))))
cat(sprintf("  Difference:  %.0f g\n",
            mean(sm[smoker==0]$birth_wt_g, na.rm=TRUE) - mean(sm[smoker==1]$birth_wt_g, na.rm=TRUE)))

# ---- 2. Smoking → BW ----
cat("\n--- Smoking -> Birth Weight ---\n\n")

bw_sm <- sm[!is.na(birth_wt_g) & birth_wt_g > 400]
bw_sm[, n_tested := .N, by = mother_id]
bw_fe <- bw_sm[n_tested >= 2]

# OLS
ols_bw <- feols(birth_wt_g ~ smoker + factor(sex) + factor(race) + maternal_age + educ_yrs + gest_age + birth_order,
                data = bw_sm, vcov = "hetero")
# Mother FE
fe_bw <- feols(birth_wt_g ~ smoker + factor(sex) + gest_age + birth_order | mother_id,
               data = bw_fe, vcov = ~mother_id)

cat(sprintf("  OLS: b=%.1f g (se=%.1f)\n", coef(ols_bw)["smoker"], se(ols_bw)["smoker"]))
cat(sprintf("  Mother FE: b=%.1f g (se=%.1f), n=%d families\n",
            coef(fe_bw)["smoker"], se(fe_bw)["smoker"], fixest::fixef(fe_bw) |> length()))

# Dose-response (OLS)
cat("\n  Dose-response (OLS, per cigarette/day):\n")
dr_bw <- feols(birth_wt_g ~ cigs_day + factor(sex) + factor(race) + maternal_age + gest_age,
               data = bw_sm[!is.na(cigs_day) & smoker==1], vcov = "hetero")
cat(sprintf("    b=%.1f g/cig (se=%.1f), n=%d smokers\n",
            coef(dr_bw)["cigs_day"], se(dr_bw)["cigs_day"], nobs(dr_bw)))

# Dose-response (Mother FE) — among smoking mothers with varying doses
cat("\n  Dose-response (Mother FE):\n")
dr_fe_bw <- bw_fe[smoker == 1 & !is.na(cigs_day)]
cat(sprintf("    Smoking mothers with dose variation: %d children, %d families\n",
            nrow(dr_fe_bw), uniqueN(dr_fe_bw$mother_id)))
if (nrow(dr_fe_bw) > 100) {
  dr_fe <- feols(birth_wt_g ~ cigs_day + factor(sex) + gest_age + birth_order | mother_id,
                 data = dr_fe_bw, vcov = ~mother_id)
  cat(sprintf("    b=%.1f g/cig (se=%.1f)\n", coef(dr_fe)["cigs_day"], se(dr_fe)["cigs_day"]))
}

# ---- 3. Smoking → IQ ----
cat("\n--- Smoking -> IQ ---\n\n")

iq_sm <- sm[!is.na(wisc_fsiq)]
iq_sm[, n_tested := .N, by = mother_id]
iq_fe <- iq_sm[n_tested >= 2]

outcomes <- c("wisc_fsiq_z", "wisc_viq_z", "wisc_piq_z", "sb_iq_z", "g_factor_z")
outcome_labels <- c("WISC FSIQ", "WISC VIQ", "WISC PIQ", "SB IQ (4yr)", "Latent g")

cat(sprintf("%-12s  %10s  %10s  %10s\n",
            "Outcome", "OLS", "OLS_adj", "Mother_FE"))
cat(paste(rep("-", 50), collapse=""), "\n")

sm_results <- list()
for (i in seq_along(outcomes)) {
  y <- outcomes[i]
  ols1 <- feols(as.formula(paste(y, "~ smoker")), data = iq_sm, vcov = "hetero")
  ols2 <- feols(as.formula(paste(y, "~ smoker + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal + birth_order")),
                data = iq_sm, vcov = "hetero")
  fe <- feols(as.formula(paste(y, "~ smoker + factor(sex) + birth_order | mother_id")),
              data = iq_fe, vcov = ~mother_id)

  sm_results[[outcomes[i]]] <- list(ols1 = ols1, ols2 = ols2, fe = fe)

  cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)  %7.4f(%s)\n",
              outcome_labels[i],
              coef(ols1)["smoker"], sprintf("%.4f", se(ols1)["smoker"]),
              coef(ols2)["smoker"], sprintf("%.4f", se(ols2)["smoker"]),
              coef(fe)["smoker"], sprintf("%.4f", se(fe)["smoker"])))
}

# ---- 4. Dose-response within families for IQ ----
cat("\n--- Dose-Response Within Families (IQ) ---\n\n")

# Among all families: does smoking dose predict IQ within families?
dr_iq <- iq_fe[!is.na(cigs_day)]
cat(sprintf("Children with cigs_day + sibling: %d, families: %d\n",
            nrow(dr_iq), uniqueN(dr_iq$mother_id)))

if (nrow(dr_iq) > 100) {
  cat(sprintf("\n%-12s  %10s  %10s\n", "Outcome", "OLS_dose", "FE_dose"))
  cat(paste(rep("-", 36), collapse=""), "\n")
  for (i in 1:3) {
    y <- outcomes[i]
    ols_dr <- feols(as.formula(paste(y, "~ cigs_day + factor(sex) + factor(race) + maternal_age + educ_yrs")),
                    data = iq_sm[!is.na(cigs_day)], vcov = "hetero")
    fe_dr <- feols(as.formula(paste(y, "~ cigs_day + factor(sex) + birth_order | mother_id")),
                   data = dr_iq, vcov = ~mother_id)
    cat(sprintf("%-12s  %7.4f(%s)  %7.4f(%s)\n",
                outcome_labels[i],
                coef(ols_dr)["cigs_day"], sprintf("%.4f", se(ols_dr)["cigs_day"]),
                coef(fe_dr)["cigs_day"], sprintf("%.4f", se(fe_dr)["cigs_day"])))
  }
}

# ---- 5. Mediation check: does BW mediate smoking→IQ? ----
cat("\n--- Mediation: Does BW Explain Smoking -> IQ? ---\n\n")

med <- iq_sm[!is.na(birth_wt_g) & birth_wt_g > 400]
med[, bw_z := as.numeric(scale(birth_wt_g))]

m_no_bw <- feols(wisc_fsiq_z ~ smoker + factor(sex) + factor(race) + maternal_age + educ_yrs + gest_age + birth_order,
                 data = med, vcov = "hetero")
m_with_bw <- feols(wisc_fsiq_z ~ smoker + bw_z + factor(sex) + factor(race) + maternal_age + educ_yrs + gest_age + birth_order,
                   data = med, vcov = "hetero")

cat(sprintf("  Without BW control: b(smoker) = %.4f (se=%.4f)\n",
            coef(m_no_bw)["smoker"], se(m_no_bw)["smoker"]))
cat(sprintf("  With BW control:    b(smoker) = %.4f (se=%.4f)\n",
            coef(m_with_bw)["smoker"], se(m_with_bw)["smoker"]))
cat(sprintf("  Attenuation: %.1f%%\n",
            100 * (1 - coef(m_with_bw)["smoker"] / coef(m_no_bw)["smoker"])))

# ---- 6. Smoking → IQ g-specificity ----
cat("\n--- Smoking Effects by Subtest (g-Specificity) ---\n\n")

subtests <- c("wisc_info_z", "wisc_comp_z", "wisc_vocab_z", "wisc_digit_z", "wisc_piq_z")
subtest_labels <- c("Information", "Comprehension", "Vocabulary", "Digit Span", "PIQ")

cat(sprintf("%-16s  %8s  %8s  %8s  %8s\n", "Subtest", "OLS_adj", "SE", "FE", "SE"))
cat(paste(rep("-", 56), collapse=""), "\n")

for (i in seq_along(subtests)) {
  y <- subtests[i]
  sub_ols <- iq_sm[!is.na(get(y))]
  sub_fe <- iq_fe[!is.na(get(y))]
  if (nrow(sub_ols) < 100) next

  m_ols <- feols(as.formula(paste(y, "~ smoker + factor(sex) + factor(race) + maternal_age + educ_yrs + sei_decimal")),
                 data = sub_ols, vcov = "hetero")
  m_fe <- feols(as.formula(paste(y, "~ smoker + factor(sex) + birth_order | mother_id")),
                data = sub_fe, vcov = ~mother_id)

  cat(sprintf("%-16s  %8.4f  %8.4f  %8.4f  %8.4f\n",
              subtest_labels[i],
              coef(m_ols)["smoker"], se(m_ols)["smoker"],
              coef(m_fe)["smoker"], se(m_fe)["smoker"]))
}

# ---- 7. Save ----
saveRDS(list(sm_results = sm_results, ols_bw = ols_bw, fe_bw = fe_bw),
        "results_smoking.rds")
cat("Done.\n")
