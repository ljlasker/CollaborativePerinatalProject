#!/usr/bin/env Rscript
# remaining_items.R
# Items 40, 38, 39 from the audit checklist

library(data.table)
library(fixest)

d <- readRDS("prepared_data.rds")

# Load HC (and height/weight) from growth data — not in prepared_data.rds
growth <- as.data.table(readRDS("prepared_growth.rds"))
for (meas in c("head_circ_cm", "height_cm", "weight_g")) {
  g7 <- growth[measure == meas & age_months == 84,
               .(case_id = as.character(case_id), value)]
  short <- gsub("_cm$|_g$", "", meas)
  short <- paste0(short, "_7yr")
  setnames(g7, "value", short)
  d <- merge(d, g7, by = "case_id", all.x = TRUE)
}
cat(sprintf("HC available: %d / %d\n", sum(!is.na(d$head_circ_7yr)), nrow(d)))

links <- fread(file.path("..", "clean", "cpp_kinship_links.csv"),
               colClasses = c(id_1 = "character", id_2 = "character",
                              mother_id = "character"))

# ══════════════════════════════════════════════════════════════════════
# ITEM 40: Kelley's Paradox Test for HC Matching Regression
# ══════════════════════════════════════════════════════════════════════
cat("\n")
cat("=== ITEM 40: Kelley's Paradox Test ===\n\n")

# The finding: Blacks and Whites have the same HC→IQ regression slope,
# but Black intercept is higher (+0.072 SD at matched IQ, Blacks have
# larger heads). Could this be regression to the mean?

# Test: Resample Whites to match Black IQ distribution. If the same
# intercept shift appears in the resampled Whites (relative to all Whites),
# then it's a statistical artifact. If not, it's a real group difference.

d_hc <- d[race %in% c(1, 2) & !is.na(wisc_fsiq) & !is.na(head_circ_7yr) & !is.na(sex)]
d_hc[, iq_z := scale(wisc_fsiq), by = sex]
d_hc[, hc_z := scale(head_circ_7yr), by = sex]

cat(sprintf("Sample: White=%d, Black=%d\n",
            d_hc[race == 1, .N], d_hc[race == 2, .N]))
cat(sprintf("Mean IQ (z): White=%.3f, Black=%.3f\n",
            d_hc[race == 1, mean(iq_z)], d_hc[race == 2, mean(iq_z)]))
cat(sprintf("Mean HC (z): White=%.3f, Black=%.3f\n",
            d_hc[race == 1, mean(hc_z)], d_hc[race == 2, mean(hc_z)]))

# Original regression: HC ~ IQ * race
m_orig <- lm(hc_z ~ iq_z * factor(race), data = d_hc)
cat(sprintf("\nOriginal HC ~ IQ + Race + IQ:Race:\n"))
cat(sprintf("  IQ slope: %.4f\n", coef(m_orig)["iq_z"]))
cat(sprintf("  Race intercept (Black vs White): %.4f (p=%.4f)\n",
            coef(m_orig)["factor(race)2"],
            summary(m_orig)$coef["factor(race)2", 4]))
cat(sprintf("  IQ:Race interaction: %.4f (p=%.4f)\n",
            coef(m_orig)["iq_z:factor(race)2"],
            summary(m_orig)$coef["iq_z:factor(race)2", 4]))

# Resampling test: draw White subsample matching Black IQ distribution
set.seed(42)

# Create IQ bins for matching BEFORE subsetting
d_hc[, iq_bin := cut(iq_z, breaks = seq(-4, 4, by = 0.5), include.lowest = TRUE)]
black_bin_counts <- d_hc[race == 2, .N, by = iq_bin]
white_data <- d_hc[race == 1]

n_iter <- 1000
intercept_diffs <- numeric(n_iter)

for (iter in 1:n_iter) {
  # Sample Whites to match Black IQ distribution (by bins)
  sampled_idx <- c()
  for (i in 1:nrow(black_bin_counts)) {
    bin_val <- black_bin_counts[i, iq_bin]
    n_needed <- black_bin_counts[i, N]
    available <- which(white_data$iq_bin == bin_val)
    if (length(available) >= n_needed) {
      sampled_idx <- c(sampled_idx, sample(available, n_needed, replace = FALSE))
    } else if (length(available) > 0) {
      sampled_idx <- c(sampled_idx, sample(available, n_needed, replace = TRUE))
    }
  }

  sampled_idx <- unique(sampled_idx)
  white_matched <- white_data[sampled_idx]
  unmatched_idx <- setdiff(seq_len(nrow(white_data)), sampled_idx)
  white_unmatched <- white_data[unmatched_idx]

  # Regression: HC ~ IQ + group (matched_white vs unmatched_white)
  wm <- copy(white_matched); wm[, matched := 1L]
  wu <- copy(white_unmatched); wu[, matched := 0L]
  combined <- rbind(wm, wu)

  m_temp <- lm(hc_z ~ iq_z + factor(matched), data = combined)
  intercept_diffs[iter] <- coef(m_temp)["factor(matched)1"]
}

cat(sprintf("\nKelley's Paradox resampling test (n=%d iterations):\n", n_iter))
cat(sprintf("  Mean intercept diff (matched vs unmatched Whites): %.4f\n",
            mean(intercept_diffs)))
cat(sprintf("  SD: %.4f\n", sd(intercept_diffs)))
cat(sprintf("  95%% CI: [%.4f, %.4f]\n",
            quantile(intercept_diffs, 0.025), quantile(intercept_diffs, 0.975)))
cat(sprintf("  Original Black-White intercept diff: %.4f\n",
            coef(m_orig)["factor(race)2"]))

# If Kelley's Paradox explained the finding, the intercept shift for
# IQ-matched Whites should be similar to the Black intercept shift.
# If it's near zero, the finding is NOT a Kelley artifact.

# Alternative test: match Whites to Black HC+IQ joint distribution
# and see if they show same intercept
cat("\nDirect test: Black vs IQ-distribution-matched Whites:\n")
# Pool matched whites and blacks, regress HC ~ IQ + race
set.seed(123)
best_match <- NULL
for (iter in 1:100) {
  sampled_idx <- c()
  for (i in 1:nrow(black_bin_counts)) {
    bin_val <- black_bin_counts[i, iq_bin]
    n_needed <- black_bin_counts[i, N]
    available <- which(white_data$iq_bin == bin_val)
    if (length(available) >= n_needed) {
      sampled_idx <- c(sampled_idx, sample(available, n_needed, replace = FALSE))
    } else if (length(available) > 0) {
      sampled_idx <- c(sampled_idx, sample(available, n_needed, replace = TRUE))
    }
  }

  w_samp <- copy(white_data[unique(sampled_idx)])
  w_samp[, group := "White_matched"]
  b_data <- copy(d_hc[race == 2])
  b_data[, group := "Black"]

  combined2 <- rbind(w_samp[, .(iq_z, hc_z, group)],
                     b_data[, .(iq_z, hc_z, group)])
  m2 <- lm(hc_z ~ iq_z + factor(group), data = combined2)
  if (is.null(best_match)) best_match <- coef(m2)["factor(group)White_matched"]
  else best_match <- c(best_match, coef(m2)["factor(group)White_matched"])
}
cat(sprintf("  Mean intercept (IQ-matched White vs Black): %.4f\n", mean(best_match)))
cat(sprintf("  SD: %.4f\n", sd(best_match)))
cat(sprintf("  → If near zero, IQ matching fully explains the difference\n"))
cat(sprintf("  → If negative, Blacks genuinely have larger HC at matched IQ\n"))


# ══════════════════════════════════════════════════════════════════════
# ITEM 38: HC BF/WF Correlations — Race-Pooled, All Kinship, Ambiguous
# ══════════════════════════════════════════════════════════════════════
cat("\n\n")
cat("=== ITEM 38: HC BF/WF Correlations — Extended ===\n\n")

sub_vars <- c("wisc_info", "wisc_comp", "wisc_vocab", "wisc_digit",
              "wisc_picarr", "wisc_block", "wisc_coding",
              "wrat_read_raw", "bender_gestalt",
              "wrat_spell_raw", "wrat_arith_raw", "goodenough_raw")
sub_labels <- c("Info", "Comp", "Vocab", "DigSp", "PicArr", "Block",
                "Code", "WRATrd", "Bend", "WRATsp", "WRATar", "Good")

# Build pair data with HC and IQ
d_hc2 <- d[!is.na(head_circ_7yr), c("case_id", "race", "sex", "head_circ_7yr",
                               "wisc_fsiq", sub_vars), with = FALSE]

pair_hc <- merge(links, d_hc2, by.x = "id_1", by.y = "case_id", suffixes = c("", ""))
setnames(pair_hc, c("race", "sex", "head_circ_7yr", "wisc_fsiq"),
         c("race_1", "sex_1", "hc_1", "iq_1"))
for (v in sub_vars) setnames(pair_hc, v, paste0(v, "_1"))

pair_hc <- merge(pair_hc, d_hc2, by.x = "id_2", by.y = "case_id", suffixes = c("", ""))
setnames(pair_hc, c("race", "sex", "head_circ_7yr", "wisc_fsiq"),
         c("race_2", "sex_2", "hc_2", "iq_2"))
for (v in sub_vars) setnames(pair_hc, v, paste0(v, "_2"))

# Classify pairs including ambiguous
pair_hc[, pair_class := fcase(
  pair_type == "MZ_twin", "MZ",
  pair_type %in% c("DZ_twin", "DZ_twin_probable"), "DZ",
  pair_type == "full_sibling", "FS",
  pair_type == "half_sibling", "HS",
  pair_type == "ambiguous_sibling", "AMB",
  default = NA_character_
)]
pair_hc <- pair_hc[!is.na(pair_class)]

# BF/WF decomposition function
bfwf <- function(x1, x2) {
  ok <- !is.na(x1) & !is.na(x2)
  if (sum(ok) < 20) return(c(N = sum(ok), BF = NA, WF = NA))
  means <- (x1[ok] + x2[ok]) / 2
  diffs <- x1[ok] - x2[ok]
  c(N = sum(ok), BF = cor(means, (x1[ok] + x2[ok]) / 2), WF = NA) # placeholder
}

# Proper BF/WF: BF = r(pair_mean_HC, pair_mean_IQ), WF = r(pair_diff_HC, pair_diff_IQ)
bfwf_hciq <- function(hc1, hc2, iq1, iq2) {
  ok <- !is.na(hc1) & !is.na(hc2) & !is.na(iq1) & !is.na(iq2)
  if (sum(ok) < 20) return(c(N = sum(ok), BF = NA_real_, WF = NA_real_))
  hc_mean <- (hc1[ok] + hc2[ok]) / 2
  hc_diff <- hc1[ok] - hc2[ok]
  iq_mean <- (iq1[ok] + iq2[ok]) / 2
  iq_diff <- iq1[ok] - iq2[ok]
  c(N = sum(ok),
    BF = cor(hc_mean, iq_mean),
    WF = cor(hc_diff, iq_diff))
}

# Race-pooled results by kinship type
cat("Race-Pooled HC-IQ BF/WF Correlations by Kinship:\n")
cat(sprintf("  %-8s  %5s  %8s  %8s\n", "Kinship", "N", "BF", "WF"))
cat("  ", strrep("-", 35), "\n")

for (pc in c("MZ", "DZ", "FS", "HS", "AMB")) {
  sub <- pair_hc[pair_class == pc]
  res <- bfwf_hciq(sub$hc_1, sub$hc_2, sub$iq_1, sub$iq_2)
  cat(sprintf("  %-8s  %5d  %8.3f  %8.3f\n", pc, res["N"],
              ifelse(is.na(res["BF"]), NA, res["BF"]),
              ifelse(is.na(res["WF"]), NA, res["WF"])))
}

# All kinship combined
cat("\n  All kinship combined:\n")
all_res <- bfwf_hciq(pair_hc$hc_1, pair_hc$hc_2, pair_hc$iq_1, pair_hc$iq_2)
cat(sprintf("  %-8s  %5d  %8.3f  %8.3f\n", "ALL", all_res["N"], all_res["BF"], all_res["WF"]))

# Non-twin sibling combined (FS + HS + AMB)
nontwin <- pair_hc[pair_class %in% c("FS", "HS", "AMB")]
nt_res <- bfwf_hciq(nontwin$hc_1, nontwin$hc_2, nontwin$iq_1, nontwin$iq_2)
cat(sprintf("  %-8s  %5d  %8.3f  %8.3f\n", "FS+HS+AMB", nt_res["N"], nt_res["BF"], nt_res["WF"]))

# Robustness across cognitive tests
cat("\nBF/WF Correlations of HC with Each Cognitive Test (FS pairs, race-pooled):\n")
cat(sprintf("  %-8s  %8s  %8s\n", "Test", "BF", "WF"))
cat("  ", strrep("-", 30), "\n")

fs_pairs <- pair_hc[pair_class == "FS"]
for (i in seq_along(sub_vars)) {
  v1 <- paste0(sub_vars[i], "_1")
  v2 <- paste0(sub_vars[i], "_2")
  res <- bfwf_hciq(fs_pairs$hc_1, fs_pairs$hc_2,
                   fs_pairs[[v1]], fs_pairs[[v2]])
  cat(sprintf("  %-8s  %8.3f  %8.3f\n", sub_labels[i], res["BF"], res["WF"]))
}

# Also for WISC FSIQ
res_fsiq <- bfwf_hciq(fs_pairs$hc_1, fs_pairs$hc_2, fs_pairs$iq_1, fs_pairs$iq_2)
cat(sprintf("  %-8s  %8.3f  %8.3f\n", "FSIQ", res_fsiq["BF"], res_fsiq["WF"]))


# ══════════════════════════════════════════════════════════════════════
# ITEM 39: Matching Asymmetry with Latent g from HOF
# ══════════════════════════════════════════════════════════════════════
cat("\n\n")
cat("=== ITEM 39: Matching Asymmetry with Latent g (HOF CFA) ===\n\n")

# Try to extract latent g from HOF CFA using lavaan
library(lavaan)

# HOF model: 4 group factors -> g
hof_syntax <- '
  Gc  =~ wisc_info + wisc_comp + wisc_vocab
  Gv  =~ wisc_picarr + wisc_block + goodenough_raw
  Grw =~ wrat_read_raw + wrat_spell_raw + wrat_arith_raw
  Gs  =~ wisc_digit + bender_gestalt + wisc_coding
  g   =~ Gc + Gv + Grw + Gs
  Gs ~~ 0*Gs
'

# Fit on full sample
d_cfa <- d[, c("case_id", "race", "sex", "head_circ_7yr", "wisc_fsiq", sub_vars), with = FALSE]
d_cfa <- d_cfa[complete.cases(d_cfa[, ..sub_vars])]

cat(sprintf("CFA sample: N=%d\n", nrow(d_cfa)))

hof_fit <- cfa(hof_syntax, data = d_cfa, estimator = "MLR")
cat(sprintf("HOF CFA: CFI=%.3f, RMSEA=%.3f\n",
            fitMeasures(hof_fit, "cfi"), fitMeasures(hof_fit, "rmsea")))

# Extract factor scores for g
g_scores <- lavPredict(hof_fit, type = "lv")
d_cfa[, g_hof := g_scores[, "g"]]

# Standardize by sex
d_cfa[, g_z := scale(g_hof), by = sex]
d_cfa[, hc_z := scale(head_circ_7yr), by = sex]

# Restrict to Black & White with HC
d_ma <- d_cfa[race %in% c(1, 2) & !is.na(hc_z)]

cat(sprintf("\nMatching Asymmetry sample: White=%d, Black=%d\n",
            d_ma[race == 1, .N], d_ma[race == 2, .N]))

# Raw gaps
g_gap <- d_ma[race == 1, mean(g_z)] - d_ma[race == 2, mean(g_z)]
hc_gap <- d_ma[race == 1, mean(hc_z)] - d_ma[race == 2, mean(hc_z)]
cat(sprintf("Raw gaps: g = %.3f SD, HC = %.3f SD\n", g_gap, hc_gap))

# Regression-based matching
m_g_ctrl_hc <- lm(g_z ~ hc_z + factor(race), data = d_ma)
m_hc_ctrl_g <- lm(hc_z ~ g_z + factor(race), data = d_ma)

g_gap_ctrl <- coef(m_g_ctrl_hc)["factor(race)2"]
hc_gap_ctrl <- coef(m_hc_ctrl_g)["factor(race)2"]

cat(sprintf("\nRegression-based matching (latent g from HOF):\n"))
cat(sprintf("  g gap controlling for HC: %.3f SD (%.1f%% remaining)\n",
            -g_gap_ctrl, 100 * (-g_gap_ctrl) / g_gap))
cat(sprintf("  HC gap controlling for g: %.3f SD (%.1f%% remaining)\n",
            -hc_gap_ctrl, ifelse(hc_gap != 0, 100 * (-hc_gap_ctrl) / hc_gap, NA)))

# Common regression line test
m_common <- lm(hc_z ~ g_z * factor(race), data = d_ma)
cat(sprintf("\nCommon regression (HC ~ g + Race + g:Race):\n"))
cat(sprintf("  g slope: %.4f\n", coef(m_common)["g_z"]))
cat(sprintf("  Race intercept (Black): %.4f (p=%.4f)\n",
            coef(m_common)["factor(race)2"],
            summary(m_common)$coef["factor(race)2", 4]))
cat(sprintf("  g:Race interaction: %.4f (p=%.4f)\n",
            coef(m_common)["g_z:factor(race)2"],
            summary(m_common)$coef["g_z:factor(race)2", 4]))

# Compare with WISC FSIQ version
d_ma2 <- d_ma[!is.na(wisc_fsiq)]
d_ma2[, iq_z := scale(wisc_fsiq), by = sex]

m_iq <- lm(hc_z ~ iq_z * factor(race), data = d_ma2)
cat(sprintf("\nComparison — WISC FSIQ version:\n"))
cat(sprintf("  IQ slope: %.4f\n", coef(m_iq)["iq_z"]))
cat(sprintf("  Race intercept (Black): %.4f (p=%.4f)\n",
            coef(m_iq)["factor(race)2"],
            summary(m_iq)$coef["factor(race)2", 4]))

# Binned matching with latent g
d_ma[, g_bin := cut(g_z, breaks = seq(-4, 4, by = 0.5), include.lowest = TRUE)]
bin_match <- d_ma[, .(
  n_w = sum(race == 1),
  n_b = sum(race == 2),
  hc_w = mean(hc_z[race == 1]),
  hc_b = mean(hc_z[race == 2])
), by = g_bin]
bin_match <- bin_match[n_w >= 10 & n_b >= 10]
bin_match[, hc_diff := hc_w - hc_b]
weighted_hc_diff <- weighted.mean(bin_match$hc_diff, bin_match$n_w + bin_match$n_b)
cat(sprintf("\nBinned matching (g in 0.5 SD bins): HC diff = %.3f SD\n",
            weighted_hc_diff))

cat("\nDone.\n")
