#!/usr/bin/env Rscript
# Compact audit of paper quantities affected by restoration of structural zeros
# in prior_livebirths.  This script is intentionally independent of saved model
# objects so every value below is regenerated from prepared_data.rds.

library(data.table)
library(fixest)
source("case_id_helpers.R")

d <- as.data.table(readRDS("prepared_data.rds"))

tidy_term <- function(model, term, analysis, outcome = "WISC FSIQ") {
  data.table(
    analysis = analysis,
    outcome = outcome,
    term = term,
    estimate = unname(coef(model)[term]),
    std_error = unname(se(model)[term]),
    p_value = unname(pvalue(model)[term]),
    n = nobs(model)
  )
}

results <- list()

# -----------------------------------------------------------------------------
# Fertility-completion proxy and family-size gradients
# -----------------------------------------------------------------------------
family_context <- d[, .(
  family_size = first(n_kids),
  max_mat_age = if (all(is.na(maternal_age))) NA_real_ else max(maternal_age, na.rm = TRUE)
), by = mother_id]

iq <- d[!is.na(mother_id) & race %in% c(1, 2)]
iq <- merge(iq, family_context, by = "mother_id", all.x = TRUE)
iq[, family_size_cap := pmin(family_size, 5)]
iq[, fert_group := fcase(
  max_mat_age < 30, "<30",
  max_mat_age < 35, "30-34",
  max_mat_age >= 35, "35+"
)]
iq[, older35 := as.integer(max_mat_age >= 35)]

for (outcome in c("wisc_fsiq", "sb_iq")) {
  outcome_label <- if (outcome == "wisc_fsiq") "WISC FSIQ" else "SB IQ"
  for (group in c("All", "<30", "30-34", "35+")) {
    sub <- if (group == "All") iq else iq[fert_group == group]
    f <- as.formula(paste(outcome, "~ family_size_cap + factor(sex) + factor(race)"))
    model <- feols(f, data = sub, vcov = "hetero")
    results[[length(results) + 1L]] <- tidy_term(
      model, "family_size_cap", paste0("Family-size slope: ", group), outcome_label
    )
  }

  f_int <- as.formula(paste(outcome,
    "~ family_size_cap * older35 + factor(sex) + factor(race)"))
  m_int <- feols(f_int, data = iq, vcov = "hetero")
  results[[length(results) + 1L]] <- tidy_term(
    m_int, "family_size_cap:older35", "Family size x age 35+", outcome_label
  )

  f_ses <- as.formula(paste(outcome,
    "~ family_size_cap * older35 + income + sei_decimal + educ_yrs + factor(sex) + factor(race)"))
  m_ses <- feols(f_ses, data = iq, vcov = "hetero")
  results[[length(results) + 1L]] <- tidy_term(
    m_ses, "family_size_cap:older35", "Family size x age 35+, SES-adjusted", outcome_label
  )

  for (race_value in c(1, 2)) {
    race_label <- if (race_value == 1) "White" else "Black"
    f_race <- as.formula(paste(outcome,
      "~ family_size_cap * older35 + factor(sex)"))
    m_race <- feols(f_race, data = iq[race == race_value], vcov = "hetero")
    results[[length(results) + 1L]] <- tidy_term(
      m_race, "family_size_cap:older35",
      paste0("Family size x age 35+: ", race_label), outcome_label
    )
  }
}

fertility_cells <- iq[!is.na(wisc_fsiq), .(
  mean_iq = mean(wisc_fsiq),
  std_error = sd(wisc_fsiq) / sqrt(.N),
  n = .N
), by = .(fert_group, family_size_cap)][order(fert_group, family_size_cap)]
fwrite(fertility_cells, "prior_livebirths_fertility_cells.csv")

# -----------------------------------------------------------------------------
# Paternal age: clustered sibling comparisons, with and without birth order
# -----------------------------------------------------------------------------
d[father_age %in% c(0, 99), father_age := NA_real_]
d[father_age < 12 | father_age > 70, father_age := NA_real_]

for (outcome in c("wisc_fsiq", "sb_iq")) {
  outcome_label <- if (outcome == "wisc_fsiq") "WISC FSIQ" else "SB IQ"
  f1 <- as.formula(paste(outcome, "~ father_age | mother_id"))
  f2 <- as.formula(paste(outcome, "~ father_age + birth_order | mother_id"))
  m1 <- feols(f1, data = d, vcov = ~mother_id)
  m2 <- feols(f2, data = d, vcov = ~mother_id)
  results[[length(results) + 1L]] <- tidy_term(
    m1, "father_age", "Paternal age, mother FE", outcome_label
  )
  results[[length(results) + 1L]] <- tidy_term(
    m2, "father_age", "Paternal age + birth order, mother FE", outcome_label
  )
}

m_pat_ols <- feols(
  wisc_fsiq_z ~ father_age + maternal_age + factor(race) + educ_yrs +
    sei_decimal + factor(sex) + birth_order + factor(institution),
  data = d, vcov = "hetero"
)
results[[length(results) + 1L]] <- tidy_term(
  m_pat_ols, "father_age", "Paternal age, fully adjusted OLS", "WISC FSIQ (SD)"
)

# -----------------------------------------------------------------------------
# SES Mundlak/FE decomposition with mother-clustered FE uncertainty
# -----------------------------------------------------------------------------
sib <- d[!is.na(wisc_fsiq) & !is.na(mother_id) & race %in% c(1, 2)]
sib[, n_tested := .N, by = mother_id]
sib <- sib[n_tested >= 2]

ses_vars <- c("income", "sei_decimal", "housing_density", "educ_yrs")
ses_labels <- c("Family income", "SEI (decimal)", "Housing density", "Education (years)")
ses_output <- list()
for (i in seq_along(ses_vars)) {
  variable <- ses_vars[i]
  sub <- copy(sib[!is.na(get(variable))])
  sub[, fam_mean := mean(get(variable)), by = mother_id]
  sub[, ses_dev := get(variable) - fam_mean]
  wf_sd <- sd(sub$ses_dev)

  mundlak <- feols(
    wisc_fsiq ~ ses_dev + fam_mean + factor(sex) + birth_order,
    data = sub, vcov = "hetero"
  )
  fe_formula <- as.formula(paste(
    "wisc_fsiq ~", variable, "+ factor(sex) + birth_order | mother_id"
  ))
  fe_model <- feols(fe_formula, data = sub, vcov = ~mother_id)
  ols_formula <- as.formula(paste(
    "wisc_fsiq ~", variable, "+ factor(sex) + birth_order"
  ))
  ols_model <- feols(ols_formula, data = sub, vcov = "hetero")

  ses_output[[i]] <- data.table(
    indicator = ses_labels[i],
    between_b = coef(mundlak)["fam_mean"],
    between_se = se(mundlak)["fam_mean"],
    within_b = coef(fe_model)[variable],
    within_se = se(fe_model)[variable],
    ols_b = coef(ols_model)[variable],
    ols_se = se(ols_model)[variable],
    within_sd = wf_sd,
    n = nobs(fe_model),
    families = uniqueN(sub$mother_id)
  )
}
ses_output <- rbindlist(ses_output)
fwrite(ses_output, "prior_livebirths_ses_decomposition.csv")

# -----------------------------------------------------------------------------
# Sibling-death decomposition and descriptive cells
# -----------------------------------------------------------------------------
raw_deaths <- fread(
  "../clean/cppvar_all_columns.csv",
  select = c("case_id", "v48_deaths_total_number_prior"),
  colClasses = list(character = "case_id"),
  strip.white = FALSE
)
raw_deaths[, case_id := canonicalize_cpp_case_id(case_id, strict = TRUE)]
raw_deaths[v48_deaths_total_number_prior == 88, v48_deaths_total_number_prior := 0]
raw_deaths[v48_deaths_total_number_prior == 99, v48_deaths_total_number_prior := NA]
death_data <- merge(d, raw_deaths, by = "case_id", all.x = TRUE)
death_data[, prior_dead := v48_deaths_total_number_prior]
death_data[, prior_surviving := pmax(prior_preg - prior_dead, 0)]
death_data[, biological_bo := prior_preg + 1L]
death_iq <- death_data[
  !is.na(wisc_fsiq) & !is.na(prior_dead) & race %in% c(1, 2)
]

m_death_ols <- feols(
  wisc_fsiq ~ prior_surviving + prior_dead + factor(sex) + factor(race) + maternal_age,
  data = death_iq, vcov = "hetero"
)
m_death_fe <- feols(
  wisc_fsiq ~ prior_surviving + prior_dead + factor(sex) | mother_id,
  data = death_iq, vcov = ~mother_id
)
for (term in c("prior_surviving", "prior_dead")) {
  results[[length(results) + 1L]] <- tidy_term(
    m_death_ols, term, "Sibling-death decomposition, OLS"
  )
  results[[length(results) + 1L]] <- tidy_term(
    m_death_fe, term, "Sibling-death decomposition, mother FE"
  )
}

death_cells <- death_iq[biological_bo %in% 1:5 & prior_dead %in% 0:3, .(
  mean_iq = mean(wisc_fsiq),
  n = .N
), by = .(biological_bo, prior_dead)][order(biological_bo, prior_dead)]
fwrite(death_cells, "prior_livebirths_death_cells.csv")

results <- rbindlist(results, fill = TRUE)
fwrite(results, "prior_livebirths_correction_estimates.csv")

cat("Wrote prior_livebirths correction audit outputs.\n")
print(results)
cat("\nSES decomposition:\n")
print(ses_output)
