library(data.table)

d <- as.data.table(readRDS("prepared_data.rds"))
raw <- fread("../clean/cppvar_all_columns.csv",
             select = c("case_id", "v48_deaths_total_number_prior"))
raw[, case_id := sprintf("%09d", as.integer(case_id))]
d <- merge(d, raw, by = "case_id", all.x = TRUE)
d[v48_deaths_total_number_prior == 88, v48_deaths_total_number_prior := 0L]
d[v48_deaths_total_number_prior == 99, v48_deaths_total_number_prior := NA_integer_]
d[, prior_dead := v48_deaths_total_number_prior]
d[, biological_bo := prior_preg]
d[, effective_bo := pmax(biological_bo - prior_dead, 0)]

bw <- d[race %in% c(1, 2) & !is.na(wisc_fsiq) & !is.na(prior_dead)]

# ---- 1. Compute means and SEs for both BO types ----
bio_tab <- bw[biological_bo <= 7, .(mean_iq = mean(wisc_fsiq),
              se_iq = sd(wisc_fsiq) / sqrt(.N), n = .N), by = .(bo = biological_bo)]
bio_tab[, type := "Biological"]

eff_tab <- bw[effective_bo <= 7, .(mean_iq = mean(wisc_fsiq),
              se_iq = sd(wisc_fsiq) / sqrt(.N), n = .N), by = .(bo = effective_bo)]
eff_tab[, type := "Effective"]

# ---- 2. Figure ----
pdf("fig_bio_vs_eff_bo.pdf", width = 8, height = 6)
par(mar = c(5, 5, 4, 2), family = "serif")

col_bio <- "#2C3E50"
col_eff <- "#8B1A1A"

y_lo <- 86
y_hi <- 102

plot(NULL, xlim = c(-0.3, 7.3), ylim = c(y_lo, y_hi),
     xaxt = "n", yaxt = "n", xlab = "", ylab = "", bty = "n")

# Gridlines
for (gy in seq(y_lo, y_hi, 2)) {
  segments(-0.3, gy, 7.3, gy, col = "grey85", lwd = 0.5)
}

# Offset
off <- 0.12

# Biological BO
with(bio_tab, {
  # CI
  arrows(bo - off, mean_iq - 1.96 * se_iq, bo - off, mean_iq + 1.96 * se_iq,
         code = 3, angle = 90, length = 0.04, col = col_bio, lwd = 1.5)
  # Points
  points(bo - off, mean_iq, pch = 16, col = col_bio, cex = 1.5)
  # Line
  lines(bo - off, mean_iq, col = col_bio, lwd = 2)
})

# Effective BO
with(eff_tab, {
  arrows(bo + off, mean_iq - 1.96 * se_iq, bo + off, mean_iq + 1.96 * se_iq,
         code = 3, angle = 90, length = 0.04, col = col_eff, lwd = 1.5)
  points(bo + off, mean_iq, pch = 17, col = col_eff, cex = 1.5)
  lines(bo + off, mean_iq, col = col_eff, lwd = 2)
})

# Axes
axis(1, at = 0:7, cex.axis = 0.95)
axis(2, at = seq(y_lo, y_hi, 2), las = 1, cex.axis = 0.9)
mtext("Birth Order", side = 1, line = 2.5, cex = 1)
mtext("Mean WISC FSIQ", side = 2, line = 3, cex = 1)

# Title
mtext("Biological vs. Effective Birth Order and IQ", side = 3, line = 2.2,
      cex = 1.2, font = 2)
mtext("Biological = all prior pregnancies; Effective = prior surviving siblings only",
      side = 3, line = 0.8, cex = 0.9, col = "gray40")

# Legend
legend("topright",
       legend = c(
         sprintf("Biological BO (all prior pregnancies)"),
         sprintf("Effective BO (living older siblings only)")
       ),
       col = c(col_bio, col_eff), pch = c(16, 17), lwd = 2, pt.cex = 1.3,
       cex = 0.85, bty = "o", bg = "white", box.col = "gray80")

dev.off()
cat("Saved: fig_bio_vs_eff_bo.pdf\n")

# ---- 3. Bio #2 with dead older sib vs Bio #1 (true firstborn) ----
cat("\n=== BIO #2 WITH DEAD OLDER SIB vs BIO #1 (TRUE FIRSTBORN) ===\n\n")

# Bio BO = 0, prior_dead = 0: true firstborn, first pregnancy
true_first <- bw[biological_bo == 0 & prior_dead == 0]

# Bio BO = 1, prior_dead = 1: second pregnancy, first child died
# (effective BO = 0 — they are the first LIVING child)
dead_older <- bw[biological_bo == 1 & prior_dead == 1]

# Bio BO = 1, prior_dead = 0: second pregnancy, first child alive
# (effective BO = 1 — they have one living older sibling)
alive_older <- bw[biological_bo == 1 & prior_dead == 0]

cat(sprintf("%-40s  %8s  %8s  %8s  %8s\n", "Group", "Mean IQ", "SD", "SE", "N"))
cat(paste(rep("-", 75), collapse=""), "\n")

for (grp in list(
  list("Bio #1, true firstborn (BO=0, dead=0)", true_first),
  list("Bio #2, older sib DIED (BO=1, dead=1)", dead_older),
  list("Bio #2, older sib ALIVE (BO=1, dead=0)", alive_older)
)) {
  sub <- grp[[2]]
  cat(sprintf("%-40s  %8.1f  %8.1f  %8.2f  %8d\n", grp[[1]],
              mean(sub$wisc_fsiq), sd(sub$wisc_fsiq),
              sd(sub$wisc_fsiq)/sqrt(nrow(sub)), nrow(sub)))
}

# Same for SB IQ
cat("\nSB IQ (age 4):\n")
for (grp in list(
  list("Bio #1, true firstborn", true_first[!is.na(sb_iq)]),
  list("Bio #2, older sib DIED", dead_older[!is.na(sb_iq)]),
  list("Bio #2, older sib ALIVE", alive_older[!is.na(sb_iq)])
)) {
  sub <- grp[[2]]
  if (nrow(sub) > 0)
    cat(sprintf("%-40s  %8.1f  %8d\n", grp[[1]], mean(sub$sb_iq), nrow(sub)))
}

# Broader: effective BO = 0 (all children who are first surviving child)
# vs true firstborn (BO = 0, dead = 0)
cat("\n=== ALL EFFECTIVE FIRSTBORNS ===\n")
eff_first <- bw[effective_bo == 0]
cat(sprintf("Effective BO = 0 (any bio BO, first surviving): IQ=%.1f (n=%d)\n",
            mean(eff_first$wisc_fsiq), nrow(eff_first)))
cat(sprintf("  Of these, bio BO = 0 (true first pregnancy):  IQ=%.1f (n=%d)\n",
            mean(eff_first[biological_bo == 0]$wisc_fsiq), nrow(eff_first[biological_bo == 0])))
cat(sprintf("  Of these, bio BO = 1 (1 prior death):         IQ=%.1f (n=%d)\n",
            mean(eff_first[biological_bo == 1]$wisc_fsiq), nrow(eff_first[biological_bo == 1])))
cat(sprintf("  Of these, bio BO = 2 (2 prior deaths):        IQ=%.1f (n=%d)\n",
            mean(eff_first[biological_bo == 2]$wisc_fsiq), nrow(eff_first[biological_bo == 2])))
cat(sprintf("  Of these, bio BO >= 3 (3+ prior deaths):      IQ=%.1f (n=%d)\n",
            mean(eff_first[biological_bo >= 3]$wisc_fsiq), nrow(eff_first[biological_bo >= 3])))

# By race
cat("\nBy race:\n")
for (r in c(1, 2)) {
  rl <- ifelse(r == 1, "White", "Black")
  t1 <- true_first[race == r]
  d1 <- dead_older[race == r]
  a1 <- alive_older[race == r]
  cat(sprintf("  %s: True 1st=%.1f (n=%d), Dead older=%.1f (n=%d), Alive older=%.1f (n=%d)\n",
              rl, mean(t1$wisc_fsiq), nrow(t1),
              mean(d1$wisc_fsiq), nrow(d1),
              mean(a1$wisc_fsiq), nrow(a1)))
}
