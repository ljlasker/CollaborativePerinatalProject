#!/usr/bin/env Rscript
# Fail-fast correction suite: rebuild the corrected analysis data, rerun every
# paper analysis whose sample/covariates depend on the corrected pregnancy
# history, and rerun the family-block pair-inference checks.

args <- commandArgs(trailingOnly = FALSE)
file_arg <- grep("^--file=", args, value = TRUE)
if (length(file_arg) == 1L) {
  setwd(dirname(normalizePath(sub("^--file=", "", file_arg))))
}

scripts <- c(
  "00_patch_structural_zero_fields.R",
  "01_data_prep.R",
  "prior_livebirths_correction_audit.R",
  "02_behavior_genetics.R",
  "02g_pair_reuse_sensitivity.R",
  "03_birth_order.R",
  "03d_flynn_cohort.R",
  "03e_flynn_cousin.R",
  "04_breastfeeding.R",
  "04b_breastfeeding_health.R",
  "05_birthweight.R",
  "06_maternal_age.R",
  "07_ses_gradients.R",
  "07b_ses_within_family.R",
  "07c_ses_developmental.R",
  "07d_resource_dilution.R",
  "08_smoking.R",
  "10_growth_iq.R",
  "17_replication_mcgrath.R",
  "19_replication_naeye.R",
  "build_death_dilution.R",
  "03b_birth_order_mi_expanded.R",
  "03c_birth_order_mi_with_only.R",
  "supplement_weighted.R",
  "phase3k_gestational_diabetes.R",
  "fig_forest_within_family.R",
  "fig_famsize_fertility.R",
  "fig_resource_dilution.R",
  "fig_ses_between_within.R",
  "fig_bio_vs_eff_bo.R",
  "summarize_prior_livebirths_impacts.R"
)

cat("--- Rerunning prior-livebirths-affected CPP paper analyses ---\n")
status <- data.frame(
  script = scripts,
  status = NA_character_,
  elapsed_seconds = NA_real_,
  stringsAsFactors = FALSE
)

for (i in seq_along(scripts)) {
  script <- scripts[[i]]
  cat(sprintf("\n>>> Running %s <<<\n", script))
  started <- Sys.time()
  tryCatch({
    source(script, local = new.env())
    status$status[[i]] <- "completed"
  }, error = function(error) {
    status$status[[i]] <- "failed"
    status$elapsed_seconds[[i]] <- as.numeric(
      difftime(Sys.time(), started, units = "secs")
    )
    write.csv(status, "rerun_correction_status.csv", row.names = FALSE, na = "")
    stop(sprintf("ERROR in %s: %s", script, conditionMessage(error)), call. = FALSE)
  })
  elapsed <- as.numeric(difftime(Sys.time(), started, units = "secs"))
  status$elapsed_seconds[[i]] <- elapsed
  write.csv(status, "rerun_correction_status.csv", row.names = FALSE, na = "")
  cat(sprintf(">>> %s completed in %.1f seconds <<<\n", script, elapsed))
}

cat("\nAll affected analyses completed without errors.\n")
