#!/usr/bin/env Rscript
# Independent, fast validation of the completed correction rerun.

library(data.table)

status <- fread("rerun_correction_status.csv")
if (any(status$status != "completed") || anyDuplicated(status$script))
  stop("Correction suite status is incomplete or duplicated")

required_scripts <- c(
  "00_patch_structural_zero_fields.R", "01_data_prep.R",
  "prior_livebirths_correction_audit.R", "02_behavior_genetics.R",
  "02g_pair_reuse_sensitivity.R", "03_birth_order.R", "03d_flynn_cohort.R",
  "03e_flynn_cousin.R", "04_breastfeeding.R", "04b_breastfeeding_health.R",
  "05_birthweight.R", "06_maternal_age.R", "07_ses_gradients.R",
  "07b_ses_within_family.R", "07c_ses_developmental.R",
  "07d_resource_dilution.R", "08_smoking.R", "10_growth_iq.R",
  "17_replication_mcgrath.R", "19_replication_naeye.R",
  "build_death_dilution.R", "03b_birth_order_mi_expanded.R",
  "03c_birth_order_mi_with_only.R", "supplement_weighted.R",
  "phase3k_gestational_diabetes.R", "fig_forest_within_family.R",
  "fig_famsize_fertility.R", "fig_resource_dilution.R",
  "fig_ses_between_within.R", "fig_bio_vs_eff_bo.R",
  "summarize_prior_livebirths_impacts.R"
)
if (!setequal(status$script, required_scripts))
  stop("Correction suite status does not cover the declared script set")

patch <- fread("structural_zero_patch_audit.csv")
if (nrow(patch) != 22L || any(patch$cells_changed != 0L))
  stop("Structural-zero patch is not idempotent after the final rerun")

d <- as.data.table(readRDS("prepared_data.rds"))
if (nrow(d) != 53640L || anyDuplicated(d$case_id) ||
    any(nchar(d$case_id) != 9L) || any(d$mother_id != substr(d$case_id, 1L, 7L)))
  stop("Prepared-data row, ID, or mother-link assertion failed")

sample <- fread("prior_livebirths_sample_comparison.csv")
expected_change <- c(10899L, 10899L, 3957L, 1750L)
if (!identical(sample$change, expected_change))
  stop("Prior-livebirth sample changes differ from the audited values")

effects <- fread("prior_livebirths_effect_comparison.csv")
wisc_bo <- effects[analysis == "Birth order" & outcome == "WISC FSIQ"]
if (nrow(wisc_bo) != 1L || abs(wisc_bo$new_estimate - 0.032408800965215) > 1e-12 ||
    abs(wisc_bo$new_std_error - 0.00826826517842996) > 1e-12)
  stop("Corrected WISC birth-order estimate changed unexpectedly")

flynn <- fread("results_flynn_cohort.csv")
wisc_flynn <- flynn[outcome == "WISC FSIQ" &
  specification == "Mother FE + sex + live-birth order"]
if (nrow(wisc_flynn) != 1L || abs(wisc_flynn$estimate_sd_decade - 0.073542302001272) > 1e-12)
  stop("Corrected sibling Flynn estimate changed unexpectedly")

cousin <- fread("results_flynn_cousin.csv")
if (nrow(cousin) != 4L || any(cousin$extended_families < 1700L))
  stop("Cousin Flynn sensitivity output is incomplete")

pair_diag <- fread("results_pair_reuse_diagnostics.csv")
if (pair_diag[metric == "pair_rows", value] != 8622L ||
    pair_diag[metric == "unique_mothers", value] != 5724L)
  stop("Pair-reuse diagnostic counts changed unexpectedly")

cat(sprintf(
  "PASS: %d correction scripts completed; prepared N=%s; all final invariants hold.\n",
  nrow(status), format(nrow(d), big.mark = ",")
))
