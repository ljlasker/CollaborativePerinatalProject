#!/usr/bin/env Rscript
# Machine-readable pre/post comparison for the prior_livebirths correction.

library(data.table)

backup_dir <- "_prior_livebirths_backup_20260823"

extract_fixest <- function(model, term) {
  tab <- model$coeftable
  stopifnot(term %in% rownames(tab))
  list(
    estimate = unname(tab[term, "Estimate"]),
    std_error = unname(tab[term, "Std. Error"]),
    n = nobs(model),
    families = if (length(model$fixef_sizes)) unname(model$fixef_sizes[[1L]]) else NA_integer_
  )
}

get_model <- function(root, file, path) {
  object <- readRDS(file.path(root, file))
  for (name in path) object <- object[[name]]
  object
}

specs <- list(
  list("Birth order", "WISC FSIQ", "Mother FE", "results_birth_order.rds",
       c("fe_results", "wisc_fsiq_z", "fe"), "parity"),
  list("Birth order", "Stanford-Binet IQ", "Mother FE", "results_birth_order.rds",
       c("fe_results", "sb_iq_z", "fe"), "parity"),
  list("Breastfeeding", "WISC FSIQ", "Mother FE, all", "results_breastfeeding.rds",
       c("bf_results", "wisc_fsiq_z", "fe_all"), "bf_any"),
  list("Breastfeeding", "WISC FSIQ", "Mother FE, discordant", "results_breastfeeding.rds",
       c("bf_results", "wisc_fsiq_z", "fe_disc"), "bf_any"),
  list("Birth weight", "WISC FSIQ", "Mother FE", "results_birthweight.rds",
       c("bw_results", "wisc_fsiq_z", "fe"), "bw_100g"),
  list("Maternal age", "WISC FSIQ", "Mother FE + corrected rank", "results_maternal_age.rds",
       c("ma_results", "wisc_fsiq_z", "fe_par"), "maternal_age"),
  list("Maternal age", "WISC FSIQ", "Mother FE + corrected rank", "results_maternal_age.rds",
       c("ma_results", "wisc_fsiq_z", "fe_par"), "birth_order"),
  list("Prenatal smoking", "WISC FSIQ", "Mother FE", "results_smoking.rds",
       c("sm_results", "wisc_fsiq_z", "fe"), "smoker")
)

rows <- rbindlist(lapply(specs, function(spec) {
  old <- extract_fixest(get_model(backup_dir, spec[[4L]], spec[[5L]]), spec[[6L]])
  new <- extract_fixest(get_model(".", spec[[4L]], spec[[5L]]), spec[[6L]])
  data.table(
    analysis = spec[[1L]], outcome = spec[[2L]], specification = spec[[3L]],
    term = spec[[6L]], old_n = old$n, new_n = new$n,
    old_families = old$families, new_families = new$families,
    old_estimate = old$estimate, old_std_error = old$std_error,
    new_estimate = new$estimate, new_std_error = new$std_error,
    estimate_change = new$estimate - old$estimate
  )
}))

old_bo <- readRDS(file.path(backup_dir, "results_birth_order.rds"))
new_bo <- readRDS("results_birth_order.rds")
sample_summary <- data.table(
  quantity = c(
    "WISC observations with live-birth rank",
    "WISC observations at rank zero (firstborn)",
    "WISC mother-FE observations",
    "WISC mother-FE mothers"
  ),
  old = c(
    sum(old_bo$desc_table$n), old_bo$desc_table$n[1L],
    old_bo$fe_results$wisc_fsiq_z$fe$nobs,
    old_bo$fe_results$wisc_fsiq_z$fe$fixef_sizes[[1L]]
  ),
  corrected = c(
    sum(new_bo$desc_table$n), new_bo$desc_table$n[1L],
    new_bo$fe_results$wisc_fsiq_z$fe$nobs,
    new_bo$fe_results$wisc_fsiq_z$fe$fixef_sizes[[1L]]
  )
)
sample_summary[, change := corrected - old]

fwrite(rows, "prior_livebirths_effect_comparison.csv")
fwrite(sample_summary, "prior_livebirths_sample_comparison.csv")
print(rows)
print(sample_summary)
